package com.tdk.txm_java.dao;


import com.tdk.txm_java.domain.Qcc_ebp;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <h3>txm_java_0304</h3>
 * <p>作业单位代码维护</p>
 *
 * @author : Wang FengCai
 * @date : 2020-03-11 09:07
 **/
@Repository
public interface IQcc_ebpDao {
    /**
     * @Author Wang FengCai
     * @Description 增加
     * @Date  2020/3/11
     * @Time  上午 09:44
     * @Param
     * @return
     **/
    @Insert("insert into qcc_ebp(educate_type,workplace_code,dept_code,section_code,assistant_code,group_code,work_center,login_time,update_time,update_oid,update_program,login_oid) values" +
            "(#{educate_type},#{workplace_code},#{dept_code},#{section_code},#{assistant_code},#{group_code},#{work_center},now(),now(),#{update_oid},#{update_program},#{login_oid})")
    void save(Qcc_ebp qcc_ebp) throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 删除
     * @Date  2020/3/11
     * @Time  上午 09:48
     * @Param
     * @return
     **/
    @Delete("delete from qcc_ebp where id=#{id}")
    void deleteById(int id) throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 修改
     * @Date  2020/3/11
     * @Time  上午 09:50
     * @Param
     * @return
     **/
    @Update("update qcc_ebp set educate_type=#{educate_type},workplace_code=#{workplace_code},dept_code=#{dept_code},section_code=#{section_code},assistant_code=#{assistant_code},group_code=#{group_code},work_center=#{work_center},update_program=#{update_program},update_time=now(),update_oid=#{update_oid} where id=#{id}")
    void update(Qcc_ebp qcc_ebp) throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 查找所有
     * @Date  2020/3/11
     * @Time  上午 09:54
     * @Param
     * @return
     **/
    @Select("select * from qcc_ebp")
    Qcc_ebp findAll() throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 根据ID查询
     * @Date  2020/3/11
     * @Time  上午 09:55
     * @Param
     * @return
     **/
    @Select("select * from qcc_ebp where id=#{id}")
    Qcc_ebp findById(int id) throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 查询dept_code在数据库中是否存在？
     * @Date  2020/3/13
     * @Time  上午 09:38
     * @Param [deptCode]
     * @return java.lang.String
     **/
    @Select("select dept_code from qcc_ebp where dept_code=#{dept_code}  group by dept_code")
    String findByDeptC(String dept_code);

    /**
     * @Author Wang FengCai
     * @Description 根据部门代码和作业种类查询
     * @Date  2020/3/13
     * @Time  上午 10:15
     * @Param [eduTpy, depC]
     * @return com.tdk.txm_java.domain.Qcc_ebp
     **/
    @Select("select * from qcc_ebp qb inner join qcc_eap qa on qb.educate_type=qa.educate_type where dept_code = #{dept_code} and qb.educate_type=#{educate_type}")
    List<Qcc_ebp> findByEduTypAndDepC(@Param("educate_type") String eduTpy, @Param("dept_code") String depC);

    /**
     * @Author Wang FengCai
     * @Description 根据部门代码，作业种类，和单位代码查询
     * @Date  2020/3/13
     * @Time  下午 01:48
     * @Param [workplaceC, eduTyp, depC]
     * @return com.tdk.txm_java.domain.Qcc_ebp
     **/
    @Select("select * from qcc_ebp where workplace_code=#{workplace_code} and educate_type=#{educate_type} and dept_code=#{dept_code} ")
    Qcc_ebp findByWpCAndDeptCAndEduT(@Param("workplace_code") String workplaceC, @Param("educate_type") String eduTyp, @Param("dept_code") String depC);

    /**
     * @Author Wang FengCai
     * @Description 根据单位代码和作业种类查询
     * @Date  2020/3/19
     * @Time  上午 10:58
     * @Param [wpC, edT]
     * @return void
     **/
    @Select("select * from qcc_ebp where workplace_code=#{workplace_code} and educate_type=#{educate_type}")
    Qcc_ebp findByWpcAndEduT(@Param("workplace_code") String wpC, @Param("educate_type") String edT);

    /**
     * @Author Wang FengCai
     * @Description 根据作业种类查询
     * @Date  2020/4/2
     * @Time  下午 01:43
     * @Param [educate_type]
     * @return java.util.List<com.tdk.txm_java.domain.Qcc_ebp>
     **/
    @Select("select * from qcc_ebp where educate_type = #{educate_type}")
    List<Qcc_ebp> findByEduTyp(String educate_type);
}
