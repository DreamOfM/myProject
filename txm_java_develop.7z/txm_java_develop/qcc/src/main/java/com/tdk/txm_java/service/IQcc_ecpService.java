package com.tdk.txm_java.service;
import com.tdk.txm_java.domain.Qcc_eap;
import com.tdk.txm_java.domain.Qcc_ecp;

import java.util.List;

/**
 * <h3>txm_java_0304</h3>
 * <p>作業系統控制檔維護</p>
 *
 * @author : Yu Liqin
 * @date : 2020-03-11 09:58
 **/
public interface IQcc_ecpService {

    /**
     * @Author Yu Liqin
     * @Description 增加
     * @Date  2020/3/11
     * @Time  上午 09:59
     * @Param
     * @return
     **/
    void save(Qcc_ecp qcc_ecp) throws Exception;

    /**
     * @Author Yu Liqin
     * @Description 删除
     * @Date  2020/3/11
     * @Time  上午 10:01
     * @Param
     * @return
     **/
    void deleteById(int id)throws Exception;

    /**
     * @Author Yu Liqin
     * @Description 修改
     * @Date  2020/3/11
     * @Time  上午 10:01
     * @Param
     * @return
     **/
    void update(Qcc_ecp qcc_ecp)throws Exception;

    /**
     * @Author Yu Liqin
     * @Description 查询所有
     * @Date  2020/3/11
     * @Time  上午 10:02
     * @Param
     * @return
     **/
    Qcc_ecp findAll()throws Exception;

    /**
     * @Author Yu Liqin
     * @Description 根据ID查询
     * @Date  2020/3/11
     * @Time  上午 10:03
     * @Param
     * @return
     **/
    Qcc_ecp findById(int id)throws Exception;
    /**
     * @Author Yu Liqin
     * @Description 查询password_code在数据库中是否存在？
     * @Date  2020/3/13
     * @Time  上午 09:33
     * @Param [password_code]
     * @return void
     **/
    String findByPassC(String password_code) throws Exception;

    /**
     * @Author Yu Liqin
     * @Description 根据password_code查询
     * @Date  2020/3/13
     * @Time  上午 10:11
     * @Param [password_code]
     * @return com.tdk.txm_java.domain.Qcc_ecp
     **/
    List<Qcc_ecp> findByPassCode(String password_code) throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 根据password_code查询
     * @Date  2020/3/31
     * @Time  上午 08:35
     * @Param [password_code]
     * @return com.tdk.txm_java.domain.Qcc_ecp
     **/
    Qcc_ecp findByPassCode1(String password_code) throws Exception;

}
