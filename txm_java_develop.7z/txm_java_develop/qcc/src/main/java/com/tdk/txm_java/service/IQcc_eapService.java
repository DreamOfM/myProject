package com.tdk.txm_java.service;

import com.tdk.txm_java.domain.Qcc_eap;

import java.util.List;

/**
 * <h3>txm_java_0304</h3>
 * <p>受训作业职种维护</p>
 *
 * @author : Wang FengCai
 * @date : 2020-03-11 09:58
 **/
public interface IQcc_eapService {

    /**
     * @Author Wang FengCai
     * @Description 增加
     * @Date  2020/3/11
     * @Time  上午 09:59
     * @Param
     * @return
     **/
    void save(Qcc_eap qcc_eap) throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 删除
     * @Date  2020/3/11
     * @Time  上午 10:01
     * @Param
     * @return
     **/
    void deleteById(int id)throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 修改
     * @Date  2020/3/11
     * @Time  上午 10:01
     * @Param
     * @return
     **/
    void update(Qcc_eap qcc_eap)throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 查询所有
     * @Date  2020/3/11
     * @Time  上午 10:02
     * @Param
     * @return
     **/
    Qcc_eap findAll()throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 根据ID查询
     * @Date  2020/3/11
     * @Time  上午 10:03
     * @Param
     * @return
     **/
    Qcc_eap findById(int id)throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 根据作业种类进行查找
     * @Date  2020/3/11
     * @Time  上午 11:13
     * @Param
     * @return
     **/
    List<Qcc_eap> findByEduTyp(String educateType) throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 根据种类代码去数据库查询是否存在
     * @Date  2020/3/12
     * @Time  上午 11:55
     * @Param [educate_type]
     * @return boolean
     **/
    Qcc_eap findByEduTyp1(String educate_type);
}
