package com.tdk.txm_java.domain;
/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_1225</h3>
 * @ClassName<h4></h4>
 * @ToDo<p></p>
 * @date : 2020-01-07 16:00
 * @version:1.0
 **/
public class Qcc_getParmeter {
    private int id;
    private String educate_type1;
    private String educate_type2;
    private String workplace_code1;
    private String workplace_code2;
    private String employee_id;
    //上岗日期
    private String date_of_induction1;
    private String date_of_induction2;
    //技能实习
    private String skill_development1;
    private String skill_development2;
    //作业训练评定
    private String job_evaluation1;
    private String job_evaluation2;
    //制品知识1
    private String manufacture_lore_one1;
    private String manufacture_lore_one2;
    //制品知识2
    private String manufacture_lore_two1;
    private String manufacture_lore_two2;
    //作业标准1
    private String standard_work_one1;
    private String standard_work_one2;
    //作业标准2
    private String standard_work_two1;
    private String standard_work_two2;
    //理论教育1
    private String exoterica_educate_one1;
    private String exoterica_educate_one2;
    //理论教育2
    private String exoterica_educate_two1;
    private String exoterica_educate_two2;
    //合格牌号
    private String eligibility_no1;
    private String eligibility_no2;
    //合格牌收回狀態
    private String eligibility_status;
    //合格認定日
    private String confirm_date1;
    private String confirm_date2;
    //QA 經理承認
    private String qa_manager_confirm1;
    private String qa_manager_confirm2;
    //姓名
    private String mmdnam;
    //辞职日
    private String mmrsgn;
    //入社日
    private String mmhire;

    public Qcc_getParmeter() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEducate_type1() {

        return educate_type1;
    }

    public void setEducate_type1(String educate_type1) {
        if(educate_type1==null||"".equals(educate_type1)){
            educate_type1="0000";
        }
        this.educate_type1 = educate_type1;
    }

    public String getEducate_type2() {

        return educate_type2;
    }

    public void setEducate_type2(String educate_type2) {
        if(educate_type2==null||"".equals(educate_type2)){
            educate_type2="ZZZZ";
        }
        this.educate_type2 = educate_type2;
    }

    public String getWorkplace_code1() {

        return workplace_code1;
    }

    public void setWorkplace_code1(String workplace_code1) {
        if(workplace_code1==null||"".equals(workplace_code1)){
            workplace_code1="0000";
        }
        this.workplace_code1 = workplace_code1;
    }

    public String getWorkplace_code2() {

        return workplace_code2;
    }

    public void setWorkplace_code2(String workplace_code2) {
        if(workplace_code2==null||"".equals(workplace_code2)){
            workplace_code2="ZZZZ";
        }
        this.workplace_code2 = workplace_code2;
    }

    public String getEmployee_id() {
        return employee_id;
    }

    public void setEmployee_id(String employee_id) {
        this.employee_id = employee_id;
    }

    public String getDate_of_induction1() {
        return date_of_induction1;
    }

    public void setDate_of_induction1(String date_of_induction1) {
        if(date_of_induction1 == null||"".equals(date_of_induction1)){
            date_of_induction1 = "1899-12-30";
        }

        this.date_of_induction1 = date_of_induction1;
    }

    public String getDate_of_induction2() {
        return date_of_induction2;
    }

    public void setDate_of_induction2(String date_of_induction2) {
        if(date_of_induction2 == null||"".equals(date_of_induction2)){
            date_of_induction2 = "2999-12-30";
        }
        this.date_of_induction2 = date_of_induction2;
    }

    public String getSkill_development1() {

        return skill_development1;
    }

    public void setSkill_development1(String skill_development1) {
        if(skill_development1 == null||"".equals(skill_development1)){
            skill_development1 = "0";
        }
        this.skill_development1 = skill_development1;
    }

    public String getSkill_development2() {

        return skill_development2;
    }

    public void setSkill_development2(String skill_development2) {
        if(skill_development2 == null||"".equals(skill_development2)){
            skill_development2 = "12";
        }
        this.skill_development2 = skill_development2;
    }

    public String getJob_evaluation1() {

        return job_evaluation1;
    }

    public void setJob_evaluation1(String job_evaluation1) {
        if(job_evaluation1 == null||"".equals(job_evaluation1)){
            job_evaluation1 = "";
        }
        this.job_evaluation1 = job_evaluation1;
    }

    public String getJob_evaluation2() {

        return job_evaluation2;
    }

    public void setJob_evaluation2(String job_evaluation2) {
        if(job_evaluation2 == null||"".equals(job_evaluation2)){
            job_evaluation2 = "ZZZZ";
        }
        this.job_evaluation2 = job_evaluation2;
    }

    public String getManufacture_lore_one1() {

        return manufacture_lore_one1;
    }

    public void setManufacture_lore_one1(String manufacture_lore_one1) {
        if(manufacture_lore_one1 == null||"".equals(manufacture_lore_one1)){
            manufacture_lore_one1 = "0";
        }
        this.manufacture_lore_one1 = manufacture_lore_one1;
    }

    public String getManufacture_lore_one2() {

        return manufacture_lore_one2;
    }

    public void setManufacture_lore_one2(String manufacture_lore_one2) {
        if(manufacture_lore_one2 == null||"".equals(manufacture_lore_one2)){
            manufacture_lore_one2 = "9999";
        }
        this.manufacture_lore_one2 = manufacture_lore_one2;
    }

    public String getManufacture_lore_two1() {

        return manufacture_lore_two1;
    }

    public void setManufacture_lore_two1(String manufacture_lore_two1) {
        if(manufacture_lore_two1 == null||"".equals(manufacture_lore_two1)){
            manufacture_lore_two1 = "0";
        }
        this.manufacture_lore_two1 = manufacture_lore_two1;
    }

    public String getManufacture_lore_two2() {

        return manufacture_lore_two2;
    }

    public void setManufacture_lore_two2(String manufacture_lore_two2) {
        if(manufacture_lore_two2 == null||"".equals(manufacture_lore_two2)){
            manufacture_lore_two2 = "9999";
        }
        this.manufacture_lore_two2 = manufacture_lore_two2;
    }

    public String getStandard_work_one1() {

        return standard_work_one1;
    }

    public void setStandard_work_one1(String standard_work_one1) {
        if(standard_work_one1 == null||"".equals(standard_work_one1)){
            standard_work_one1 = "0";
        }
        this.standard_work_one1 = standard_work_one1;
    }

    public String getStandard_work_one2() {

        return standard_work_one2;
    }

    public void setStandard_work_one2(String standard_work_one2) {
        if(standard_work_one2 == null||"".equals(standard_work_one2)){
            standard_work_one2 = "9999";
        }
        this.standard_work_one2 = standard_work_one2;
    }

    public String getStandard_work_two1() {

        return standard_work_two1;
    }

    public void setStandard_work_two1(String standard_work_two1) {

        if(standard_work_two1 == null||"".equals(standard_work_two1)){
            standard_work_two1 = "0";
        }
        this.standard_work_two1 = standard_work_two1;
    }

    public String getStandard_work_two2() {

        return standard_work_two2;
    }

    public void setStandard_work_two2(String standard_work_two2) {
        if(standard_work_two2 == null||"".equals(standard_work_two2)){
            standard_work_two2 = "9999";
        }
        this.standard_work_two2 = standard_work_two2;
    }

    public String getExoterica_educate_one1() {

        return exoterica_educate_one1;
    }

    public void setExoterica_educate_one1(String exoterica_educate_one1) {
        if(exoterica_educate_one1 == null||"".equals(exoterica_educate_one1)){
            exoterica_educate_one1 = "0";
        }
        this.exoterica_educate_one1 = exoterica_educate_one1;
    }

    public String getExoterica_educate_one2() {

        return exoterica_educate_one2;
    }

    public void setExoterica_educate_one2(String exoterica_educate_one2) {
        if(exoterica_educate_one2 == null||"".equals(exoterica_educate_one2)){
            exoterica_educate_one2 = "9999";
        }
        this.exoterica_educate_one2 = exoterica_educate_one2;
    }

    public String getExoterica_educate_two1() {

        return exoterica_educate_two1;
    }

    public void setExoterica_educate_two1(String exoterica_educate_two1) {
        if(exoterica_educate_two1 == null||"".equals(exoterica_educate_two1)){
            exoterica_educate_two1 = "0";
        }
        this.exoterica_educate_two1 = exoterica_educate_two1;
    }

    public String getExoterica_educate_two2() {

        return exoterica_educate_two2;
    }

    public void setExoterica_educate_two2(String exoterica_educate_two2) {
        if(exoterica_educate_two2 == null||"".equals(exoterica_educate_two2)){
            exoterica_educate_two2 = "9999";
        }
        this.exoterica_educate_two2 = exoterica_educate_two2;
    }

    public String getEligibility_no1() {

        return eligibility_no1;
    }

    public void setEligibility_no1(String eligibility_no1) {
        if(eligibility_no1 == null||"".equals(eligibility_no1)){
            eligibility_no1 = "0";
        }
        this.eligibility_no1 = eligibility_no1;
    }

    public String getEligibility_no2() {

        return eligibility_no2;
    }

    public void setEligibility_no2(String eligibility_no2) {
        if(eligibility_no2 == null||"".equals(eligibility_no2)){
            eligibility_no2 = "9999";
        }
        this.eligibility_no2 = eligibility_no2;
    }

    public String getEligibility_status() {
        return eligibility_status;
    }

    public void setEligibility_status(String eligibility_status) {

        this.eligibility_status = eligibility_status;
    }

    public String getConfirm_date1() {

        return confirm_date1;
    }

    public void setConfirm_date1(String confirm_date1) {
        if(confirm_date1 == null||"".equals(confirm_date1)){
            confirm_date1 = "1899-12-30";
        }
        this.confirm_date1 = confirm_date1;
    }

    public String getConfirm_date2() {

        return confirm_date2;
    }

    public void setConfirm_date2(String confirm_date2) {
        if(confirm_date2 == null||"".equals(confirm_date2)){
            confirm_date2 = "2999-12-30";
        }
        this.confirm_date2 = confirm_date2;
    }

    public String getQa_manager_confirm1() {
        return qa_manager_confirm1;
    }

    public void setQa_manager_confirm1(String qa_manager_confirm1) {
        this.qa_manager_confirm1 = qa_manager_confirm1;
    }

    public String getQa_manager_confirm2() {
        return qa_manager_confirm2;
    }

    public void setQa_manager_confirm2(String qa_manager_confirm2) {
        this.qa_manager_confirm2 = qa_manager_confirm2;
    }

    public String getMmdnam() {
        return mmdnam;
    }

    public void setMmdnam(String mmdnam) {
        this.mmdnam = mmdnam;
    }

    public String getMmrsgn() {
        return mmrsgn;
    }

    public void setMmrsgn(String mmrsgn) {
        this.mmrsgn = mmrsgn;
    }

    public String getMmhire() {
        return mmhire;
    }

    public void setMmhire(String mmhire) {
        this.mmhire = mmhire;
    }

    @Override
    public String toString() {
        return "Qcc_getParmeter{" +
                "id=" + id +
                ", educate_type1='" + educate_type1 + '\'' +
                ", educate_type2='" + educate_type2 + '\'' +
                ", workplace_code1='" + workplace_code1 + '\'' +
                ", workplace_code2='" + workplace_code2 + '\'' +
                ", employee_id='" + employee_id + '\'' +
                ", date_of_induction1='" + date_of_induction1 + '\'' +
                ", date_of_induction2='" + date_of_induction2 + '\'' +
                ", skill_development1=" + skill_development1 +
                ", skill_development2=" + skill_development2 +
                ", job_evaluation1='" + job_evaluation1 + '\'' +
                ", job_evaluation2='" + job_evaluation2 + '\'' +
                ", manufature_lore_one1='" + manufacture_lore_one1 + '\'' +
                ", manufature_lore_one2='" + manufacture_lore_one2 + '\'' +
                ", manufature_lore_two1='" + manufacture_lore_two1 + '\'' +
                ", manufature_lore_two2='" + manufacture_lore_two2 + '\'' +
                ", standard_work_one1='" + standard_work_one1 + '\'' +
                ", standard_work_one2='" + standard_work_one2 + '\'' +
                ", standard_work_two1='" + standard_work_two1 + '\'' +
                ", standard_work_two2='" + standard_work_two2 + '\'' +
                ", exoterica_educate_one1='" + exoterica_educate_one1 + '\'' +
                ", exoterica_educate_one2='" + exoterica_educate_one2 + '\'' +
                ", exoterica_educate_two1='" + exoterica_educate_two1 + '\'' +
                ", exoterica_educate_two2='" + exoterica_educate_two2 + '\'' +
                ", eligibility_no1='" + eligibility_no1 + '\'' +
                ", eligibility_no2='" + eligibility_no2 + '\'' +
                ", eligibility_status='" + eligibility_status + '\'' +
                ", confirm_date1='" + confirm_date1 + '\'' +
                ", confirm_date2='" + confirm_date2 + '\'' +
                ", qa_manager_confirm1='" + qa_manager_confirm1 + '\'' +
                ", qa_manager_confirm2='" + qa_manager_confirm2 + '\'' +
                ", mmdnam='" + mmdnam + '\'' +
                ", mmrsgn='" + mmrsgn + '\'' +
                ", mmhire='" + mmhire + '\'' +
                '}';
    }
}
