package com.tdk.txm_java.service.impl;
import com.tdk.txm_java.dao.IQcc_ebpDao;
import com.tdk.txm_java.domain.Qcc_ebp;
import com.tdk.txm_java.service.IQcc_ebpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_0304</h3>
 * @ClassName<h4></h4>
 * @ToDo<p>受训作业职种维护</p>
 * @date : 2020-03-11 10:04
 * @version:1.0
 **/
@Service
@Transactional
public class Qcc_ebpServiceImpl implements IQcc_ebpService {
    @Autowired
    private IQcc_ebpDao iQccEbpDao;

    /**
     * @Author Wang FengCai
     * @Description 增加
     * @Date  2020/3/11
     * @Time  上午 10:05
     * @Param [qcc_eap]
     * @return void
     **/
    @Override
    public void save(Qcc_ebp qcc_ebp) throws Exception {
        // 小写转换成大写
        qcc_ebp.setEducate_type(qcc_ebp.getEducate_type().toUpperCase());
        qcc_ebp.setWorkplace_code(qcc_ebp.getWorkplace_code().toUpperCase());
        qcc_ebp.setDept_code(qcc_ebp.getDept_code().toUpperCase());
        iQccEbpDao.save(qcc_ebp);
    }

    /**
     * @Author Wang FengCai
     * @Description 删除
     * @Date  2020/3/11
     * @Time  上午 10:06
     * @Param [id]
     * @return void
     **/
    @Override
    public void deleteById(int id) throws Exception {
        iQccEbpDao.deleteById(id);
    }

    /**
     * @Author Wang FengCai
     * @Description 更新
     * @Date  2020/3/11
     * @Time  上午 10:06
     * @Param [qcc_ebp]
     * @return void
     **/
    @Override
    public void update(Qcc_ebp qcc_ebp) throws Exception {
        //TODO 小写转换成大写;
        qcc_ebp.setDept_code(qcc_ebp.getDept_code().toUpperCase());
        qcc_ebp.setWorkplace_code(qcc_ebp.getWorkplace_code().toUpperCase());
        qcc_ebp.setUpdate_oid(qcc_ebp.getUpdate_oid().toUpperCase());
        qcc_ebp.setEducate_type(qcc_ebp.getEducate_type().toUpperCase());
        qcc_ebp.setSection_code(qcc_ebp.getSection_code().toUpperCase());
        qcc_ebp.setAssistant_code(qcc_ebp.getAssistant_code().toUpperCase());
        qcc_ebp.setGroup_code(qcc_ebp.getGroup_code().toUpperCase());

        iQccEbpDao.update(qcc_ebp);
    }

    /**
     * @Author Wang FengCai
     * @Description 查找所有
     * @Date  2020/3/11
     * @Time  上午 10:06
     * @Param []
     * @return void
     **/
    @Override
    public Qcc_ebp findAll() throws Exception {
        return iQccEbpDao.findAll();
    }

    /**
     * @Author Wang FengCai
     * @Description 根据ID查询
     * @Date  2020/3/11
     * @Time  上午 10:06
     * @Param [id]
     * @return void
     **/
    @Override
    public Qcc_ebp findById(int id) throws Exception {
        return iQccEbpDao.findById(id);
    }

    /**
     * @Author Wang FengCai
     * @Description 查询dept_code在数库中是否存在
     * @Date  2020/3/13
     * @Time  上午 09:36
     * @Param [dept_code]
     * @return java.lang.String
     **/
    @Override
    public String findByDeptC(String dept_code) {
        //转换成大写
        dept_code.toUpperCase();
        return iQccEbpDao.findByDeptC(dept_code);
    }

    /**
     * @Author Wang FengCai
     * @Description 根据部门代码和作业种类查询
     * @Date  2020/3/13
     * @Time  上午 10:12
     * @Param [educateType, deptCode]
     * @return com.tdk.txm_java.domain.Qcc_ebp
     **/
    @Override
    public List<Qcc_ebp> findByEduTypAndDepC(String educateType, String deptCode) throws Exception {
        //转换大小写
        String eduTpy = educateType.toUpperCase();
        String depC = deptCode.toUpperCase();
        return iQccEbpDao.findByEduTypAndDepC(eduTpy,depC);
    }

    /**
     * @Author Wang FengCai
     * @Description 根据部门代码，作业种类，和单位代码查询
     * @Date  2020/3/13
     * @Time  下午 01:43
     * @Param [workplace_code, educate_type, dept_code]
     * @return com.tdk.txm_java.domain.Qcc_ebp
     **/
    @Override
    public Qcc_ebp findByWpCAndDeptCAndEduT(String workplace_code, String educate_type, String dept_code) {
        //转化大小写
        String workplaceC = workplace_code.toUpperCase();
        String eduTyp = educate_type.toUpperCase();
        String depC = dept_code.toUpperCase();
        return iQccEbpDao.findByWpCAndDeptCAndEduT(workplaceC,eduTyp,depC);
    }

    /**
     * @Author Wang FengCai
     * @Description 根据单位代码和作业种类查询
     * @Date  2020/3/19
     * @Time  上午 10:55
     * @Param [workplace_code, educate_type]
     * @return void
     **/
    @Override
    public Qcc_ebp findByWpCAndEduT(String workplace_code, String educate_type) {
        //转换成大写
        String wpC = workplace_code.toUpperCase();
        String edT = educate_type.toUpperCase();
        return iQccEbpDao.findByWpcAndEduT(wpC,edT);

    }

    /**
     * @Author Wang FengCai
     * @Description 根据作业种类查找
     * @Date  2020/4/2
     * @Time  下午 01:41
     * @Param [educate_type]
     * @return void
     **/
    @Override
    public List<Qcc_ebp> findByEduTyp(String educate_type) {
        educate_type.toUpperCase();
        return iQccEbpDao.findByEduTyp(educate_type);
    }

}
