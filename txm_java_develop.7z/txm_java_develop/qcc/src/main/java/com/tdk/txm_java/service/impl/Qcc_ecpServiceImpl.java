package com.tdk.txm_java.service.impl;
import com.tdk.txm_java.dao.IQcc_ecpDao;
import com.tdk.txm_java.domain.Qcc_ecp;
import com.tdk.txm_java.service.IQcc_ecpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_0304</h3>
 * @ClassName<h4></h4>
 * @ToDo<p>受训作业职种维护</p>
 * @date : 2020-03-11 10:04
 * @version:1.0
 **/
@Service
@Transactional
public class Qcc_ecpServiceImpl implements IQcc_ecpService {
    @Autowired
    private IQcc_ecpDao iQccEcpDao;

    /**
     * @Author Wang FengCai
     * @Description 增加
     * @Date  2020/3/11
     * @Time  上午 10:05
     * @Param [qcc_eap]
     * @return void
     **/
    @Override
    public void save(Qcc_ecp qcc_ecp) throws Exception {
        //TODO 小写转换成大写
        qcc_ecp.setEducate_type_from(qcc_ecp.getEducate_type_from().toUpperCase());
        qcc_ecp.setEducate_type_to(qcc_ecp.getEducate_type_to().toUpperCase());
        qcc_ecp.setWorkplace_code_from(qcc_ecp.getWorkplace_code_from().toUpperCase());
        qcc_ecp.setWorkplace_code_to(qcc_ecp.getWorkplace_code_to().toUpperCase());
        qcc_ecp.setPassword_code(qcc_ecp.getPassword_code().toUpperCase());
        iQccEcpDao.save(qcc_ecp);
    }

    /**
     * @Author Wang FengCai
     * @Description 删除
     * @Date  2020/3/11
     * @Time  上午 10:06
     * @Param [id]
     * @return void
     **/
    @Override
    public void deleteById(int id) throws Exception {
        iQccEcpDao.deleteById(id);
    }

    /**
     * @Author Wang FengCai
     * @Description 更新
     * @Date  2020/3/11
     * @Time  上午 10:06
     * @Param [qcc_ebp]
     * @return void
     **/
    @Override
    public void update(Qcc_ecp qcc_ecp) throws Exception {
        //TODO 小写转换成大写
        qcc_ecp.setEducate_type_from(qcc_ecp.getEducate_type_from().toUpperCase());
        qcc_ecp.setEducate_type_to(qcc_ecp.getEducate_type_to().toUpperCase());
        qcc_ecp.setWorkplace_code_from(qcc_ecp.getWorkplace_code_from().toUpperCase());
        qcc_ecp.setWorkplace_code_to(qcc_ecp.getWorkplace_code_to().toUpperCase());
        qcc_ecp.setUpdate_oid(qcc_ecp.getUpdate_oid().toUpperCase());
        qcc_ecp.setPassword_code(qcc_ecp.getPassword_code().toUpperCase());
        iQccEcpDao.update(qcc_ecp);
    }

    /**
     * @Author Wang FengCai
     * @Description 查找所有
     * @Date  2020/3/11
     * @Time  上午 10:06
     * @Param []
     * @return void
     **/
    @Override
    public Qcc_ecp findAll() throws Exception {
        return iQccEcpDao.findAll();
    }

    /**
     * @Author Wang FengCai
     * @Description 根据ID查询
     * @Date  2020/3/11
     * @Time  上午 10:06
     * @Param [id]
     * @return void
     **/
    @Override
    public Qcc_ecp findById(int id) throws Exception {
        return iQccEcpDao.findById(id);
    }

    /**
     * @Author Wang FengCai
     * @Description 查询dept_code在数库中是否存在
     * @Date  2020/3/13
     * @Time  上午 09:36
     * @Param [dept_code]
     * @return java.lang.String
     **/
    @Override
    public String findByPassC(String password_code) {
        //转换成大写
        String passwordCode = password_code.toUpperCase();
        return iQccEcpDao.findByPassC(passwordCode);
    }

    /**
     * @Author Wang FengCai
     * @Description 根据password_code查询
     * @Date  2020/3/13
     * @Time  上午 10:12
     * @Param [educateType, deptCode]
     * @return com.tdk.txm_java.domain.Qcc_ebp
     **/
    @Override
    public List<Qcc_ecp> findByPassCode(String password_code) throws Exception {
        //转换大小写
        String passwordCode = password_code.toUpperCase();
        return iQccEcpDao.findByPassCode(passwordCode);
    }

    /**
     * @Author Wang FengCai
     * @Description  根据password_code查询
     * @Date  2020/3/31
     * @Time  上午 08:35
     * @Param [password_code]
     * @return com.tdk.txm_java.domain.Qcc_ecp
     **/
    @Override
    public Qcc_ecp findByPassCode1(String password_code) throws Exception {
        //转换大小写
        String passwordCode = password_code.toUpperCase();
        return iQccEcpDao.findByPassCode1(passwordCode);
    }


}
