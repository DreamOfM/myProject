package com.tdk.txm_java.service.impl;

import com.tdk.txm_java.dao.IQcc_master_inspectionDao;
import com.tdk.txm_java.domain.Com_employee;
import com.tdk.txm_java.domain.Qcc_getParmeter2MasterInspection;
import com.tdk.txm_java.domain.Qcc_master_inspection;
import com.tdk.txm_java.service.ICom_employeeService;
import com.tdk.txm_java.service.IQcc_eapService;
import com.tdk.txm_java.service.IQcc_ebpService;
import com.tdk.txm_java.service.IQcc_master_inspectionService;
import com.tdk.txm_java.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_20200325</h3>
 * @ClassName<h4></h4>
 * @ToDo<p></p>
 * @date : 2020-04-08 20:07
 * @version:1.0
 **/
@Service
@Transactional
public class Qcc_master_inspectionServiceImpl implements IQcc_master_inspectionService {
    @Autowired
    IQcc_master_inspectionDao iQccMasterInspectionDao;
    @Autowired
    IQcc_master_inspectionService iQccMasterInspectionService;
    @Autowired
    ICom_employeeService iCom_employeeService;
    @Autowired
    IQcc_eapService iQccEapService;
    @Autowired
    IQcc_ebpService iQccEbpService;

    @Override
    public void update(Qcc_master_inspection qccMasterInspection) throws Exception {
        //转换成大写
        if(qccMasterInspection.getCharacte()!=null&&!"".equals(qccMasterInspection.getCharacte())){
            qccMasterInspection.setCharacte(qccMasterInspection.getCharacte().toUpperCase());
        }

        if(qccMasterInspection.getColor_sensitivity()!=null&&!"".equals(qccMasterInspection.getColor_sensitivity())){
            qccMasterInspection.setColor_sensitivity(qccMasterInspection.getColor_sensitivity().toUpperCase());
        }

        if(qccMasterInspection.getSpecial()!=null&&!"".equals(qccMasterInspection.getSpecial())){
            qccMasterInspection.setSpecial(qccMasterInspection.getSpecial().toUpperCase());
        }

        if(qccMasterInspection.getEducate_type()!=null&&!"".equals(qccMasterInspection.getEducate_type())){
            qccMasterInspection.setEducate_type(qccMasterInspection.getEducate_type().toUpperCase());
        }

        if(qccMasterInspection.getWorkplace_code()!=null&&!"".equals(qccMasterInspection.getWorkplace_code())){
            qccMasterInspection.setWorkplace_code(qccMasterInspection.getWorkplace_code().toUpperCase());
        }

        if(qccMasterInspection.getJob_evaluation()!=null&&!"".equals(qccMasterInspection.getJob_evaluation())){
            qccMasterInspection.setJob_evaluation(qccMasterInspection.getJob_evaluation().toUpperCase());
        }

        if (qccMasterInspection.getCharacte() != null && !"".equals(qccMasterInspection.getCharacte())) {
            qccMasterInspection.setCharacte(qccMasterInspection.getCharacte().toUpperCase());
        }
        if ("ZC05".equals(qccMasterInspection.getEducate_type().toUpperCase()) || "ZC06".equals(qccMasterInspection.getEducate_type().toUpperCase())) {
            qccMasterInspection.setCharacte("");
            qccMasterInspection.setSure(0);
            qccMasterInspection.setFlexibitity(0);
        }
        iQccMasterInspectionDao.update(qccMasterInspection);
    }

    @Override
    public void save(Qcc_master_inspection qccMasterInspection) throws Exception {
        //转换成大写
        qccMasterInspection.setEducate_type(qccMasterInspection.getEducate_type().toUpperCase());
        qccMasterInspection.setWorkplace_code(qccMasterInspection.getWorkplace_code().toUpperCase());
        qccMasterInspection.setCharacte(qccMasterInspection.getCharacte().toUpperCase());
        qccMasterInspection.setColor_sensitivity(qccMasterInspection.getColor_sensitivity().toUpperCase());
        qccMasterInspection.setSpecial(qccMasterInspection.getSpecial().toUpperCase());
        qccMasterInspection.getLogin_oid();
        qccMasterInspection.getUpdate_program();
        qccMasterInspection.getUpdate_oid();
        iQccMasterInspectionDao.save(qccMasterInspection);
    }

    @Override
    public List<Qcc_master_inspection> findAll() throws Exception {

        return iQccMasterInspectionDao.findAll();
    }

    @Override
    public Qcc_master_inspection findById(int id) throws Exception {
        return iQccMasterInspectionDao.findById(id);
    }

    @Override
    public List<Qcc_master_inspection> findByEduTypAndWorC(String educateType, String workplaceCode) throws Exception {
        //转换成大写
        educateType.toUpperCase();
        workplaceCode.toUpperCase();

        return iQccMasterInspectionDao.findByEduTypAndWorC(educateType, workplaceCode);
    }

    @Override
    public Qcc_master_inspection findByEmpI(String employee_id) {
        return iQccMasterInspectionDao.findByEmpI(employee_id);
    }

    /**
     * @Author Wang FengCai
     * @Description 查找--人员检出力有效性评估
     * @Date 2020/4/15
     * @Time 上午 10:23
     **/
    @Override
    public List<Qcc_master_inspection> findByEduTypAndWorC2IdenAss(String educateType, String workplaceCode) {
        //转换成大写
        educateType.toUpperCase();
        workplaceCode.toUpperCase();
        return iQccMasterInspectionDao.findByEduTypAndWorC2IdenAss(educateType, workplaceCode);
    }

    @Override
    public void deleteById(int id) throws Exception {
        iQccMasterInspectionDao.deleteById(id);
    }

    /**
     * @Author Yu Liqin
     * @Description //视力有效性定期评估
     * @Date 2020/4/13
     * @Time 下午 04:52
     **/
    @Override
    public List<Qcc_master_inspection> findByEduTypAndWorPQa(String educateType, String workplaceCode) {
        educateType.toUpperCase();
        workplaceCode.toUpperCase();
        return iQccMasterInspectionDao.findByEduTypAndWorPQa(educateType, workplaceCode);
    }

    /**
     * @Author Yu Liqin
     * @Description 查找--试作实习合格维护
     * @Date 2020/4/16
     * @Time 下午 06:53
     **/
    @Override
    public List<Qcc_master_inspection> findByEduTypAndWorBo(String educateType, String workplaceCode) {
        educateType.toUpperCase();
        workplaceCode.toUpperCase();
        return iQccMasterInspectionDao.findByEduTypAndWorBo(educateType, workplaceCode);
    }

    /**
     * @Author Wang FengCai
     * @Description //星期天执行  辞职日,调离日超过一个月自动删除
     * @Date 2020/4/24
     * @Time 上午 11:10
     **/
    @Override
    public void deleteTask2Main() throws Exception {
        //查询表中所有的数据
        List<Qcc_master_inspection> qccMasterInspections = iQccMasterInspectionService.findAll();
        if (qccMasterInspections.size() > 0) {
        //遍历取回的list集合取出工号，到人事主档中查询，若查询不到则删除
        for (Qcc_master_inspection qccMasterIn : qccMasterInspections) {
            //判断
            String  employee_id = qccMasterIn.getEmployee_id();
            int id = qccMasterIn.getId();
            Com_employee comEmployee = iCom_employeeService.findByEmployee_id(employee_id);
            if (comEmployee != null&&!"".equals(comEmployee)) {
                //查询到结果，判断离职日是否为'0'
                if (!"0".equals(comEmployee.getMmrsgn()) && comEmployee.getMmrsgn() != null) {
                    //调用业务层的删除方法将辞职日,调离日超过一个月的删除
                    iQccMasterInspectionService.deleteById(id);
                } else  {
                    Qcc_master_inspection qccMasterIns = iQccMasterInspectionService.findById(id);
                    //若离职日为'0',则判断这笔数据对应的调离日是否为空？不为空，且时间已经超过一个月，删除
                    if (qccMasterIns!= null&&!"".equals(qccMasterIn)) {
                        Date date_of_departure = qccMasterIns.getDate_of_departure();
                        if(date_of_departure!=null){
                            //取出调离日，计算是否大于一个月
                            if (DateUtils.calculateDays(date_of_departure) > 30) {
                                //调用业务层的删除方法将辞职日,调离日超过一个月的删除
                                iQccMasterInspectionService.deleteById(id);
                                System.out.println("。。。。。。。。。。。。。。已删除。。。。。。。。。。。。。");
                            }
                        }
                    }
                }
            } else if (iCom_employeeService.findByEmployee_id(employee_id) == null || "".equals(iCom_employeeService.findByEmployee_id(employee_id))) {
                //该工号在人事主档不存在，删除该工号对应的数据
                iQccMasterInspectionService.deleteById(id);
            }
        }
    }
    }

    /**
     * @param employeeId
     * @Author Wang FengCai
     * @Description 根据工号查询作业种类
     * @Date 2020/5/6
     * @Time 下午 07:43
     */
    @Override
    public List<Qcc_master_inspection> findByEmpId(String employeeId) {
        employeeId.toUpperCase();
        return iQccMasterInspectionDao.findByEmpId(employeeId);
    }

    /**
     * @param employeeId
     * @Author Wang FengCai
     * @Description 根据工号查询作业种类(调离日期为空)
     * @Date 2020/5/6
     * @Time 下午 07:43
     */
    @Override
    public List<Qcc_master_inspection> findByEmpId2Add(String employeeId) {
        employeeId.toUpperCase();
        return iQccMasterInspectionDao.findByEmpId2Add(employeeId);
    }

    /**
     * @param employeeId
     * @Author Wang FengCai
     * @Description 检查人员基本资料新增时  检查需要调用的方法
     * @Date 2020/5/7
     * @Time 下午 07:43
     */
//    @Override
//    public List<Qcc_master_inspection> findByEmpId2Add(String employeeId) {
//        return iQccMasterInspectionDao.findByEmpId2Add(employeeId);
//    }

    /**
     * @param employee_id
     * @param educateType
     * @param workplaceCode
     * @Author Wang FengCai
     * @Description 根据工号，作业种类和单位代码去查询
     * @Date 2020/5/7
     * @Time 下午 07:10
     */
    @Override
    public Qcc_master_inspection findByEmpIdAndEduAndWorC(String employee_id, String educateType, String workplaceCode) {
        employee_id.toUpperCase();
        educateType.toUpperCase();
        workplaceCode.toUpperCase();

        return iQccMasterInspectionDao.findByEmpIdAndEduAndWorC(employee_id,educateType,workplaceCode);
    }

    /**
     * @param employee_id
     * @param educateType
     * @Author Wang FengCai
     * @Description 根据工号，作业种类查询
     * @Date 2020/5/7
     * @Time 下午 07:10
     */
    @Override
    public List<Qcc_master_inspection> findByEmpIdAndEduTyp(String employee_id, String educateType) {
        return iQccMasterInspectionDao.findByEmpIdAndEduTyp(employee_id, educateType);
    }

    /**
     * @Author Wang FengCai
     * @Description 检查人员报表
     * @Date  2020/5/14
     * @Time  上午 11:50
     **/
    @Override
    public List<Qcc_master_inspection> findDatapool2MasterInspection(Qcc_getParmeter2MasterInspection qccGetParmeter2MasterInspection) {
        //将取回的结果遍历并进行处理
        for (Qcc_master_inspection qccMasterInspection : iQccMasterInspectionDao.findDatapool2MasterInspection( qccGetParmeter2MasterInspection)) {
            String employeeId = qccMasterInspection.getEmployee_id();
            if (employeeId != null && !"".equals(employeeId)) {
                try {
                    Com_employee comEmployee = iCom_employeeService.findByEmployee_id(employeeId);
                    if ( comEmployee != null && !"".equals( comEmployee)) {
                        if ( comEmployee.getMmdnam() != null && !"".equals( comEmployee.getMmdnam())) {
                            qccMasterInspection.setChinese_name( comEmployee.getMmdnam());
                        }
                        //取出人事主档中的人事股别
                        if ( comEmployee.getMmdept() != null && !"".equals( comEmployee.getMmdept())) {
                            qccMasterInspection.setMmdept( comEmployee.getMmdept());
                        }
                        //取出职种代码对应的职种名称
                        if ( comEmployee.getMmp3nm() != null && !"".equals( comEmployee.getMmp3nm())) {
                            qccMasterInspection.setMmp3nm( comEmployee.getMmp3nm());
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

        return iQccMasterInspectionDao.findDatapool2MasterInspection( qccGetParmeter2MasterInspection);
    }


}
