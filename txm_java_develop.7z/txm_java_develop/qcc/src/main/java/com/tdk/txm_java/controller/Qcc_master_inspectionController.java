package com.tdk.txm_java.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tdk.txm_java.domain.*;
import com.tdk.txm_java.service.ICom_employeeService;
import com.tdk.txm_java.service.IQcc_eapService;
import com.tdk.txm_java.service.IQcc_ebpService;
import com.tdk.txm_java.service.IQcc_master_inspectionService;
import com.tdk.txm_java.utils.JsonUtil;
import com.tdk.txm_java.utils.DateUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.lang.reflect.InvocationTargetException;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_20200325</h3>
 * @ClassName<h4></h4>
 * @ToDo<p>检查人员主档</p>
 * @date : 2020-04-09 09:01
 * @version:1.0
 **/
@Controller
@RequestMapping("/qcc_master_inspection")
public class Qcc_master_inspectionController {
    @Autowired
    private IQcc_master_inspectionService iQccMasterInspectionService;
    @Autowired
    private ICom_employeeService iCom_employeeService;
    @Autowired
    private IQcc_ebpService iQccEbpService;
    @Autowired
    private IQcc_eapService iQccEapService;

    /**
     * @Author Wang FengCai
     * @Description 人员检查主档保存--检查
     * @Date 2020/4/10
     **/
    @RequestMapping("/check01.do")
    public void check01(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        List<Qcc_master_inspection> qcc1Mains = new ArrayList<Qcc_master_inspection>();
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //字段date_to_now(到岗日)，chinese_name(姓名)，date_of_resignation(辞职日)
                if ("date_to_now".equals(name1) || "del".equals(name1) || "num".equals(name1) || "chinese_name".equals(name1) || "date_of_resignation".equals(name1)) {
                    //不做处理
                } else {
                    //将每一个key值对应的一组值放到数组里去
                    String[] vals = (String[]) map.get(name1);
                    c = vals.length;
                    //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                    hashMap.put(name1, vals[b]);
                }
            }

            //判断若工号为空则不继续执行
            if (hashMap.get("employee_id") == null || "".equals(hashMap.get("employee_id"))) {
                b++;
                if (b == c) {
                    break;
                }
                continue;
            } else {
                //记录当前行
                String errLine = String.valueOf(b);
                //取出作业种类和单位代码
                String educate_type = hashMap.get("educate_type").toUpperCase();
                String workplace_code = hashMap.get("workplace_code").toUpperCase();
                //取出工号
                String empId = hashMap.get("employee_id");
                //TODO 去主檔查詢
                iQccMasterInspectionService.findByEmpIdAndEduAndWorC(educate_type, workplace_code, empId);
                if (hashMap.get("date_of_induction") == null || "".equals(hashMap.get("date_of_induction"))) {
                    //到岗日期不能为空
                    info.setFlag(false);
                    errorList.add("date_of_induction" + errLine);
                    info.setErrorMsg("到岗日期不能为空,请确认");
                }
                //不是特例（特例不为Y）的
                if (!"Y".equals(hashMap.get("special").toUpperCase())) {
                    //若作业种类不是ZC05 ZC06 ZC09的
                    if (!"ZC05".equals(educate_type) && !"ZC06".equals(educate_type) && !"ZC09".equals(educate_type)) {
                        if (hashMap.get("color_sensitivity") == null || "".equals(hashMap.get("color_sensitivity"))) {
                            info.setFlag(false);
                            errorList.add("color_sensitivity" + errLine);
                            info.setErrorMsg("色觉不能为空,请确认");
                        } else {
                            //色觉不为空且只能是N或者Y
                            if (!"N".equals(hashMap.get("color_sensitivity").toUpperCase()) && !"Y".equals(hashMap.get("color_sensitivity").toUpperCase())) {
                                info.setFlag(false);
                                errorList.add("color_sensitivity" + errLine);
                                info.setErrorMsg("色觉只能是N或者Y,请确认");
                            }
                        }
                        if (hashMap.get("characte") == null || "".equals(hashMap.get("characte"))) {
                            info.setFlag(false);
                            errorList.add("characte" + errLine);
                            info.setErrorMsg("性向不能为空,请确认");
                        } else {
                            //性向只能是B B+ A A+
                            if (!"B".equals(hashMap.get("characte").toUpperCase()) && !"B+".equals(hashMap.get("characte").toUpperCase()) && !"A".equals(hashMap.get("characte").toUpperCase()) && !"A+".equals(hashMap.get("characte").toUpperCase())&& !"A-".equals(hashMap.get("characte").toUpperCase())) {
                                info.setFlag(false);
                                errorList.add("characte" + errLine);
                                info.setErrorMsg("性向只能是B B+ A A+ A-,请确认");

                            }
                        }
                        if ("".equals(hashMap.get("sure")) || hashMap.get("sure") == null) {
                            info.setFlag(false);
                            errorList.add("sure" + errLine);
                            info.setErrorMsg("SURE不能为空,请确认");
                        } else {
                            //URSE要大于等80
                            if (Integer.parseInt(hashMap.get("sure")) < 80) {
                                info.setFlag(false);
                                errorList.add("sure" + errLine);
                                info.setErrorMsg("SURE要大于等于80,请确认");

                            }
                        }
                        if ("".equals(hashMap.get("flexibitity")) || hashMap.get("flexibitity") == null) {
                            info.setFlag(false);
                            errorList.add("flexibitity" + errLine);
                            info.setErrorMsg("适性不能为空,请确认");
                        } else {
                            //适性要大于等于70
                            if (Integer.parseInt(hashMap.get("flexibitity")) < 70) {
                                info.setFlag(false);
                                errorList.add("flexibitity" + errLine);
                                info.setErrorMsg("适性要大于等于70,请确认");
                            }
                        }
                        // 非特例	视力必须大于等于0.8
                        if ("".equals(hashMap.get("eye_left")) || hashMap.get("eye_left") == null) {
                            info.setFlag(false);
                            errorList.add("eye_left" + errLine);
                            info.setErrorMsg("非特例视力必须输入,请确认");
                        } else {
                            //视力必须大于等于0.8
                            if (hashMap.get("eye_left").compareTo("0.8") < 0) {
                                info.setFlag(false);
                                errorList.add("eye_left" + errLine);
                                info.setErrorMsg("非特例视力必须大于等于0.8,请确认");
                            }
                        }

                        if ("".equals(hashMap.get("eye_right")) || hashMap.get("eye_right") == null) {
                            info.setFlag(false);
                            errorList.add("eye_right" + errLine);
                            info.setErrorMsg("非特例视力必须输入,请确认");
                        } else {
                            //视力必须大于等于0.8
                            if (hashMap.get("eye_right").compareTo("0.8") < 0) {
                                info.setFlag(false);
                                errorList.add("eye_right" + errLine);
                                info.setErrorMsg("非特例视力必须大于等于0.8,请确认");
                            }
                        }
                    } else if ("ZC05".equals(educate_type) || "ZC06".equals(educate_type) || "ZC09".equals(educate_type)) {
                        // 非特例且ZC05 或者 ZC06 ZC09
                        if (!"".equals(hashMap.get("eye_left")) && hashMap.get("eye_right") != null) {
                            //有输入值的话视力必须大于等于0.8
                            if (hashMap.get("eye_left").compareTo("0.8") < 0) {
                                info.setFlag(false);
                                errorList.add("eye_left" + errLine);
                                info.setErrorMsg("非特例视力必须大于等于0.8,请确认");
                            }
                        }
                        if (!"".equals(hashMap.get("eye_right")) && hashMap.get("eye_right") != null) {
                            //有输入值的话视力必须大于等于0.8
                            if (Double.valueOf(hashMap.get("eye_right").trim()) < 0.8) {
                                info.setFlag(false);
                                errorList.add("eye_right" + errLine);
                                info.setErrorMsg("非特例视力必须大于等于0.8,请确认");
                            }
                        }
                    }
                    if (!"Y".equals(hashMap.get("special").toUpperCase()) && !"".equals(hashMap.get("special")) && hashMap.get("special") != null) {
                        //特例只允许维护Y或者空
                        info.setFlag(false);
                        errorList.add("special" + errLine);
                        info.setErrorMsg("特例只允许维护Y或者空,请确认");
                    }
                }
                b++;
                if (b == c) {
                    break;
                }
            }
        }
        info.setErrorList(errorList);
        info.setData(qcc1Mains);
        //响应数据
        JsonUtil.writeValue(info,response);
    }

    /**
     * @Author Wang FengCai
     * @Description //TODO 主档查询结果页面，上岗日期修改问题
     * @Date 2020/4/10
     **/
    @RequestMapping("/check02.do")
    public void check02(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<Qcc_master_inspection> qcc_masterinspections = new ArrayList<Qcc_master_inspection>();
        String date_to_now = null;
        //计算离岗 年/天
        //将字符串类型的日期转换成日期格式
        //取出到岗日
        String date_of_induction = request.getParameter("date_of_induction");
        //将字符串转换成LocalDate类型
        LocalDate localDate = LocalDate.parse(date_of_induction, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        //取出离岗日，若离岗日不为空，则使用离岗日期计算
        if (request.getParameter("date_of_departure") != null && "".equals(request.getParameter("date_of_departure"))) {
            String date_of_departure = request.getParameter("date_of_departure");
            //将离职日期字符串转换成LocalDate类型
            LocalDate regDate = LocalDate.parse(date_of_departure, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            //调用工具类的方法计算时间
            Period period = DateUtils.calculateTimeDifferenceByPeriod2(regDate, localDate);
            //调用工具类中时间显示的方法
            date_to_now = DateUtils.dateDisplay(period);
            //插入数据
            info.setData(date_to_now);
        } else {
            //计算时间差
            Period p = DateUtils.calculateTimeDifferenceByPeriod(localDate);
            //调用工具类中时间显示的方法
            date_to_now = DateUtils.dateDisplay(p);
            //插入数据
            info.setData(date_to_now);
        }
        // 响应数据
        JsonUtil.writeValue(info,response);
    }

    /**
     * @Author Wang FengCai
     * @Description 验证工号是否存在？以及是否可以新增
     * @Date 2020/4/12
     **/
    @RequestMapping("/check03.do")
    public void check03(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        //取出工号
        String employee_id = request.getParameter("employee_id");
        String educateType = request.getParameter("educate_type");
        String workplaceCode = request.getParameter("workplace_code");
        //去人事主档查找数据
        Com_employee comEmployee = iCom_employeeService.findByEmployee_id(employee_id);
        if (comEmployee == null || "".equals(comEmployee)) {
            info.setErrorMsg("工号在人事主档不存在，请确认");
            info.setFlag(false);
        } else {
            //判断员工是否离职？离职则不新增
            if (comEmployee.getMmrsgn() != null && !"0".equals(comEmployee.getMmrsgn())) {
                info.setErrorMsg("该员工已离职，无法新增，请重新确认");
                info.setFlag(false);
            } else {
                //如果这个用户是新人从未维护过的或者之前维护过现在不在岗的，则可以直接新增
                List<Qcc_master_inspection> qccMasterInspectionList = iQccMasterInspectionService.findByEmpId2Add(employee_id);
                if (qccMasterInspectionList.isEmpty()) {
                    info.setData(comEmployee);
                    info.setFlag(true);
                } else {
                    //因为取回的值是list,所以进行遍历
                    for (Qcc_master_inspection qccMasterInspection : qccMasterInspectionList) {
                        //取出作业种类 判断是否为ZC05 OR ZC06 OR ZC09
                        if ("ZC05".equals(qccMasterInspection.getEducate_type()) || "ZC06".equals(qccMasterInspection.getEducate_type()) || "ZC09".equals(qccMasterInspection.getEducate_type())) {
                            //判断前端传回来的作业种类
                            if ("ZC05".equals(educateType.toUpperCase()) || "ZC06".equals(educateType.toUpperCase()) || "ZC09".equals(educateType.toUpperCase())) {
                                //判断在数据表中是否存在？
                                Qcc_master_inspection qccMasterInspection1 = iQccMasterInspectionService.findByEmpIdAndEduAndWorC(employee_id, educateType, workplaceCode);
                                if (qccMasterInspection1 != null && !"".equals(qccMasterInspection1)) {
                                    info.setErrorMsg("该工号已维护且未调离，不能新增");
                                    info.setFlag(false);
                                } else {
                                    info.setData(comEmployee);
                                    info.setFlag(true);
                                }
                            } else {
                                info.setErrorMsg("该工号已维护且未调离，不能新增");
                                info.setFlag(false);
                            }
                        } else {
                            //判断数据库中是否已存在？
                            if (iQccMasterInspectionService.findByEmpI(employee_id) == null || "".equals(iQccMasterInspectionService.findByEmpI(employee_id))) {
                                info.setData(comEmployee);
                                info.setFlag(true);
                            } else {
                                info.setFlag(false);
                                info.setErrorMsg("该工号已维护且未调离，不能新增");
                            }
                        }
                    }
                }
            }
        }
        // 响应数据
        JsonUtil.writeValue(info,response);
    }

    /**
     * @Author Wang FengCai
     * @Description 实习成绩输入--检查
     * @Date 2020/4/13
     **/
    @RequestMapping("/check04.do")
    public void check04(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        List<Qcc_master_inspection> qcc1Mains = new ArrayList<Qcc_master_inspection>();
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //字段date_to_now(到岗日)，chinese_name(姓名)，date_of_resignation(辞职日)
                if ("date_to_now".equals(name1) || "del".equals(name1) || "num".equals(name1) || "chinese_name".equals(name1) || "date_of_resignation".equals(name1)) {
                    //不做处理
                } else {
                    //将每一个key值对应的一组值放到数组里去
                    String[] vals = (String[]) map.get(name1);
                    c = vals.length;
                    //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                    hashMap.put(name1, vals[b]);
                }
            }
            //记录当前记录行
            String errLine = String.valueOf(b);
            if (hashMap.get("skill_development") == null || "".equals(hashMap.get("skill_development"))) {
                b++;
                if (b == c) {
                    break;
                }
                continue;
            }
            //根据ID取出数据库的值
            Qcc_master_inspection qccMasterInspection = iQccMasterInspectionService.findById(Integer.parseInt(hashMap.get("id")));
            String date_to_now = null;
            //计算离岗 年/天
            //将字符串类型的日期转换成日期格式
            //取出到岗日
            Date date_of_induction = qccMasterInspection.getDate_of_induction();
            //将Date转换成LocalDate类型
            LocalDate localDate = DateUtils.date2LocalDate(date_of_induction);
            //取出离岗日，若离岗日不为空，则使用离岗日期计算
            if (qccMasterInspection.getDate_of_departure() != null && !"".equals(qccMasterInspection.getDate_of_departure())) {
                //将离职日期字符串转换成LocalDate类型
                LocalDate regDate = DateUtils.date2LocalDate(qccMasterInspection.getDate_of_departure());
                //调用工具类的方法计算时间
                Period period = DateUtils.calculateTimeDifferenceByPeriod2(regDate, localDate);
                //作业种类不是ZC05 ZC06 ZC09,到岗天数小于30，技能实习不能输入
                if (!"ZC09".equals(qccMasterInspection.getEducate_type()) && !"ZC05".equals(qccMasterInspection.getEducate_type()) && !"ZC06".equals(qccMasterInspection.getEducate_type()) && (period.getMonths() == 0 && period.getYears() == 0 && period.getDays() < 30)) {
                    info.setFlag(false);
                    errorList.add("skill_development" + errLine);
                    info.setErrorMsg("到岗天数小于30，技能实习不能输入,请确认");
                }
                //作业种类是ZC05 ZC06 ZC09,到岗天数小于7，技能实习不能输入
                if ("ZC05".equals(qccMasterInspection.getEducate_type()) || "ZC06".equals(qccMasterInspection.getEducate_type()) || !"ZC09".equals(qccMasterInspection.getEducate_type())) {
                    if (period.getYears() == 0 && period.getMonths() == 0 && period.getDays() < 7) {
                        //判断离岗日是否小于7
                        info.setFlag(false);
                        errorList.add("skill_development" + errLine);
                        info.setErrorMsg("到岗天数小于7，技能实习不能输入,请确认");
                    }
                }
            } else {
                //计算时间差
                Period period = DateUtils.calculateTimeDifferenceByPeriod(localDate);
                //作业种类不是ZC05 ZC06 ZC09,到岗天数小于30，技能实习不能输入
                if (!"ZC05".equals(qccMasterInspection.getEducate_type()) && !"ZC06".equals(qccMasterInspection.getEducate_type()) && !"ZC09".equals(qccMasterInspection.getEducate_type())) {
                    //判断离岗日是否大于30
                    if (period.getMonths() == 0 && period.getYears() == 0 && period.getDays() < 30) {
                        info.setFlag(false);
                        errorList.add("skill_development" + errLine);
                        info.setErrorMsg("到岗天数小于30，技能实习不能输入,请确认");
                    }
                }
                //作业种类是ZC05 ZC06 ZC09,到岗天数小于7，技能实习不能输入
                if (("ZC05".equals(qccMasterInspection.getEducate_type()) || "ZC09".equals(qccMasterInspection.getEducate_type()) || "ZC06".equals(qccMasterInspection.getEducate_type())) && (period.getYears() == 0 && period.getMonths() == 0 && period.getDays() < 7)) {
                    //判断离岗日是否大于7
                    info.setFlag(false);
                    errorList.add("skill_development" + errLine);
                    info.setErrorMsg("到岗天数小于7，技能实习不能输入,请确认");
                }
            }
            //取出GRR判断
            if (hashMap.get("field1").trim() != null && !"".equals(hashMap.get("field1").trim())) {
                if (!"999".equals(hashMap.get("field1").trim()) && !"OK".equals(hashMap.get("field1").trim().toUpperCase())) {
                    info.setFlag(false);
                    errorList.add("field1" + errLine);
                    info.setErrorMsg("GRR只能输入999/OK或者空,请确认");
                }
            }
            b++;
            if (b == c) {
                break;
            }
        }
        info.setErrorList(errorList);
        info.setData(qcc1Mains);
        // 响应数据
        JsonUtil.writeValue(info,response);
    }

    /**
     * @Author Wang FengCai
     * @Description 检出力有效性评估-工号检查
     * @Date 2020/4/15
     **/
    @RequestMapping("/check05.do")
    public void check05(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        //取出认定者工号
        String employee_id = request.getParameter("qc_confirm_of_1");
        //去人事主档查找数据
        Com_employee comEmployee = iCom_employeeService.findByEmployee_id(employee_id);
        if (comEmployee != null && !"".equals(comEmployee)) {
            info.setData(comEmployee);
            info.setFlag(true);
        } else {
            info.setErrorMsg("工号在人事主档不存在，请确认");
            info.setFlag(false);
        }
        // 响应数据
        JsonUtil.writeValue(info,response);
    }

    /**
     * @Author Wang FengCai
     * @Description 检出力有效性评估--update检查
     * @Date 2020/4/15
     **/
    @RequestMapping("/check06.do")
    public void check06(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        List<Qcc_master_inspection> qcc1Mains = new ArrayList<Qcc_master_inspection>();
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //字段date_to_now(到岗日)，chinese_name(姓名)，date_of_resignation(辞职日)
                if ("date_to_now".equals(name1) || "del".equals(name1) || "num".equals(name1) || "chinese_name".equals(name1) || "date_of_resignation".equals(name1)) {
                    //不做处理
                } else {
                    //将每一个key值对应的一组值放到数组里去
                    String[] vals = (String[]) map.get(name1);
                    c = vals.length;
                    //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                    hashMap.put(name1, vals[b]);
                }
            }
            //记录当前记录行
            String errLine = String.valueOf(b);
            if (!"Y".equals(hashMap.get("special").toUpperCase())) {
                if (!StringUtils.isEmpty(hashMap.get("identify_ability_1"))) {
                    //特性不是Y的成绩必须大于等于85
                    if (hashMap.get("identify_ability_1") != null && Integer.parseInt(hashMap.get("identify_ability_1")) < 85) {
                        info.setFlag(false);
                        errorList.add("identify_ability_1" + errLine);
                        info.setErrorMsg("特性不是Y的成绩必须大于等于85,请确认");
                    }
                }

            }
            b++;
            if (b == c) {
                break;
            }
        }
        info.setErrorList(errorList);
        info.setData(qcc1Mains);

        // 响应数据
        JsonUtil.writeValue(info,response);
    }

    @RequestMapping("/check2EmpId.do")
    public void check2EmpId(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        //取出工号
        String employee_id = request.getParameter("employee_id");
        //判断工号在qcc_edp中是否存在？
        List<Qcc_master_inspection> qccMasterInspectionList = iQccMasterInspectionService.findByEmpId(employee_id);
        if (qccMasterInspectionList == null || qccMasterInspectionList.isEmpty()) {
            info.setErrorMsg("该工号不存在，请确认");
            info.setFlag(false);
        }
        // 响应数据
        JsonUtil.writeValue(info,response);
    }

    /**
     * @Description: 数据传到新增页面
     */
    @RequestMapping("/add.do")
    public ModelAndView add(String educate_type, String workplace_code, String password_code, String workplaceCodeChineseName, String educateTypeChineseName) {
        ModelAndView mv = new ModelAndView();
        mv.setViewName("qcc-master-inspection-add");
        mv.addObject("educate_type", educate_type);
        mv.addObject("workplace_code", workplace_code);
        mv.addObject("password_code", password_code);
        mv.addObject("workplaceCodeChineseName", workplaceCodeChineseName);
        mv.addObject("educateTypeChineseName", educateTypeChineseName);
        System.out.println("1" + mv);
        return mv;
    }

    /**
     * @Author Wang FengCai
     * @Description 查找
     * @Date 2020/4/9
     **/
    @RequestMapping("/findByEduTypAndWorC.do")
    protected ModelAndView findByEduTypAndWorC(HttpServletRequest request, @RequestParam(value = "pn", defaultValue = "1") Integer pn, @RequestParam(value = "PageSize", defaultValue = "10") Integer ps) throws Exception {
        //引入PageHelper分页插件
        PageHelper.startPage(pn, ps);
        //取回前端传回的数据
        String educateType = request.getParameter("educate_type");
        String workplaceCode = request.getParameter("workplace_code");
        //调用业务层的方法查询
        List<Qcc_master_inspection> qcc1Mains = iQccMasterInspectionService.findByEduTypAndWorC(educateType, workplaceCode);
        if(qcc1Mains.size()>0){
            //将取回的结果遍历
            for (Qcc_master_inspection qcc1Main : qcc1Mains) {
                //取出每个对象中的工号
                String emId = qcc1Main.getEmployee_id();
                //根据工号去人事主档查询
                Com_employee comEmployee = iCom_employeeService.findByEmployee_id(emId);
                if (comEmployee == null || "".equals(comEmployee)) {
                    //该工号在人事主档已不存在
                    System.out.println(emId + "该工号在人事主档已不存在");
                } else {
                    //取出离职日，做处理
                    if (comEmployee.getMmrsgn() == null || "0".equals(comEmployee.getMmrsgn())) {
                        String mh = "";
                        qcc1Main.setMmrsgn(mh);
                    } else {
                        //在字符串中插入"-"
                        StringBuffer mh = new StringBuffer(comEmployee.getMmrsgn());
                        mh.insert(6, "-");
                        mh.insert(4, "-");
                        //转换格式
                        qcc1Main.setMmrsgn(mh.toString());
                    }
                    //取出姓名，并处理
                    String mdn = comEmployee.getMmdnam();
                    qcc1Main.setMmdnam(mdn);
                }

                //将Date类型转换成LocalDate
                LocalDate date_of_induction = DateUtils.date2LocalDate(qcc1Main.getDate_of_induction());
                //取出调离日期并判断
                Date date_of_departure = qcc1Main.getDate_of_departure();
                //计算离岗 年/天
                Period p;
                String date_to_now = null;
                //判断调离日是否为空
                if (qcc1Main.getDate_of_departure() != null && !"".equals(qcc1Main.getDate_of_departure())) {
                    //到岗年/天=调离日-到岗日
                    p = DateUtils.calculateTimeDifferenceByPeriod2(DateUtils.date2LocalDate(date_of_departure), date_of_induction);
                } else {
                    //调用工具类的方法计算时间差
                    p = DateUtils.calculateTimeDifferenceByPeriod(date_of_induction);
                }
                //调用工具类 判断 年/天的显示格式
                date_to_now = DateUtils.dateDisplay(p);
                //重新放到对象中去
                qcc1Main.setDate_to_now(date_to_now);
                //调用方法查询作业种类和单位代码对应的中文信息
                //去eap中取出作业种类和单位代码对应的中文信息
                Qcc_eap qccEap = iQccEapService.findByEduTyp1(qcc1Main.getEducate_type());
                if (qccEap.getEducate_type_name() != null) {
                    qcc1Main.setEducateTypeChineseName(qccEap.getEducate_type_name());
                }
                Qcc_ebp qccEbp = iQccEbpService.findByWpCAndEduT(qcc1Main.getWorkplace_code(), qcc1Main.getEducate_type());
                if (qccEbp != null) {
                    //去ebp中取出单位代码对应的信息
                    qcc1Main.setWorkplaceCodeChineseName(qccEbp.getSection_code() + " " + qccEbp.getAssistant_code() + " " + qccEbp.getGroup_code() + " " + qccEbp.getWork_center());
                }
            }
        }
        //创建视图对象
        ModelAndView mv = new ModelAndView();
        PageInfo page = new PageInfo(qcc1Mains, ps);
        //使用addObject()设置需要返回的值
        mv.addObject("qcc1Mains", qcc1Mains);
        mv.addObject("pageInfo", page);
        //通过setViewName()方法跳转到指定的页面
        mv.setViewName("qcc-master-inspection-list");
        return mv;
    }


    public void findEducateTypeChineseNameAndWorkplaceCodeChineseName(Qcc_master_inspection qcc1Main) {
        //去eap中取出作业种类和单位代码对应的中文信息
        Qcc_eap qccEap = iQccEapService.findByEduTyp1(qcc1Main.getEducate_type());
        if (qccEap.getEducate_type_name() != null) {
            qcc1Main.setEducateTypeChineseName(qccEap.getEducate_type_name());
        }
        Qcc_ebp qccEbp = iQccEbpService.findByWpCAndEduT(qcc1Main.getWorkplace_code(), qcc1Main.getEducate_type());
        if (qccEbp != null) {
            //去ebp中取出单位代码对应的信息
            qcc1Main.setWorkplaceCodeChineseName(qccEbp.getSection_code() + " " + qccEbp.getAssistant_code() + " " + qccEbp.getGroup_code() + " " + qccEbp.getWork_center());
        }
    }

    /**
     * @Author Wang FengCai
     * @Description 根据工号查询作业种类等信息
     * @Date 2020/5/6
     **/
    @RequestMapping("/findByEmpId.do")
    protected ModelAndView findByEmpId(HttpServletRequest request) throws Exception {
        String employeeId = request.getParameter("employee_id");
        //调用业务层的方法查询
        List<Qcc_master_inspection> qcc1Mains = iQccMasterInspectionService.findByEmpId(employeeId);
        //将取回的结果遍历
        for (Qcc_master_inspection qcc1Main : qcc1Mains) {
            //根据工号去人事主档查询
            Com_employee comEmployee = iCom_employeeService.findByEmployee_id(qcc1Main.getEmployee_id());
            if (comEmployee != null && !"".equals(comEmployee)) {
                //取出离职日，做处理
                if (comEmployee.getMmrsgn() == null || "0".equals(comEmployee.getMmrsgn())) {
                    String mh = "";
                    qcc1Main.setMmrsgn(mh);
                } else {
                    //在字符串中插入"-"
                    StringBuffer mh = new StringBuffer(comEmployee.getMmrsgn());
                    mh.insert(6, "-");
                    mh.insert(4, "-");
                    //转换格式
                    qcc1Main.setMmrsgn(mh.toString());
                }
                //取出姓名，并处理
                String mdn = comEmployee.getMmdnam();
                qcc1Main.setMmdnam(mdn);
            }
            //将Date类型转换成LocalDate
            LocalDate date_of_induction = DateUtils.date2LocalDate(qcc1Main.getDate_of_induction());
            //取出调离日期并判断
            Date date_of_departure = qcc1Main.getDate_of_departure();
            //计算离岗 年/天
            Period p;
            String date_to_now = null;
            //判断调离日是否为空
            if (qcc1Main.getDate_of_departure() != null && !"".equals(qcc1Main.getDate_of_departure())) {
                //到岗年/天=调离日-到岗日
                p = DateUtils.calculateTimeDifferenceByPeriod2(DateUtils.date2LocalDate(date_of_departure), date_of_induction);
            } else {
                //调用工具类的方法计算时间差
                p = DateUtils.calculateTimeDifferenceByPeriod(date_of_induction);
            }
            //调用工具类 判断 年/天的显示格式
            date_to_now = DateUtils.dateDisplay(p);
            //重新放到对象中去
            qcc1Main.setDate_to_now(date_to_now);
        }
        //创建视图对象
        ModelAndView mv = new ModelAndView();
        //使用addObject()设置需要返回的值
        mv.addObject("qcc1Mains", qcc1Mains);
        //通过setViewName()方法跳转到指定的页面
        mv.setViewName("qcc-master-data-list");
        return mv;
    }

    /**
     * @Author Wang FengCai
     * @Description 查找--实习成绩维护
     * @Date 2020/4/9
     **/
    @RequestMapping("/findByEduTypAndWorC2IS.do")
    protected ModelAndView findByEduTypAndWorC2InternScore(HttpServletRequest request, @RequestParam(value = "pn", defaultValue = "1") Integer pn, @RequestParam(value = "PageSize", defaultValue = "10") Integer ps) throws Exception {
        //引入PageHelper分页插件
        PageHelper.startPage(pn, ps);
        //取回前端传回的数据
        String educateType = request.getParameter("educate_type");
        String workplaceCode = request.getParameter("workplace_code");
        //调用业务层的方法查询
        List<Qcc_master_inspection> qcc1Mains = iQccMasterInspectionService.findByEduTypAndWorC(educateType, workplaceCode);
        if (qcc1Mains != null && qcc1Mains.size() != 0) {
            //将取回的结果遍历
            for (Qcc_master_inspection qcc1Main : qcc1Mains) {
                //取出每个对象中的工号
                String emId = qcc1Main.getEmployee_id();
                //根据工号去人事主档查询
                Com_employee comEmployee = iCom_employeeService.findByEmployee_id(emId);
                if (comEmployee != null && !"".equals(comEmployee)) {
                    //取出离职日，做处理
                    if (comEmployee.getMmrsgn() == null || "".equals(comEmployee.getMmrsgn()) || "0".equals(comEmployee.getMmrsgn())) {
                        String mh = "";
                        qcc1Main.setMmrsgn(mh);
                    } else {
                        //在字符串中插入"-"
                        StringBuffer mh1 = new StringBuffer(comEmployee.getMmrsgn());
                        mh1.insert(6, "-");
                        mh1.insert(4, "-");
                        //转换格式
                        qcc1Main.setMmrsgn(mh1.toString());
                    }

                    //取出姓名，并处理
                    String mdn = comEmployee.getMmdnam();
                    qcc1Main.setMmdnam(mdn);
                    //转换格式
                    LocalDate date_of_induction = DateUtils.date2LocalDate(qcc1Main.getDate_of_induction());
                    //取出调离日期并判断
                    Date date_of_departure = qcc1Main.getDate_of_departure();
                    //计算离岗 年/天
                    Period p;
                    String date_to_now = null;
                    //判断调离日是否为空
                    if (qcc1Main.getDate_of_departure() != null && !"".equals(qcc1Main.getDate_of_departure())) {
                        //到岗年/天=调离日-到岗日
                        p = DateUtils.calculateTimeDifferenceByPeriod2(DateUtils.date2LocalDate(date_of_departure), date_of_induction);
                    } else {
                        //调用工具类的方法计算时间差
                        p = DateUtils.calculateTimeDifferenceByPeriod(date_of_induction);
                    }
                    //调用工具类 判断 年/天的显示格式
                    date_to_now = DateUtils.dateDisplay(p);
                    //重新放到对象中去
                    qcc1Main.setDate_to_now(date_to_now);
                }
                //调用方法查询单位代码和作业种类对应的中文信息
                findEducateTypeChineseNameAndWorkplaceCodeChineseName(qcc1Main);
            }
        }
        //创建视图对象
        ModelAndView mv = new ModelAndView();
        PageInfo page = new PageInfo(qcc1Mains, ps);
        //使用addObject()设置需要返回的值
        mv.addObject("qcc1Mains", qcc1Mains);
        mv.addObject("pageInfo", page);
        //通过setViewName()方法跳转到指定的页面
        mv.setViewName("qcc-master-internScore-list");
        return mv;
    }

    /**
     * @Author Wang FengCai
     * @Description 查找--人员检出力有效性评估
     * @Date 2020/4/15
     **/
    @RequestMapping("/findByEduTypAndWorC2IA.do")
    protected ModelAndView findByEduTypAndWorC2IndentAssess(HttpServletRequest request, @RequestParam(value = "pn", defaultValue = "1") Integer pn, @RequestParam(value = "PageSize", defaultValue = "10") Integer ps) throws Exception {
        PageHelper.startPage(pn, ps);
        ModelAndView mv = new ModelAndView();
        String educateType = request.getParameter("educate_type");
        String workplaceCode = request.getParameter("workplace_code");
        int num;
        String message=null;
        //取出用户输入的天数
        if (request.getParameter("number") != null && !"".equals(request.getParameter("number"))) {
            num = Integer.parseInt(request.getParameter("number"));
        } else {
            num = 180;
        }

        List<Qcc_master_inspection> qcc1Mains = iQccMasterInspectionService.findByEduTypAndWorC2IdenAss(educateType, workplaceCode);
        if(qcc1Mains.size()>0){
            //将取回的结果遍历
            for (Qcc_master_inspection qcc1Main : qcc1Mains) {
                //取出每个对象中的工号
                String emId = qcc1Main.getEmployee_id();
                //根据工号去人事主档查询
                Com_employee comEmployee = iCom_employeeService.findByEmployee_id(emId);
                if (comEmployee != null && !"".equals(comEmployee)) {
                    //取出姓名，并处理
                    String mdn = comEmployee.getMmdnam();
                    qcc1Main.setMmdnam(mdn);
                    //取出认定日期，并处理
                    if (qcc1Main.getConfirm_date_of_1() == null || "".equals(qcc1Main.getConfirm_date_of_1())) {
                        //处理认定日期
                        if (qcc1Main.getConfirm_date() != null) {
                            int confirmDate = DateUtils.calculateDays(qcc1Main.getConfirm_date());
                            // 和用户输入的天数进行比较
                            if (confirmDate > num) {
                                //显示在前端页面
                                qcc1Main.setConfirm_date2now("已认定" + String.valueOf(confirmDate) + "天");
                            }
                        }
                    } else {
                        int confirmD = DateUtils.calculateDays(qcc1Main.getConfirm_date_of_1());
                        //显示在前端页面
                        if (confirmD > num) {
                            //显示在前端页面
                            qcc1Main.setConfirm_date2now("一次认定已" + String.valueOf(confirmD) + "天");
                        }

                    }
                    //取出认定者工号，根据认定者工号去人事主档中查出姓名
                    if (qcc1Main.getQc_confirm_of_1() != null && !"".equals(qcc1Main.getQc_confirm_of_1())) {
                        Com_employee comEmployee1 = iCom_employeeService.findByEmployee_id(qcc1Main.getQc_confirm_of_1().trim());
                        if (comEmployee1 != null) {
                            //取出姓名，并处理
                            qcc1Main.setQc_confirm_name(comEmployee1.getMmdnam());
                        }
                    }

                    //将字符串类型的日期转换成日期格式
                    LocalDate date_of_induction = DateUtils.date2LocalDate(qcc1Main.getDate_of_induction());
                    //取出调离日期并判断
                    Date date_of_departure = qcc1Main.getDate_of_departure();
                    //计算离岗 年/天
                    Period p;
                    String date_to_now = null;
                    //判断调离日是否为空
                    if (qcc1Main.getDate_of_departure() == null || "".equals(qcc1Main.getDate_of_departure())) {
                        //调用工具类的方法计算时间差
                        p = DateUtils.calculateTimeDifferenceByPeriod(date_of_induction);
                    } else {
                        //到岗年/天=调离日-到岗日
                        p = DateUtils.calculateTimeDifferenceByPeriod2(DateUtils.date2LocalDate(date_of_departure), date_of_induction);
                    }
                    //调用工具类 判断 年/天的显示格式
                    date_to_now = DateUtils.dateDisplay(p);
                    //重新放到对象中去
                    qcc1Main.setDate_to_now(date_to_now);
                }
                //调用方法查询作业种类和单位代码对应的中文信息
                findEducateTypeChineseNameAndWorkplaceCodeChineseName(qcc1Main);
            }

            PageInfo page = new PageInfo(qcc1Mains, ps);
            mv.addObject("qcc1Mains", qcc1Mains);
            mv.addObject("pageInfo", page);
        }else{
            message="未查询到结果，请重新确认";
            mv.addObject("message",message);
        }

        mv.setViewName("qcc-master-identifyAssess-list");
        return mv;
    }

    /**
     * @Author Wang FengCai
     * @Description 删除
     * @Date 2020/4/9
     **/
    @RequestMapping("/deleteById.do")
    public void deleteById(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        iQccMasterInspectionService.deleteById(Integer.parseInt(request.getParameter("id")));
        JsonUtil.writeValue(info,response);
    }

    /**
     * @Author Wang FengCai
     * @Description 保存
     * @Date 2020/4/10
     **/
    @RequestMapping("/update.do")
    public void update(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        //取出前端传回的所有数据
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        String username = (String) session.getAttribute("username");
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<String, String>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //字段date_to_now(到岗 年/天)，chinese_name(姓名)，date_of_resignation(辞职日)
                if ("date_to_now".equals(name1) || "del".equals(name1) || "num".equals(name1) || "chinese_name".equals(name1) || "date_of_resignation".equals(name1)) {
                    //不做处理
                } else {
                    //将每一个key值对应的一组值放到数组里去
                    String[] vals = (String[]) map.get(name1);
                    c = vals.length;
                    //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                    hashMap.put(name1, vals[b]);
                }
            }
            Qcc_master_inspection qcc1Main = iQccMasterInspectionService.findById(Integer.parseInt(hashMap.get("id")));
            if(qcc1Main!=null&&!"".equals(qcc1Main)){
                try {
                    DateUtils.convert2Date();
                    BeanUtils.populate(qcc1Main, hashMap);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    e.printStackTrace();
                }
                //更新的程序
                qcc1Main.setUpdate_oid(username);
                qcc1Main.setUpdate_program("/qcc_master_inspection/update");
                //调用业务层的update()方法
                iQccMasterInspectionService.update(qcc1Main);
            }
                b++;
                if (b == c) {
                    break;
                }

        }
        // 响应数据
        JsonUtil.writeValue(info,response);

    }

    /**
     * @Author Wang FengCai
     * @Description 增加
     * @Date 2020/4/10
     **/
    @RequestMapping("/save.do")
    public void save(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        String username = (String) session.getAttribute("username");
        String educateType = request.getParameter("educate_type");
        String workplaceCode = request.getParameter("workplace_code");
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                if ("date_to_now".equals(name1) || "num".equals(name1) || "chinese_name".equals(name1) || "date_of_resignation".equals(name1)) {
                    //不做处理
                } else {
                    //将每一个key值对应的一组值放到数组里去
                    String[] vals = (String[]) map.get(name1);
                    c = vals.length;
                    if ("educate_type".equals(name1)) {
                        vals[b] = educateType;
                    }
                    if ("workplace_code".equals(name1)) {
                        vals[b] = workplaceCode;
                    }
                    //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                    hashMap.put(name1, vals[b]);
                }
            }
            //如果取出的 工号为空，则不往数据库里插入数据
            if (hashMap.get("employee_id") == null || "".equals(hashMap.get("employee_id"))) {
                b++;
                if (b == c) {
                    break;
                }
                continue;
            }

            Qcc_master_inspection qccMasterInspection = new Qcc_master_inspection();
            try {
                DateUtils.convert2Date();
                BeanUtils.populate(qccMasterInspection, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            qccMasterInspection.setLogin_oid(username);
            qccMasterInspection.setUpdate_program("/qcc_master_inspection/save");
            //调用业务层的save()方法
            iQccMasterInspectionService.save(qccMasterInspection);
            b++;
            if (b == c) {
                break;
            }
        }
        // 响应数据
        JsonUtil.writeValue(info,response);
    }


    /**
     * @Author Yu Liqin
     * @Description 按作业类型以及单位代码 未调离并且QA经理已经承认(qa_manager_confirm='1')
     * @Date 2020/4/13
     **/
    @RequestMapping("/findByEduTypAndWorPQa.do")
    protected ModelAndView findByEduTypAndWorPQa(HttpServletRequest request, @RequestParam(value = "pn", defaultValue = "1") Integer pn, @RequestParam(value = "PageSize", defaultValue = "10") Integer ps) throws Exception {
        //引入PageHelper分页插件
        PageHelper.startPage(pn, ps);
        //取回前端传回的数据
        String educateType = request.getParameter("educate_type");
        String workplaceCode = request.getParameter("workplace_code");
        //调用业务层的方法查询
        List<Qcc_master_inspection> qcc1Mains = iQccMasterInspectionService.findByEduTypAndWorPQa(educateType, workplaceCode);
        //将取回的结果遍历
        for (Qcc_master_inspection qcc1Main : qcc1Mains) {
            //取出每个对象中的工号
            String emId = qcc1Main.getEmployee_id();
            //根据工号去人事主档查询
            Com_employee comEmployee = iCom_employeeService.findByEmployee_id(emId);
            if (comEmployee != null && !"".equals(comEmployee)) {
                //取出离职日，做处理
                if (comEmployee.getMmrsgn() == null || "".equals(comEmployee.getMmrsgn()) || "0".equals(comEmployee.getMmrsgn())) {
                    String mh = "";
                    qcc1Main.setMmrsgn(mh);
                } else {
                    //在字符串中插入"-"
                    new StringBuffer(comEmployee.getMmrsgn()).insert(6, "-");
                    new StringBuffer(comEmployee.getMmrsgn()).insert(4, "-");
                    //转换格式
                    qcc1Main.setMmrsgn(new StringBuffer(comEmployee.getMmrsgn()).toString());
                }
                //取出姓名，并处理
                String mdn = comEmployee.getMmdnam();
                qcc1Main.setMmdnam(mdn);
                //将字符串类型的日期转换成日期格式
                LocalDate date_of_induction = DateUtils.date2LocalDate(qcc1Main.getDate_of_induction());
                //取出调离日期并判断
                Date date_of_departure = qcc1Main.getDate_of_departure();

                //计算离岗 年/天
                Period p;
                String date_to_now = null;
                //判断调离日是否为空
                if (qcc1Main.getDate_of_departure() != null && !"".equals(qcc1Main.getDate_of_departure())) {
                    //到岗年/天=调离日-到岗日
                    p = DateUtils.calculateTimeDifferenceByPeriod2(DateUtils.date2LocalDate(date_of_departure), date_of_induction);
                } else {
                    //调用工具类的方法计算时间差
                    p = DateUtils.calculateTimeDifferenceByPeriod(date_of_induction);

                }
                //调用工具类 判断 年/天的显示格式
                date_to_now = DateUtils.dateDisplay(p);
                //重新放到对象中去
                qcc1Main.setDate_to_now(date_to_now);

                //计算评估_天
                int dayToNow = 0;
                if (qcc1Main.getConfirm_date_of_2() != null && !"".equals(qcc1Main.getConfirm_date_of_2())) {
                    //调用工具类计算
                    dayToNow = DateUtils.calculateDays(qcc1Main.getConfirm_date_of_2());
                } else {
                    if (qcc1Main.getConfirm_date() != null) {
                        //使用认定日来计算
                        dayToNow = DateUtils.calculateDays(qcc1Main.getConfirm_date());
                    }
                }
                //将计算结果插入到对象中
                qcc1Main.setDayToNow(dayToNow);

            }
            //调用方法查询单位代码和作业种类对应的中文信息
            findEducateTypeChineseNameAndWorkplaceCodeChineseName(qcc1Main);
        }
        //创建视图对象
        ModelAndView mv = new ModelAndView();
        PageInfo page = new PageInfo(qcc1Mains, ps);
        //使用addObject()设置需要返回的值
        mv.addObject("qcc1Mains", qcc1Mains);
        mv.addObject("pageInfo", page);
        //通过setViewName()方法跳转到指定的页面
        mv.setViewName("qcc-vision-history-list");
        return mv;
    }

    /**
     * @Author Yu Liqin
     * @Description 非特性视力必须大于等于0.8
     * @Date 2020/4/13
     **/
    @RequestMapping("/CheckVision.do")
    public void CheckVision(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        List<Qcc_master_inspection> qcc1Mains = new ArrayList<Qcc_master_inspection>();
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //字段date_to_now(到岗日)，chinese_name(姓名)，date_of_resignation(辞职日)
                if ("date_to_now".equals(name1) || "del".equals(name1) || "num".equals(name1) || "chinese_name".equals(name1) || "date_of_resignation".equals(name1)) {
                    //不做处理
                } else {
                    //将每一个key值对应的一组值放到数组里去
                    String[] vals = (String[]) map.get(name1);
                    c = vals.length;
                    //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                    hashMap.put(name1, vals[b]);
                }
            }
            //判断若工号为空则不继续执行
            if (hashMap.get("employee_id") == null || "".equals(hashMap.get("employee_id"))) {
                b++;
                if (b == c) {
                    break;
                }
                continue;
            } else {
                //记录当前记录行
                String errLine = String.valueOf(b);
                if (!"Y".equals(hashMap.get("special")) && !"".equals(hashMap.get("confirm_date_of_2")) && hashMap.get("confirm_date_of_2") != null) {
                    if ("".equals(hashMap.get("eye_left")) || hashMap.get("eye_left") == null) {
                        info.setFlag(false);
                        errorList.add("eye_left" + errLine);
                        info.setErrorMsg("非特例视力必须输入,请确认");
                    } else {
                        //非特例 视力必须大于等于0.8
                        if (hashMap.get("eye_left").compareTo("0.8") < 0) {
                            info.setFlag(false);
                            errorList.add("eye_left" + errLine);
                            info.setErrorMsg("非特例视力必须大于等于0.8,请确认");
                        }
                    }
                    if ("".equals(hashMap.get("eye_right")) || hashMap.get("eye_right") == null) {
                        info.setFlag(false);
                        errorList.add("eye_right" + errLine);
                        info.setErrorMsg("非特例视力必须输入,请确认");
                    } else {
                        //非特例是	视力必须大于等于0.8
                        if (hashMap.get("eye_right").compareTo("0.8") < 0) {
                            info.setFlag(false);
                            errorList.add("eye_right" + errLine);
                            info.setErrorMsg("非特例视力必须大于等于0.8,请确认");
                        }
                    }
                }
                b++;
                if (b == c) {
                    break;
                }
            }
        }

        info.setErrorList(errorList);
        info.setData(qcc1Mains);
        //响应数据
        JsonUtil.writeValue(info,response);
    }

    /**
     * @Author Yu Liqin
     * @Description //TODO a801550
     * @Date 2020/4/16
     **/
    @RequestMapping("/CheckIdentify.do")
    public void CheckIdentify(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        List<Qcc_master_inspection> qcc1Mains = new ArrayList<Qcc_master_inspection>();
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //字段date_to_now(到岗日)，chinese_name(姓名)，date_of_resignation(辞职日)
                if ("date_to_now".equals(name1) || "del".equals(name1) || "num".equals(name1) || "chinese_name".equals(name1) || "date_of_resignation".equals(name1)) {
                    //不做处理
                } else {
                    //将每一个key值对应的一组值放到数组里去
                    String[] vals = (String[]) map.get(name1);
                    c = vals.length;
                    //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                    hashMap.put(name1, vals[b]);
                }
            }
            //判断若工号为空则不继续执行
            if (hashMap.get("employee_id") == null || "".equals(hashMap.get("employee_id"))) {
                b++;
                if (b == c) {
                    break;
                }
                continue;
            } else {
                //记录当前记录行
                String errLine = String.valueOf(b);
                String qaConf = hashMap.get("qa_manager_confirm");
                if(qaConf!=null&&"1".equals(qaConf)){
                    String confDate = hashMap.get("confirm_date");
                    if(confDate==null||"".equals(confDate)){
                        info.setFlag(false);
                        errorList.add("confirm_date" + errLine);
                        info.setErrorMsg("认定日期不能为空,请确认");
                    }
                }
                if (!"Y".equals(hashMap.get("special")) && "1".equals(qaConf)) {
                    //非特例 成绩必须大于90
                    if (Integer.parseInt(hashMap.get("sampling_principle")) < 90 && hashMap.get("sampling_principle") != null && !"".equals(hashMap.get("sampling_principle"))) {
                        info.setFlag(false);
                        errorList.add("sampling_principle" + errLine);
                        info.setErrorMsg("非特成绩必须大于等于90,请确认");
                    }
                    //非特例 成绩必须大于90
                    if (Integer.parseInt(hashMap.get("product_knowledge").trim()) < 90 && hashMap.get("product_knowledge") != null) {
                        info.setFlag(false);
                        errorList.add("product_knowledge" + errLine);
                        info.setErrorMsg("成绩必须大于90,请确认");
                    }
                    //非特例 成绩必须大于90
                    if (Integer.parseInt(hashMap.get("operation_education").trim()) < 90 && hashMap.get("operation_education") != null) {
                        info.setFlag(false);
                        errorList.add("operation_education" + errLine);
                        info.setErrorMsg("成绩必须大于90,请确认");
                    }
                    //非特例 成绩必须大于1
                    if (hashMap.get("skill_development").compareTo("1") < 0) {
                        info.setFlag(false);
                        errorList.add("skill_development" + errLine);
                        info.setErrorMsg("成绩必须大于1,请确认");
                    }
                    //非特例 成绩必须大于94
                    if (Integer.parseInt(hashMap.get("identify_ability").trim()) < 85 && hashMap.get("identify_ability") != null) {
                        info.setFlag(false);
                        errorList.add("identify_ability" + errLine);
                        info.setErrorMsg("成绩必须大于85,请确认");
                    }
                    //非特例 成绩必须是A
                    if (!"A".equals(hashMap.get("job_evaluation").toUpperCase())) {
                        info.setFlag(false);
                        errorList.add("job_evaluation" + errLine);
                        info.setErrorMsg("成绩不合格,请确认");
                    }
                }
                if (!"999".equals(hashMap.get("field1")) && !"OK".equals(hashMap.get("field1").toUpperCase()) && !"".equals(hashMap.get("field1"))) {
                    info.setFlag(false);
                    errorList.add("field1" + errLine);
                    info.setErrorMsg("grr只能维护999，OK或者空,请确认");
                }
                b++;
                if (b == c) {
                    break;
                }
            }
        }

        info.setErrorList(errorList);
        info.setData(qcc1Mains);
        //响应数据
        JsonUtil.writeValue(info,response);
    }


    /**
     * @Author Yu Liqin
     * @Description //TODO a801550
     * @Date 2020/4/16
     **/
    @RequestMapping("/findByEduTypAndWorBo.do")
    protected ModelAndView findByEduTypAndWorBo(HttpServletRequest
                                                        request, @RequestParam(value = "pn", defaultValue = "1") Integer
                                                        pn, @RequestParam(value = "PageSize", defaultValue = "10") Integer ps) throws Exception {
        //引入PageHelper分页插件
        PageHelper.startPage(pn, ps);
        //取回前端传回的数据
        String educateType = request.getParameter("educate_type");
        String workplaceCode = request.getParameter("workplace_code");
        //调用业务层的方法查询
        List<Qcc_master_inspection> qcc1Mains = iQccMasterInspectionService.findByEduTypAndWorBo(educateType, workplaceCode);
        if (qcc1Mains != null && !"".equals(qcc1Mains)) {
            //将取回的结果遍历
            for (Qcc_master_inspection qcc1Main : qcc1Mains) {
                //取出每个对象中的工号
                String emId = qcc1Main.getEmployee_id();
                //根据工号去人事主档查询
                Com_employee comEmployee = iCom_employeeService.findByEmployee_id(emId);
                if (comEmployee != null && !"".equals(comEmployee)) {
                    //取出离职日，做处理
                    if (comEmployee.getMmrsgn() == null || "".equals(comEmployee.getMmrsgn()) || "0".equals(comEmployee.getMmrsgn())) {
                        qcc1Main.setMmrsgn("");
                    } else {
                        //在字符串中插入"-"
                        StringBuffer mh1 = new StringBuffer(comEmployee.getMmrsgn());
                        mh1.insert(6, "-");
                        mh1.insert(4, "-");
                        //转换格式
                        qcc1Main.setMmrsgn(mh1.toString());
                    }
                    //取出姓名，并处理
                    String mdn = comEmployee.getMmdnam();
                    qcc1Main.setMmdnam(mdn);
                    //转换格式
                    LocalDate date_of_induction = DateUtils.date2LocalDate(qcc1Main.getDate_of_induction());
                    //计算离岗 年/天
                    Period p;
                    String date_to_now = null;
                    //判断调离日是否为空
                    if (qcc1Main.getDate_of_departure() != null && !"".equals(qcc1Main.getDate_of_departure())) {
                        //到岗年/天=调离日-到岗日
                        p = DateUtils.calculateTimeDifferenceByPeriod2(DateUtils.date2LocalDate(qcc1Main.getDate_of_departure()), date_of_induction);
                    } else {
                        //调用工具类的方法计算时间差
                        p = DateUtils.calculateTimeDifferenceByPeriod(date_of_induction);
                    }
                    //调用工具类 判断 年/天的显示格式
                    date_to_now = DateUtils.dateDisplay(p);
                    //重新放到对象中去
                    qcc1Main.setDate_to_now(date_to_now);
                }
                //调用方法查询单位代码和作业种类对应的中文信息
                findEducateTypeChineseNameAndWorkplaceCodeChineseName(qcc1Main);
            }
        }
        //创建视图对象
        ModelAndView mv = new ModelAndView();
        PageInfo page = new PageInfo(qcc1Mains, ps);
        //使用addObject()设置需要返回的值
        mv.addObject("qcc1Mains", qcc1Mains);
        mv.addObject("pageInfo", page);
        //通过setViewName()方法跳转到指定的页面
        mv.setViewName("qcc-identify-qualify-list");
        return mv;
    }

    /**
     * @Author Wang FengCai
     * @Description 检查人员报表
     * @Date 2020/4/28
     **/
    @RequestMapping("/findDatapool2MasterInspection.do")
    public ModelAndView findDatapool2MasterInspection(HttpServletRequest request) throws Exception {
        String dataPoolModel = request.getParameter("dataPoolModel");
        //创建一个对象
        Qcc_getParmeter2MasterInspection qccGetParmeter2MasterInspection = new Qcc_getParmeter2MasterInspection();
        qccGetParmeter2MasterInspection.setEducate_type1(request.getParameter("educate_typeFrom").toUpperCase());
        qccGetParmeter2MasterInspection.setEducate_type2(request.getParameter("educate_typeTo").toUpperCase());
        qccGetParmeter2MasterInspection.setWorkplace_code1(request.getParameter("workplace_codeFrom").toUpperCase());
        qccGetParmeter2MasterInspection.setWorkplace_code2(request.getParameter("workplace_codeTo").toUpperCase());
        qccGetParmeter2MasterInspection.setJob_evaluation1(request.getParameter("job_evaluationFrom").toUpperCase());
        qccGetParmeter2MasterInspection.setJob_evaluation2(request.getParameter("job_evaluationTo").toUpperCase());
        qccGetParmeter2MasterInspection.setSkill_development1(request.getParameter("skill_developmentFrom").toUpperCase());
        qccGetParmeter2MasterInspection.setSkill_development2(request.getParameter("skill_developmentTo").toUpperCase());
        qccGetParmeter2MasterInspection.setEligibility_no1(request.getParameter("eligibility_noFrom").toUpperCase());
        qccGetParmeter2MasterInspection.setEligibility_no2(request.getParameter("eligibility_noTo").toUpperCase());
        qccGetParmeter2MasterInspection.setIdentify_ability1(request.getParameter("identify_abilityFrom").toUpperCase());
        qccGetParmeter2MasterInspection.setIdentify_ability2(request.getParameter("identify_abilityTo").toUpperCase());
        qccGetParmeter2MasterInspection.setDate_of_induction1(request.getParameter("date_of_inductionFrom").toUpperCase());
        qccGetParmeter2MasterInspection.setDate_of_induction2(request.getParameter("date_of_inductionTo").toUpperCase());
        qccGetParmeter2MasterInspection.setConfirm_date1(request.getParameter("confirm_dateFrom").toUpperCase());
        qccGetParmeter2MasterInspection.setConfirm_date2(request.getParameter("confirm_dateTo").toUpperCase());
        qccGetParmeter2MasterInspection.setSpecial(request.getParameter("special").toUpperCase());
        qccGetParmeter2MasterInspection.setStamp_serial_no1(request.getParameter("stamp_serial_noFrom").toUpperCase());
        qccGetParmeter2MasterInspection.setStamp_serial_no2(request.getParameter("stamp_serial_noTo").toUpperCase());
        qccGetParmeter2MasterInspection.setConfirm_date1(request.getParameter("confirm_dateFrom").toUpperCase());
        qccGetParmeter2MasterInspection.setConfirm_date2(request.getParameter("confirm_dateTo").toUpperCase());
        qccGetParmeter2MasterInspection.setConfirm_date_of_one1(request.getParameter("confirm_date_of_1From").toUpperCase());
        qccGetParmeter2MasterInspection.setConfirm_date_of_one2(request.getParameter("confirm_date_of_1To").toUpperCase());
        qccGetParmeter2MasterInspection.setSampling_principle1(request.getParameter("sampling_principleFrom").toUpperCase());
        qccGetParmeter2MasterInspection.setSampling_principle2(request.getParameter("sampling_principleTo").toUpperCase());
        qccGetParmeter2MasterInspection.setProduct_knowledge1(request.getParameter("product_knowledgeFrom").toUpperCase());
        qccGetParmeter2MasterInspection.setProduct_knowledge2(request.getParameter("product_knowledgeTo").toUpperCase());
        qccGetParmeter2MasterInspection.setOperation_education1(request.getParameter("operation_educationFrom").toUpperCase());
        qccGetParmeter2MasterInspection.setOperation_education2(request.getParameter("operation_educationTo").toUpperCase());
        qccGetParmeter2MasterInspection.setDataPoolModel(request.getParameter("dataPoolModel").toUpperCase());
        System.out.println(qccGetParmeter2MasterInspection.toString());
        //调用业层的方法查询
        List<Qcc_master_inspection> qccMasterInspectionList = iQccMasterInspectionService.findDatapool2MasterInspection(qccGetParmeter2MasterInspection);
        //创建视图对象
        ModelAndView modelAndView = new ModelAndView();
        //使用addObject()设置需要返回的值
        modelAndView.addObject("qccMasterInspectionList", qccMasterInspectionList);
        //通过setViewName()方法跳转到指定的页面
        if (qccMasterInspectionList.isEmpty()) {
            //跳转到未查询到结果的画面
            modelAndView.setViewName("qcc-master-nofound");
        } else {
            if ("1".equals(dataPoolModel) || "".equals(dataPoolModel)) {
                //跳转到抽样检查
                modelAndView.setViewName("qcc-master-datapool-list1");
            } else if ("2".equals(dataPoolModel)) {
                //跳转到全数外观
                modelAndView.setViewName("qcc-master-datapool-list2");
            } else if ("3".equals(dataPoolModel)) {
                //跳转到全数特性
                modelAndView.setViewName("qcc-master-datapool-list3");
            }
        }
        //返回视图解析对象
        return modelAndView;
    }

}
