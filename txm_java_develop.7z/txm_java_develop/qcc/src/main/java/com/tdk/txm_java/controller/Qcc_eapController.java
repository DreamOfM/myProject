package com.tdk.txm_java.controller;

import com.tdk.txm_java.domain.Qcc_eap;
import com.tdk.txm_java.domain.Qcc_ebp;
import com.tdk.txm_java.domain.ResultInfo;
import com.tdk.txm_java.service.IQcc_eapService;
import com.tdk.txm_java.service.IQcc_ebpService;
import com.tdk.txm_java.utils.JsonUtil;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_0304</h3>
 * @ToDo<p>受训作业职种维护</p>
 * @date : 2020-03-11 10:12
 * @version:1.0
 **/
@Controller
@RequestMapping("/qcc_eap")
public class Qcc_eapController {
    @Autowired
    private IQcc_eapService iQccEapService;
    @Autowired
    private IQcc_ebpService iQccEbpService;

    /**
     * @Author Wang FengCai
     * @Description 检查作业种类在数据库中是否存在
     * @Date 2020/3/12
     **/
    @RequestMapping("/check01.do")
    public void check01(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        //取到前端传回来的educate_type
        String educate_type = request.getParameter("educate_type");
        //根据id取出数据库原始的值
        if(iQccEapService.findByEduTyp1(educate_type)!=null&&!"".equals(iQccEapService.findByEduTyp1(educate_type))){
            info.setErrorMsg("种类代码已存在，请重新输入");
            info.setFlag(false);
        }
        //响应数据
        JsonUtil.writeValue(info,response);
    }

    /**
     * @Author Wang FengCai
     * @Description 新增---检查
     * @Date  2020/4/20
     **/
    @RequestMapping("/check02.do")
    public void check02(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<Qcc_eap> qccEapList = new ArrayList<Qcc_eap>();
        List<String> errorList = new ArrayList<String>();
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //将每一个key值对应的一组值放到数组里去
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                hashMap.put(name1, vals[b]);
            }
            //记录当前记录行
            String errLine = String.valueOf(b);
            //如果取出的 educate_type为空，则不往数据库里插入数据
            if (hashMap.get("educate_type").equals(null) || hashMap.get("educate_type").equals("")) {
                b++;
                if (b == c) {
                    break;
                }
                continue;
            }else {
                //判断中文名称是否为空
                if (hashMap.get("educate_type_name") == null || "".equals(hashMap.get("educate_type_name"))) {
                    info.setErrorMsg("中文名称不能为空，请确认");
                    errorList.add("educate_type_name" + errLine);
                    info.setFlag(false);
                }
            }
            b++;
            if (b == c) {
                break;
            }
        }
        info.setErrorList(errorList);
        info.setData(qccEapList);
        //响应数据
        JsonUtil.writeValue(info,response);
    }

    /**
     * @Author Wang FengCai
     * @Description 根据作业种类查询
     * @Date 2020/3/11
     **/
    @RequestMapping("/findByEduTyp.do")
    public ModelAndView findByEduTyp(HttpServletRequest request) throws Exception {
        //取出前端传回的数据
        String educateType = request.getParameter("educate_type") + "%";
        //调用业层的方法查询
        List<Qcc_eap> qccEapList = iQccEapService.findByEduTyp(educateType);
        //创建视图对象
        ModelAndView modelAndView = new ModelAndView();
        //使用addObject()设置需要返回的值
        modelAndView.addObject("qccEapList", qccEapList);
        //通过setViewName()方法跳转到指定的页面
        modelAndView.setViewName("qcc-eap-list");
        //返回视图解析对象
        return modelAndView;
    }

    /**
     * @Author Wang FengCai
     * @Description 修改
     * @Date 2020/3/11
     **/
    @RequestMapping("/update.do")
    public void update(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        //取出前端传回的所有数据
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<Qcc_eap> qccEapList = new ArrayList<Qcc_eap>();
        List<String> errorList = new ArrayList<String>();
        String username = (String) session.getAttribute("username");
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //将每一个key值对应的一组值放到数组里去
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                hashMap.put(name1, vals[b]);
            }
            //记录当前记录行
            String errLine = String.valueOf(b);
            //如果取出的 educate_type为空，则不往数据库里插入数据
            if (hashMap.get("educate_type").equals(null) || "".equals(hashMap.get("educate_type"))) {
                b++;
                if (b == c) {
                    break;
                }
                continue;
            }else{
                //判断中文名称是否为空
                if(hashMap.get("educate_type_name")==null||"".equals(hashMap.get("educate_type_name"))){
                    info.setErrorMsg("中文名称不能为空，请确认");
                    errorList.add("educate_type_name" + errLine);
                    info.setFlag(false);
                }else{
                    //创建对象
                    Qcc_eap qccEap = new Qcc_eap();
                    //更新的程序
                    qccEap.setUpdate_oid(username);
                    qccEap.setUpdate_program("/qcc_eap/update");
                    try {
                        BeanUtils.populate(qccEap, hashMap);
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    } catch (InvocationTargetException e) {
                        e.printStackTrace();
                    }
                    //调用业务层的update()方法
                    iQccEapService.update(qccEap);
                }
            }

            b++;
            if (b == c) {
                break;
            }
        }
        info.setErrorList(errorList);
        info.setData(qccEapList);
        // 响应数据
        JsonUtil.writeValue(info,response);
    }

    /**
     * @Author Wang FengCai
     * @Description 删除
     * @Date 2020/3/12
     **/

    @RequestMapping("/deleteById.do")
    public void deleteById(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        //取出前端传回的id
        int id = Integer.parseInt(request.getParameter("id"));
        String educate_type = request.getParameter("educate_type").toUpperCase();
        List<Qcc_ebp> qccEbps = iQccEbpService.findByEduTyp(educate_type);
        if(iQccEbpService.findByEduTyp(educate_type)==null||iQccEbpService.findByEduTyp(educate_type).isEmpty()){
            //调用业务层的方法
            iQccEapService.deleteById(id);
        }else if(iQccEbpService.findByEduTyp(educate_type)!=null&&!iQccEbpService.findByEduTyp(educate_type).isEmpty()) {
            info.setErrorMsg("该作业种类不能删除,请确认");
            info.setFlag(false);
        }

        // 响应数据
        JsonUtil.writeValue(info,response);
    }

    /**
     * @Author Wang FengCai
     * @Description 增加
     * @Date  2020/3/12
     **/
    @RequestMapping("/save.do")
    public void save(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<Qcc_eap> qccEapList = new ArrayList<Qcc_eap>();
        List<String> errorList = new ArrayList<String>();
        String username = (String) session.getAttribute("username");
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //将每一个key值对应的一组值放到数组里去
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                hashMap.put(name1, vals[b]);
            }
            //记录当前记录行
            String errLine = String.valueOf(b);
            //如果取出的 educate_type为空，则不往数据库里插入数据
            if (hashMap.get("educate_type").equals(null) || hashMap.get("educate_type").equals("")) {
                b++;
                if (b == c) {
                    break;
                }
                continue;
            }else {
                //判断中文名称是否为空
                if (hashMap.get("educate_type_name") == null || "".equals(hashMap.get("educate_type_name"))) {
                    info.setErrorMsg("中文名称不能为空，请确认");
                    errorList.add("educate_type_name" + errLine);
                    info.setFlag(false);
                } else {
                    //创建对象
                    Qcc_eap qccEap = new Qcc_eap();

                    try {
                        BeanUtils.populate(qccEap, hashMap);
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    } catch (InvocationTargetException e) {
                        e.printStackTrace();
                    }
                    qccEap.setLogin_oid(username);
                    //调用业务层的save()方法
                    iQccEapService.save(qccEap);
                }
            }
            b++;
            if (b == c) {
                break;
            }
        }
        info.setErrorList(errorList);
        info.setData(qccEapList);
        // 响应数据
        JsonUtil.writeValue(info,response);
    }
}
