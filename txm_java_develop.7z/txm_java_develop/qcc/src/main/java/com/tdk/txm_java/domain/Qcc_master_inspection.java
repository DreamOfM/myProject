package com.tdk.txm_java.domain;

import java.util.Date;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_20200325</h3>
 * @ClassName<h4></h4>
 * @ToDo<p>抽样检查人员主档</p>
 * @date : 2020-04-08 13:49
 * @version:1.0
 **/
public class Qcc_master_inspection {
    private int id ;
    private String educate_type;
    private String workplace_code;
    private String employee_id;
    private Date  date_of_induction;
    private Date  date_of_departure;
    private String characte;
    private int  sure;
    private int  flexibitity;
    private double eye_left;
    private double eye_right;
    private String color_sensitivity;
    private int  sampling_principle;
    private int  product_knowledge;
    private int   operation_education;
    private double skill_development;
    private int  identify_ability;
    private String job_evaluation;
    private String stamp_serial_no;
    private String stamp_type;
    private String eligibility_no;
    private String eligibility_status;
    private Date  confirm_date;
    private String qa_manager_confirm;
    private int   identify_ability_1;
    private String qc_confirm_of_1;
    private Date  confirm_date_of_1;
    /**
     * @Author Wang FengCai
     * @Description 用户要求新增一个长假开始时间栏位用于对应那些产假病假的情况
     * @Date  2020/8/28
     * @Time  下午 02:06
     **/
    private Date  date_of_vacation;
    private int   identif_ability_2;
    private String qc_confirm_of_2;
    private Date confirm_date_of_2;
    private String special;
    private double grr;
    private String field1;
    private double field2;

    private Date login_time;
    private String login_oid;
    private Date update_time;
    private String update_oid;
    private String update_program;
    //作业种类中文名称
    private String educateTypeChineseName;

    //单位代码信息
    private String  workplaceCodeChineseName;

    //人事主档姓名
    private String mmdnam;
    //辞职日
    private String mmrsgn;
    //入社日
    private String mmhire;
    //到岗 年/天
    private String  date_to_now;
    //认定_日
    private String confirm_date2now;
    //认定者姓名
    private String qc_confirm_name;
    //视力评估增加的字段，用于显示计算结果
    private int dayToNow;
    //职种代码
    private String mmpos3;
    //职种名称
    private String mmp3nm;
    //人事股别
    private String mmdept;
    //姓名
    private String chinese_name;

    public Qcc_master_inspection() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEducate_type() {
        return educate_type;
    }

    public void setEducate_type(String educate_type) {
        this.educate_type = educate_type;
    }

    public String getWorkplace_code() {
        return workplace_code;
    }

    public void setWorkplace_code(String workplace_code) {
        this.workplace_code = workplace_code;
    }

    public String getEmployee_id() {
        return employee_id;
    }

    public void setEmployee_id(String employee_id) {
        this.employee_id = employee_id;
    }

    public Date getDate_of_induction() {
        return date_of_induction;
    }

    public void setDate_of_induction(Date date_of_induction) {
        this.date_of_induction = date_of_induction;
    }

    public Date getDate_of_departure() {
        return date_of_departure;
    }

    public void setDate_of_departure(Date date_of_departure) {
        this.date_of_departure = date_of_departure;
    }

    public String getCharacte() {
        return characte;
    }

    public void setCharacte(String characte) {
        this.characte = characte;
    }

    public int getSure() {
        return sure;
    }

    public void setSure(int sure) {
        this.sure = sure;
    }

    public int getFlexibitity() {
        return flexibitity;
    }

    public void setFlexibitity(int flexibitity) {
        this.flexibitity = flexibitity;
    }

    public double getEye_left() {
        return eye_left;
    }

    public void setEye_left(double eye_left) {
        this.eye_left = eye_left;
    }

    public double getEye_right() {
        return eye_right;
    }

    public void setEye_right(double eye_right) {
        this.eye_right = eye_right;
    }

    public String getColor_sensitivity() {
        return color_sensitivity;
    }

    public void setColor_sensitivity(String color_sensitivity) {
        this.color_sensitivity = color_sensitivity;
    }

    public int getSampling_principle() {
        return sampling_principle;
    }

    public void setSampling_principle(int sampling_principle) {
        this.sampling_principle = sampling_principle;
    }

    public int getProduct_knowledge() {
        return product_knowledge;
    }

    public void setProduct_knowledge(int product_knowledge) {
        this.product_knowledge = product_knowledge;
    }

    public int getOperation_education() {
        return operation_education;
    }

    public void setOperation_education(int operation_education) {
        this.operation_education = operation_education;
    }

    public double getSkill_development() {
        return skill_development;
    }

    public void setSkill_development(double skill_development) {
        this.skill_development = skill_development;
    }

    public int getIdentify_ability() {
        return identify_ability;
    }

    public void setIdentify_ability(int identify_ability) {
        this.identify_ability = identify_ability;
    }

    public String getJob_evaluation() {
        return job_evaluation;
    }

    public void setJob_evaluation(String job_evaluation) {
        this.job_evaluation = job_evaluation;
    }

    public String getStamp_serial_no() {
        return stamp_serial_no;
    }

    public void setStamp_serial_no(String stamp_serial_no) {
        this.stamp_serial_no = stamp_serial_no;
    }

    public String getStamp_type() {
        return stamp_type;
    }

    public void setStamp_type(String stamp_type) {
        this.stamp_type = stamp_type;
    }

    public String getEligibility_no() {
        return eligibility_no;
    }

    public void setEligibility_no(String eligibility_no) {
        this.eligibility_no = eligibility_no;
    }

    public String getEligibility_status() {
        return eligibility_status;
    }

    public void setEligibility_status(String eligibility_status) {
        this.eligibility_status = eligibility_status;
    }

    public Date getConfirm_date() {
        return confirm_date;
    }

    public void setConfirm_date(Date confirm_date) {
        this.confirm_date = confirm_date;
    }

    public String getQa_manager_confirm() {
        return qa_manager_confirm;
    }

    public void setQa_manager_confirm(String qa_manager_confirm) {
        this.qa_manager_confirm = qa_manager_confirm;
    }

    public int getIdentify_ability_1() {
        return identify_ability_1;
    }

    public void setIdentify_ability_1(int identify_ability_1) {
        this.identify_ability_1 = identify_ability_1;
    }

    public String getQc_confirm_of_1() {
        return qc_confirm_of_1;
    }

    public void setQc_confirm_of_1(String qc_confirm_of_1) {
        this.qc_confirm_of_1 = qc_confirm_of_1;
    }

    public Date getConfirm_date_of_1() {
        return confirm_date_of_1;
    }

    public void setConfirm_date_of_1(Date confirm_date_of_1) {
        this.confirm_date_of_1 = confirm_date_of_1;
    }

    public Date getDate_of_vacation() {
        return date_of_vacation;
    }

    public void setDate_of_vacation(Date date_of_vacation) {
        this.date_of_vacation = date_of_vacation;
    }

    public int getIdentif_ability_2() {
        return identif_ability_2;
    }

    public void setIdentif_ability_2(int identif_ability_2) {
        this.identif_ability_2 = identif_ability_2;
    }

    public String getQc_confirm_of_2() {
        return qc_confirm_of_2;
    }

    public void setQc_confirm_of_2(String qc_confirm_of_2) {
        this.qc_confirm_of_2 = qc_confirm_of_2;
    }

    public Date getConfirm_date_of_2() {
        return confirm_date_of_2;
    }

    public void setConfirm_date_of_2(Date confirm_date_of_2) {
        this.confirm_date_of_2 = confirm_date_of_2;
    }

    public String getSpecial() {
        return special;
    }

    public void setSpecial(String special) {
        this.special = special;
    }

    public double getGrr() {
        return grr;
    }

    public void setGrr(double grr) {
        this.grr = grr;
    }

    public String getField1() {
        return field1;
    }

    public void setField1(String field1) {
        this.field1 = field1;
    }

    public double getField2() {
        return field2;
    }

    public void setField2(double field2) {
        this.field2 = field2;
    }

    public Date getLogin_time() {
        return login_time;
    }

    public void setLogin_time(Date login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public Date getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(Date update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    public String getEducateTypeChineseName() {
        return educateTypeChineseName;
    }

    public void setEducateTypeChineseName(String educateTypeChineseName) {
        this.educateTypeChineseName = educateTypeChineseName;
    }

    public String getWorkplaceCodeChineseName() {
        return workplaceCodeChineseName;
    }

    public void setWorkplaceCodeChineseName(String workplaceCodeChineseName) {
        this.workplaceCodeChineseName = workplaceCodeChineseName;
    }

    public String getMmdnam() {
        return mmdnam;
    }

    public void setMmdnam(String mmdnam) {
        this.mmdnam = mmdnam;
    }

    public String getMmrsgn() {
        return mmrsgn;
    }

    public void setMmrsgn(String mmrsgn) {
        this.mmrsgn = mmrsgn;
    }

    public String getMmhire() {
        return mmhire;
    }

    public void setMmhire(String mmhire) {
        this.mmhire = mmhire;
    }

    public String getDate_to_now() {
        return date_to_now;
    }

    public void setDate_to_now(String date_to_now) {
        this.date_to_now = date_to_now;
    }

    public String getConfirm_date2now() {
        return confirm_date2now;
    }

    public void setConfirm_date2now(String confirm_date2now) {
        this.confirm_date2now = confirm_date2now;
    }

    public String getQc_confirm_name() {
        return qc_confirm_name;
    }

    public void setQc_confirm_name(String qc_confirm_name) {
        this.qc_confirm_name = qc_confirm_name;
    }

    public int getDayToNow() {
        return dayToNow;
    }

    public void setDayToNow(int dayToNow) {
        this.dayToNow = dayToNow;
    }

    public String getMmpos3() {
        return mmpos3;
    }

    public void setMmpos3(String mmpos3) {
        this.mmpos3 = mmpos3;
    }

    public String getMmp3nm() {
        return mmp3nm;
    }

    public void setMmp3nm(String mmp3nm) {
        this.mmp3nm = mmp3nm;
    }

    public String getMmdept() {
        return mmdept;
    }

    public void setMmdept(String mmdept) {
        this.mmdept = mmdept;
    }

    public String getChinese_name() {
        return chinese_name;
    }

    public void setChinese_name(String chinese_name) {
        this.chinese_name = chinese_name;
    }

    @Override
    public String toString() {
        return "Qcc_master_inspection{" +
                "id=" + id +
                ", educate_type='" + educate_type + '\'' +
                ", workplace_code='" + workplace_code + '\'' +
                ", employee_id='" + employee_id + '\'' +
                ", date_of_induction=" + date_of_induction +
                ", date_of_departure=" + date_of_departure +
                ", characte='" + characte + '\'' +
                ", sure=" + sure +
                ", flexibitity=" + flexibitity +
                ", eye_left=" + eye_left +
                ", eye_right=" + eye_right +
                ", color_sensitivity='" + color_sensitivity + '\'' +
                ", sampling_principle=" + sampling_principle +
                ", product_knowledge=" + product_knowledge +
                ", operation_education=" + operation_education +
                ", skill_development=" + skill_development +
                ", identify_ability=" + identify_ability +
                ", job_evaluation='" + job_evaluation + '\'' +
                ", stamp_serial_no='" + stamp_serial_no + '\'' +
                ", stamp_type='" + stamp_type + '\'' +
                ", eligibility_no='" + eligibility_no + '\'' +
                ", eligibility_status='" + eligibility_status + '\'' +
                ", confirm_date=" + confirm_date +
                ", qa_manager_confirm='" + qa_manager_confirm + '\'' +
                ", identify_ability_1=" + identify_ability_1 +
                ", qc_confirm_of_1='" + qc_confirm_of_1 + '\'' +
                ", confirm_date_of_1=" + confirm_date_of_1 +
                ", date_of_vacation=" + date_of_vacation +
                ", identif_ability_2=" + identif_ability_2 +
                ", qc_confirm_of_2='" + qc_confirm_of_2 + '\'' +
                ", confirm_date_of_2=" + confirm_date_of_2 +
                ", special='" + special + '\'' +
                ", grr=" + grr +
                ", field1='" + field1 + '\'' +
                ", field2=" + field2 +
                ", login_time=" + login_time +
                ", login_oid='" + login_oid + '\'' +
                ", update_time=" + update_time +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                ", educateTypeChineseName='" + educateTypeChineseName + '\'' +
                ", workplaceCodeChineseName='" + workplaceCodeChineseName + '\'' +
                ", mmdnam='" + mmdnam + '\'' +
                ", mmrsgn='" + mmrsgn + '\'' +
                ", mmhire='" + mmhire + '\'' +
                ", date_to_now='" + date_to_now + '\'' +
                ", confirm_date2now='" + confirm_date2now + '\'' +
                ", qc_confirm_name='" + qc_confirm_name + '\'' +
                ", dayToNow=" + dayToNow +
                ", mmpos3='" + mmpos3 + '\'' +
                ", mmp3nm='" + mmp3nm + '\'' +
                ", mmdept='" + mmdept + '\'' +
                ", chinese_name='" + chinese_name + '\'' +
                '}';
    }
}
