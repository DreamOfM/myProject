package com.tdk.txm_java.controller;

import com.tdk.txm_java.domain.Qcc_ebp;
import com.tdk.txm_java.domain.ResultInfo;
import com.tdk.txm_java.service.IQcc_eapService;
import com.tdk.txm_java.service.IQcc_ebpService;
import com.tdk.txm_java.service.IQcc_edpService;
import com.tdk.txm_java.utils.JsonUtil;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_0304</h3>
 * @ClassName<h4></h4>
 * @ToDo<p>受训作业职种维护</p>
 * @date : 2020-03-11 10:12
 * @version:1.0
 **/
@Controller
@RequestMapping("/qcc_ebp")
public class Qcc_ebpController {
    @Autowired
    private IQcc_ebpService iQccEbpService;
    @Autowired
    private IQcc_eapService iQccEapService;
    @Autowired
    private IQcc_edpService iQccEdpService;

    /**
     * @Author Wang FengCai
     * @Description 检查部门代码/单位代码是否存在
     * @Date 2020/3/13
     **/
    @RequestMapping("/check01.do")
    public void check01(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        //取到前端传回来的educate_type,dept_code并做判断
        if (request.getParameter("dept_code") != null) {
            String dept_code = request.getParameter("dept_code");
            //去数据库里查询
            if (iQccEbpService.findByDeptC(dept_code) == null || "".equals(iQccEbpService.findByDeptC(dept_code))) {
                info.setErrorMsg("部门代码不存在，请重新确认");
                info.setFlag(false);
            }
        }
        if (request.getParameter("educate_type") != null) {
            String educate_type = request.getParameter("educate_type");
            //去数据库里查询
            if (iQccEapService.findByEduTyp1(educate_type) == null || "".equals(iQccEapService.findByEduTyp1(educate_type))) {
                info.setErrorMsg("作业种类不存在，请重新确认");
                info.setFlag(false);
            }
        }

        if (request.getParameter("workplace_code") != null && request.getParameter("educate_type") != null && request.getParameter("dept_code") != null) {
            String workplace_code = request.getParameter("workplace_code");
            String educate_type = request.getParameter("educate_type");
            String dept_code = request.getParameter("dept_code");
            //去数据库里查找
            if (iQccEbpService.findByWpCAndDeptCAndEduT(workplace_code, educate_type, dept_code) != null) {
                info.setErrorMsg("单位代码已存在，请确认");
                info.setFlag(false);
            }
        }
        //响应数据
        JsonUtil.writeValue(info,response);
    }

    @RequestMapping("/check03.do")
    public void check03(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        //取出部门代码
        String dept_code = request.getParameter("dept_code").toUpperCase();
        //取出单位代码
        String workplace_code = request.getParameter("workplace_code").toUpperCase();
        //取到前端传回来的educate_type
        String educate_type = request.getParameter("educate_type").toUpperCase();
        //判断
        if (workplace_code != null && educate_type != null && dept_code != null) {
            //去数据库里查找
            if (iQccEbpService.findByWpCAndDeptCAndEduT(workplace_code, educate_type, dept_code) != null) {
                info.setErrorMsg("单位代码已存在，请确认");
                info.setFlag(false);
            }
        }
        //响应数据
        JsonUtil.writeValue(info,response);
    }


    /**
     * @Author Wang FengCai
     * @Description //TODO a079359
     * @Date 2020/4/3
     **/
    @RequestMapping("/check02.do")
    public void check02(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<Qcc_ebp> qccEbpList = new ArrayList<Qcc_ebp>();
        List<String> errorList = new ArrayList<String>();
        String username = (String) session.getAttribute("username");
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //将每一个key值对应的一组值放到数组里去
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                hashMap.put(name1, vals[b]);
            }
            //取出部门代码
            String dept_code = hashMap.get("dept_code").toUpperCase();
            //取出单位代码
            String workplace_code = hashMap.get("workplace_code").toUpperCase();
            //取到前端传回来的educate_type
            String educate_type = hashMap.get("educate_type").toUpperCase();
            //拆分单位代码的前两位
            String wk = workplace_code.substring(0, 2);
            //记录当前记录行
            String errLine = String.valueOf(b);
            //比较是否和部门代码相等
            if (!dept_code.equals(wk)) {
                info.setFlag(false);
                info.setErrorMsg("单位代码前两位要和部门代码一致");
                errorList.add("workplace_code" + errLine);
            }
            b++;
            if (b == c) {
                break;
            }
        }
        info.setErrorList(errorList);
        info.setData(qccEbpList);
        //响应数据
        JsonUtil.writeValue(info,response);
    }

    /**
     * @Author Wang FengCai
     * @Description 根据种类代码和部门代码查找
     * @Date 2020/3/13
     **/
    @RequestMapping("/findByEduTypAndDepC.do")
    public ModelAndView findByEduTypAndDepC(HttpServletRequest request) throws Exception {
        //取出前端传回的数据
        String educateType = request.getParameter("educate_type");
        String deptCode = request.getParameter("dept_code");
        //调用业层的方法查询
        List<Qcc_ebp> qccEbpList = iQccEbpService.findByEduTypAndDepC(educateType, deptCode);
        //创建视图对象
        ModelAndView modelAndView = new ModelAndView();
        //使用addObject()设置需要返回的值
        modelAndView.addObject("qccEbpList", qccEbpList);
        //通过setViewName()方法跳转到指定的页面
        modelAndView.setViewName("qcc-ebp-list");
        //返回视图解析对象
        return modelAndView;
    }

    /**
     * @Author Wang FengCai
     * @Description 修改
     * @Date 2020/3/13
     **/
    @RequestMapping("/update.do")
    public void update(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        //取出前端传回的所有数据
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<Qcc_ebp> qccEbpList = new ArrayList<Qcc_ebp>();
        List<String> errorList = new ArrayList<String>();
        String username = (String) session.getAttribute("username");
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //将每一个key值对应的一组值放到数组里去
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                hashMap.put(name1, vals[b]);
            }
            //取出ID
            int id = Integer.parseInt(hashMap.get("id"));
            //创建对象
            Qcc_ebp qccEbp = iQccEbpService.findById(id);
            //更新的程序
            qccEbp.setUpdate_oid(username);
            qccEbp.setUpdate_program("/qcc_ebp/update");
            try {
                BeanUtils.populate(qccEbp, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //调用业务层的update()方法
            iQccEbpService.update(qccEbp);
            b++;
            if (b == c) {
                break;
            }
        }
        info.setErrorList(errorList);
        info.setData(qccEbpList);
        // 响应数据
        JsonUtil.writeValue(info,response);
    }

    /**
     *@Description: 数据传到新增页面
     */
    @RequestMapping("/add.do")
    public ModelAndView add(String educate_type,String dept_code){
        ModelAndView mv = new ModelAndView();
        mv.setViewName("qcc-ebp-add");
        mv.addObject("educate_type",educate_type);
        mv.addObject("dept_code",dept_code);
        return mv;
    }

    /**
     * @Author Wang FengCai
     * @Description 删除
     * @Date 2020/3/13
     **/
    @RequestMapping("/deleteById.do")
    public void deleteById(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        int id = Integer.parseInt(request.getParameter("id"));
        //取出单位代码，判断在edp表中是否存在？存在则不能删除
        String workplace_code = request.getParameter("workplace_code").toUpperCase();
        //去edp表中查询并判断
        if (iQccEdpService.findByWoc(workplace_code) != null&&!iQccEdpService.findByWoc(workplace_code).isEmpty()) {
            info.setErrorMsg("该单位代码不能删除");
            info.setFlag(false);
        } else {
            //调用业务层的方法删除
            iQccEbpService.deleteById(id);
        }

        JsonUtil.writeValue(info,response);
    }

    /**
     * @Author Wang FengCai
     * @Description 增加
     * @Date 2020/3/13
     **/
    @RequestMapping("/save.do")
    public void save(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<Qcc_ebp> qccEbpList = new ArrayList<Qcc_ebp>();
        List<String> errorList = new ArrayList<String>();
        String username = (String) session.getAttribute("username");
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        //取出key值为material_code(品名代码),material_spec(品名规则),work_center(工作站)对应的值。
        String[] vals1 = (String[]) map.get("educate_type");
        String[] vals2 = (String[]) map.get("dept_code");
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //因为从第6笔开始，educate_type dept_code对应的值为空，所以需要手动为每一笔数据添加进去
                if (name1.equals("educate_type")) {
                    hashMap.put(name1, vals1[0].toUpperCase());
                } else if (name1.equals("dept_code")) {
                    hashMap.put(name1, vals2[0].toUpperCase());
                } else {
                    //将每一个key值对应的一组值放到数组里去
                    String[] vals = (String[]) map.get(name1);
                    c = vals.length;
                    //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                    hashMap.put(name1, vals[b]);
                }
            }
            //记录当前记录行
            String errLine = String.valueOf(b);
            //如果取出的 educate_type为空，则不往数据库里插入数据
            if (hashMap.get("workplace_code").equals(null) || hashMap.get("workplace_code").equals("")) {
                b++;
                if (b == c) {
                    break;
                }
                continue;
            } else if (hashMap.get("section_code") == null || "".equals(hashMap.get("section_code"))) {
                info.setErrorMsg("不能为空");
                errorList.add("section_code" + errLine);
                info.setFlag(false);
            } else if (hashMap.get("assistant_code") == null || "".equals(hashMap.get("assistant_code"))) {
                info.setErrorMsg("不能为空");
                errorList.add("assistant_code" + errLine);
                info.setFlag(false);
            } else {
                //创建对象
                Qcc_ebp qccEbp = new Qcc_ebp();

                try {
                    BeanUtils.populate(qccEbp, hashMap);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    e.printStackTrace();
                }
                qccEbp.setLogin_oid(username);
                //调用业务层的save()方法
                iQccEbpService.save(qccEbp);
            }
            b++;
            if (b == c) {
                break;
            }
        }
        info.setErrorList(errorList);
        info.setData(qccEbpList);
        // 响应数据
        JsonUtil.writeValue(info,response);
    }
}
