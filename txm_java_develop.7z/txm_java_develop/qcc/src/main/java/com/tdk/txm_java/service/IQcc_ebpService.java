package com.tdk.txm_java.service;
import com.tdk.txm_java.domain.Qcc_ebp;

import java.util.List;

/**
 * <h3>txm_java_0304</h3>
 * <p>受训作业单位代码维护</p>
 *
 * @author : Wang FengCai
 * @date : 2020-03-11 09:58
 **/
public interface IQcc_ebpService {

    /**
     * @Author Wang FengCai
     * @Description 增加
     * @Date  2020/3/11
     * @Time  上午 09:59
     * @Param
     * @return
     **/
    void save(Qcc_ebp qcc_ebp) throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 删除
     * @Date  2020/3/11
     * @Time  上午 10:01
     * @Param
     * @return
     **/
    void deleteById(int id)throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 修改
     * @Date  2020/3/11
     * @Time  上午 10:01
     * @Param
     * @return
     **/
    void update(Qcc_ebp qcc_ebp)throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 查询所有
     * @Date  2020/3/11
     * @Time  上午 10:02
     * @Param
     * @return
     **/
    Qcc_ebp findAll()throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 根据ID查询
     * @Date  2020/3/11
     * @Time  上午 10:03
     * @Param
     * @return
     **/
    Qcc_ebp findById(int id)throws Exception;
    /**
     * @Author Wang FengCai
     * @Description 查询dept_code在数据库中是否存在？
     * @Date  2020/3/13
     * @Time  上午 09:33
     * @Param [dept_code]
     * @return void
     **/
    String findByDeptC(String dept_code) throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 根据部门代码和作业种类查询
     * @Date  2020/3/13
     * @Time  上午 10:11
     * @Param [educateType, deptCode]
     * @return com.tdk.txm_java.domain.Qcc_ebp
     **/
    List<Qcc_ebp> findByEduTypAndDepC(String educateType, String deptCode) throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 根据部门代码，作业种类，和单位代码查询
     * @Date  2020/3/13
     * @Time  下午 01:43
     * @Param [workplace_code, educate_type, dept_code]
     * @return com.tdk.txm_java.domain.Qcc_ebp
     **/
    Qcc_ebp findByWpCAndDeptCAndEduT(String workplace_code, String educate_type, String dept_code);

    /**
     * @Author Wang FengCai
     * @Description 根据单位代码，和作业种类查询
     * @Date  2020/3/19
     * @Time  上午 10:53
     * @Param [workplace_code, educate_type]
     * @return void
     **/
    Qcc_ebp findByWpCAndEduT(String workplace_code, String educate_type);

    /**
     * @Author Wang FengCai
     * @Description 根据作业种类查找
     * @Date  2020/4/2
     * @Time  下午 01:41
     * @Param [educate_type]
     * @return void
     **/
    List<Qcc_ebp> findByEduTyp(String educate_type);
}
