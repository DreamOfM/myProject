package com.tdk.txm_java.dao;

import com.tdk.txm_java.domain.Qcc_assessment_history;
import com.tdk.txm_java.domain.Qcc_vision_history;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

/**
 * <h3>txm_java_0409</h3>
 * <p>檢查人員視力有效性評估持久层</p>
 *
 * @author : Wang FengCai
 * @date : 2020-04-13 08:38
 **/
@Repository
public interface IQcc_vision_historyDao {
    @Insert("insert into qcc_vision_history (educate_type,workplace_code,employee_id,confirm_date_of_2,check_type,eye_left,eye_right,confess_data,login_time,update_time,update_oid,update_program,login_oid) values" +
            "(#{educate_type},#{workplace_code},#{employee_id},#{confirm_date_of_2},'1',#{eye_left},#{eye_right},#{confess_data},now(),now(),#{update_oid},#{update_program},#{login_oid})")
    void save(Qcc_vision_history qccVisHistory) throws Exception;

    @Select("select * from qcc_vision_history where educate_type=#{educate_type} and workplace_code=#{workplace_code} and employee_id=#{employee_id} and confirm_date_of_2=#{confirm_date_of_2}")
    Qcc_vision_history findByEduTypAndWorEmD(@Param("educate_type") String educateType, @Param("workplace_code") String workplaceCode, @Param("employee_id") String employee_id, @Param("confirm_date_of_2") String confirm_date)throws Exception;


}
