package com.tdk.txm_java.controller;

import com.tdk.txm_java.service.IQcc_edpService;
import com.tdk.txm_java.service.IQcc_master_inspectionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java29</h3>
 * @ClassName<h4></h4>
 * @ToDo<p>定时JOB 每周日中午12点</ p>
 * @date : 2020-05-07 09:38
 * @version:1.0
 **/
@Component
public class Qcc_task_Controller {
    @Autowired
    IQcc_master_inspectionService iQccMasterInspectionService;
    @Autowired
    IQcc_edpService iQccEdpService;
    /**
     * 每周日午十二点启动任务
     */
    @Scheduled(cron ="0 00 12 ? * SUN")
    public void delete2Main() throws Exception {
        iQccMasterInspectionService.deleteTask2Main();
    }
    /**
     * 每周日中午十二点十分启动任务
     */
    @Scheduled(cron ="0 10 12 ? * SUN")
    public void delete2Edp() throws Exception {
        iQccEdpService.deleteTask2Edp();
    }
}
