package com.tdk.txm_java.dao;

import com.tdk.txm_java.domain.Qcc_assessment_history;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

/**
 * <h3>txm_java_0409</h3>
 * <p>抽樣檢查人員有效評估持久层</p>
 *
 * @author : Wang FengCai
 * @date : 2020-04-13 08:20
 **/
@Repository
public interface IQcc_assessment_historyDao {
    @Insert("insert into qcc_assessment_history (educate_type,workplace_code,employee_id,confirm_date_of_1,qc_confirm_of_1,qc_confirm_name,identify_ability_1,confess_data,login_time,update_time,update_oid,update_program,login_oid) values" +
            "(#{educate_type},#{workplace_code},#{employee_id},#{confirm_date_of_1},#{qc_confirm_of_1},#{qc_confirm_name},#{identify_ability_1},#{confess_data},now(),now(),#{update_oid},#{update_program},#{login_oid})")
    void save(Qcc_assessment_history qccAssHistory) throws Exception;

    @Delete("delete from qcc_assessment_history where id=#{id}")
    void delete(int id)throws Exception;

    @Update("update set qcc_assessment_history educate_type=#{educate_type}, workplace_code=#{workplace_code}, employee_id=#{employee_id}, confirm_date_of_1=#{confirm_date_of_1}, qc_confirm_of_1=#{qc_confirm_of_1}, qc_confirm_name=#{qc_confirm_name}, identify_ability_1=#{identify_ability_1}, confess_data=#{confess_data},update_program=#{update_program},update_oid=#{update_oid} where id=#{id}")
    void update(Qcc_assessment_history qccAssHistory)throws Exception;

    @Select("select * from qcc_assessment_history where id=#{id}")
    Qcc_assessment_history findById(int id)throws Exception;

    @Select("select * from qcc_assessment_history")
    Qcc_assessment_history findAll()throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 根据作业种类，单位代码，认定日期去历史档中查询数据
     * @Date  2020/4/15
     * @Time  下午 08:23
     **/
    @Select("select * from qcc_assessment_history where educate_type=#{educate_type} and workplace_code=#{workplace_code} and confirm_date_of_1=#{confirm_date_of_1} and employee_id=#{employee_id}")
    Qcc_assessment_history findByEduTyAndWorCoAndConFiAndEmpId(@Param("educate_type") String eduT, @Param("workplace_code") String workC, @Param("confirm_date_of_1") String conF,@Param("employee_id") String empId);
}
