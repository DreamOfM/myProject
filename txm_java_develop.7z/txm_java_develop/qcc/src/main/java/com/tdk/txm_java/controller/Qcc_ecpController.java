package com.tdk.txm_java.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tdk.txm_java.domain.Qcc_ecp;
import com.tdk.txm_java.domain.ResultInfo;
import com.tdk.txm_java.service.IQcc_eapService;
import com.tdk.txm_java.service.IQcc_ecpService;
import com.tdk.txm_java.utils.JsonUtil;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

/**
 * @author : Yu Liqin
 * @ProjectName<h3>txm_java_0304</h3>
 * @ClassName<h4></h4>
 * @ToDo<p>作業系統控制檔維護</p>
 * @date : 2020-03-11 10:12
 * @version:1.0
 **/
@Controller
@RequestMapping("/qcc_ecp")
public class Qcc_ecpController {
    @Autowired
    private IQcc_ecpService iQccEcpService;
    @Autowired
    private IQcc_eapService iQccEapService;

    /**
     * @Author Yu Liqin
     * @Description 密码在数据库中是否存在
     * @Date 2020/3/12
     **/
    @RequestMapping("/check.do")
    public void check(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        //取到前端传回来的educate_type,educate_type_name
        String password_code = request.getParameter("password_code").toUpperCase();
        //判断种类代码在数据库中是否存在
        if (iQccEcpService.findByPassC(password_code) != null) {
            info.setErrorMsg("密码已存在，请重新输入");
            info.setFlag(false);
        }
        //响应数据
        JsonUtil.writeValue(info,response);
    }
    /**
     * @Author Wang FengCai
     * @Description 保存-检查
     * @Date  2020/3/27
     **/
    @RequestMapping("/check01.do")
    public void check01(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        List<Qcc_ecp> qccEcps = new ArrayList<Qcc_ecp>();
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        Qcc_ecp qccEcp = new Qcc_ecp();
        int b = 0;   //第几笔记录
        int c = 0;   //total
        while (true) {
            //一条数据
            for (String name : set) {
                String[] vals = (String[]) map.get(name);
                c = vals.length;
                hashMap.put(name, vals[b]);
            }
            //判断
            if (hashMap.get("password_code").equals(null) || "".equals(hashMap.get("password_code"))) {
                b++;
                if (b == c) {
                    break;
                }
                continue;
            }
            //记录当前记录行
            String errLine = String.valueOf(b);
            //取出单位代码FROM TO
            String workplace_code1 = hashMap.get("workplace_code_from").toUpperCase();
            String workplace_code2 = hashMap.get("workplace_code_to").toUpperCase();
            //取出作业种类
            String educate_type1 = hashMap.get("educate_type_from").toUpperCase();
            String educate_type2 = hashMap.get("educate_type_to").toUpperCase();
            if(workplace_code1.compareTo(workplace_code2)>0) {
                info.setErrorMsg("单位代码不合规，请确认");
                errorList.add("workplace_code_from" + errLine);
                errorList.add("workplace_code_to" + errLine);
                info.setFlag(false);
            }
            if(educate_type1.compareTo(educate_type2)>0){
                info.setErrorMsg("作业种类不合规，请确认");
                errorList.add("educate_type_from" + errLine);
                errorList.add("educate_type_to" + errLine);
                info.setFlag(false);
            }else{
                if (iQccEapService.findByEduTyp1(educate_type1) == null) {
                    info.setErrorMsg("作业种类不存在，请确认");
                    errorList.add("educate_type_from" + errLine);
                    info.setFlag(false);
                }
                if (iQccEapService.findByEduTyp1(educate_type2) == null) {
                    info.setErrorMsg("作业种类不存在，请确认");
                    errorList.add("educate_type_to" + errLine);
                    info.setFlag(false);
                }
            }

            b++;
            if (b == c) {
                break;
            }
        }
        info.setErrorList(errorList);
        info.setData(qccEcps);

        //响应数据
        JsonUtil.writeValue(info,response);
    }

    /**
     * @Author Wang FengCai
     * @Description 根据密码查询-检查密码是否存在
     * @Date 2020/3/27
     **/
    @RequestMapping("/check02.do")
    public void check02(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        //取到前端传回来的password_code
        String password_code = request.getParameter("password_code");
        //判断种类代码在数据库中是否存在
        if (iQccEcpService.findByPassC(password_code) == null) {
            info.setErrorMsg("密码不存在，请重新输入");
            info.setFlag(false);
        }
        //响应数据
        JsonUtil.writeValue(info,response);
    }


    /**
     * @Author Yu Liqin
     * @Description 根据密码查询
     * @Date 2020/3/11
     **/
    @RequestMapping("/findByPassCode.do")
    public ModelAndView findByPassCode(@RequestParam(value = "pn", defaultValue = "1") Integer pn, @RequestParam(value = "PageSize", defaultValue = "15") Integer ps, HttpServletRequest request) throws Exception {
        //查询之前需要调用,,传入页码，以及每页的大小
        PageHelper.startPage(pn, ps);
        //取出前端传回的数据
        String password_code = request.getParameter("password_code")+"%";
        //调用业层的方法查询
        List<Qcc_ecp> qccEcpList = iQccEcpService.findByPassCode(password_code);
        //创建视图对象
        ModelAndView modelAndView = new ModelAndView();
        //使用addObject()设置需要返回的值
        modelAndView.addObject("qccEcpList", qccEcpList);
        PageInfo page = new PageInfo(qccEcpList, ps);
        modelAndView.addObject("pageInfo", page);
        //通过setViewName()方法跳转到指定的页面
        modelAndView.setViewName("qcc-ecp-list");
        //返回视图解析对象
        return modelAndView;
    }

    /**
     * @Author Yu Liqin
     * @Description 修改
     * @Date 2020/3/11
     **/
    @RequestMapping("/update.do")
    public void update(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws
            Exception {
        //取出前端传回的所有数据
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        String username = (String) session.getAttribute("username");
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //将每一个key值对应的一组值放到数组里去
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                hashMap.put(name1, vals[b]);
            }
            //如果取出的 password_code为空，则不往数据库里插入数据
            if (hashMap.get("password_code").equals(null) || "".equals(hashMap.get("password_code"))) {
                b++;
                if (b == c) {
                    break;
                }
                continue;
            } else {
                //创建对象
                Qcc_ecp qccEcp = new Qcc_ecp();
                //更新的程序
                qccEcp.setUpdate_oid(username);
                qccEcp.setUpdate_program("/qcc_ecp/update");
                try {
                    BeanUtils.populate(qccEcp, hashMap);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    e.printStackTrace();
                }
                //调用业务层的update()方法
                iQccEcpService.update(qccEcp);
            }
            b++;
            if (b == c) {
                break;
            }

        }
        // 响应数据
        JsonUtil.writeValue(info,response);

    }

    /**
     * @Author Yu Liqin
     * @Description 删除
     * @Date 2020/3/12
     **/

    @RequestMapping("/deleteById.do")
    public void deleteById(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws
            Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        String username = (String) session.getAttribute("username");
        //取出前端传回的id
        int id = Integer.parseInt(request.getParameter("id"));
        //调用业务层的方法
        iQccEcpService.deleteById(id);
        // 响应数据
        JsonUtil.writeValue(info,response);
    }

    /**
     * @Author Wang FengCai
     * @Description 增加
     * @Date 2020/3/12
     **/
    @RequestMapping("/save.do")
    public void save(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws
            Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        List<Qcc_ecp> qccEcps = new ArrayList<Qcc_ecp>();
        String username = (String) session.getAttribute("username");
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //将每一个key值对应的一组值放到数组里去
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                hashMap.put(name1, vals[b]);
            }
            //如果取出的 password_code为空，则不往数据库里插入数据
            if (hashMap.get("password_code").equals(null) || hashMap.get("password_code").equals("")) {
                b++;
                if (b == c) {
                    break;
                }
                continue;
            }
            //创建对象
            Qcc_ecp qccEcp = new Qcc_ecp();
            try {
                BeanUtils.populate(qccEcp, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            qccEcp.setLogin_oid(username);
            qccEcp.setUpdate_oid(username);
            qccEcp.setUpdate_program("/qcc_ecp/save.do");
            //调用业务层的save()方法
            iQccEcpService.save(qccEcp);
            b++;
            if (b == c) {
                break;
            }
        }
        // 响应数据
        JsonUtil.writeValue(info,response);
    }


}



