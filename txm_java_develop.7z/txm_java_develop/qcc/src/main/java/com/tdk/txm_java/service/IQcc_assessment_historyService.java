package com.tdk.txm_java.service;

import com.tdk.txm_java.domain.Qcc_assessment_history;
import com.tdk.txm_java.domain.Qcc_edp;
import org.apache.ibatis.annotations.Select;

/**
 * <h3>txm_java_0409</h3>
 * <p>抽樣檢查人員有效評估业务层</p>
 *
 * @author : Wang FengCai
 * @date : 2020-04-13 09:12
 **/

public interface IQcc_assessment_historyService {

    void save(Qcc_assessment_history qccAssHistory) throws Exception;

    void delete(int id)throws Exception;

    void update(Qcc_assessment_history qccAssHistory)throws Exception;

    Qcc_assessment_history findAll()throws Exception;

    Qcc_assessment_history findById(int id)throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 根据作业种类，单位代码，认定日期去历史档查询数据
     * @Date  2020/4/15
     * @Time  下午 08:20
     **/
    Qcc_assessment_history findByEduTyAndWorCoAndConFiAndEmpId(String eduT, String workC, String conF, String empId);
}
