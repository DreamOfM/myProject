package com.tdk.txm_java.domain;

import java.util.Date;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_20200325</h3>
 * @ClassName<h4></h4>
 * @ToDo<p>视力有效性评估</p>
 * @date : 2020-04-08 14:56
 * @version:1.0
 **/
public class Qcc_vision_history {
    private int id;
    private String educate_type;
    private String workplace_code;
    private String employee_id;
    private String confirm_date_of_2;
    private String check_type;
    private Double eye_left;
    private Double eye_right;
    private String confess_data;
    private Date  login_time;
    private String login_oid;
    private Date update_time;
    private String update_oid;
    private String update_program;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEducate_type() {
        return educate_type;
    }

    public void setEducate_type(String educate_type) {
        this.educate_type = educate_type;
    }

    public String getWorkplace_code() {
        return workplace_code;
    }

    public void setWorkplace_code(String workplace_code) {
        this.workplace_code = workplace_code;
    }

    public String getEmployee_id() {
        return employee_id;
    }

    public void setEmployee_id(String employee_id) {
        this.employee_id = employee_id;
    }

    public String getConfirm_date_of_2() {
        return confirm_date_of_2;
    }

    public void setConfirm_date_of_2(String confirm_date_of_2) {
        this.confirm_date_of_2 = confirm_date_of_2;
    }

    public String getCheck_type() {
        return check_type;
    }

    public void setCheck_type(String check_type) {
        this.check_type = check_type;
    }

    public Double getEye_left() {
        return eye_left;
    }

    public void setEye_left(Double eye_left) {
        this.eye_left = eye_left;
    }

    public Double getEye_right() {
        return eye_right;
    }

    public void setEye_right(Double eye_right) {
        this.eye_right = eye_right;
    }

    public String getConfess_data() {
        return confess_data;
    }

    public void setConfess_data(String confess_data) {
        this.confess_data = confess_data;
    }

    public Date getLogin_time() {
        return login_time;
    }

    public void setLogin_time(Date login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public Date getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(Date update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }



    @Override
    public String toString() {
        return "Qcc_vision_history{" +
                "id=" + id +
                ", educate_type='" + educate_type + '\'' +
                ", workplace_code='" + workplace_code + '\'' +
                ", employee_id='" + employee_id + '\'' +
                ", confirm_date='" + confirm_date_of_2 + '\'' +
                ", check_type='" + check_type + '\'' +
                ", eye_left=" + eye_left +
                ", eye_right=" + eye_right +
                ", confess_data='" + confess_data + '\'' +
                ", login_time=" + login_time +
                ", login_oid='" + login_oid + '\'' +
                ", update_time=" + update_time +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                '}';
    }
}
