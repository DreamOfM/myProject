package com.tdk.txm_java.domain;

import java.util.Date;

/**
 * @author : Yu Liqin
 * @ProjectName<h3>txm_java_0304</h3>
 * @ClassName<h4></h4>
 * @ToDo<p>作業系統控制檔維護</p>
 * @date : 2020-03-16 09:12
 * @version:1.0
 **/
public class Qcc_ecp {
    private int id;
    //受訓作業種類
    private  String  password_code;
    //单位代码from
    private  String  workplace_code_from;
    //单位代码 to
    private  String  workplace_code_to;
    //受訓作業種類 from
    private  String educate_type_from;
    //受訓作業種類 to
    private  String educate_type_to;
    //登录时间
    private  Date    login_time;
    //更新时间
    private  Date    update_time;
    //更新ID
    private  String  update_oid;
    //更新程序
    private  String  update_program;
    //登录ID
    private  String  login_oid;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPassword_code() {
        return password_code;
    }

    public void setPassword_code(String password_code) {
        this.password_code = password_code;
    }

    public String getWorkplace_code_from() {
        return workplace_code_from;
    }

    public void setWorkplace_code_from(String workplace_code_from) {
        this.workplace_code_from = workplace_code_from;
    }

    public String getWorkplace_code_to() {
        return workplace_code_to;
    }

    public void setWorkplace_code_to(String workplace_code_to) {
        this.workplace_code_to = workplace_code_to;
    }

    public String getEducate_type_from() {
        return educate_type_from;
    }

    public void setEducate_type_from(String educate_type_from) {
        this.educate_type_from = educate_type_from;
    }

    public String getEducate_type_to() {
        return educate_type_to;
    }

    public void setEducate_type_to(String educate_type_to) {
        this.educate_type_to = educate_type_to;
    }

    public Date getLogin_time() {
        return login_time;
    }

    public void setLogin_time(Date login_time) {
        this.login_time = login_time;
    }

    public Date getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(Date update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public Qcc_ecp() {
    }

    @Override
    public String toString() {
        return "Qcc_ecp{" +
                "id=" + id +
                ", password_code='" + password_code + '\'' +
                ", workplace_code_from='" + workplace_code_from + '\'' +
                ", workplace_code_to='" + workplace_code_to + '\'' +
                ", educate_type_from='" + educate_type_from + '\'' +
                ", educate_type_to='" + educate_type_to + '\'' +
                ", login_time=" + login_time +
                ", update_time=" + update_time +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                ", login_oid='" + login_oid + '\'' +
                '}';
    }
}
