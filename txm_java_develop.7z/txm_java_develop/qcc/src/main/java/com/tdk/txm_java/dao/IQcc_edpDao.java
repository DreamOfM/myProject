package com.tdk.txm_java.dao;

import com.tdk.txm_java.domain.Qcc_edp;
import com.tdk.txm_java.domain.Qcc_getParmeter;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <h3>txm_java_0304</h3>
 * <p>受训人员基本资料维护</p>
 *
 * @author : Wang FengCai
 * @date : 2020-03-11 09:07
 **/
@Repository
public interface IQcc_edpDao {
    /**
     * @return void
     * @Author Wang FengCai
     * @Description 增加
     * @Date 2020/3/16
     * @Time 上午 09:23
     * @Param [qcc_edp]
     **/
    @Insert("insert into qcc_edp(educate_type,workplace_code,employee_id,date_of_induction,date_of_departure,date_of_vacation,skill_development,job_evaluation,manufature_lore_one,manufature_lore_two,standard_work_one,standard_work_two,exoterica_educate_one,exoterica_educate_two ,eligibility_no,eligibility_status,confirm_date ,qa_manager_confirm,assess_of_1 ,qc_confirm_of_1 ,assess_of_2 ,qc_confirm_of_2,assess_of_3,qc_confirm_of_3,login_time,update_time,update_oid,update_program,login_oid) values" +
            "(#{educate_type},#{workplace_code},#{employee_id},#{date_of_induction},#{date_of_departure},#{date_of_vacation},#{skill_development},#{job_evaluation},#{manufature_lore_one},#{manufature_lore_two},#{standard_work_one},#{standard_work_two},#{exoterica_educate_one},#{exoterica_educate_two},#{eligibility_no},#{eligibility_status},#{confirm_date},#{qa_manager_confirm},#{assess_of_1},#{qc_confirm_of_1},#{assess_of_2},#{qc_confirm_of_2},#{assess_of_3},#{qc_confirm_of_3},now(),#{update_time},#{update_oid},#{update_program},#{login_oid})")
    void save(Qcc_edp qcc_edp) throws Exception;

    /**
     * @return void
     * @Author Wang FengCai
     * @Description 删除
     * @Date 2020/3/16
     * @Time 上午 09:24
     * @Param [id]
     **/
    @Delete("delete from qcc_edp where id=#{id}")
    void deleteById(int id) throws Exception;

    /**
     * @return void
     * @Author Wang FengCai
     * @Description 修改
     * @Date 2020/3/16
     * @Time 上午 09:24
     * @Param [qcc_edp]
     **/
    @Update("update qcc_edp set educate_type=#{educate_type},workplace_code=#{workplace_code},employee_id=#{employee_id},date_of_induction=#{date_of_induction},date_of_departure=#{date_of_departure},date_of_vacation=#{date_of_vacation},skill_development=#{skill_development},job_evaluation=#{job_evaluation},manufature_lore_one=#{manufature_lore_one},manufature_lore_two=#{manufature_lore_two},standard_work_one=#{standard_work_one},standard_work_two=#{standard_work_two},exoterica_educate_one=#{exoterica_educate_one},exoterica_educate_two=#{exoterica_educate_two},eligibility_no=#{eligibility_no},eligibility_status=#{eligibility_status},confirm_date=#{confirm_date},qa_manager_confirm=#{qa_manager_confirm},assess_of_1=#{assess_of_1},qc_confirm_of_1=#{qc_confirm_of_1},assess_of_2=#{assess_of_2},qc_confirm_of_2=#{qc_confirm_of_2},assess_of_3=#{assess_of_3},qc_confirm_of_3=#{qc_confirm_of_3},update_program=#{update_program},update_oid=#{update_oid} where id=#{id}")
    void update(Qcc_edp qcc_edp) throws Exception;

    /**
     * @return com.tdk.txm_java.domain.Qcc_edp
     * @Author Wang FengCai
     * @Description 查询所有
     * @Date 2020/3/16
     * @Time 上午 09:24
     * @Param []
     **/
    @Select("select id, educate_type,workplace_code,employee_id,date_of_induction,date_of_departure,date_of_vacation,skill_development,job_evaluation,manufature_lore_one,manufature_lore_two,standard_work_one,standard_work_two,exoterica_educate_one,exoterica_educate_two ,eligibility_no,eligibility_status,confirm_date ,qa_manager_confirm,assess_of_1 ,qc_confirm_of_1 ,assess_of_2 ,qc_confirm_of_2,assess_of_3,qc_confirm_of_3 from qcc_edp order by employee_id")
    List<Qcc_edp> findAll() throws Exception;

    /**
     * @return com.tdk.txm_java.domain.Qcc_edp
     * @Author Wang FengCai
     * @Description 根据ID查询
     * @Date 2020/3/16
     * @Time 上午 09:25
     * @Param [id]
     **/
    @Select("select id, educate_type,workplace_code,employee_id,date_of_induction,date_of_departure,date_of_vacation,skill_development,job_evaluation,manufature_lore_one,manufature_lore_two,standard_work_one,standard_work_two,exoterica_educate_one,exoterica_educate_two ,eligibility_no,eligibility_status,confirm_date ,qa_manager_confirm,assess_of_1 ,qc_confirm_of_1 ,assess_of_2 ,qc_confirm_of_2,assess_of_3,qc_confirm_of_3 from qcc_edp where id=#{id}")
    Qcc_edp findById(int id) throws Exception;

    /**
     * @return java.util.List<com.tdk.txm_java.domain.Qcc_edp>
     * @Author Wang FengCai
     * @Description 根据作业种类和单位代码查找
     * @Date 2020/3/16
     * @Time 下午 01:51
     * @Param [educateType, workplaceCode]
     **/
    @Select("select id, educate_type,workplace_code,employee_id,date_of_induction,date_of_departure,date_of_vacation,skill_development,job_evaluation,manufature_lore_one,manufature_lore_two,standard_work_one,standard_work_two,exoterica_educate_one,exoterica_educate_two ,eligibility_no,eligibility_status,confirm_date ,qa_manager_confirm,assess_of_1 ,qc_confirm_of_1 ,assess_of_2 ,qc_confirm_of_2,assess_of_3,qc_confirm_of_3 from qcc_edp where educate_type=#{educate_type} and workplace_code=#{workplace_code} order by employee_id")
    List<Qcc_edp> findByEduTypAndWorC(@Param("educate_type") String educateType, @Param("workplace_code") String workplaceCode);

    /**
     * @return java.util.List<com.tdk.txm_java.domain.Qcc_edp>
     * @Author Wang FengCai
     * @Description 根据作业种类和单位代码查找——QC成绩维护
     * @Date 2020/3/21
     * @Time 下午 03:49
     * @Param [educateType, workplaceCode]
     **/
    @Select("select id, educate_type,workplace_code,employee_id,date_of_induction,date_of_departure,date_of_vacation,skill_development,job_evaluation,manufature_lore_one,manufature_lore_two,standard_work_one,standard_work_two,exoterica_educate_one,exoterica_educate_two ,eligibility_no,eligibility_status,confirm_date ,qa_manager_confirm,assess_of_1 ,qc_confirm_of_1 ,assess_of_2 ,qc_confirm_of_2,assess_of_3,qc_confirm_of_3 from qcc_edp where educate_type=#{educate_type} and workplace_code=#{workplace_code} and date_of_departure is null order by employee_id")
    List<Qcc_edp> findByEduTypAndWorCQc(@Param("educate_type") String educateType, @Param("workplace_code") String workplaceCode);


    /**
     * @return com.tdk.txm_java.domain.Qcc_edp
     * @Author Wang FengCai
     * @Description 根据工号查询
     * @Date 2020/3/23
     * @Time 上午 09:20
     * @Param [employeeId]
     **/
    @Select("select id, educate_type,workplace_code,employee_id,date_of_induction,date_of_departure,date_of_vacation,skill_development,job_evaluation,manufature_lore_one,manufature_lore_two,standard_work_one,standard_work_two,exoterica_educate_one,exoterica_educate_two ,eligibility_no,eligibility_status,confirm_date ,qa_manager_confirm,assess_of_1 ,qc_confirm_of_1 ,assess_of_2 ,qc_confirm_of_2,assess_of_3,qc_confirm_of_3 from qcc_edp where employee_id=#{employeeId} and date_of_departure is null")
    Qcc_edp findByEmpI(String employeeId);


    /**
     * @return com.tdk.txm_java.domain.Qcc_edp
     * @Author Wang FengCai
     * @Description 根据作业种类，单位代码，工号来查询
     * @Date 2020/3/24
     * @Time 下午 01:24
     * @Param [educate_type, workplace_code, employee_id]
     **/
    @Select("select id, educate_type,workplace_code,employee_id,date_of_induction,date_of_departure,date_of_vacation,skill_development,job_evaluation,manufature_lore_one,manufature_lore_two,standard_work_one,standard_work_two,exoterica_educate_one,exoterica_educate_two ,eligibility_no,eligibility_status,confirm_date ,qa_manager_confirm,assess_of_1 ,qc_confirm_of_1 ,assess_of_2 ,qc_confirm_of_2,assess_of_3,qc_confirm_of_3 from qcc_edp where educate_type=#{educate_type} and workplace_code=#{workplace_code} and employee_id=#{employee_id} and date_of_departure is null")
    Qcc_edp findByEduTypAndWorCAndEmpI(@Param("educate_type") String educate_type, @Param("workplace_code") String workplace_code, @Param("employee_id") String employee_id);

    /**
     * @return java.lang.String
     * @Author Wang FengCai
     * @Description 查询合格牌号是否重复
     * @Date 2020/3/25
     * @Time 下午 01:25
     * @Param [el]
     **/
    @Select("select eligibility_no,employee_id from qcc_edp where eligibility_no=#{eligibility_no}")
    Qcc_edp findAllByEl(String el);

    /**
     * @return java.util.List<com.tdk.txm_java.domain.Qcc_edp>
     * @Author Wang FengCai
     * @Description 根据种类代码和单位代码查找——技能有效性认定
     * @Date 2020/3/25
     * @Time 下午 02:55
     * @Param [educateType, workplaceCode]
     **/
    @Select("select id, educate_type,workplace_code,employee_id,date_of_induction,date_of_departure,skill_development,date_of_vacation,job_evaluation,manufature_lore_one,manufature_lore_two,standard_work_one,standard_work_two,exoterica_educate_one,exoterica_educate_two ,eligibility_no,eligibility_status,confirm_date ,qa_manager_confirm,assess_of_1 ,qc_confirm_of_1 ,assess_of_2 ,qc_confirm_of_2,assess_of_3,qc_confirm_of_3 from qcc_edp where educate_type=#{educate_type} and workplace_code=#{workplace_code} and qa_manager_confirm='1' and confirm_date is not null and date_of_departure  is null  order by employee_id ")
    List<Qcc_edp> findByEduTypAndWorcEC(@Param("educate_type") String educateType, @Param("workplace_code") String workplaceCode);

    /**
     * @return java.util.List<com.tdk.txm_java.domain.Qcc_edp>
     * @Author Wang FengCai
     * @Description 根据单位代码查询
     * @Date 2020/4/3
     * @Time 上午 10:39
     * @Param [workplace_code]
     **/
    @Select("select id, educate_type,workplace_code,employee_id,date_of_induction,date_of_departure,date_of_vacation,skill_development,job_evaluation,manufature_lore_one,manufature_lore_two,standard_work_one,standard_work_two,exoterica_educate_one,exoterica_educate_two ,eligibility_no,eligibility_status,confirm_date ,qa_manager_confirm,assess_of_1 ,qc_confirm_of_1 ,assess_of_2 ,qc_confirm_of_2,assess_of_3,qc_confirm_of_3 from qcc_edp where workplace_code=#{workplace_code}")
    List<Qcc_edp> findByWoc(String workplace_code);

    /**
     * @return java.util.List<com.tdk.txm_java.domain.Qcc_edp>
     * @Author Wang FengCai
     * @Description 根据工号查询---基本资料维护新增
     * @Date 2020/4/8
     * @Time 上午 10:33
     * @Param [employee_id]
     **/
    @Select("select id, educate_type,workplace_code,employee_id,date_of_induction,date_of_departure,date_of_vacation,skill_development,job_evaluation,manufature_lore_one,manufature_lore_two,standard_work_one,standard_work_two,exoterica_educate_one,exoterica_educate_two ,eligibility_no,eligibility_status,confirm_date ,qa_manager_confirm,assess_of_1 ,qc_confirm_of_1 ,assess_of_2 ,qc_confirm_of_2,assess_of_3,qc_confirm_of_3 from qcc_edp where employee_id=#{employee_id}")
    List<Qcc_edp> findByEmpI_1(String employee_id);

    /**
     * @Author Wang FengCai
     * @Description 重要作业报表
     * @Date 2020/4/28
     * @Time 下午 02:00
     **/
//    @SelectProvider(method = "selectPartner2Edp", type = Qcc_InventoryDaoP.class)
//    List<Qcc_edp> findDatapool2Edp(Qcc_getParmeter qccGetParmeter);

  @Select("select educate_type,workplace_code,employee_id,date_of_induction,date_of_departure,date_of_vacation,skill_development," +
          "job_evaluation,manufature_lore_one,manufature_lore_two,standard_work_one,standard_work_two," +
          "exoterica_educate_one,exoterica_educate_two ,eligibility_no,eligibility_status,confirm_date ," +
          "qa_manager_confirm,assess_of_1 ,qc_confirm_of_1 ,assess_of_2 ,qc_confirm_of_2,assess_of_3," +
          "qc_confirm_of_3  FROM qcc_edp WHERE " +
          "(educate_type BETWEEN #{educate_type1} AND #{educate_type2} ) " +
          "and (workplace_code BETWEEN #{workplace_code1} AND #{workplace_code2}) " +
          "and (date_of_induction BETWEEN #{date_of_induction1} AND #{date_of_induction2}) " +
          "and (skill_development BETWEEN #{skill_development1} AND #{skill_development2})" +
          "and (job_evaluation BETWEEN #{job_evaluation1} AND #{job_evaluation2})" +
          "and (manufature_lore_one BETWEEN #{manufacture_lore_one1} AND #{manufacture_lore_one2}) " +
          "and (manufature_lore_two BETWEEN #{manufacture_lore_two1} AND #{manufacture_lore_two2})" +
          "and (standard_work_one BETWEEN #{standard_work_one1} AND #{standard_work_one2})" +
          "and (standard_work_two BETWEEN #{standard_work_two1} AND #{standard_work_two2})" +
          "and (exoterica_educate_one BETWEEN #{exoterica_educate_one1} AND #{exoterica_educate_one2})" +
          "and (exoterica_educate_two BETWEEN #{exoterica_educate_two1} AND #{exoterica_educate_two2})" +
          "order by educate_type,workplace_code, employee_id")
  List<Qcc_edp> findDatapool2Edp(Qcc_getParmeter qccGetParmeter);

    /**
     * @Author Wang FengCai
     * @Description 根据工号查询作业种类等信息
     * @Date 2020/5/7
     * @Time 上午 09:06
     **/
    @Select("select id, educate_type,workplace_code,employee_id,date_of_induction,date_of_vacation,date_of_departure,skill_development,job_evaluation,manufature_lore_one,manufature_lore_two,standard_work_one,standard_work_two,exoterica_educate_one,exoterica_educate_two ,eligibility_no,eligibility_status,confirm_date ,qa_manager_confirm,assess_of_1 ,qc_confirm_of_1 ,assess_of_2 ,qc_confirm_of_2,assess_of_3,qc_confirm_of_3 from qcc_edp where employee_id = #{employee_id}")
    List<Qcc_edp> findByEmpId(String emplyeeId);

    /**
     * @Author Wang FengCai
     * @Description 根据工号和作业种类去查询
     * @Date  2020/5/8
     * @Time  下午 02:28
     **/
    @Select("select * from qcc_edp where employee_id=#{employee_id} and educate_type=#{educate_type} and date_of_departure is null ")
    Qcc_edp findByEmpIdAndEduTyp(@Param("employee_id") String employee_id,@Param("educate_type") String educateTpye);

    /**
     * @Author Wang FengCai
     * @Description 根据工号，合格牌号，作业种类来查询
     * @Date 2020/7/27
     * @Time 上午 10:36
     */
    @Select("select * from qcc_edp where educate_type=#{educate_type} and eligibility_no=#{eligibility_no}")
    List<Qcc_edp> findByEduTypAndEl(@Param("educate_type") String educate_type,@Param("eligibility_no") String el);
}
