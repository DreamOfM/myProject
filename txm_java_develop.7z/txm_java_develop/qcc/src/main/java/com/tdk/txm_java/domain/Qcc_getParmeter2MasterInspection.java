package com.tdk.txm_java.domain;
/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_1225</h3>
 * @ClassName<h4></h4>
 * @ToDo<p></p>
 * @date : 2020-01-07 16:00
 * @version:1.0
 **/
public class Qcc_getParmeter2MasterInspection {
    private int id;
    private String educate_type1;
    private String educate_type2;
    private String workplace_code1;
    private String workplace_code2;
    //上岗日期
    private String date_of_induction1;
    private String date_of_induction2;
    //技能实习
    private String skill_development1;
    private String skill_development2;
    //作业训练评定
    private String job_evaluation1;
    private String job_evaluation2;
    //检出力
    private String identify_ability1;
    private String identify_ability2;
    //抽样/仪器教育
    private String sampling_principle1;
    private String sampling_principle2;
    //作业教育
    private String operation_education1;
    private String operation_education2;
    //制品知识
    private String product_knowledge1;
    private String product_knowledge2;
    //合格牌号
    private String eligibility_no1;
    private String eligibility_no2;
    //印章编号
    private String stamp_serial_no1;
    private String stamp_serial_no2;
    //合格認定日
    private String confirm_date1;
    private String confirm_date2;
    //最后评估日
    private String confirm_date_of_one1;
    private String confirm_date_of_one2;
    //特例
    private String special;
    //报表样式
    private String dataPoolModel;


    public Qcc_getParmeter2MasterInspection() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEducate_type1() {

        return educate_type1;
    }

    public void setEducate_type1(String educate_type1) {
        if(educate_type1==null||"".equals(educate_type1)){
            educate_type1="0000";
        }
        this.educate_type1 = educate_type1;
    }

    public String getEducate_type2() {

        return educate_type2;
    }

    public void setEducate_type2(String educate_type2) {
        if(educate_type2==null||"".equals(educate_type2)){
            educate_type2="ZZZZ";
        }
        this.educate_type2 = educate_type2;
    }

    public String getWorkplace_code1() {

        return workplace_code1;
    }

    public void setWorkplace_code1(String workplace_code1) {
        if(workplace_code1==null||"".equals(workplace_code1)){
            workplace_code1="0000";
        }
        this.workplace_code1 = workplace_code1;
    }

    public String getWorkplace_code2() {

        return workplace_code2;
    }

    public void setWorkplace_code2(String workplace_code2) {
        if(workplace_code2==null||"".equals(workplace_code2)){
            workplace_code2="ZZZZ";
        }
        this.workplace_code2 = workplace_code2;
    }

    public String getDate_of_induction1() {
        return date_of_induction1;
    }

    public void setDate_of_induction1(String date_of_induction1) {
        if(date_of_induction1 == null||"".equals(date_of_induction1)){
            date_of_induction1 = "1899-12-30";
        }

        this.date_of_induction1 = date_of_induction1;
    }

    public String getDate_of_induction2() {
        return date_of_induction2;
    }

    public void setDate_of_induction2(String date_of_induction2) {
        if(date_of_induction2 == null||"".equals(date_of_induction2)){
            date_of_induction2 = "2999-12-30";
        }
        this.date_of_induction2 = date_of_induction2;
    }

    public String getSkill_development1() {

        return skill_development1;
    }

    public void setSkill_development1(String skill_development1) {
        if(skill_development1 == null||"".equals(skill_development1)){
            skill_development1 = "";
        }
        this.skill_development1 = skill_development1;
    }

    public String getSkill_development2() {

        return skill_development2;
    }

    public void setSkill_development2(String skill_development2) {
        if(skill_development2 == null||"".equals(skill_development2)){
            skill_development2 = "9999";
        }
        this.skill_development2 = skill_development2;
    }

    public String getJob_evaluation1() {

        return job_evaluation1;
    }

    public void setJob_evaluation1(String job_evaluation1) {
        if(job_evaluation1 == null||"".equals(job_evaluation1)){
            job_evaluation1 = "";
        }
        this.job_evaluation1 = job_evaluation1;
    }

    public String getJob_evaluation2() {

        return job_evaluation2;
    }

    public void setJob_evaluation2(String job_evaluation2) {
        if(job_evaluation2 == null||"".equals(job_evaluation2)){
            job_evaluation2 = "Z";
        }
        this.job_evaluation2 = job_evaluation2;
    }

    public String getEligibility_no1() {

        return eligibility_no1;
    }

    public void setEligibility_no1(String eligibility_no1) {
        if(eligibility_no1 == null||"".equals(eligibility_no1)){
            eligibility_no1 = "";
        }
        this.eligibility_no1 = eligibility_no1;
    }

    public String getEligibility_no2() {

        return eligibility_no2;
    }

    public void setEligibility_no2(String eligibility_no2) {
        if(eligibility_no2 == null||"".equals(eligibility_no2)){
            eligibility_no2 = "9999";
        }
        this.eligibility_no2 = eligibility_no2;
    }


    public String getConfirm_date1() {

        return confirm_date1;
    }

    public void setConfirm_date1(String confirm_date1) {
        if(confirm_date1 == null||"".equals(confirm_date1)){
            confirm_date1 = "";
        }
        this.confirm_date1 = confirm_date1;
    }

    public String getConfirm_date2() {

        return confirm_date2;
    }

    public void setConfirm_date2(String confirm_date2) {
        if(confirm_date2 == null||"".equals(confirm_date2)){
            confirm_date2 = "2999-12-30";
        }
        this.confirm_date2 = confirm_date2;
    }

    public String getIdentify_ability1() {
        return identify_ability1;
    }

    public void setIdentify_ability1(String identify_ability1) {
        if("".equals(identify_ability1)){
            identify_ability1 = "";
        }
        this.identify_ability1 = identify_ability1;
    }

    public String getIdentify_ability2() {
        return identify_ability2;
    }

    public void setIdentify_ability2(String identify_ability2) {
        if("".equals(identify_ability2)){
            identify_ability2 = "9999";
        }
        this.identify_ability2 = identify_ability2;
    }

    public String getSampling_principle1() {
        return sampling_principle1;
    }

    public void setSampling_principle1(String sampling_principle1) {
        if(sampling_principle1 == null||"".equals(sampling_principle1)){
            sampling_principle1 = "";
        }
        this.sampling_principle1 = sampling_principle1;
    }

    public String getSampling_principle2() {
        return sampling_principle2;
    }

    public void setSampling_principle2(String sampling_principle2) {
        if(sampling_principle2 == null||"".equals(sampling_principle2)){
            sampling_principle2 = "9999";
        }
        this.sampling_principle2 = sampling_principle2;
    }

    public String getOperation_education1() {
        return operation_education1;
    }

    public void setOperation_education1(String operation_education1) {
        if(operation_education1 == null||"".equals(operation_education1)){
            operation_education1 = "";
        }
        this.operation_education1 = operation_education1;
    }

    public String getOperation_education2() {
        return operation_education2;
    }

    public void setOperation_education2(String operation_education2) {
        if(operation_education2 == null||"".equals(operation_education2)){
            operation_education2 = "9999";
        }
        this.operation_education2 = operation_education2;
    }

    public String getProduct_knowledge1() {
        return product_knowledge1;
    }

    public void setProduct_knowledge1(String product_knowledge1) {
        if(product_knowledge1 == null||"".equals(product_knowledge1)){
            product_knowledge1 = "";
        }
        this.product_knowledge1 = product_knowledge1;
    }

    public String getProduct_knowledge2() {
        return product_knowledge2;
    }

    public void setProduct_knowledge2(String product_knowledge2) {
        if(product_knowledge2 == null||"".equals(product_knowledge2)){
            product_knowledge2 = "9999";
        }
        this.product_knowledge2 = product_knowledge2;
    }

    public String getStamp_serial_no1() {
        return stamp_serial_no1;
    }

    public void setStamp_serial_no1(String stamp_serial_no1) {
        if(stamp_serial_no1 == null||"".equals(stamp_serial_no1)){
            stamp_serial_no1 = "";
        }
        this.stamp_serial_no1 = stamp_serial_no1;
    }

    public String getStamp_serial_no2() {
        return stamp_serial_no2;
    }

    public void setStamp_serial_no2(String stamp_serial_no2) {
        if(stamp_serial_no2 == null||"".equals(stamp_serial_no2)){
            stamp_serial_no2 = "ZZZZ";
        }
        this.stamp_serial_no2 = stamp_serial_no2;
    }

    public String getConfirm_date_of_one1() {
        return confirm_date_of_one1;
    }

    public void setConfirm_date_of_one1(String confirm_date_of_one1) {
        if(confirm_date_of_one1 == null||"".equals(confirm_date_of_one1)){
            confirm_date_of_one1 = null;
        }
        this.confirm_date_of_one1 = confirm_date_of_one1;
    }

    public String getConfirm_date_of_one2() {
        return confirm_date_of_one2;
    }

    public void setConfirm_date_of_one2(String confirm_date_of_one2) {
        if(confirm_date_of_one2 == null||"".equals(confirm_date_of_one2)){
            confirm_date_of_one2 = "2899-12-30";
        }
        this.confirm_date_of_one2 = confirm_date_of_one2;
    }

    public String getSpecial() {
        return special;
    }

    public void setSpecial(String special) {
//        if(special == null||"".equals(special)||(!"Y".equals(special)&&!"N".equals(special))){
//            special = "";
//        }
        this.special = special;
    }

    public String getDataPoolModel() {
        return dataPoolModel;
    }

    public void setDataPoolModel(String dataPoolModel) {
        this.dataPoolModel = dataPoolModel;
    }

    @Override
    public String toString() {
        return "Qcc_getParmeter2MasterInspection{" +
                "id=" + id +
                ", educate_type1='" + educate_type1 + '\'' +
                ", educate_type2='" + educate_type2 + '\'' +
                ", workplace_code1='" + workplace_code1 + '\'' +
                ", workplace_code2='" + workplace_code2 + '\'' +
                ", date_of_induction1='" + date_of_induction1 + '\'' +
                ", date_of_induction2='" + date_of_induction2 + '\'' +
                ", skill_development1='" + skill_development1 + '\'' +
                ", skill_development2='" + skill_development2 + '\'' +
                ", job_evaluation1='" + job_evaluation1 + '\'' +
                ", job_evaluation2='" + job_evaluation2 + '\'' +
                ", identify_ability1='" + identify_ability1 + '\'' +
                ", identify_ability2='" + identify_ability2 + '\'' +
                ", sampling_principle1='" + sampling_principle1 + '\'' +
                ", sampling_principle2='" + sampling_principle2 + '\'' +
                ", operation_education1='" + operation_education1 + '\'' +
                ", operation_education2='" + operation_education2 + '\'' +
                ", product_knowledge1='" + product_knowledge1 + '\'' +
                ", product_knowledge2='" + product_knowledge2 + '\'' +
                ", eligibility_no1='" + eligibility_no1 + '\'' +
                ", eligibility_no2='" + eligibility_no2 + '\'' +
                ", stamp_serial_no1='" + stamp_serial_no1 + '\'' +
                ", stamp_serial_no2='" + stamp_serial_no2 + '\'' +
                ", confirm_date1='" + confirm_date1 + '\'' +
                ", confirm_date2='" + confirm_date2 + '\'' +
                ", confirm_date_of_one1='" + confirm_date_of_one1 + '\'' +
                ", confirm_date_of_one2='" + confirm_date_of_one2 + '\'' +
                ", special='" + special + '\'' +
                ", dataPoolModel='" + dataPoolModel + '\'' +
                '}';
    }
}
