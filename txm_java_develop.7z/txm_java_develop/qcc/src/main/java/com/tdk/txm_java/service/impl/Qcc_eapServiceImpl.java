package com.tdk.txm_java.service.impl;

import com.tdk.txm_java.dao.IQcc_eapDao;
import com.tdk.txm_java.domain.Qcc_eap;
import com.tdk.txm_java.service.IQcc_eapService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_0304</h3>
 * @ClassName<h4></h4>
 * @ToDo<p>受训作业职种维护</p>
 * @date : 2020-03-11 10:04
 * @version:1.0
 **/
@Service
@Transactional
public class Qcc_eapServiceImpl implements IQcc_eapService {
    @Autowired
    private IQcc_eapDao iQccEapDao;

    /**
     * @Author Wang FengCai
     * @Description 增加
     * @Date  2020/3/11
     * @Time  上午 10:05
     * @Param [qcc_eap]
     * @return void
     **/
    @Override
    public void save(Qcc_eap qcc_eap) throws Exception {
        //小写转换成大写
        qcc_eap.setEducate_type(qcc_eap.getEducate_type().toUpperCase());
        qcc_eap.setLogin_oid(qcc_eap.getLogin_oid().toUpperCase());
        qcc_eap.setUpdate_oid(qcc_eap.getUpdate_oid());
        iQccEapDao.save(qcc_eap);
    }

    /**
     * @Author Wang FengCai
     * @Description 删除
     * @Date  2020/3/11
     * @Time  上午 10:06
     * @Param [id]
     * @return void
     **/
    @Override
    public void deleteById(int id) throws Exception {
        iQccEapDao.deleteById(id);
    }

    /**
     * @Author Wang FengCai
     * @Description 更新
     * @Date  2020/3/11
     * @Time  上午 10:06
     * @Param [qcc_eap]
     * @return void
     **/
    @Override
    public void update(Qcc_eap qcc_eap) throws Exception {
        //转换成大写
        qcc_eap.setEducate_type(qcc_eap.getEducate_type().toUpperCase());
        qcc_eap.setUpdate_oid(qcc_eap.getUpdate_oid());
        iQccEapDao.update(qcc_eap);
    }

    /**
     * @Author Wang FengCai
     * @Description 查找所有
     * @Date  2020/3/11
     * @Time  上午 10:06
     * @Param []
     * @return void
     **/
    @Override
    public Qcc_eap findAll() throws Exception {
        return iQccEapDao.findAll();
    }

    /**
     * @Author Wang FengCai
     * @Description 根据ID查询
     * @Date  2020/3/11
     * @Time  上午 10:06
     * @Param [id]
     * @return void
     **/
    @Override
    public Qcc_eap findById(int id) throws Exception {
        return iQccEapDao.findById(id);
    }

    /**
     * @Author Wang FengCai
     * @Description 根据作业种类查询
     * @Date  2020/3/11
     * @Time  上午 11:15
     * @Param [educateType]
     * @return com.tdk.txm_java.domain.Qcc_eap
     **/
    @Override
    public List<Qcc_eap> findByEduTyp(String educateType) throws Exception {
        //将前端传的值转换成大写
        educateType = educateType.toUpperCase();
        return iQccEapDao.findByEduTyp(educateType);
    }

    /**
     * @Author Wang FengCai
     * @Description 根据种类代码去数据库查询是否存在
     * @Date  2020/3/12
     * @Time  上午 11:55
     * @Param [educate_type]
     * @return boolean
     **/
    @Override
    public Qcc_eap findByEduTyp1(String educate_type) {
        //转成大写
        educate_type.toUpperCase();
        return iQccEapDao.findByEduTyp1(educate_type);
    }
}
