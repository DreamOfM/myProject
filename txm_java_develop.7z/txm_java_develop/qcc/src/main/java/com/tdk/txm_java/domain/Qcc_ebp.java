package com.tdk.txm_java.domain;

import java.util.Date;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_0304</h3>
 * @ClassName<h4></h4>
 * @ToDo<p>受训作业单位代码维护</p>
 * @date : 2020-03-12 16:50
 * @version:1.0
 **/
public class Qcc_ebp {
    //ID
    private int id;
    //受訓作業種類
    private  String educate_type;
    //單位代號
    private  String workplace_code;
    //部門代號
    private  String dept_code;
    //課別名稱
    private  String section_code;
    //股別名稱
    private  String assistant_code;
    //組別名稱
    private  String group_code;
    //工程名稱
    private  String work_center;
    //登录时间
    private  Date   login_time;
    //更新时间
    private  Date   update_time;
    //更新ID
    private  String update_oid;
    //更新程序
    private  String update_program;
    //登录ID
    private  String login_oid;

    public Qcc_ebp() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEducate_type() {
        return educate_type;
    }

    public void setEducate_type(String educate_type) {
        this.educate_type = educate_type;
    }

    public String getWorkplace_code() {
        return workplace_code;
    }

    public void setWorkplace_code(String workplace_code) {
        this.workplace_code = workplace_code;
    }

    public String getDept_code() {
        return dept_code;
    }

    public void setDept_code(String dept_code) {
        this.dept_code = dept_code;
    }

    public String getSection_code() {
        return section_code;
    }

    public void setSection_code(String section_code) {
        this.section_code = section_code;
    }

    public String getAssistant_code() {
        return assistant_code;
    }

    public void setAssistant_code(String assistant_code) {
        this.assistant_code = assistant_code;
    }

    public String getGroup_code() {
        return group_code;
    }

    public void setGroup_code(String group_code) {
        this.group_code = group_code;
    }

    public String getWork_center() {
        return work_center;
    }

    public void setWork_center(String work_center) {
        this.work_center = work_center;
    }

    public Date getLogin_time() {
        return login_time;
    }

    public void setLogin_time(Date login_time) {
        this.login_time = login_time;
    }

    public Date getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(Date update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    @Override
    public String toString() {
        return "Qcc_ebp{" +
                "id=" + id +
                ", educate_type='" + educate_type + '\'' +
                ", workplace_code='" + workplace_code + '\'' +
                ", dept_code='" + dept_code + '\'' +
                ", section_code='" + section_code + '\'' +
                ", assistant_code='" + assistant_code + '\'' +
                ", group_code='" + group_code + '\'' +
                ", work_center='" + work_center + '\'' +
                ", login_time=" + login_time +
                ", update_time=" + update_time +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                ", login_oid='" + login_oid + '\'' +
                '}';
    }
}
