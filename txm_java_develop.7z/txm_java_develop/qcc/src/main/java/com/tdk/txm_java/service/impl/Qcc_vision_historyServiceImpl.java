package com.tdk.txm_java.service.impl;

import com.tdk.txm_java.dao.IQcc_vision_historyDao;
import com.tdk.txm_java.domain.Qcc_vision_history;
import com.tdk.txm_java.service.IQcc_vision_historyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_0409</h3>
 * @ClassName<h4></h4>
 * @ToDo<p>檢查人員視力有效性評估业务层实现类</p>
 * @date : 2020-04-13 09:27
 * @version:1.0
 **/
@Service
@Transactional
public class Qcc_vision_historyServiceImpl implements IQcc_vision_historyService {
    @Autowired
    private IQcc_vision_historyDao iQccVisHistoryDao;

    @Override
    public void save(Qcc_vision_history qccVisHistory) throws Exception {
        //TODO 转换大写
        iQccVisHistoryDao.save(qccVisHistory);
    }


    @Override
    public Qcc_vision_history findByEduTypAndWorEmD(String educateType, String workplaceCode,String employee_id,String confirm_date) throws Exception {
        educateType.toUpperCase();
        workplaceCode.toUpperCase();
        return iQccVisHistoryDao.findByEduTypAndWorEmD(educateType,workplaceCode,employee_id,confirm_date);
    }
}
