package com.tdk.txm_java.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tdk.txm_java.domain.*;
import com.tdk.txm_java.exception.SysException;
import com.tdk.txm_java.service.*;
import com.tdk.txm_java.utils.JsonUtil;
import com.tdk.txm_java.utils.DateUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_0304</h3>
 * @ClassName<h4></h4>
 * @ToDo<p>受训人员基本资料维护</p>
 * @date : 2020-03-16 13:12
 * @version:1.0
 **/
@Controller
@RequestMapping("/qcc_edp")
public class Qcc_edpController {
    @Autowired
    private IQcc_edpService iQccEdpService;
    @Autowired
    private IQcc_ebpService iQccEbpService;
    @Autowired
    private IQcc_eapService iQccEapService;
    @Autowired
    private IQcc_ecpService iQccEcpService;
    @Autowired
    private ICom_employeeService iComEmployeeService;



    /**
     * @Author Wang FengCai
     * @Description 去表中查询作业种类和单位代码对应的中文信息
     * @Date 2020/5/15
     * @Time 下午 03:55
     **/
    private void findEducateTypeChineseNameAndWorkplaceCodeChineseName(Qcc_edp qccEdp) {
        //去eap中取出作业种类和单位代码对应的中文信息
        qccEdp.setEducateTypeChineseName(iQccEapService.findByEduTyp1(qccEdp.getEducate_type()).getEducate_type_name());
        //去ebp中取出单位代码对应的信息
        qccEdp.setWorkplaceCodeChineseName(iQccEbpService.findByWpCAndEduT(qccEdp.getWorkplace_code(), qccEdp.getEducate_type()).getSection_code() + " " + iQccEbpService.findByWpCAndEduT(qccEdp.getWorkplace_code(), qccEdp.getEducate_type()).getAssistant_code() + " " + iQccEbpService.findByWpCAndEduT(qccEdp.getWorkplace_code(), qccEdp.getEducate_type()).getGroup_code() + " " + iQccEbpService.findByWpCAndEduT(qccEdp.getWorkplace_code(), qccEdp.getEducate_type()).getWork_center());
    }


    @RequestMapping("/check01.do")
    public void check01(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        //取到前端传回来的educate_type,workplace_code
        String educate_type = request.getParameter("educate_type").toUpperCase();
        String workplace_code = request.getParameter("workplace_code").toUpperCase();
        String password_code = request.getParameter("password_code").toUpperCase();
        String work_from = "";
        String work_to = "";
        String educ_from = "";
        String educ_to = "";

        if (educate_type == null || "".equals(educate_type)) {
            info.setErrorMsg("作业种类不能为空，请确认");
            info.setFlag(false);
        } else {
            if (iQccEapService.findByEduTyp1(educate_type) == null || "".equals(iQccEapService.findByEduTyp1(educate_type))) {
                info.setErrorMsg("作业种类不存在，请确认");
                info.setFlag(false);
            }
        }
        //查看权限
        //取出密码对应的单位代码权限范围
        Qcc_ecp qccEcp = iQccEcpService.findByPassCode1(password_code);
        if(qccEcp!=null&&!"".equals(qccEcp)){
            work_from = qccEcp.getWorkplace_code_from().toUpperCase();
            work_to = qccEcp.getWorkplace_code_to().toUpperCase();
            educ_from = qccEcp.getEducate_type_from().toUpperCase();
            educ_to = qccEcp.getEducate_type_to().toUpperCase();
        }

        //判断非空
        if (workplace_code == null || "".equals(workplace_code)) {
            info.setErrorMsg("单位代码不能为空，请确认");
            info.setFlag(false);
        } else {
            //判断单位代码是否存在
            if (iQccEbpService.findByWpCAndEduT(workplace_code, educate_type) != null && !"".equals(iQccEbpService.findByWpCAndEduT(workplace_code, educate_type))) {
                //调用 compareTo()方法比较两个字符串的大小
                if (workplace_code.compareTo(work_from) >= 0 && workplace_code.compareTo(work_to) <= 0 && educate_type.compareTo(educ_from) >= 0 && educate_type.compareTo(educ_to) <= 0) {
                    List<Qcc_edp> qccEdpList = iQccEdpService.findByEduTypAndWorC(educate_type, workplace_code);
                    if(qccEdpList.size()>0){
                        info.setData(qccEdpList);
                        info.setFlag(true);
                    }
                } else {
                    info.setErrorMsg("权限不足，请重新确认");
                    info.setFlag(false);
                }
            } else {
                info.setErrorMsg("单位代码在基础档未维护，请确认");
                info.setFlag(false);
            }
        }


        //响应数据
        JsonUtil.writeValue(info,response);
    }

    @RequestMapping("/check001.do")
    public void check001(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        //取到前端传回来的educate_type,workplace_code
        String educate_type = request.getParameter("educate_type").toUpperCase();
        String workplace_code = request.getParameter("workplace_code").toUpperCase();
        //判断非空
        if (workplace_code == null || "".equals(workplace_code)) {
            info.setErrorMsg("单位代码不能为空，请确认");
            info.setFlag(false);
        }
        if (educate_type == null || "".equals(educate_type)) {
            info.setErrorMsg("作业种类能为空，请确认");
            info.setFlag(false);
        } else {
            if (iQccEbpService.findByWpCAndEduT(workplace_code, educate_type) == null || "".equals(iQccEbpService.findByWpCAndEduT(workplace_code, educate_type))) {
                info.setErrorMsg("单位代码不存在，请确认");
                info.setFlag(false);
            }
        }
        //响应数据
        JsonUtil.writeValue(info,response);
    }

    @RequestMapping("/check02.do")
    public void check02(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        //取到前端传回来的educate_type
        String educate_type = request.getParameter("educate_type").toUpperCase();
        if (educate_type == null || "".equals(educate_type)) {
            info.setErrorMsg("作业种类不能为空，请确认");
            info.setFlag(false);
        } else {
            if (iQccEapService.findByEduTyp1(educate_type) == null) {
                info.setErrorMsg("作业种类不存在，请确认");
                info.setFlag(false);
            }
        }
        //响应数据
        JsonUtil.writeValue(info,response);
    }

    @RequestMapping("/check03.do")
    public void check03(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        List<Qcc_edp> qccEdps = new ArrayList<Qcc_edp>();
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //字段date_to_now(到岗日)，chinese_name(姓名)，date_of_resignation(辞职日)
                if ("date_to_now".equals(name1) || "del".equals(name1) || "num".equals(name1) || "chinese_name".equals(name1) || "date_of_resignation".equals(name1)) {
                    //不做处理
                } else {
                    //将每一个key值对应的一组值放到数组里去
                    String[] vals = (String[]) map.get(name1);
                    c = vals.length;
                    //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                    hashMap.put(name1, vals[b]);
                }
            }

            //记录当前记录行
            String errLine = String.valueOf(b);
            //取出skill_development做判断
            if (hashMap.get("skill_development") == null || "".equals(hashMap.get("skill_development"))) {
                hashMap.put("skill_development", "0");
            } else {
                if (Integer.parseInt(hashMap.get("skill_development")) > 12 || Integer.parseInt(hashMap.get("skill_development")) < 0) {
                    info.setErrorMsg("实习技能的范围为0~12，请确认");
                    errorList.add("skill_development" + errLine);
                    info.setFlag(false);
                }
            }
            //取出job_evaluation做判断
            if (!("A".equals(hashMap.get("job_evaluation"))) && !("".equals(hashMap.get("job_evaluation")))) {
                info.setErrorMsg("作业评定只能维护A或者不维护，请确认");
                errorList.add("job_evaluation" + errLine);
                info.setFlag(false);
            }
            String date_of_departure = hashMap.get("date_of_departure");
            //取出到岗日 将字符串类型的日期转换成日期格式
            String date_of_induction = hashMap.get("date_of_induction");
            Date d = DateUtils.string2Date(date_of_induction, "yyyy-MM-dd");
            //计算日期
            int day = DateUtils.calculateDays(d);
            //判断到岗日是否小于14天
            if (day < 14 && day > 0) {
                if (hashMap.get("skill_development") != null && !("0".equals(hashMap.get("skill_development")))) {
                    info.setErrorMsg("到岗日小于14天，不能维护技能实习");
                    info.setFlag(false);
                    errorList.add("skill_development" + errLine);
                }
            }
            //判断eligibility_status
            if (hashMap.get("date_of_departure") != null && !("".equals(hashMap.get("date_of_departure")))) {
                //判断调离日是否大于到岗日
                if (date_of_departure.compareTo(date_of_induction) <= 0) {
                    //大于0 说明date_of_departure>date_of_induction 小于0则反之
                    info.setErrorMsg("调离日不能小于到岗日");
                    errorList.add("date_of_departure" + errLine);
                    info.setFlag(false);
                }
                //判断合格牌状态
                if (hashMap.get("eligibility_status") == null || "".equals(hashMap.get("eligibility_status"))) {
                    info.setFlag(false);
                    errorList.add("eligibility_status" + errLine);
                    info.setErrorMsg("合格牌回收 必须维护，请确认");
                } else if (!("1".equals(hashMap.get("eligibility_status")))) {
                    info.setErrorMsg("合格牌回收只能维护 1，请确认");
                    errorList.add("eligibility_status" + errLine);
                    info.setFlag(false);
                }
            }
            b++;
            if (b == c) {
                break;
            }
        }
        info.setErrorList(errorList);
        info.setData(qccEdps);
        // 响应数据
        JsonUtil.writeValue(info,response);
    }

    @RequestMapping("/check04.do")
    public void check04(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        //取出工号
        String employee_id = request.getParameter("employee_id");
        String educateTpye = request.getParameter("educate_type");
        //去人事主档查找数据
        Com_employee comEmployee = iComEmployeeService.findByEmployee_id(employee_id);
        if (comEmployee == null || "".equals(comEmployee)) {
            info.setErrorMsg("工号在人事主档不存在，请确认");
            info.setFlag(false);
        } else {
            //判断员工是否离职？离职则不新增
            if (comEmployee.getMmrsgn() != null && !"0".equals(comEmployee.getMmrsgn())) {
                info.setErrorMsg("该员工已离职，无法新增，请重新确认");
                info.setFlag(false);
            } else {
                //判断工号在qcc_edp中是否存在？
                Qcc_edp qccEdp = iQccEdpService.findByEmpIdAndEduTyp(employee_id, educateTpye);
                if (qccEdp != null && !"".equals(qccEdp)) {
                    info.setErrorMsg("该工号已维护,且未调离，不能新增");
                    info.setFlag(false);
                } else {
                    info.setData(comEmployee);
                    info.setFlag(true);
                }
            }
        }

        // 响应数据
        JsonUtil.writeValue(info,response);
    }

    /**
     * @Author Wang FengCai
     * @Description 检查工号是否存在
     * @Date 2020/5/7
     **/
    @RequestMapping("/check2EmpId.do")
    public void check2EmpId(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        //取出工号
        String employee_id = request.getParameter("employee_id");
        //判断工号在qcc_edp中是否存在？
        List<Qcc_edp> qccEdp = iQccEdpService.findByEmpI_1(employee_id);
        if (qccEdp == null || qccEdp.isEmpty()) {
            info.setErrorMsg("该工号不存在，请确认");
            info.setFlag(false);
        }
        // 响应数据
        JsonUtil.writeValue(info,response);
    }

    @RequestMapping("/check05.do")
    public void check05(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<Qcc_edp> qccEdps = new ArrayList<Qcc_edp>();
        String date_to_now = null;
        //计算离岗 年/天
        //将字符串类型的日期转换成日期格式
        //取出到岗日
        String date_of_induction = request.getParameter("date_of_induction");
        if(date_of_induction!=null&&!"".equals(date_of_induction)){
            LocalDate localDate = LocalDate.parse(date_of_induction, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            //计算时间差
            Period p = DateUtils.calculateTimeDifferenceByPeriod(localDate);
            //判断
            if (p.getYears() == 0 && p.getMonths() == 0 && p.getDays() < 14) {
                date_to_now = p.getDays() + "天";
                info.setErrorMsg("到岗大于14天，才能维护技能实习");
                info.setData(date_to_now);
                info.setFlag(false);
            } else {
                date_to_now = p.getYears() + "年" + p.getMonths() + "个月" + p.getDays() + "天";
                info.setData(date_to_now);
            }
        }
        // 响应数据
        JsonUtil.writeValue(info,response);
    }


    /**
     * @return void
     * @Author Wang FengCai
     * @Description 受训人员基本资料维护新增画面-控制点检查
     * @Date 2020/3/24
     * @Time 上午 10:45
     * @Param [request, response]
     **/
    @RequestMapping("/check06.do")
    public void check06(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<Qcc_edp> qccEdps = new ArrayList<Qcc_edp>();
        List<String> errorList = new ArrayList<String>();
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                if ("date_to_now".equals(name1) || "num".equals(name1) || "chinese_name".equals(name1) || "date_of_resignation".equals(name1)) {
                    //不做处理
                } else {
                    //将每一个key值对应的一组值放到数组里去
                    String[] vals = (String[]) map.get(name1);
                    c = vals.length;
                    //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                    if(b<c){
                        hashMap.put(name1, vals[b]);
                    }
                }
            }
            //记录当前记录行
            String errLine = String.valueOf(b);
            //如果取出的 工号为空，则不往数据库里插入数据
            if (hashMap.get("employee_id").equals(null) || hashMap.get("employee_id").equals("")) {
                b++;
                if (b == c) {
                    break;
                }
                continue;
            } else {
                //第一个判断
                if (hashMap.get("date_of_induction") == null || "".equals(hashMap.get("date_of_induction"))) {
                    //做判断
                    info.setErrorMsg("到岗日不能为空，请确认");
                    errorList.add("date_of_induction" + errLine);
                    info.setFlag(false);
                } else {
                    //计算到岗时间，并进行判断
                    //取出到岗日 将字符串类型的日期转换成日期格式
                    String date_of_induction = hashMap.get("date_of_induction");
                    LocalDate localDate = LocalDate.parse(date_of_induction, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                    //调用工具类计算时间差
                    Period p = DateUtils.calculateTimeDifferenceByPeriod(localDate);
                    //判断
                    if (p.getYears() == 0 && p.getMonths() == 0 && p.getDays() < 14) {
                        //检查技能实习是否为空
                        if (!"".equals(hashMap.get("skill_development")) && hashMap.get("skill_development") != null) {
                            info.setErrorMsg("到岗小于14天,不能维护技能实习");
                            errorList.add("skill_development" + errLine);
                            info.setFlag(false);
                        }
                    } else if (p.getMonths() >= 1 || p.getDays() > 14) {
                        //检查技能实习是否为空
                        if (!"".equals(hashMap.get("skill_development")) && hashMap.get("skill_development") != null) {
                            //检查技能实习是否合规
                            if (Integer.parseInt(hashMap.get("skill_development")) > 12 || Integer.parseInt(hashMap.get("skill_development")) < 0) {
                                info.setErrorMsg("技能实习范围0~12，请确认");
                                errorList.add("skill_development" + errLine);
                                info.setFlag(false);
                            }
                        }
                    }


                    //对作业评定的值进行判断
                    if (!("A".equals(hashMap.get("job_evaluation").toUpperCase())) && !("".equals(hashMap.get("job_evaluation")))) {
                        info.setErrorMsg("作业评定只能是A 或者 为空，请重新确认");
                        errorList.add("job_evaluation" + errLine);
                        info.setFlag(false);
                    }
                    //对调离日为空的数据进行处理
                    if ("".equals(hashMap.get("date_of_departure"))) {
                        hashMap.put("date_of_departure", "1899-12-30");
                    } else {
                        String date_of_departure = hashMap.get("date_of_departure");
                        //将字符串类型的日期转换成日期格式
                        //判断调离日是否大于到岗日
                        if (date_of_departure.compareTo(date_of_induction) <= 0) {
                            //大于0 说明date_of_departure>date_of_induction 小于0则反之
                            info.setErrorMsg("调离日不能小于到岗日");
                            errorList.add("date_of_departure" + errLine);
                            info.setFlag(false);
                        }
                        //判断合格牌回收状态
                        if ("".equals(hashMap.get("eligibility_status"))) {
                            info.setErrorMsg("请维护合格牌回收状态");
                            errorList.add("eligibility_status" + errLine);
                            info.setFlag(false);
                        } else {
                            //判断合格牌状态是否维护的是1
                            if (!("1".equals(hashMap.get("eligibility_status")))) {
                                info.setErrorMsg("合格牌回收状态只能是1，请确认");
                                errorList.add("eligibility_status" + errLine);
                                info.setFlag(false);
                            }
                        }
                    }

                }
            }
            b++;
            if (b == c) {
                break;
            }
        }
        info.setErrorList(errorList);
        info.setData(qccEdps);
        // 响应数据
        JsonUtil.writeValue(info,response);
    }

    /**
     * @return void
     * @Author Wang FengCai
     * @Description QA成绩输入-控制点检查
     * @Date 2020/3/24
     * @Time 上午 10:44
     * @Param [request, response]
     **/
    @RequestMapping("/check07.do")
    public void check07(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<Qcc_edp> qccEdps = new ArrayList<Qcc_edp>();
        List<String> errorList = new ArrayList<String>();
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //将每一个key值对应的一组值放到数组里去
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                if(b<c){
                    hashMap.put(name1, vals[b]);
                }
            }
            //记录当前记录行
            String errLine = String.valueOf(b);
            //第一个判断.使用工具类判断非空和不为null
            if (!StringUtils.isEmpty(hashMap.get("exoterica_educate_one"))) {
                if (Integer.parseInt(hashMap.get("exoterica_educate_one")) < 0 || Integer.parseInt(hashMap.get("exoterica_educate_one")) > 100) {
                    //做判断
                    info.setErrorMsg("理论教育2成绩的范围为0~100，请重新确认");
                    errorList.add("exoterica_educate_one" + errLine);
                    info.setFlag(false);
                }
                if (!StringUtils.isEmpty(hashMap.get("exoterica_educate_two"))) {
                    if (Integer.parseInt(hashMap.get("exoterica_educate_one")) < 90 && Integer.parseInt(hashMap.get("exoterica_educate_one")) > 0) {
                        //判断理论教育2
                        if (Integer.parseInt(hashMap.get("exoterica_educate_two")) < 0 || Integer.parseInt(hashMap.get("exoterica_educate_two")) > 100) {
                            //做判断
                            info.setErrorMsg("理论教育2成绩的范围为0~100，请重新确认");
                            errorList.add("exoterica_educate_two" + errLine);
                            info.setFlag(false);
                        }
                        if (Integer.parseInt(hashMap.get("exoterica_educate_two")) < 90 && Integer.parseInt(hashMap.get("exoterica_educate_two")) > 0) {
                            if (hashMap.get("confirm_date") != null && !StringUtils.isEmpty(hashMap.get("confirm_date"))) {
                                info.setErrorMsg("合格认定日不能维护，请确认");
                                errorList.add("confirm_date" + errLine);
                                info.setFlag(false);
                            }

                        }
                    }
                }
            }

            //取出作业种类和单位代码
            String educate_type = hashMap.get("educate_type");
            String workplace_code = hashMap.get("workplace_code");
            String employee_id = hashMap.get("employee_id");
            //根据作业代码和工作单位查询
            Qcc_edp qccEdp = iQccEdpService.findByEduTypAndWorCAndEmpI(educate_type, workplace_code, employee_id);

            //判断合格认定日是否为空，不为空则合格牌号必须输入
            if (hashMap.get("confirm_date") != null && !("".equals(hashMap.get("confirm_date")))) {
                //判断合格认定日是否可以维护
                if (String.valueOf(qccEdp.getSkill_development()) == null) {
                    info.setErrorMsg("技能实习没维护，合格认定日不能维护，请确认");
                    errorList.add("confirm_date" + errLine);
                    info.setFlag(false);
                }
                //先判断理论教育2
                if (hashMap.get("exoterica_educate_two") != null && !"".equals(hashMap.get("exoterica_educate_two"))) {
                    if (Integer.parseInt(hashMap.get("exoterica_educate_two")) < 90) {
                        info.setErrorMsg("理論教育2成绩不合格，合格认定日不能维护，请确认");
                        errorList.add("exoterica_educate_two" + errLine);
                        info.setFlag(false);
                    }
                } else {
                    if (Integer.parseInt(hashMap.get("exoterica_educate_one")) < 90) {
                        info.setErrorMsg("理論教育1成绩不合格，合格认定日不能维护，请确认");
                        errorList.add("exoterica_educate_one" + errLine);
                        info.setFlag(false);
                    }
                }

                //2
                if (qccEdp.getManufature_lore_two() < 90 && qccEdp.getManufature_lore_two() != 0) {
                    info.setErrorMsg("制品知識2成绩不合格，合格认定日不能维护，请确认");
                    errorList.add("confirm_date" + errLine);
                    info.setFlag(false);
                }
                if (qccEdp.getManufature_lore_one() < 90 && qccEdp.getManufature_lore_two() == 0) {
                    info.setErrorMsg("制品知識1成绩不合格，合格认定日不能维护，请确认");
                    errorList.add("confirm_date" + errLine);
                    info.setFlag(false);
                }
                if (qccEdp.getStandard_work_two() != 0 && qccEdp.getStandard_work_two() < 90) {
                    info.setErrorMsg("作業標準2成绩不合格，合格认定日不能维护，请确认");
                    errorList.add("confirm_date" + errLine);
                    info.setFlag(false);
                }
                if (qccEdp.getStandard_work_one() < 90 && qccEdp.getStandard_work_two() == 0) {
                    info.setErrorMsg("作業標準1成绩不合格，合格认定日不能维护，请确认");
                    errorList.add("confirm_date" + errLine);
                    info.setFlag(false);
                }

                //判断合格牌号是否为空
                if (hashMap.get("eligibility_no") == null || "".equals(hashMap.get("eligibility_no"))) {
                    info.setErrorMsg("请维护合格牌号");
                    errorList.add("eligibility_no" + errLine);
                    info.setFlag(false);
                } else {
                    //判断合格牌号的范围
                    if (hashMap.get("eligibility_no").compareTo("9999") > 0 || hashMap.get("eligibility_no").compareTo("0") < 0) {
                        info.setErrorMsg("合格牌号的范围为0~9999，请确认");
                        errorList.add("eligibility_no" + errLine);
                        info.setFlag(false);
                    } else {
                        //判断合格牌号是否存在
                        String el = hashMap.get("eligibility_no");
                        //取出原来的数据
                        Qcc_edp qccEdp1 = iQccEdpService.findById(Integer.parseInt(hashMap.get("id")));
                        if (qccEdp1 != null && !"".equals(qccEdp1)) {
                            //查询
                            List<Qcc_edp> qccEdpList = iQccEdpService.findByEduTypAndEl(educate_type, el);
                            if (qccEdpList.size()>0) {
                                //遍历
                                for(Qcc_edp qccEdp2:qccEdpList){
                                    //判断是否是同一个工号
                                    if(!employee_id.equals(qccEdp2.getEmployee_id())){
                                        //判断是否已存在
                                        if("".equals(qccEdp2.getEligibility_status())){
                                            info.setErrorMsg("该合格牌号已存在，请重新输入");
                                            errorList.add("eligibility_no" + errLine);
                                            info.setFlag(false);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (hashMap.get("qa_manager_confirm") != null && !("".equals(hashMap.get("qa_manager_confirm")))) {
                    //判断经理承的值，为空或1
                    if (!("1".equals(hashMap.get("qa_manager_confirm"))) && !("".equals(hashMap.get("qa_manager_confirm")))) {
                        info.setErrorMsg("经理承认只能维护1或者空，请确认");
                        errorList.add("qa_manager_confirm" + errLine);
                        info.setFlag(false);
                    }
                }
            } else {
                //判断合格牌号不为空的话，合格认定日必须维护
                if (hashMap.get("eligibility_no") != null && !("".equals(hashMap.get("eligibility_no")))) {
                    //判断合格牌号的范围
                    if (hashMap.get("eligibility_no").compareTo("9999") > 0 || hashMap.get("eligibility_no").compareTo("0") < 0) {
                        info.setErrorMsg("合格牌号的范围为0~9999，请确认");
                        errorList.add("eligibility_no" + errLine);
                        info.setFlag(false);
                    } else {
                        //判断合格判定日是否为空
                        info.setErrorMsg("合格牌号不为空，请维护合格认定日");
                        errorList.add("confirm_date" + errLine);
                        info.setFlag(false);
                    }
                }
                //判断经理承认，合格认定日为空，则经理承认不能维护
                if (hashMap.get("qa_manager_confirm") != null && !("".equals(hashMap.get("qa_manager_confirm")))) {
                    info.setErrorMsg("若合格认定日为空，经理承认不能维护，请确认");
                    errorList.add("qa_manager_confirm" + errLine);
                    info.setFlag(false);
                }
            }

            b++;
            if (b == c) {
                break;
            }
        }
        info.setErrorList(errorList);
        info.setData(qccEdps);
        // 响应数据
        JsonUtil.writeValue(info,response);
    }

    /**
     * @return void
     * @Author Wang FengCai
     * @Description 定期技能有效性认定-检查
     * @Date 2020/3/25
     * @Time 下午 04:37
     * @Param [request, response]
     **/
    @RequestMapping("/check08.do")
    public void check08(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<Qcc_edp> qccEdps = new ArrayList<Qcc_edp>();
        List<String> errorList = new ArrayList<String>();
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //将每一个key值对应的一组值放到数组里去
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                hashMap.put(name1, vals[b]);
            }
            //记录当前记录行
            String errLine = String.valueOf(b);
            //取出评定日
            if (hashMap.get("assess_of_1") == null || "".equals(hashMap.get("assess_of_1"))) {
                b++;
                if (b == c) {
                    break;
                }
                continue;
            } else {
                //计算认定日 年/天
                //取出合格认定日
                String confirm_date = hashMap.get("confirm_date");
                String assess_of_1 = hashMap.get("assess_of_1");
                LocalDate localDate = LocalDate.parse(confirm_date, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                LocalDate now = LocalDate.parse(assess_of_1, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                //判断QC认定
                if (hashMap.get("qc_confirm_of_1") != null && !("".equals(hashMap.get("qc_confirm_of_1"))) && !("1".equals(hashMap.get("qc_confirm_of_1")))) {
                    info.setErrorMsg("QC认定只能维护空或者 1，请确认");
                    errorList.add("qc_confirm_of_1" + errLine);
                    info.setFlag(false);
                }
            }
            b++;
            if (b == c) {
                break;
            }
        }
        info.setErrorList(errorList);
        info.setData(qccEdps);
        // 响应数据
        JsonUtil.writeValue(info,response);
    }

    /**
     * @return
     * @Author Wang FengCai
     * @Description QC成绩输入--控制点检查
     * @Date 2020/4/3
     * @Time 下午 08:17
     * @Param
     **/
    @RequestMapping("/check09.do")
    public void check09(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        //取出前端传回的所有数据
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        List<Qcc_edp> qccEdps = new ArrayList<Qcc_edp>();
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //字段date_to_now(到岗 年/天)，chinese_name(姓名)，date_of_resignation(辞职日)
                if ("date_to_now".equals(name1) || "del".equals(name1) || "num".equals(name1) || "chinese_name".equals(name1) || "date_of_resignation".equals(name1)) {
                    //不做处理
                } else {
                    //将每一个key值对应的一组值放到数组里去
                    String[] vals = (String[]) map.get(name1);
                    c = vals.length;
                    //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                    hashMap.put(name1, vals[b]);
                }
            }
            //记录当前记录行
            String errLine = String.valueOf(b);
            //取出ID
            int id = Integer.parseInt(hashMap.get("id"));
            if (hashMap.get("manufature_lore_one") != null && !("".equals(hashMap.get("manufature_lore_one")))) {
                //对制品知识1的成绩范围进行判断
                if (Integer.parseInt(hashMap.get("manufature_lore_one")) > 100 || Integer.parseInt(hashMap.get("manufature_lore_one")) < 0) {
                    info.setErrorMsg("制品知识1成绩范围0~100，请确认");
                    errorList.add("manufature_lore_one" + errLine);
                    info.setFlag(false);
                }
//                else if (Integer.parseInt(hashMap.get("manufature_lore_one")) >= 90 && Integer.parseInt(hashMap.get("manufature_lore_one")) <= 100) {
//                    //TODO 判断第二次的制品知识成绩
//                    if (hashMap.get("manufature_lore_two") != null && !("".equals(hashMap.get("manufature_lore_two"))) && !"".equals(hashMap.get("manufature_lore_two"))) {
//                        info.setErrorMsg("制品知识1成绩已合格，不用再二次维护");
//                        errorList.add("manufature_lore_two" + errLine);
//                        info.setFlag(false);
//                    }
//                }
            }
            if (!("".equals(hashMap.get("standard_work_one"))) && hashMap.get("standard_work_one") != null) {
                //对制品知识1的成绩范围进行判断
                if (Integer.parseInt(hashMap.get("standard_work_one")) > 100 || Integer.parseInt(hashMap.get("standard_work_one")) < 0) {
                    info.setErrorMsg("作业标准成绩范围0~100，请确认");
                    errorList.add("standard_work_one" + errLine);
                    info.setFlag(false);
                }
//                else if (Integer.parseInt(hashMap.get("standard_work_one")) >= 90 && Integer.parseInt(hashMap.get("standard_work_one")) <= 100) {
//                    //TODO 判断第二次作业标准的成绩
//                    if (hashMap.get("standard_work_two") != null && !"".equals(hashMap.get("standard_work_two"))) {
//                        info.setErrorMsg("作业标准1成绩已合格，不用再二次维护");
//                        errorList.add("standard_work_two" + errLine);
//                        info.setFlag(false);
//                    }
//                }
            }
            //作业评定的判断
//            if (!("A".equals(hashMap.get("job_evaluation").toUpperCase())) && !("".equals(hashMap.get("job_evaluation").toUpperCase()))) {
//                info.setErrorMsg("作业评定只能是A 或者 为空，请重新确认");
//                errorList.add("job_evaluation" + errLine);
//                info.setFlag(false);
//            }
//            //取出到岗日 将字符串类型的日期转换成日期格式
//            String date_of_induction = hashMap.get("date_of_induction");
//            LocalDate localDate = LocalDate.parse(date_of_induction, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
//            //调用工具类计算时间差
//            Period p = DateUtils.calculateTimeDifferenceByPeriod(localDate);
//            //判断
//            if (p.getDays() < 14 && p.getYears() == 0 && p.getMonths() == 0) {
//                //检查技能实习是否为空
//                if (!"0".equals(hashMap.get("skill_development")) && hashMap.get("skill_development") != null) {
//                    info.setErrorMsg("到岗小于14天,不能维护技能实习");
//                    errorList.add("skill_development" + errLine);
//                    info.setFlag(false);
//                }
//            }
//
//            if (p.getDays() > 14) {
//                //检查技能实习是否为空
//                if (!"0".equals(hashMap.get("skill_development")) && hashMap.get("skill_development") != null) {
//                    //检查技能实习是否合规
//                    if (!(Integer.parseInt(hashMap.get("skill_development")) < 12 && Integer.parseInt(hashMap.get("skill_development")) > 0)) {
//                        info.setErrorMsg("技能实习范围0~12，请确认");
//                        errorList.add("skill_development" + errLine);
//                        info.setFlag(false);
//                    }
//                }
//
//            }

            b++;
            if (b == c) {
                break;
            }
        }
        info.setErrorList(errorList);
        info.setData(qccEdps);
        // 响应数据
        JsonUtil.writeValue(info,response);
    }

    /**
     * @Description: 数据传到新增页面
     */
    @RequestMapping("/add.do")
    public ModelAndView add(String educate_type, String workplace_code, String password_code) {
        ModelAndView mv = new ModelAndView();
        mv.setViewName("qcc-edp-basic-add");
        mv.addObject("educate_type", educate_type);
        mv.addObject("workplace_code", workplace_code);
        mv.addObject("password_code", password_code);
        return mv;
    }

    /**
     * @Author Wang FengCai
     * @Description 根据密码查询
     * @Date 2020/3/30
     **/
    @RequestMapping("/findByPassCode.do")
    public void findByPassCode(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        //取出前端传回的数据
        String password_code = request.getParameter("password_code").toUpperCase();
        //调用业层的方法查询
        String qccEdp = iQccEcpService.findByPassC(password_code);
        if (qccEdp == null || "".equals(qccEdp)) {
            info.setErrorMsg("密码不存在，请确认");
            info.setFlag(false);
        }
        JsonUtil.writeValue(info,response);
    }

    /**
     * @Author Wang FengCai
     * @Description 根据种类代码和单位代码查找
     * @Date 2020/3/16
     **/
    @RequestMapping("/findByEduTypAndWorC.do")
    public ModelAndView findByEduTypAndWorC(@RequestParam(value = "pn", defaultValue = "1") Integer pn, @RequestParam(value = "PageSize", defaultValue = "10") Integer ps, HttpServletRequest request) throws Exception {
        //引入PageHelper分页插件
        //查询之前需要调用,传入页码，以及每页的大小
        PageHelper.startPage(pn, ps);
        //取出前端传回的数据
        String educateType = request.getParameter("educate_type").toUpperCase();
        String workplaceCode = request.getParameter("workplace_code").toUpperCase();
        //调用业层的方法查询
        List<Qcc_edp> qccEdpList = iQccEdpService.findByEduTypAndWorC(educateType, workplaceCode);
        if(qccEdpList.size()>0){
            //将取回的结果遍历
            for (Qcc_edp qccEdp : qccEdpList) {
                //取出每个对象中的工号
                String emId = qccEdp.getEmployee_id();
                //根据工号去人事主档查询
                Com_employee comEmployee = iComEmployeeService.findByEmployee_id(emId);
                if (comEmployee != null && !"".equals(comEmployee)) {
                    //取出离职日，做处理
                    if (comEmployee.getMmrsgn() == null || "".equals(comEmployee.getMmrsgn()) || "0".equals(comEmployee.getMmrsgn())) {
                        String mh = "";
                        qccEdp.setMmrsgn(mh);
                    } else {
                        String mh = comEmployee.getMmrsgn();
                        //在字符串中插入"-"
                        StringBuffer mh1 = new StringBuffer(mh);
                        mh1.insert(6, "-");
                        mh1.insert(4, "-");
                        //转换格式
                        qccEdp.setMmrsgn(mh1.toString());
                    }
                    //取出姓名，并处理
                    String mdn = comEmployee.getMmdnam();
                    qccEdp.setMmdnam(mdn);

                    //调用方法查询单位代码和作业中对应的中文信息
                    findEducateTypeChineseNameAndWorkplaceCodeChineseName(qccEdp);

                    //计算离岗 年/天
                    //转换日期格式
                    LocalDate localDate = DateUtils.date2LocalDate(qccEdp.getDate_of_induction());
                    Period p;
                    String date_to_now = null;
                    //判断调离日是否为空
                    if (qccEdp.getDate_of_departure() != null && !"".equals(qccEdp.getDate_of_departure())) {
                        //转换成日期格式
                        LocalDate newDate = DateUtils.date2LocalDate(qccEdp.getDate_of_departure());
                        //到岗年/天=调离日-到岗日
                        p = DateUtils.calculateTimeDifferenceByPeriod2(newDate, localDate);
                    } else {
                        //调用工具类的方法计算时间差
                        p = DateUtils.calculateTimeDifferenceByPeriod(localDate);
                    }
                    //调用工具类 判断 年/天的显示格式
                    date_to_now = DateUtils.dateDisplay(p);

                    //重新放到对象中去
                    qccEdp.setDate_to_now(date_to_now);
                }
            }
        }
        //创建视图对象
        ModelAndView modelAndView = new ModelAndView();
        //startPage后面紧跟的是这个查询就是一个分页查询
        //使用pageInfo包装查询后的结果，只需要将Pageinfo交给页面就行了
        //封装了详细的分页信息，包括我们查出来的数据,传入连续显示的数据
        PageInfo page = new PageInfo(qccEdpList, ps);
        //使用addObject()设置需要返回的值
        modelAndView.addObject("qccEdpList", qccEdpList);
        modelAndView.addObject("pageInfo", page);
        //通过setViewName()方法跳转到指定的页面
        modelAndView.setViewName("qcc-edp-basic-list");
        //返回视图解析对象
        return modelAndView;
    }

    /**
     * @Author Wang FengCai
     * @Description 根据工号查询作业种类等信息
     * @Date 2020/5/7
     **/
    @RequestMapping("/findByEmpId.do")
    public ModelAndView findByEmpId(HttpServletRequest request) throws Exception {
        String emplyeeId = request.getParameter("employee_id");
        List<Qcc_edp> qccEdpList = new ArrayList<>();
        if(emplyeeId!=null&&!"".equals(emplyeeId)){
            qccEdpList = iQccEdpService.findByEmpId(emplyeeId);
            if(qccEdpList.size()>0){
                //将取回的结果遍历
                for (Qcc_edp qccEdp : qccEdpList) {
                    //取出离职日，做处理
                    Com_employee comEmployee = iComEmployeeService.findByEmployee_id(qccEdp.getEmployee_id());
                    if (comEmployee.getMmrsgn() == null || "".equals(comEmployee.getMmrsgn()) || "0".equals(comEmployee.getMmrsgn())) {
                        String mh = "";
                        qccEdp.setMmrsgn(mh);
                    } else {
                        String mh = comEmployee.getMmrsgn();
                        //在字符串中插入"-"
                        StringBuffer mh1 = new StringBuffer(mh);
                        mh1.insert(6, "-");
                        mh1.insert(4, "-");
                        //转换格式
                        qccEdp.setMmrsgn(mh1.toString());
                    }
                    //取出姓名，并处理
                    String mdn = comEmployee.getMmdnam();
                    qccEdp.setMmdnam(mdn);
                    //计算离岗 年/天
                    //转换日期格式
                    LocalDate localDate = DateUtils.date2LocalDate(qccEdp.getDate_of_induction());
                    Period p;
                    String date_to_now = null;
                    //判断调离日是否为空
                    if (qccEdp.getDate_of_departure() != null && !"".equals(qccEdp.getDate_of_departure())) {
                        //转换成日期格式
                        LocalDate newDate = DateUtils.date2LocalDate(qccEdp.getDate_of_departure());
                        //到岗年/天=调离日-到岗日
                        p = DateUtils.calculateTimeDifferenceByPeriod2(newDate, localDate);
                    } else {
                        //调用工具类的方法计算时间差
                        p = DateUtils.calculateTimeDifferenceByPeriod(localDate);
                    }
                    //调用工具类 判断 年/天的显示格式
                    date_to_now = DateUtils.dateDisplay(p);
                    //重新放到对象中去
                    qccEdp.setDate_to_now(date_to_now);
                }
            }
        }
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("qccEdpList", qccEdpList);
        modelAndView.setViewName("qcc-edp-data-list");
        return modelAndView;
    }

    /**
     * @Author Wang FengCai
     * @Description 根据种类代码和单位代码查找——QC成绩维护
     * @Date 2020/3/21
     **/
    @RequestMapping("/findByEduTypAndWorC_Qc.do")
    public ModelAndView findByEduTypAndWorCQc(@RequestParam(value = "pn", defaultValue = "1") Integer pn, @RequestParam(value = "PageSize", defaultValue = "10") Integer ps, HttpServletRequest request) throws Exception {
        //引入PageHelper分页插件
        //查询之前需要调用,,传入页码，以及每页的大小
        PageHelper.startPage(pn, ps);
        //取出前端传回的数据
        String educateType = request.getParameter("educate_type");
        String workplaceCode = request.getParameter("workplace_code");
        //调用业层的方法查询
        List<Qcc_edp> qccEdpList = iQccEdpService.findByEduTypAndWorCQc(educateType, workplaceCode);
        if(qccEdpList.size()>0){
            //将取回的结果遍历
            for (Qcc_edp qccEdp : qccEdpList) {
                //取出每个对象中的工号
                String emId = qccEdp.getEmployee_id();
                //根据工号去人事主档查询
                Com_employee comEmployee = iComEmployeeService.findByEmployee_id(emId);
                if (comEmployee != null && !"".equals(comEmployee)) {

                    //取出姓名，并处理
                    String mdn = comEmployee.getMmdnam();
                    qccEdp.setMmdnam(mdn);

                    //计算离岗 年/天
                    //转换日期格式
                    LocalDate localDate = DateUtils.date2LocalDate(qccEdp.getDate_of_induction());
                    //调用工具类的方法计算时间差
                    Period p = DateUtils.calculateTimeDifferenceByPeriod(localDate);
                    String date_to_now = null;
                    //调用工具类 判断 年/天的显示格式
                    date_to_now = DateUtils.dateDisplay(p);
                    qccEdp.setDate_to_now(date_to_now);
                }
                //调用方法查询单位代码和作业中对应的中文信息
                findEducateTypeChineseNameAndWorkplaceCodeChineseName(qccEdp);
            }
        }

        //创建视图对象
        ModelAndView modelAndView = new ModelAndView();
        //startPage后面紧跟的是这个查询就是一个分页查询
        //使用pageInfo包装查询后的结果，只需要将Pageinfo交给页面就行了
        //封装了详细的分页信息，包括我们查出来的数据,传入连续显示的数据
        PageInfo page = new PageInfo(qccEdpList, ps);
        //使用addObject()设置需要返回的值
        modelAndView.addObject("qccEdpList", qccEdpList);
        modelAndView.addObject("pageInfo", page);
        //通过setViewName()方法跳转到指定的页面
        modelAndView.setViewName("qcc-edp-qc-result");
        //返回视图解析对象
        return modelAndView;
    }


    /**
     * @Author Wang FengCai
     * @Description 根据种类代码和单位代码查找——QA成绩维护
     * @Date 2020/3/24
     **/
    @RequestMapping("/findByEduTypAndWorC_Qa.do")
    public ModelAndView findByEduTypAndWorCQa(@RequestParam(value = "pn", defaultValue = "1") Integer pn, @RequestParam(value = "PageSize", defaultValue = "10") Integer ps, HttpServletRequest request) throws Exception {
        //引入PageHelper分页插件
        //查询之前需要调用,,传入页码，以及每页的大小
        PageHelper.startPage(pn, ps);
        //取出前端传回的数据
        String educateType = request.getParameter("educate_type");
        String workplaceCode = request.getParameter("workplace_code");
        //调用业层的方法查询
        List<Qcc_edp> qccEdpList = iQccEdpService.findByEduTypAndWorCQc(educateType, workplaceCode);
        if(qccEdpList.size()>0){
            //将取回的结果遍历
            for (Qcc_edp qccEdp : qccEdpList) {
                //取出每个对象中的工号
                String emId = qccEdp.getEmployee_id();
                //根据工号去人事主档查询
                Com_employee comEmployee = iComEmployeeService.findByEmployee_id(emId);
                if (comEmployee != null && !"".equals(comEmployee)) {
                    //取出姓名，并处理
                    String mdn = comEmployee.getMmdnam();
                    qccEdp.setMmdnam(mdn);
                    //计算离岗 年/天
                    //调用工具类的方法计算时间差
                    Period p = DateUtils.calculateTimeDifferenceByPeriod(DateUtils.date2LocalDate(qccEdp.getDate_of_induction()));
                    String date_to_now = null;
                    //调用工具类 判断 年/天的显示格式
                    date_to_now = DateUtils.dateDisplay(p);
                    qccEdp.setDate_to_now(date_to_now);
                }
                //调用方法查询单位代码和作业种类对应的中文信息
                findEducateTypeChineseNameAndWorkplaceCodeChineseName(qccEdp);
            }
        }

        //创建视图对象
        ModelAndView modelAndView = new ModelAndView();
        //startPage后面紧跟的是这个查询就是一个分页查询
        //使用pageInfo包装查询后的结果，只需要将Pageinfo交给页面就行了
        //封装了详细的分页信息，包括我们查出来的数据,传入连续显示的数据
        PageInfo page = new PageInfo(qccEdpList, ps);
        //使用addObject()设置需要返回的值
        modelAndView.addObject("qccEdpList", qccEdpList);
        modelAndView.addObject("pageInfo", page);
        //通过setViewName()方法跳转到指定的页面
        modelAndView.setViewName("qcc-edp-qa-result");
        //返回视图解析对象
        return modelAndView;
    }

    /**
     * @Author Wang FengCai
     * @Description 根据种类代码和单位代码查找——技能有效性认定
     * @Date 2020/3/25
     **/
    @RequestMapping("/findByEduTypAndWorC_EC.do")
    public ModelAndView findByEduTypAndWorCEC(@RequestParam(value = "pn", defaultValue = "1") Integer pn, @RequestParam(value = "PageSize", defaultValue = "10") Integer ps, HttpServletRequest request) throws Exception {
        //引入PageHelper分页插件
        //查询之前需要调用,,传入页码，以及每页的大小
        PageHelper.startPage(pn, ps);
        //取出前端传回的数据
        String educateType = request.getParameter("educate_type");
        String workplaceCode = request.getParameter("workplace_code");
        //调用业层的方法查询
        List<Qcc_edp> qccEdpList = iQccEdpService.findByEduTypAndWorCEC(educateType, workplaceCode);
        //将取回的结果遍历
        int dayToNow = 0;
        if(qccEdpList.size()>0){
            for (Qcc_edp qccEdp : qccEdpList) {
                //取出每个对象中的工号
                String emId = qccEdp.getEmployee_id();
                //根据工号去人事主档查询
                Com_employee comEmployee = iComEmployeeService.findByEmployee_id(emId);
                if (comEmployee != null && !"".equals(comEmployee)) {
                    //取出姓名，并处理
                    String mdn = comEmployee.getMmdnam();
                    qccEdp.setMmdnam(mdn);
                    //若一次认定日期不为空，则按一次认定的日期和系统时间计算
                    if (qccEdp.getAssess_of_1() != null && !"".equals(qccEdp.getAssess_of_1())) {
                        //计算离岗 年/天
                        LocalDate localDate = DateUtils.date2LocalDate(qccEdp.getAssess_of_1());
                        //调用工具类的方法计算时间差
                        Period p = DateUtils.calculateTimeDifferenceByPeriod(localDate);
                        String date_to_now = null;
                        //调用工具类 判断 年/天的显示格式
                        date_to_now = DateUtils.dateDisplay(p);
                        qccEdp.setDate_to_now(date_to_now);
                    } else {
                        //计算离岗 年/天
                        LocalDate localDate = DateUtils.date2LocalDate(qccEdp.getConfirm_date());
                        //调用工具类的方法计算时间差
                        Period p = DateUtils.calculateTimeDifferenceByPeriod(localDate);
                        String date_to_now = null;
                        //调用工具类 判断 年/天的显示格式
                        date_to_now = DateUtils.dateDisplay(p);
                        qccEdp.setDate_to_now(date_to_now);
                    }
                    //计算已认定多少天？ 显示成“天”
                    if (qccEdp.getAssess_of_1() != null && !"".equals(qccEdp.getAssess_of_1())) {
                        dayToNow = DateUtils.calculateDays(qccEdp.getAssess_of_1());
                    } else {
                        dayToNow = DateUtils.calculateDays(qccEdp.getConfirm_date());
                    }
                    //默认大于一年（365）在前端页面以红色提示用户
                    if (dayToNow > 365) {
                        qccEdp.setDayToNow(dayToNow);
                    }
                }
                //调用方法查询单位代码和作业种类对应的中文信息
                findEducateTypeChineseNameAndWorkplaceCodeChineseName(qccEdp);
            }
        }

        //创建视图对象
        ModelAndView modelAndView = new ModelAndView();
        //startPage后面紧跟的是这个查询就是一个分页查询
        //使用pageInfo包装查询后的结果，只需要将Pageinfo交给页面就行了
        //封装了详细的分页信息，包括我们查出来的数据,传入连续显示的数据
        PageInfo page = new PageInfo(qccEdpList, ps);
        //使用addObject()设置需要返回的值
        modelAndView.addObject("qccEdpList", qccEdpList);
        modelAndView.addObject("pageInfo", page);
        //通过setViewName()方法跳转到指定的页面
        modelAndView.setViewName("qcc-edp-effec-cogn");
        //返回视图解析对象
        return modelAndView;
    }


    /**
     * @Author Wang FengCai
     * @Description 根据ID删除
     * @Date 2020/3/17
     **/
    @RequestMapping("/deleteById.do")
    public void deleteById(HttpServletRequest request, HttpServletResponse response) throws SysException, IOException {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        int id = Integer.parseInt(request.getParameter("id"));
        try {
            iQccEdpService.deleteById(id);
        } catch (Exception e) {
            e.printStackTrace();
            throw new SysException("根据ID删除数据失败");
        }
        JsonUtil.writeValue(info,response);
    }

    /**
     * @Author Wang FengCai
     * @Description 修改
     * @Date 2020/3/17
     **/

    @RequestMapping("/update.do")
    public void update(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        //取出前端传回的所有数据
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        String username = (String) session.getAttribute("username");
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //字段date_to_now(到岗 年/天)，chinese_name(姓名)，date_of_resignation(辞职日)
                if ("date_to_now".equals(name1) || "del".equals(name1) || "num".equals(name1) || "chinese_name".equals(name1) || "date_of_resignation".equals(name1)) {
                    //不做处理
                } else {
                    //将每一个key值对应的一组值放到数组里去
                    String[] vals = (String[]) map.get(name1);
                    c = vals.length;
                    //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                    hashMap.put(name1, vals[b]);
                }
            }
            //取出ID
            int id = Integer.parseInt(hashMap.get("id"));
            //创建对象
            Qcc_edp qcc_edp = iQccEdpService.findById(id);
            //判断
            if (qcc_edp == null || "".equals(qcc_edp)) {
                b++;
                if (b == c) {
                    break;
                }
                continue;
            } else {
                try {
                    //自定义转换器  避免No value specified for 'Date' 和DateConverter does not support default String to 'Date' conversion.的异常
                    DateUtils.convert2Date();
                    BeanUtils.populate(qcc_edp, hashMap);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    e.printStackTrace();
                }
                //更新的程序
                qcc_edp.setUpdate_oid(username);
                qcc_edp.setUpdate_program("/qcc_edp/update");
                //调用业务层的update()方法
                iQccEdpService.update(qcc_edp);
                b++;
                if (b == c) {
                    break;
                }
            }
        }
        // 响应数据
        JsonUtil.writeValue(info,response);
    }

    /**
     * @Author Wang FengCai
     * @Description 修改——QA成绩维护
     * @Date 2020/3/24
     **/
    @RequestMapping("/update_Qa.do")
    public void updateQa(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        //取出前端传回的所有数据
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        List<Qcc_edp> qccEdps = new ArrayList<Qcc_edp>();
        String username = (String) session.getAttribute("username");
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //字段date_to_now(到岗 年/天)，chinese_name(姓名)，date_of_resignation(辞职日)
                if ("date_to_now".equals(name1) || "del".equals(name1) || "num".equals(name1) || "chinese_name".equals(name1) || "date_of_resignation".equals(name1)) {
                    //不做处理
                } else {
                    //将每一个key值对应的一组值放到数组里去
                    String[] vals = (String[]) map.get(name1);
                    c = vals.length;
                    //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                    hashMap.put(name1, vals[b]);
                }
            }
            //记录当前记录行
            String errLine = String.valueOf(b);
            //取出ID
            int id = Integer.parseInt(hashMap.get("id"));
            //创建对象
            Qcc_edp qccEdp = iQccEdpService.findById(id);
            //更新的程序
            qccEdp.setUpdate_oid(username);
            qccEdp.setUpdate_program("/qcc_edp/update_Qa");
            try {
                //自定义转换器  避免No value specified for 'Date' 和DateConverter does not support default String to 'Date' conversion.的异常
                DateUtils.convert2Date();
                BeanUtils.populate(qccEdp, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //调用业务层的update()方法
            iQccEdpService.update(qccEdp);
            b++;
            if (b == c) {
                break;
            }
        }
        info.setErrorList(errorList);
        info.setData(qccEdps);
        // 响应数据
        JsonUtil.writeValue(info,response);
    }

    /**
     * @Author Wang FengCai
     * @Description 修改——QC成绩维护
     * @Date 2020/3/21
     **/
    @RequestMapping("/update_EC.do")
    public void updateEC(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        //取出前端传回的所有数据
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        List<Qcc_edp> qccEdps = new ArrayList<Qcc_edp>();
        String username = (String) session.getAttribute("username");
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //字段date_to_now(到岗 年/天)，chinese_name(姓名)，date_of_resignation(辞职日)
                if ("date_to_now".equals(name1) || "del".equals(name1) || "num".equals(name1) || "chinese_name".equals(name1) || "date_of_resignation".equals(name1)) {
                    //不做处理
                } else {
                    //将每一个key值对应的一组值放到数组里去
                    String[] vals = (String[]) map.get(name1);
                    c = vals.length;
                    //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                    hashMap.put(name1, vals[b]);
                }
            }
            //记录当前记录行
            String errLine = String.valueOf(b);
            if ("".equals(hashMap.get("assess_of_1")) || hashMap.get("assess_of_1") == null) {
                b++;
                if (b == c) {
                    break;
                }
                continue;
            }
            //取出ID
            int id = Integer.parseInt(hashMap.get("id"));
            //创建对象
            Qcc_edp qcc_edp = iQccEdpService.findById(id);
            //更新的程序
            qcc_edp.setUpdate_oid(username);
            qcc_edp.setUpdate_program("/qcc_edp/update_EC");
            try {
                //自定义转换器  避免No value specified for 'Date' 和DateConverter does not support default String to 'Date' conversion.的异常
                DateUtils.convert2Date();
                BeanUtils.populate(qcc_edp, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //调用业务层的update()方法
            iQccEdpService.update(qcc_edp);
            b++;
            if (b == c) {
                break;
            }
        }
        info.setErrorList(errorList);
        info.setData(qccEdps);
        // 响应数据
        JsonUtil.writeValue(info,response);
    }

    /**
     * @Author Wang FengCai
     * @Description 修改——定期技能有效性认定
     * @Date 2020/3/25
     **/
    @RequestMapping("/update_Qc.do")
    public void updateQc(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        //取出前端传回的所有数据
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        String username = (String) session.getAttribute("username");
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //字段date_to_now(到岗 年/天)，chinese_name(姓名)，date_of_resignation(辞职日)
                if ("date_to_now".equals(name1) || "del".equals(name1) || "num".equals(name1) || "chinese_name".equals(name1) || "date_of_resignation".equals(name1)) {
                    //不做处理
                } else {
                    //将每一个key值对应的一组值放到数组里去
                    String[] vals = (String[]) map.get(name1);
                    c = vals.length;
                    //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                    hashMap.put(name1, vals[b]);
                }
            }
            //取出ID
            int id = Integer.parseInt(hashMap.get("id"));
            //创建对象
            Qcc_edp qcc_edp = iQccEdpService.findById(id);
            //更新的程序
            qcc_edp.setUpdate_oid(username);
            qcc_edp.setUpdate_program("/qcc_edp/update_Qc");
            try {
                DateUtils.convert2Date();
                BeanUtils.populate(qcc_edp, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //调用业务层的update()方法
            iQccEdpService.update(qcc_edp);
            b++;
            if (b == c) {
                break;
            }
        }
        // 响应数据
        JsonUtil.writeValue(info,response);
    }

    /**
     * @Author Wang FengCai
     * @Description //增加
     * @Date 2020/3/19
     **/

    @RequestMapping("/save.do")
    public void save(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        List<Qcc_edp> qccEdps = new ArrayList<Qcc_edp>();
        String username = (String) session.getAttribute("username");
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                if ("date_to_now".equals(name1) || "num".equals(name1) || "chinese_name".equals(name1) || "date_of_resignation".equals(name1)) {
                    //不做处理
                } else {
                    //将每一个key值对应的一组值放到数组里去
                    String[] vals = (String[]) map.get(name1);
                    c = vals.length;
                    //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                    hashMap.put(name1, vals[b]);
                }
            }
            //如果取出的 工号为空，则不往数据库里插入数据
            if (hashMap.get("employee_id").equals(null) || hashMap.get("employee_id").equals("")) {
                b++;
                if (b == c) {
                    break;
                }
                continue;
            }
            //创建对象
            Qcc_edp qccEdp = new Qcc_edp();
            try {
                DateUtils.convert2Date();
                BeanUtils.populate(qccEdp, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            qccEdp.setLogin_oid(username);
            qccEdp.setUpdate_program("/qcc_edp/save");
            qccEdp.setUpdate_oid(username);
            //调用业务层的save()方法
            iQccEdpService.save(qccEdp);
            b++;
            if (b == c) {
                break;
            }
        }
        info.setErrorList(errorList);
        info.setData(qccEdps);
        // 响应数据
        JsonUtil.writeValue(info,response);
    }

    /**
     * @Author Wang FengCai
     * @Description 重要作业报表
     * @Date 2020/4/28
     **/
    @RequestMapping("/findDatapool2Edp.do")
    public ModelAndView findDatapool2Edp(HttpServletRequest request) throws Exception {
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        List<Qcc_edp> qccEdpList = null;
        //调用MapUtils进行判断
//        if(MapUtils.isEmpty(map)){
//            //调用查询所有的方法
//            qccEdpList = iQccEdpService.findAll();
//            //将取回的结果遍历并处理
//            iteration2EdpList(qccEdpList);
//        }else{
        //创建一个对象
        Qcc_getParmeter qccGetParmeter = new Qcc_getParmeter();
        qccGetParmeter.setEducate_type1(request.getParameter("educate_typeFrom"));
        qccGetParmeter.setEducate_type2(request.getParameter("educate_typeTo"));
        qccGetParmeter.setWorkplace_code1(request.getParameter("workplace_codeFrom"));
        qccGetParmeter.setWorkplace_code2(request.getParameter("workplace_codeTo"));
        qccGetParmeter.setJob_evaluation1(request.getParameter("job_evaluationFrom"));
        qccGetParmeter.setJob_evaluation2(request.getParameter("job_evaluationTo"));
        qccGetParmeter.setSkill_development1(request.getParameter("skill_developmentFrom"));
        qccGetParmeter.setSkill_development2(request.getParameter("skill_developmentTo"));
        qccGetParmeter.setEligibility_no1(request.getParameter("eligibility_noFrom"));
        qccGetParmeter.setEligibility_no2(request.getParameter("eligibility_noTo"));
        qccGetParmeter.setDate_of_induction1(request.getParameter("date_of_inductionFrom"));
        qccGetParmeter.setDate_of_induction2(request.getParameter("date_of_inductionTo"));
        qccGetParmeter.setConfirm_date1(request.getParameter("confirm_dateFrom"));
        qccGetParmeter.setConfirm_date2(request.getParameter("confirm_dateTo"));
        qccGetParmeter.setManufacture_lore_one1(request.getParameter("manufature_lore_oneFrom"));
        qccGetParmeter.setManufacture_lore_one2(request.getParameter("manufature_lore_oneTo"));
        qccGetParmeter.setManufacture_lore_two1(request.getParameter("manufature_lore_twoFrom"));
        qccGetParmeter.setManufacture_lore_two2(request.getParameter("manufature_lore_twoTo"));
        qccGetParmeter.setStandard_work_one1(request.getParameter("standard_work_oneFrom"));
        qccGetParmeter.setStandard_work_one2(request.getParameter("standard_work_oneTo"));
        qccGetParmeter.setStandard_work_two1(request.getParameter("standard_work_twoFrom"));
        qccGetParmeter.setStandard_work_two2(request.getParameter("standard_work_twoTo"));
        qccGetParmeter.setExoterica_educate_one1(request.getParameter("exoterica_educate_oneFrom"));
        qccGetParmeter.setExoterica_educate_one2(request.getParameter("exoterica_educate_oneTo"));
        qccGetParmeter.setExoterica_educate_two1(request.getParameter("exoterica_educate_twoFrom"));
        qccGetParmeter.setExoterica_educate_two2(request.getParameter("exoterica_educate_twoTo"));
        //调用业层的方法查询
        qccEdpList = iQccEdpService.findDatapool2Edp(qccGetParmeter);

//        }
        //创建视图对象
        ModelAndView modelAndView = new ModelAndView();
        //使用addObject()设置需要返回的值
        modelAndView.addObject("qccEdpList", qccEdpList);
        //通过setViewName()方法跳转到指定的页面
        if (qccEdpList.isEmpty()) {
            modelAndView.setViewName("qcc-edp-nofound");
        } else {
            modelAndView.setViewName("qcc-edp-datapool-list");
        }
        //返回视图解析对象
        return modelAndView;
    }

}
