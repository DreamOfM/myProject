package com.tdk.txm_java.exception;

import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_20200325</h3>
 * @ClassName<h4></h4>
 * @ToDo<p>异常处理器</p>
 * @date : 2020-04-06 09:59
 * @version:1.0
 **/
public class SysExcepetionResolver implements HandlerExceptionResolver {
    /**
     * @Author Wang FengCai
     * @Description 跳转到具体页面的方法
     * @Date  2020/4/6
     * @Time  上午 10:01
     * @Param
     * @return
     **/
    @Override
    public ModelAndView resolveException(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) {
        e.printStackTrace();
        SysException sysException = null;

        //判断
        if(e instanceof SysException){
            //类型强转
            sysException = (SysException) e;
        }else{
            sysException = new SysException("请联系管理员");
        }

        ModelAndView mv = new ModelAndView();
        //存入错误的提示信息
        mv.addObject("message",sysException.getMessage());
        //跳转页面
        mv.setViewName("error");
        return mv;
    }
}
