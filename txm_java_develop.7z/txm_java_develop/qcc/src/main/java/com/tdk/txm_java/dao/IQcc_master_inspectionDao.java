package com.tdk.txm_java.dao;

import com.tdk.txm_java.domain.Qcc_getParmeter2MasterInspection;
import com.tdk.txm_java.domain.Qcc_master_inspection;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

/**
 * <h3>txm_java_20200325</h3>
 * <p>主档</p>
 *
 * @author : Wang FengCai
 * @date : 2020-04-08 19:28
 **/
@Repository
public interface IQcc_master_inspectionDao {

    @Update("update qcc_master_inspection set educate_type=#{educate_type}, workplace_code=#{workplace_code}, employee_id=#{employee_id}, date_of_induction=#{date_of_induction}, date_of_departure=#{date_of_departure},date_of_vacation=#{date_of_vacation}, characte=#{characte}, sure=#{sure}, flexibitity=#{flexibitity}, eye_left=#{eye_left}, eye_right=#{eye_right}, color_sensitivity=#{color_sensitivity}, sampling_principle=#{sampling_principle}, product_knowledge=#{product_knowledge}, operation_education=#{operation_education}, skill_development=#{skill_development}, identify_ability=#{identify_ability}, job_evaluation=#{job_evaluation}, stamp_serial_no=#{stamp_serial_no}, stamp_type=#{stamp_type}, eligibility_no=#{eligibility_no}, eligibility_status=#{eligibility_status}, confirm_date=#{confirm_date}, qa_manager_confirm=#{qa_manager_confirm}, identify_ability_1=#{identify_ability_1}, qc_confirm_of_1=#{qc_confirm_of_1}, confirm_date_of_1=#{confirm_date_of_1}, identif_ability_2=#{identif_ability_2}, qc_confirm_of_2=#{qc_confirm_of_2}, confirm_date_of_2=#{confirm_date_of_2}, special=#{special}, grr=#{grr}, field1=#{field1}, field2=#{field2}, update_oid=#{update_oid}, update_program=#{update_program} where id=#{id}")
    void update(Qcc_master_inspection qcc1Main)throws Exception;

    @Insert("insert into qcc_master_inspection(educate_type,workplace_code,employee_id,date_of_induction,date_of_departure,date_of_vacation," +
            "characte,sure,flexibitity,eye_left,eye_right,color_sensitivity,sampling_principle,product_knowledge,operation_education,skill_development," +
            "identify_ability,job_evaluation,stamp_serial_no,stamp_type,eligibility_no,eligibility_status," +
            "qa_manager_confirm,identify_ability_1,qc_confirm_of_1,confirm_date_of_1,identif_ability_2," +
            "qc_confirm_of_2,confirm_date_of_2,special,grr,field1,field2,login_time,login_oid,update_oid,update_program)values" +
            "(#{educate_type},#{workplace_code},#{employee_id},#{date_of_induction},#{date_of_departure},#{date_of_vacation},#{characte}," +
            "#{sure},#{flexibitity},#{eye_left},#{eye_right},#{color_sensitivity},#{sampling_principle}," +
            "#{product_knowledge},#{operation_education},#{skill_development},#{identify_ability}," +
            "#{job_evaluation},#{stamp_serial_no},#{stamp_type},#{eligibility_no},#{eligibility_status}," +
            "#{qa_manager_confirm},#{identify_ability_1},#{qc_confirm_of_1},#{confirm_date_of_1}," +
            "#{identif_ability_2},#{qc_confirm_of_2},#{confirm_date_of_2},#{special},#{grr},#{field1},#{field2}," +
            "now(),#{login_oid},#{update_oid},#{update_program})")
    void save(Qcc_master_inspection qcc1Main)throws Exception;

    @Select("select * from qcc_master_inspection")
    List<Qcc_master_inspection> findAll()throws Exception;

    @Select("select * from qcc_master_inspection where id=#{id}")
    Qcc_master_inspection findById(int id)throws Exception;

    @Select("select * from qcc_master_inspection where educate_type=#{educate_type} and workplace_code=#{workplace_code} order by employee_id")
    List<Qcc_master_inspection> findByEduTypAndWorC(@Param("educate_type") String educateType, @Param("workplace_code") String workplaceCode)throws Exception;

    @Select("select * from qcc_master_inspection where employee_id=#{employee_id} and date_of_departure is null")
    Qcc_master_inspection findByEmpI(String employee_id);

    @Delete("delete from qcc_master_inspection where id=#{id}")
    void deleteById(int id)throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 查找--人员检出力有效效性评估
     * @Date  2020/4/15
     * @Time  上午 10:26
     **/
    @Select("select * from qcc_master_inspection where educate_type=#{educate_type} and workplace_code=#{workplace_code} and qa_manager_confirm='1' and identify_ability<>999 and date_of_departure is null order by employee_id")
    List<Qcc_master_inspection> findByEduTypAndWorC2IdenAss(@Param("educate_type") String educateType,@Param("workplace_code")  String workplaceCode);

    /**
     * @Author Yu Liqin
     * @Description 查找--视力有效性定期评估
     * @Date  2020/4/13
     * @Time  下午 04:44
     **/
    @Select("select * from qcc_master_inspection where educate_type=#{educate_type} and workplace_code=#{workplace_code} and date_of_departure is null and qa_manager_confirm='1' order by employee_id")
    List<Qcc_master_inspection> findByEduTypAndWorPQa(@Param("educate_type") String educateType, @Param("workplace_code") String workplaceCode);

    /**
     * @Author Yu Liqin
     * @Description 查找--试作实习合格维护
     * @Date  2020/4/16
     * @Time  下午 06:51
     **/

    @Select("select * from qcc_master_inspection where educate_type=#{educate_type} and workplace_code=#{workplace_code} and date_of_departure is null order by employee_id")
    List<Qcc_master_inspection> findByEduTypAndWorBo(@Param("educate_type") String educateType, @Param("workplace_code") String workplaceCode);

    /**
     * @Author Wang FengCai
     * @Description 更新调离日期
     * @Date  2020/4/24
     * @Time  下午 01:54
     **/
    @Update("update qcc_master_inspection set date_of_departure=#{date_of_departure} where id=#{id}")
    void update2DateOfDeparById(@Param("id") int id,@Param("date_of_departure") Date date_of_departure);

    /**
     * @Author Wang FengCai
     * @Description 根据工号去查询作业种类等信息
     * @Date  2020/5/6
     * @Time  下午 07:44
     **/
    @Select("select id,educate_type,workplace_code,employee_id,date_of_induction,date_of_departure," +
            "characte,sure,flexibitity,eye_left,eye_right,color_sensitivity,sampling_principle,product_knowledge,operation_education,skill_development," +
            "identify_ability,job_evaluation,stamp_serial_no,stamp_type,eligibility_no,eligibility_status," +
            "qa_manager_confirm,identify_ability_1,qc_confirm_of_1,confirm_date_of_1,identif_ability_2," +
            "qc_confirm_of_2,confirm_date_of_2,special,grr,field1,field2 from qcc_master_inspection where employee_id = #{employeeId} ")
    List<Qcc_master_inspection> findByEmpId(String employeeId);

    /**
     * @Author Wang FengCai
     * @Description 根据工号，作业种类，单位代码查询
     * @Date  2020/5/7
     * @Time  下午 07:13
     **/
    @Select("select * from qcc_master_inspection where employee_id=#{employee_id} and educate_type=#{educate_type} and workplace_code=#{workplace_code} and date_of_departure is null")
    Qcc_master_inspection findByEmpIdAndEduAndWorC(@Param("employee_id") String employee_id, @Param("educate_type") String educateType, @Param("workplace_code") String workplaceCode);

    /**
     * @Author Wang FengCai
     * @Description 根据工号，作业种类查询
     * @Date  2020/5/7
     * @Time  下午 07:13
     **/
    @Select("select * from qcc_master_inspection where employee_id=#{employee_id} and educate_type=#{educate_type}")
    List<Qcc_master_inspection> findByEmpIdAndEduTyp(@Param("employee_id") String employee_id, @Param("educate_type") String educateType);


        /**
     * @Author Wang FengCai
     * @Description 检查人员报表
     * @Date  2020/5/14
     * @Time  上午 11:51
     **/
    @Select("SELECT educate_type,workplace_code,employee_id,date_of_induction,date_of_departure," +
            "characte,sure,flexibitity,confirm_date,eye_left,eye_right,color_sensitivity,sampling_principle,product_knowledge,operation_education,skill_development," +
            "identify_ability,job_evaluation,stamp_serial_no,stamp_type,eligibility_no,eligibility_status," +
            "qa_manager_confirm,identify_ability_1,qc_confirm_of_1,confirm_date_of_1,identif_ability_2, " +
            "qc_confirm_of_2,confirm_date_of_2,special,grr,field1,field2,date_of_vacation FROM qcc_master_inspection WHERE " +
            "(educate_type BETWEEN #{educate_type1} AND #{educate_type2} ) " +
            "and (workplace_code BETWEEN #{workplace_code1} AND #{workplace_code2}) " +
            "and (date_of_induction BETWEEN #{date_of_induction1} AND #{date_of_induction2}) " +
            "and (skill_development BETWEEN #{skill_development1} AND #{skill_development2})" +
            "and (sampling_principle BETWEEN #{sampling_principle1} AND #{sampling_principle2})" +
            "and (product_knowledge BETWEEN #{product_knowledge1} AND #{product_knowledge2})" +
            "and (operation_education BETWEEN #{operation_education1} AND #{operation_education2})" +
            "order by educate_type,workplace_code,employee_id")
    List<Qcc_master_inspection> findDatapool2MasterInspection(Qcc_getParmeter2MasterInspection qccGetParmeter2MasterInspection);

    /**
     * @Author Wang FengCai
     * @Description 根据工号去查询（返回调离日期为空的值）
     * @Date  2020/5/6
     * @Time  下午 07:44
     **/
    @Select("select id,educate_type,workplace_code,employee_id,date_of_induction,date_of_departure," +
            "characte,sure,flexibitity,eye_left,eye_right,color_sensitivity,sampling_principle,product_knowledge,operation_education,skill_development," +
            "identify_ability,job_evaluation,stamp_serial_no,stamp_type,eligibility_no,eligibility_status," +
            "qa_manager_confirm,identify_ability_1,qc_confirm_of_1,confirm_date_of_1,identif_ability_2," +
            "qc_confirm_of_2,confirm_date_of_2,special,grr,field1,field2 from qcc_master_inspection where employee_id = #{employeeId} and date_of_departure is null")
    List<Qcc_master_inspection> findByEmpId2Add(String employeeId);
}

