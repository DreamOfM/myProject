package com.tdk.txm_java.dao;


import com.tdk.txm_java.domain.Qcc_eap;
import com.tdk.txm_java.domain.Qcc_ecp;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author : Yu Liqin
 * @ProjectName<h3>txm_java_0304</h3>
 * @ClassName<h4></h4>
 * @ToDo<p>作業系統控制檔維護</p>
 * @date : 2020-03-16 09:12
 * @version:1.0
 **/
@Repository
public interface IQcc_ecpDao {
    /**
     * @Author Yu Liqin
     * @Description 增加
     * @Date  2020/3/16
     * @Time  上午 09:44
     * @Param
     * @return
     **/
    @Insert("insert into qcc_ecp(password_code,workplace_code_from,workplace_code_to,educate_type_from,educate_type_to,login_time,update_time,update_oid,update_program,login_oid) values" +
            "(#{password_code},#{workplace_code_from},#{workplace_code_to},#{educate_type_from},#{educate_type_to},now(),now(),#{update_oid},#{update_program},#{login_oid})")
    void save(Qcc_ecp qcc_ecp) throws Exception;

    /**
     * @Author  Yu Liqin
     * @Description 删除
     * @Date  2020/3/11
     * @Time  上午 09:48
     * @Param
     * @return
     **/
    @Delete("delete from qcc_ecp where id=#{id}")
    void deleteById(int id) throws Exception;

    /**
     * @Author  Yu Liqin
     * @Description 修改
     * @Date  2020/3/11
     * @Time  上午 09:50
     * @Param
     * @return
     **/
    @Update("update qcc_ecp set password_code=#{password_code},workplace_code_from=#{workplace_code_from},workplace_code_to=#{workplace_code_to}, educate_type_from=#{educate_type_from},educate_type_to=#{educate_type_to},update_program=#{update_program},update_oid=#{update_oid} where id=#{id}")
    void update(Qcc_ecp qcc_ecp) throws Exception;

    /**
     * @Author Yu Liqin
     * @Description 查找所有
     * @Date  2020/3/11
     * @Time  上午 09:54
     * @Param
     * @return
     **/
    @Select("select * from qcc_ecp")
    Qcc_ecp findAll() throws Exception;

    /**
     * @Author Yu Liqin
     * @Description 根据ID查询
     * @Date  2020/3/11
     * @Time  上午 09:55
     * @Param
     * @return
     **/
    @Select("select * from qcc_ecp where id=#{id}")
    Qcc_ecp findById(int id) throws Exception;

    /**
     * @Author Yu Li qin
     * @Description 查询dept_code在数据库中是否存在？
     * @Date  2020/3/13
     * @Time  上午 09:38
     * @Param [deptCode]
     * @return java.lang.String
     **/
    @Select("select password_code from qcc_ecp where password_code=#{password_code}  group by password_code")
    String findByPassC(String password_code);

    /**
     * @Author Yu Liqin
     * @Description 根据password_code查询
     * @Date  2020/3/13
     * @Time  上午 10:15
     * @Param [password_code]
     * @return com.tdk.txm_java.domain.Qcc_ecp
     **/
    @Select("select * from qcc_ecp where password_code like #{password_code}")
    List<Qcc_ecp> findByPassCode(String password_code);

    /**
     * @Author Wang FengCai
     * @Description 根据password_code查询
     * @Date  2020/3/31
     * @Time  上午 08:36
     * @Param [passwordCode]
     * @return com.tdk.txm_java.domain.Qcc_ecp
     **/
    @Select("select * from qcc_ecp where password_code = #{password_code}")
    Qcc_ecp findByPassCode1(String passwordCode);
}

