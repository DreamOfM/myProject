package com.tdk.txm_java.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tdk.txm_java.domain.Com_employee;
import com.tdk.txm_java.domain.Qcc_master_inspection;
import com.tdk.txm_java.domain.ResultInfo;
import com.tdk.txm_java.service.ICom_employeeService;
import com.tdk.txm_java.service.IQcc_eapService;
import com.tdk.txm_java.service.IQcc_ebpService;
import com.tdk.txm_java.service.IQcc_master_inspectionService;
import com.tdk.txm_java.utils.JsonUtil;
import com.tdk.txm_java.utils.DateUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.lang.reflect.InvocationTargetException;
import java.time.LocalDate;
import java.time.Period;
import java.util.*;

/**
 * @Author Xiaoni Chen
 * @Description //TODO a373493
 * @Date 2020/4/13
 * @Time 下午 04:17
 **/

@Controller
@RequestMapping("/qcc_master_qualified")
public class Qcc_master_qualifiedController {
    @Autowired
    private IQcc_master_inspectionService iQccMasterInspectionService;
    @Autowired
    private ICom_employeeService iCom_employeeService;
    @Autowired
    private IQcc_ebpService iQccEbpService;
    @Autowired
    private IQcc_eapService iQccEapService;

    private void findEducateTypeChineseNameAndWorkplaceCodeChineseName(Qcc_master_inspection qcc1Main) {
        //去eap中取出作业种类和单位代码对应的中文信息
        qcc1Main.setEducateTypeChineseName(iQccEapService.findByEduTyp1(qcc1Main.getEducate_type()).getEducate_type_name());
        //去ebp中取出单位代码对应的信息
        qcc1Main.setWorkplaceCodeChineseName(iQccEbpService.findByWpCAndEduT(qcc1Main.getWorkplace_code(), qcc1Main.getEducate_type()).getSection_code() + " " + iQccEbpService.findByWpCAndEduT(qcc1Main.getWorkplace_code(), qcc1Main.getEducate_type()).getAssistant_code() + " " + iQccEbpService.findByWpCAndEduT(qcc1Main.getWorkplace_code(), qcc1Main.getEducate_type()).getGroup_code() + " " + iQccEbpService.findByWpCAndEduT(qcc1Main.getWorkplace_code(), qcc1Main.getEducate_type()).getWork_center());
    }


    @RequestMapping("/checkscreen.do")
    public void checkscreen(HttpServletRequest request, HttpServletResponse response) throws Exception {

        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        List<Qcc_master_inspection> qcc1Mains = new ArrayList<Qcc_master_inspection>();
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //字段date_to_now(到岗日)，chinese_name(姓名)，date_of_resignation(辞职日)
                if ("date_to_now".equals(name1) || "del".equals(name1) || "num".equals(name1) || "chinese_name".equals(name1) || "date_of_resignation".equals(name1)) {
                    //不做处理
                } else {
                    //将每一个key值对应的一组值放到数组里去
                    String[] vals = (String[]) map.get(name1);
                    c = vals.length;
                    //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                    hashMap.put(name1, vals[b]);
                }
            }

            //取出id,根据Id查找对象
            int id = Integer.parseInt(hashMap.get("id"));
            String errLine = String.valueOf(b);
            if (!"".equals(hashMap.get("qa_manager_confirm")) && !"1".equals(hashMap.get("qa_manager_confirm"))) {
                info.setFlag(false);
                errorList.add("qa_manager_confirm" + errLine);
                info.setErrorMsg("承认只允许维护 1 或者空,请确认!");
            }
            if (!"".equals(hashMap.get("special").toUpperCase()) && !"Y".equals(hashMap.get("special").toUpperCase())) {
                info.setFlag(false);
                errorList.add("special" + errLine);
                info.setErrorMsg("特例只允许维护Y或者空,请确认!");
            }
            if ("".equals(hashMap.get("job_evaluation")) && hashMap.get("confirm_date") != null) {
                info.setFlag(false);
                errorList.add("job_evaluation" + errLine);
                info.setErrorMsg("作业评定为空不能进行认定,请确认!");
            }
            if (!"".equals(hashMap.get("qa_manager_confirm")) && hashMap.get("confirm_date") == null) {
                info.setFlag(false);
                errorList.add("confirm_date" + errLine);
                info.setErrorMsg("认定日为空不能维护承认,请确认!");
            }

            if (Integer.parseInt(hashMap.get("sampling_principle")) < 90) {
                //特例只允许维护Y或者空
                info.setFlag(false);
                errorList.add("sampling_principle" + errLine);
                info.setErrorMsg("成绩< 90 不合格,请确认!");
            }
            b++;
            if (b == c) {
                break;
            }
        }
        info.setErrorList(errorList);
        info.setData(qcc1Mains);
        //响应数据
        JsonUtil.writeValue(info,response);
    }

    @RequestMapping("/findByEduTypAndWorC1.do")
    protected ModelAndView findByEduTypAndWorC1(HttpServletRequest request, @RequestParam(value = "pn", defaultValue = "1") Integer pn, @RequestParam(value = "PageSize", defaultValue = "10") Integer ps) throws Exception {
        //引入PageHelper分页插件
        PageHelper.startPage(pn, ps);
        //取回前端传回的数据
        String educateType = request.getParameter("educate_type");
        String workplaceCode = request.getParameter("workplace_code");
        //调用业务层的方法查询
        List<Qcc_master_inspection> qcc1Mains = iQccMasterInspectionService.findByEduTypAndWorBo(educateType, workplaceCode);
        //将取回的结果遍历
        for (Qcc_master_inspection qcc1Main : qcc1Mains) {
            //取出每个对象中的工号
            String emId = qcc1Main.getEmployee_id();
            //根据工号去人事主档查询
            Com_employee comEmployee = iCom_employeeService.findByEmployee_id(emId);
            if ( comEmployee != null && !"".equals(comEmployee)) {
                //取出离职日，做处理
                if (comEmployee.getMmrsgn() == null || "".equals(comEmployee.getMmrsgn()) || "0".equals(comEmployee.getMmrsgn())) {
                    qcc1Main.setMmrsgn("");
                } else {
                    //在字符串中插入"-"
                    new StringBuffer(comEmployee.getMmrsgn()).insert(6, "-");
                    new StringBuffer(comEmployee.getMmrsgn()).insert(4, "-");
                    //转换格式
                    qcc1Main.setMmrsgn(new StringBuffer(comEmployee.getMmrsgn()).toString());
                }

                //取出姓名，并处理
                String mdn = comEmployee.getMmdnam();
                qcc1Main.setMmdnam(mdn);
                //转换格式
                LocalDate date_of_induction = DateUtils.date2LocalDate(qcc1Main.getDate_of_induction());
                //计算离岗 年/天
                Period p;
                String date_to_now = null;
                //判断调离日是否为空
                if (qcc1Main.getDate_of_departure() != null && !"".equals(qcc1Main.getDate_of_departure())) {
                    //到岗年/天=调离日-到岗日
                    p = DateUtils.calculateTimeDifferenceByPeriod2(DateUtils.date2LocalDate(qcc1Main.getDate_of_departure()), date_of_induction);
                } else {
                    //调用工具类的方法计算时间差
                    p = DateUtils.calculateTimeDifferenceByPeriod(date_of_induction);
                }
                //调用工具类 判断 年/天的显示格式
                date_to_now = DateUtils.dateDisplay(p);
                //重新放到对象中去
                qcc1Main.setDate_to_now(date_to_now);
            }
            //调用方法查询单位代码和作业种类对应的中文信息
            findEducateTypeChineseNameAndWorkplaceCodeChineseName(qcc1Main);
        }
        //创建视图对象
        ModelAndView mv = new ModelAndView();
        PageInfo page = new PageInfo(qcc1Mains, ps);
        //使用addObject()设置需要返回的值
        mv.addObject("qcc1Mains", qcc1Mains);
        mv.addObject("pageInfo", page);
        //通过setViewName()方法跳转到指定的页面
        mv.setViewName("qcc-master-qualified-list");
        return mv;
    }

    @RequestMapping("/update.do")
    public void update(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        //取出前端传回的所有数据
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        String username = (String) session.getAttribute("username");
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<String, String>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //字段date_to_now(到岗 年/天)，chinese_name(姓名)，date_of_resignation(辞职日)
                if ("date_to_now".equals(name1) || "del".equals(name1) || "num".equals(name1) || "chinese_name".equals(name1) || "date_of_resignation".equals(name1)) {
                    //不做处理
                } else {
                    //将每一个key值对应的一组值放到数组里去
                    String[] vals = (String[]) map.get(name1);
                    c = vals.length;
                    //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                    hashMap.put(name1, vals[b]);
                }
            }
            //取出ID
            int id = Integer.parseInt(hashMap.get("id"));
            //判断
            Qcc_master_inspection qccMasterInspection = iQccMasterInspectionService.findById(id);
            if ( qccMasterInspection == null || "".equals(qccMasterInspection)) {
                b++;
                if (b == c) {
                    break;
                }
                continue;
            } else {
                //创建对象
                Qcc_master_inspection qcc1Main = iQccMasterInspectionService.findById(id);
                try {
                    DateUtils.convert2Date();
                    BeanUtils.populate(qcc1Main, hashMap);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    e.printStackTrace();
                }
                //更新的程序
                qcc1Main.setUpdate_oid(username);
                qcc1Main.setUpdate_program("/qcc_master_inspection/update");
                //调用业务层的update()方法
                iQccMasterInspectionService.update(qcc1Main);
                b++;
                if (b == c) {
                    break;
                }
            }
        }
        // 响应数据
        JsonUtil.writeValue(info,response);

    }
}

