package com.tdk.txm_java.service;

import com.tdk.txm_java.domain.Qcc_getParmeter;
import com.tdk.txm_java.domain.Qcc_getParmeter2MasterInspection;
import com.tdk.txm_java.domain.Qcc_master_inspection;

import java.util.Date;
import java.util.List;

/**
 * <h3>txm_java_20200325</h3>
 * <p>主档--业务层--接口</p>
 *
 * @author : Wang FengCai
 * @date : 2020-04-08 20:01
 **/
public interface IQcc_master_inspectionService {

    void update(Qcc_master_inspection qcc1Main) throws Exception;

    void save(Qcc_master_inspection qcc1Main) throws Exception;

    List<Qcc_master_inspection> findAll() throws Exception;

    Qcc_master_inspection findById(int id) throws Exception;

    List<Qcc_master_inspection> findByEduTypAndWorC(String educateType, String workplaceCode) throws Exception;

    void deleteById(int id) throws Exception;

    Qcc_master_inspection findByEmpI(String employee_id)throws Exception;
    /**
     * @Author Wang FengCai
     * @Description 查找--人员检出力有效性评估
     * @Date  2020/4/15
     * @Time  上午 10:09
     **/
    List<Qcc_master_inspection> findByEduTypAndWorC2IdenAss(String educateType, String workplaceCode) throws Exception;

    /**
     * @Author Yu Liqin
     * @Description  视力有效性定期评估
     * @Date  2020/4/13
     * @Time  下午 04:51
     **/

    List<Qcc_master_inspection> findByEduTypAndWorPQa(String educateType, String workplaceCode) throws Exception;

    /**
     * @Author Yu Liqin
     * @Description 查找--试作实习合格维护
     * @Date  2020/4/16
     * @Time  下午 06:54
     **/

    List<Qcc_master_inspection> findByEduTypAndWorBo(String educateType, String workplaceCode)throws Exception;

    /**
     * @Author Wang FengCai
     * @Description //星期天执行  辞职日,调离日超过一个月自动删除
     * @Date 2020/4/24
     * @Time 上午 11:10
     **/
    void deleteTask2Main() throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 根据工号查询作业种类
     * @Date  2020/5/6
     * @Time  下午 07:43
     **/
    List<Qcc_master_inspection> findByEmpId(String employeeId);

    /**
     * @Author Wang FengCai
     * @Description 根据工号查询作业种类(调离日期为空)
     * @Date  2020/5/6
     * @Time  下午 07:43
     **/
    List<Qcc_master_inspection> findByEmpId2Add(String employeeId);

    /**
     * @Author Wang FengCai
     * @Description 检查人员基本资料新增时  检查需要调用的方法
     * @Date  2020/5/7
     * @Time  下午 07:43
     **/
//    List<Qcc_master_inspection> findByEmpId2Add(String employeeId);

    /**
     * @Author Wang FengCai
     * @Description 根据工号，作业种类和单位代码去查询
     * @Date  2020/5/7
     * @Time  下午 07:10
     **/
    Qcc_master_inspection findByEmpIdAndEduAndWorC(String employee_id, String educateType, String workplaceCode);

    /**
     * @Author Wang FengCai
     * @Description 根据工号，作业种类查询
     * @Date  2020/5/7
     * @Time  下午 07:10
     **/
    List<Qcc_master_inspection> findByEmpIdAndEduTyp(String employee_id, String educateType);

    /**
     * @Author Wang FengCai
     * @Description 检查人员报表
     * @Date  2020/5/14
     * @Time  上午 11:45
     **/
    List<Qcc_master_inspection> findDatapool2MasterInspection(Qcc_getParmeter2MasterInspection qccGetParmeter2MasterInspection);
}

