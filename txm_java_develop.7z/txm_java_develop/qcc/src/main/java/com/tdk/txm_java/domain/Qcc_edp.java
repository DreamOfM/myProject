package com.tdk.txm_java.domain;
import java.util.Date;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_0304</h3>
 * @ClassName<h4></h4>
 * @ToDo<p>受训人员基本资料维护</p>
 * @date : 2020-03-16 09:00
 * @version:1.0
 **/
public class Qcc_edp {
    private int id;
    private String educate_type;
    private String workplace_code;
    private String employee_id;
    //上岗日期
    private Date date_of_induction;
    //离岗日期
    private Date date_of_departure;
    //技能实习
    private int skill_development;
    //作业训练评定
    private String job_evaluation;
    //制品知识1
    private int manufature_lore_one;
    //制品知识2
    private int manufature_lore_two;
    //作业标准1
    private int standard_work_one;
    //作业标准2
    private int standard_work_two;
    //理论教育1
    private int exoterica_educate_one;
    //理论教育2
    private int exoterica_educate_two;
    //合格牌号
    private String eligibility_no;
    //合格牌收回狀態
    private String eligibility_status;
    //合格認定日
    private Date confirm_date;
    //QA 經理承認
    private String qa_manager_confirm;
    //1 次訓練評定日
    private Date assess_of_1;
    //1 次 QC 主管認定
    private String qc_confirm_of_1;
    //2 次訓練評定日
    private String assess_of_2;
    //2 次 QC 主管認定
    private String qc_confirm_of_2;
    //3 次訓練評定日
    private Date assess_of_3;
    /**
     * @Author Wang FengCai
     * @Description 用户要求新增一个长假开始时间栏位用于对应那些产假病假的情况
     * @Date  2020/11/9
     **/
    private Date  date_of_vacation;

    //3 次 QC 主管認定
    private String qc_confirm_of_3;
    //登录时间
    private  Date   login_time;
    //更新时间
    private  Date   update_time;
    //更新ID
    private  String update_oid;
    //更新程序
    private  String update_program;
    //登录ID
    private  String login_oid;

    //姓名
    private String mmdnam;
    //辞职日
    private String mmrsgn;
    //入社日
    private String mmhire;
    //到岗 年/天
    private String date_to_now;
    //技能有效评估增加的字段，用于显示计算结果
    private int dayToNow;
    //职种代码
    private String mmpos3;
    //职种名称
    private String mmp3nm;
    //人事股别
    private String mmdept;
    private String chinese_name;
    //作业种类中文名称
    private String educateTypeChineseName;
    //单位代码信息
    private String  workplaceCodeChineseName;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEducate_type() {
        return educate_type;
    }

    public void setEducate_type(String educate_type) {
        this.educate_type = educate_type;
    }

    public String getWorkplace_code() {
        return workplace_code;
    }

    public void setWorkplace_code(String workplace_code) {
        this.workplace_code = workplace_code;
    }

    public String getEmployee_id() {
        return employee_id;
    }

    public void setEmployee_id(String employee_id) {
        this.employee_id = employee_id;
    }

    public Date getDate_of_induction() {
        return date_of_induction;
    }

    public void setDate_of_induction(Date date_of_induction) {
        this.date_of_induction = date_of_induction;
    }

    public Date getDate_of_departure() {
        return date_of_departure;
    }

    public void setDate_of_departure(Date date_of_departure) {
        this.date_of_departure = date_of_departure;
    }

    public int getSkill_development() {
        return skill_development;
    }

    public void setSkill_development(int skill_development) {
        this.skill_development = skill_development;
    }

    public String getJob_evaluation() {
        return job_evaluation;
    }

    public void setJob_evaluation(String job_evaluation) {
        this.job_evaluation = job_evaluation;
    }

    public int getManufature_lore_one() {
        return manufature_lore_one;
    }

    public void setManufature_lore_one(int manufature_lore_one) {
        this.manufature_lore_one = manufature_lore_one;
    }

    public int getManufature_lore_two() {
        return manufature_lore_two;
    }

    public void setManufature_lore_two(int manufature_lore_two) {
        this.manufature_lore_two = manufature_lore_two;
    }

    public int getStandard_work_one() {
        return standard_work_one;
    }

    public void setStandard_work_one(int standard_work_one) {
        this.standard_work_one = standard_work_one;
    }

    public int getStandard_work_two() {
        return standard_work_two;
    }

    public void setStandard_work_two(int standard_work_two) {
        this.standard_work_two = standard_work_two;
    }

    public int getExoterica_educate_one() {
        return exoterica_educate_one;
    }

    public void setExoterica_educate_one(int exoterica_educate_one) {
        this.exoterica_educate_one = exoterica_educate_one;
    }

    public int getExoterica_educate_two() {
        return exoterica_educate_two;
    }

    public void setExoterica_educate_two(int exoterica_educate_two) {
        this.exoterica_educate_two = exoterica_educate_two;
    }

    public String getEligibility_no() {
        return eligibility_no;
    }

    public void setEligibility_no(String eligibility_no) {
        this.eligibility_no = eligibility_no;
    }

    public String getEligibility_status() {
        return eligibility_status;
    }

    public void setEligibility_status(String eligibility_status) {
        this.eligibility_status = eligibility_status;
    }

    public Date getConfirm_date() {
        return confirm_date;
    }

    public void setConfirm_date(Date confirm_date) {
        this.confirm_date = confirm_date;
    }

    public String getQa_manager_confirm() {
        return qa_manager_confirm;
    }

    public void setQa_manager_confirm(String qa_manager_confirm) {
        this.qa_manager_confirm = qa_manager_confirm;
    }

    public Date getAssess_of_1() {
        return assess_of_1;
    }

    public void setAssess_of_1(Date assess_of_1) {
        this.assess_of_1 = assess_of_1;
    }

    public String getQc_confirm_of_1() {
        return qc_confirm_of_1;
    }

    public void setQc_confirm_of_1(String qc_confirm_of_1) {
        this.qc_confirm_of_1 = qc_confirm_of_1;
    }

    public String getAssess_of_2() {
        return assess_of_2;
    }

    public void setAssess_of_2(String assess_of_2) {
        this.assess_of_2 = assess_of_2;
    }

    public String getQc_confirm_of_2() {
        return qc_confirm_of_2;
    }

    public void setQc_confirm_of_2(String qc_confirm_of_2) {
        this.qc_confirm_of_2 = qc_confirm_of_2;
    }

    public Date getAssess_of_3() {
        return assess_of_3;
    }

    public void setAssess_of_3(Date assess_of_3) {
        this.assess_of_3 = assess_of_3;
    }

    public Date getDate_of_vacation() {
        return date_of_vacation;
    }

    public void setDate_of_vacation(Date date_of_vacation) {
        this.date_of_vacation = date_of_vacation;
    }

    public String getQc_confirm_of_3() {
        return qc_confirm_of_3;
    }

    public void setQc_confirm_of_3(String qc_confirm_of_3) {
        this.qc_confirm_of_3 = qc_confirm_of_3;
    }

    public Date getLogin_time() {
        return login_time;
    }

    public void setLogin_time(Date login_time) {
        this.login_time = login_time;
    }

    public Date getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(Date update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getMmdnam() {
        return mmdnam;
    }

    public void setMmdnam(String mmdnam) {
        this.mmdnam = mmdnam;
    }

    public String getMmrsgn() {
        return mmrsgn;
    }

    public void setMmrsgn(String mmrsgn) {
        this.mmrsgn = mmrsgn;
    }

    public String getMmhire() {
        return mmhire;
    }

    public void setMmhire(String mmhire) {
        this.mmhire = mmhire;
    }

    public String getDate_to_now() {
        return date_to_now;
    }

    public void setDate_to_now(String date_to_now) {
        this.date_to_now = date_to_now;
    }

    public int getDayToNow() {
        return dayToNow;
    }

    public void setDayToNow(int dayToNow) {
        this.dayToNow = dayToNow;
    }

    public String getMmpos3() {
        return mmpos3;
    }

    public void setMmpos3(String mmpos3) {
        this.mmpos3 = mmpos3;
    }

    public String getMmp3nm() {
        return mmp3nm;
    }

    public void setMmp3nm(String mmp3nm) {
        this.mmp3nm = mmp3nm;
    }

    public String getMmdept() {
        return mmdept;
    }

    public void setMmdept(String mmdept) {
        this.mmdept = mmdept;
    }

    public String getChinese_name() {
        return chinese_name;
    }

    public void setChinese_name(String chinese_name) {
        this.chinese_name = chinese_name;
    }

    public String getEducateTypeChineseName() {
        return educateTypeChineseName;
    }

    public void setEducateTypeChineseName(String educateTypeChineseName) {
        this.educateTypeChineseName = educateTypeChineseName;
    }

    public String getWorkplaceCodeChineseName() {
        return workplaceCodeChineseName;
    }

    public void setWorkplaceCodeChineseName(String workplaceCodeChineseName) {
        this.workplaceCodeChineseName = workplaceCodeChineseName;
    }

    @Override
    public String toString() {
        return "Qcc_edp{" +
                "id=" + id +
                ", educate_type='" + educate_type + '\'' +
                ", workplace_code='" + workplace_code + '\'' +
                ", employee_id='" + employee_id + '\'' +
                ", date_of_induction=" + date_of_induction +
                ", date_of_departure=" + date_of_departure +
                ", skill_development=" + skill_development +
                ", job_evaluation='" + job_evaluation + '\'' +
                ", manufature_lore_one=" + manufature_lore_one +
                ", manufature_lore_two=" + manufature_lore_two +
                ", standard_work_one=" + standard_work_one +
                ", standard_work_two=" + standard_work_two +
                ", exoterica_educate_one=" + exoterica_educate_one +
                ", exoterica_educate_two=" + exoterica_educate_two +
                ", eligibility_no='" + eligibility_no + '\'' +
                ", eligibility_status='" + eligibility_status + '\'' +
                ", confirm_date=" + confirm_date +
                ", qa_manager_confirm='" + qa_manager_confirm + '\'' +
                ", assess_of_1=" + assess_of_1 +
                ", qc_confirm_of_1='" + qc_confirm_of_1 + '\'' +
                ", assess_of_2='" + assess_of_2 + '\'' +
                ", qc_confirm_of_2='" + qc_confirm_of_2 + '\'' +
                ", assess_of_3=" + assess_of_3 +
                ", date_of_vacation=" + date_of_vacation +
                ", qc_confirm_of_3='" + qc_confirm_of_3 + '\'' +
                ", login_time=" + login_time +
                ", update_time=" + update_time +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                ", login_oid='" + login_oid + '\'' +
                ", mmdnam='" + mmdnam + '\'' +
                ", mmrsgn='" + mmrsgn + '\'' +
                ", mmhire='" + mmhire + '\'' +
                ", date_to_now='" + date_to_now + '\'' +
                ", dayToNow=" + dayToNow +
                ", mmpos3='" + mmpos3 + '\'' +
                ", mmp3nm='" + mmp3nm + '\'' +
                ", mmdept='" + mmdept + '\'' +
                ", chinese_name='" + chinese_name + '\'' +
                ", educateTypeChineseName='" + educateTypeChineseName + '\'' +
                ", workplaceCodeChineseName='" + workplaceCodeChineseName + '\'' +
                '}';
    }
}
