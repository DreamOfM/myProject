package com.tdk.txm_java.service;
import com.tdk.txm_java.domain.Qcc_edp;
import com.tdk.txm_java.domain.Qcc_getParmeter;

import java.util.List;


/**
 * <h3>txm_java_0304</h3>
 * <p>受训人员基本资料维护</p>
 *
 * @author : Wang FengCai
 * @date : 2020-03-11 09:58
 **/
public interface IQcc_edpService {

    /**
     * @Author Wang FengCai
     * @Description 增加
     * @Date  2020/3/16
     * @Time  上午 09:49
     * @Param [qcc_edp]
     * @return void
     **/
    void save(Qcc_edp qcc_edp) throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 删除
     * @Date  2020/3/16
     * @Time  上午 09:49
     * @Param [id]
     * @return void
     **/
    void deleteById(int id)throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 修改
     * @Date  2020/3/16
     * @Time  上午 09:50
     * @Param [qcc_edp]
     * @return void
     **/
    void update(Qcc_edp qcc_edp)throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 查询所有
     * @Date  2020/3/16
     * @Time  上午 09:50
     * @Param []
     * @return com.tdk.txm_java.domain.Qcc_edp
     **/
    List<Qcc_edp> findAll()throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 根据ID查询
     * @Date  2020/3/16
     * @Time  上午 09:51
     * @Param [id]
     * @return com.tdk.txm_java.domain.Qcc_edp
     **/
    Qcc_edp findById(int id)throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 根据作业种类和单位代码查找
     * @Date  2020/3/16
     * @Time  下午 01:51
     * @Param [educateType, workplaceCode]
     * @return java.util.List<com.tdk.txm_java.domain.Qcc_edp>
     **/
    List<Qcc_edp> findByEduTypAndWorC(String educateType, String workplaceCode);

    /**
     * @Author Wang FengCai
     * @Description 根据种类代码和单位代码查找——QC成绩维护
     * @Date  2020/3/21
     * @Time  下午 03:46
     * @Param [educateType, workplaceCode]
     * @return java.util.List<com.tdk.txm_java.domain.Qcc_edp>
     **/
    List<Qcc_edp> findByEduTypAndWorCQc(String educateType, String workplaceCode);

    /**
     * @Author Wang FengCai
     * @Description 根据工号查询
     * @Date  2020/3/23
     * @Time  上午 09:19
     * @Param [employeeId]
     * @return boolean
     **/
    Qcc_edp findByEmpI(String employeeId);

    /**
     * @Author Wang FengCai
     * @Description 根据作业种类，单位代码，工号来查询
     * @Date  2020/3/24
     * @Time  下午 01:21
     * @Param [educate_type, workplace_code, employee_id]
     * @return com.tdk.txm_java.domain.Qcc_edp
     **/
    Qcc_edp findByEduTypAndWorCAndEmpI(String educate_type, String workplace_code, String employee_id);

    /**
     * @Author Wang FengCai
     * @Description 查询合格牌号是否重复
     * @Date  2020/3/25
     * @Time  下午 01:22
     * @Param [el]
     * @return void
     **/
    Qcc_edp findAllByEl(String el);

    /**
     * @Author Wang FengCai
     * @Description 根据种类代码和单位代码查找——技能有效性认定
     * @Date  2020/3/25
     * @Time  下午 02:54
     * @Param [educateType, workplaceCode]
     * @return java.util.List<com.tdk.txm_java.domain.Qcc_edp>
     **/
    List<Qcc_edp> findByEduTypAndWorCEC(String educateType, String workplaceCode);

    /**
     * @Author Wang FengCai
     * @Description 根据单位代码查询
     * @Date  2020/4/3
     * @Time  上午 10:38
     * @Param [workplace_code]
     * @return java.util.List<com.tdk.txm_java.domain.Qcc_edp>
     **/
    List<Qcc_edp> findByWoc(String workplace_code);

    /**
     * @Author Wang FengCai
     * @Description 根据工号查询--基本资料新增
     * @Date  2020/4/8
     * @Time  上午 10:28
     * @Param [employee_id]
     * @return java.util.List<com.tdk.txm_java.domain.Qcc_edp>
     **/
    List<Qcc_edp> findByEmpI_1(String employee_id);

    /**
     * @Author Wang FengCai
     * @Description 定时删除
     * @Date  2020/4/27
     * @Time  下午 03:55
     **/
    void deleteTask2Edp() throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 重要作业报表
     * @Date  2020/4/28
     * @Time  下午 01:53
     **/
    List<Qcc_edp> findDatapool2Edp(Qcc_getParmeter qccGetParmeter);

    /**
     * @Author Wang FengCai
     * @Description 根据工号查询作业种类等信息
     * @Date  2020/5/7
     * @Time  上午 09:04
     **/
    List<Qcc_edp> findByEmpId(String emplyeeId);

    /**
     * @Author Wang FengCai
     * @Description 根据工号和作业种类去查询
     * @Date  2020/5/8
     * @Time  下午 02:27
     **/
    Qcc_edp findByEmpIdAndEduTyp(String employee_id, String educateTpye);

    /**
     * @Author Wang FengCai
     * @Description 根据工号，合格牌号，作业种类来查询
     * @Date  2020/7/27
     * @Time  上午 10:36
     **/
    List<Qcc_edp> findByEduTypAndEl(String educate_type,String el);

}
