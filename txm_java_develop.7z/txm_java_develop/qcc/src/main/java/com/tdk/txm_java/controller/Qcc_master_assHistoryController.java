package com.tdk.txm_java.controller;

import com.tdk.txm_java.domain.Qcc_assessment_history;
import com.tdk.txm_java.domain.Qcc_master_inspection;
import com.tdk.txm_java.domain.ResultInfo;
import com.tdk.txm_java.service.IQcc_assessment_historyService;
import com.tdk.txm_java.service.IQcc_master_inspectionService;
import com.tdk.txm_java.utils.JsonUtil;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_20200325</h3>
 * @ClassName<h4></h4>
 * @ToDo<p>检查人员检出力有效性评估</p>
 * @date : 2020-04-09 09:01
 * @version:1.0
 **/
@Controller
@RequestMapping("/qcc_master_assHistroy")
public class Qcc_master_assHistoryController {
    @Autowired
    private IQcc_assessment_historyService iQccAssessmentHistoryService;
    @Autowired
    private IQcc_master_inspectionService iQccMasterInspectionService;

    /**
     * @Author Wang FengCai
     * @Description 增加
     * @Date 2020/4/15
     **/
    @RequestMapping("/save.do")
    public void save(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        String username = (String) session.getAttribute("username");
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                if ("date_to_now".equals(name1) || "num".equals(name1) || "chinese_name".equals(name1)) {
                    //不做处理
                } else {
                    //将每一个key值对应的一组值放到数组里去
                    String[] vals = (String[]) map.get(name1);
                    c = vals.length;
                    //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                    hashMap.put(name1, vals[b]);
                }
            }
            //如果取出的 认定日为空，则不往数据库里插入数据
            if (hashMap.get("confirm_date_of_1") == null || "".equals(hashMap.get("confirm_date_of_1").trim())) {
                b++;
                if (b == c) {
                    break;
                }
                continue;
            } else {
                //取出作业种类，单位代码，认定日，id
                String eduT = hashMap.get("educate_type");
                String workC = hashMap.get("workplace_code");
                String empId = hashMap.get("employee_id");
                String conF = hashMap.get("confirm_date_of_1");
                int id = Integer.parseInt(hashMap.get("id"));
                //根据id去数据库中查询原数据
                Qcc_master_inspection qccMasIns = iQccMasterInspectionService.findById(id);
                //取出一次认定日，并处理
                if (!"".equals(hashMap.get("confirm_date_of_1")) && hashMap.get("confirm_date_of_1") != null) {
                //将原认定日和前端传回的认定日进行比对
                    Qcc_assessment_history qccAssessmentHistory = iQccAssessmentHistoryService.findByEduTyAndWorCoAndConFiAndEmpId(eduT, workC, conF, empId);
                if (  qccAssessmentHistory == null||"".equals( qccAssessmentHistory)) {
                    //创建对象
                    Qcc_assessment_history qccAssH = new Qcc_assessment_history();
                    try {
                        BeanUtils.populate(qccAssH, hashMap);
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    } catch (InvocationTargetException e) {
                        e.printStackTrace();
                    }
                    qccAssH.setLogin_oid(username);
                    qccAssH.setUpdate_oid(username);
                    qccAssH.setUpdate_program("/qcc_master_assHistroy/save.do");
                    //调用业务层的save()方法
                    iQccAssessmentHistoryService.save(qccAssH);

                    }
                }
                b++;
                if (b == c) {
                    break;
                }
            }
        }
        // 响应数据
        JsonUtil.writeValue(info,response);
    }
}
