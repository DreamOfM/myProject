package com.tdk.txm_java.service.impl;

import com.tdk.txm_java.dao.IQcc_edpDao;
import com.tdk.txm_java.domain.Com_employee;
import com.tdk.txm_java.domain.Qcc_edp;
import com.tdk.txm_java.domain.Qcc_getParmeter;
import com.tdk.txm_java.service.ICom_employeeService;
import com.tdk.txm_java.service.IQcc_edpService;
import com.tdk.txm_java.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_0304</h3>
 * @ClassName<h4></h4>
 * @<p>受训人员基本资料维护</p>
 * @date : 2020-03-16 10:04
 * @version:1.0
 **/
@Service
@Transactional
public class Qcc_edpServiceImpl implements IQcc_edpService {
    @Autowired
    private IQcc_edpDao iQccEdpDao;
    @Autowired
    IQcc_edpService iQccEdpService;
    @Autowired
    ICom_employeeService iCom_employeeService;
    @Autowired
    ICom_employeeService iComEmployeeService;

    /**
     * @return void
     * @Author Wang FengCai
     * @Description 增加
     * @Date 2020/3/16
     * @Time 上午 09:53
     * @Param [qcc_edp]
     **/
    @Override
    public void save(Qcc_edp qcc_edp) throws Exception {
        //转换成大写
        qcc_edp.setLogin_oid(qcc_edp.getLogin_oid().toUpperCase());
        qcc_edp.setJob_evaluation(qcc_edp.getJob_evaluation().toUpperCase());
        qcc_edp.setWorkplace_code(qcc_edp.getWorkplace_code().toUpperCase());
        qcc_edp.setEducate_type(qcc_edp.getEducate_type().toUpperCase());
        qcc_edp.setJob_evaluation(qcc_edp.getJob_evaluation().toUpperCase());
        iQccEdpDao.save(qcc_edp);
    }

    /**
     * @return void
     * @Author Wang FengCai
     * @Description 删除
     * @Date 2020/3/16
     * @Time 上午 09:58
     * @Param [id]
     **/
    @Override
    public void deleteById(int id) throws Exception {
        iQccEdpDao.deleteById(id);
    }

    /**
     * @return void
     * @Author Wang FengCai
     * @Description 修改
     * @Date 2020/3/16
     * @Time 上午 09:58
     * @Param [qcc_edp]
     **/
    @Override
    public void update(Qcc_edp qcc_edp) throws Exception {
        //转换成大写
        qcc_edp.setJob_evaluation(qcc_edp.getJob_evaluation().toUpperCase());
        qcc_edp.setWorkplace_code(qcc_edp.getWorkplace_code().toUpperCase());
        qcc_edp.setEducate_type(qcc_edp.getEducate_type().toUpperCase());
        qcc_edp.setJob_evaluation(qcc_edp.getJob_evaluation().toUpperCase());
        iQccEdpDao.update(qcc_edp);
    }

    /**
     * @return com.tdk.txm_java.domain.Qcc_edp
     * @Author Wang FengCai
     * @Description 查询全部
     * @Date 2020/3/16
     * @Time 上午 09:58
     * @Param []
     **/
    @Override
    public List<Qcc_edp> findAll() throws Exception {
        return iQccEdpDao.findAll();
    }

    /**
     * @return com.tdk.txm_java.domain.Qcc_edp
     * @Author Wang FengCai
     * @Description 根据ID 查找
     * @Date 2020/3/16
     * @Time 上午 09:59
     * @Param [id]
     **/
    @Override
    public Qcc_edp findById(int id) throws Exception {
        return iQccEdpDao.findById(id);
    }

    /**
     * @return java.util.List<com.tdk.txm_java.domain.Qcc_edp>
     * @Author Wang FengCai
     * @Description 根据作业种类和单位代码查找
     * @Date 2020/3/16
     * @Time 下午 01:51
     * @Param [educateType, workplaceCode]
     **/
    @Override
    public List<Qcc_edp> findByEduTypAndWorC(String educateType, String workplaceCode) {
        //大写转换
        educateType.toUpperCase();
        workplaceCode.toUpperCase();
        return iQccEdpDao.findByEduTypAndWorC(educateType, workplaceCode);

    }

    /**
     * @return java.util.List<com.tdk.txm_java.domain.Qcc_edp>
     * @Author Wang FengCai
     * @Description 根据作业种类和单位代码查找——QC成绩维护
     * @Date 2020/3/21
     * @Time 下午 03:47
     * @Param [educateType, workplaceCode]
     **/
    @Override
    public List<Qcc_edp> findByEduTypAndWorCQc(String educateType, String workplaceCode) {
        educateType.toUpperCase();
        workplaceCode.toUpperCase();
        return iQccEdpDao.findByEduTypAndWorCQc(educateType, workplaceCode);
    }

    /**
     * @return com.tdk.txm_java.domain.Qcc_edp
     * @Author Wang FengCai
     * @Description 根据工号查询
     * @Date 2020/3/23
     * @Time 上午 09:20
     * @Param [employeeId]
     **/
    @Override
    public Qcc_edp findByEmpI(String employeeId) {
        //转换成大写
        employeeId.toUpperCase();
        return iQccEdpDao.findByEmpI(employeeId);
    }

    /**
     * @return com.tdk.txm_java.domain.Qcc_edp
     * @Author Wang FengCai
     * @Description 根据作业种类，单位代码，工号来查询
     * @Date 2020/3/24
     * @Time 下午 01:22
     * @Param [educate_type, workplace_code, employee_id]
     **/
    @Override
    public Qcc_edp findByEduTypAndWorCAndEmpI(String educate_type, String workplace_code, String employee_id) {
        //转换成大写
        educate_type.toUpperCase();
        workplace_code.toUpperCase();
        employee_id.toUpperCase();
        return iQccEdpDao.findByEduTypAndWorCAndEmpI(educate_type, workplace_code, employee_id);
    }

    /**
     * @return java.lang.String
     * @Author Wang FengCai
     * @Description 查询合格牌号是否重复
     * @Date 2020/3/25
     * @Time 下午 01:23
     * @Param [el]
     **/
    @Override
    public Qcc_edp findAllByEl(String el) {
        return iQccEdpDao.findAllByEl(el);
    }

    /**
     * @return java.util.List<com.tdk.txm_java.domain.Qcc_edp>
     * @Author Wang FengCai
     * @Description 根据种类代码和单位代码查找——技能有效性认定
     * @Date 2020/3/25
     * @Time 下午 02:55
     * @Param [educateType, workplaceCode]
     **/
    @Override
    public List<Qcc_edp> findByEduTypAndWorCEC(String educateType, String workplaceCode) {
        educateType.toUpperCase();
        workplaceCode.toUpperCase();
        return iQccEdpDao.findByEduTypAndWorcEC(educateType, workplaceCode);
    }

    /**
     * @return java.util.List<com.tdk.txm_java.domain.Qcc_edp>
     * @Author Wang FengCai
     * @Description 根据单位代码查询
     * @Date 2020/4/3
     * @Time 上午 10:38
     * @Param [workplace_code]
     **/
    @Override
    public List<Qcc_edp> findByWoc(String workplace_code) {
        //转换成大写
        workplace_code.toUpperCase();
        return iQccEdpDao.findByWoc(workplace_code);
    }

    /**
     * @return java.util.List<com.tdk.txm_java.domain.Qcc_edp>
     * @Author Wang FengCai
     * @Description 根据工号查询--基本资料维护新增
     * @Date 2020/4/8
     * @Time 上午 10:32
     * @Param [employee_id]
     **/
    @Override
    public List<Qcc_edp> findByEmpI_1(String employee_id) {
        return iQccEdpDao.findByEmpI_1(employee_id);
    }

    /**
     * @Author Wang FengCai
     * @Description 定时删除
     * @Date 2020/4/27
     * @Time 下午 03:55
     **/
    @Override
    public void deleteTask2Edp() throws Exception {
        //查询表中所有的数据
        List<Qcc_edp> qccEdps = iQccEdpService.findAll();
        if (qccEdps.size() > 0) {
            //遍历取回的list集合取出工号，到人事主档中查询，若查询不到则删除
            for (Qcc_edp qccEdp : qccEdps) {
                //判断
                Com_employee comEmployee = iComEmployeeService.findByEmployee_id(qccEdp.getEmployee_id());
                int id = qccEdp.getId();
                if (comEmployee != null) {
                    //查询到结果，判断离职日是否为'0'
                    if (!"0".equals(comEmployee.getMmrsgn()) && comEmployee.getMmrsgn() != null) {
                        //调用业务层的删除方法将辞职日,调离日超过一个月的删除
                        iQccEdpService.deleteById(id);
                    } else {
                        //若离职日为'0',则判断这笔数据对应的调离日是否为空？不为空，且时间已经超过一个月，删除
                        if (iQccEdpService.findById(id) != null) {
                            Qcc_edp qcc_edp = iQccEdpService.findById(id);
                            //取出调离日，计算是否大于一个月
                            Date date_of_departure = qcc_edp.getDate_of_departure();
                            if(date_of_departure!=null&&!"".equals(date_of_departure)){
                                if (DateUtils.calculateDays(date_of_departure) > 30) {
                                    //调用业务层的删除方法将辞职日,调离日超过一个月的删除
                                    iQccEdpService.deleteById(id);
                                }
                            }
                        }
                    }
                } else if (comEmployee == null || "".equals(comEmployee)) {
                    //该工号在人事主档不存在，删除该工号对应的数据
                    iQccEdpService.deleteById(id);
                }
            }
        }
    }

    /**
     * @param qccGetParmeter
     * @Author Wang FengCai
     * @Description 重要作业报表
     * @Date 2020/4/28
     * @Time 下午 01:53
     */
    @Override
    public List<Qcc_edp> findDatapool2Edp(Qcc_getParmeter qccGetParmeter) {
        //转换大写
        qccGetParmeter.setEducate_type1(qccGetParmeter.getEducate_type1().toUpperCase());
        qccGetParmeter.setEducate_type2(qccGetParmeter.getEducate_type2().toUpperCase());
        qccGetParmeter.setWorkplace_code1(qccGetParmeter.getWorkplace_code1().toUpperCase());
        qccGetParmeter.setWorkplace_code2(qccGetParmeter.getWorkplace_code2().toUpperCase());
        qccGetParmeter.setJob_evaluation1(qccGetParmeter.getJob_evaluation1().toUpperCase());
        qccGetParmeter.setJob_evaluation2(qccGetParmeter.getJob_evaluation2().toUpperCase());
        //将取回的结果遍历
        for (Qcc_edp qccEdp : iQccEdpDao.findDatapool2Edp(qccGetParmeter)) {
            String empId = qccEdp.getEmployee_id();
            if (empId != null && !"".equals(empId)) {
                try {
                    Com_employee comEmployee = iComEmployeeService.findByEmployee_id(empId);
                    System.out.println(comEmployee.toString());
                    if (comEmployee != null && !"".equals(comEmployee)) {
                        if (comEmployee.getMmdnam() != null && !"".equals(comEmployee.getMmdnam())) {
                            qccEdp.setChinese_name(comEmployee.getMmdnam());
                            System.out.println(comEmployee.getMmdnam());
                        }
                        //取出人事主档中的人事股别
                        if (comEmployee.getMmdept() != null && !"".equals(comEmployee.getMmdept())) {
                            qccEdp.setMmdept(comEmployee.getMmdept());
                            System.out.println(comEmployee.getMmdept());
                        }
                        //取出职种代码对应的职种名称
                        if (comEmployee.getMmp3nm() != null && !"".equals(comEmployee.getMmp3nm())) {
                            qccEdp.setMmp3nm(comEmployee.getMmp3nm());
                            System.out.println(comEmployee.getMmp3nm());
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return iQccEdpDao.findDatapool2Edp(qccGetParmeter);
    }

    /**
     * @param emplyeeId
     * @Author Wang FengCai
     * @Description 根据工号查询作业种类等信息
     * @Date 2020/5/7
     * @Time 上午 09:04
     */
    @Override
    public List<Qcc_edp> findByEmpId(String emplyeeId) {
        emplyeeId.toUpperCase();
        return iQccEdpDao.findByEmpId(emplyeeId);
    }

    /**
     * @param employee_id
     * @param educateTpye
     * @Author Wang FengCai
     * @Description 根据工号和作业种类去查询
     * @Date 2020/5/8
     * @Time 下午 02:27
     */
    @Override
    public Qcc_edp findByEmpIdAndEduTyp(String employee_id, String educateTpye) {
        employee_id.toUpperCase();
        educateTpye.toUpperCase();
        return iQccEdpDao.findByEmpIdAndEduTyp(employee_id, educateTpye);
    }

    /**
     * @Author Wang FengCai
     * @Description 根据工号，合格牌号，作业种类来查询
     * @Date 2020/7/27
     * @Time 上午 10:36
     */
    @Override
    public List<Qcc_edp> findByEduTypAndEl(String educate_type, String el) {
        return iQccEdpDao.findByEduTypAndEl(educate_type, el);
    }

}
