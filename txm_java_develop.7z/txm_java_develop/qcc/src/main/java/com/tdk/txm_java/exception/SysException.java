package com.tdk.txm_java.exception;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_20200325</h3>
 * @ClassName<h4></h4>
 * @ToDo<p>自定义异常类</p>
 * @date : 2020-04-06 09:49
 * @version:1.0
 **/
public class SysException extends Exception {

    private static final long serialVersionUID = 4055945147128016300L;

    //存储提示信息的
    private  String message;

    public SysException(String message) {
        super(message);
    }

    @Override
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }


    @Override
    public String toString() {
        return "SysException{" +
                "message='" + message + '\'' +
                '}';
    }
}
