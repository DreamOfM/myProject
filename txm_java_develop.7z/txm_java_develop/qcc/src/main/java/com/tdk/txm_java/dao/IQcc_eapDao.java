package com.tdk.txm_java.dao;

import com.tdk.txm_java.domain.Qcc_eap;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <h3>txm_java_0304</h3>
 * <p>作业职种代码维护</p>
 *
 * @author : Wang FengCai
 * @date : 2020-03-11 09:07
 **/
@Repository
public interface IQcc_eapDao {
    /**
     * @Author Wang FengCai
     * @Description 增加
     * @Date  2020/3/11
     * @Time  上午 09:44
     * @Param
     * @return
     **/
    @Insert("insert into qcc_eap(educate_type,educate_type_name,login_time,update_time,update_oid,update_program,login_oid) values" +
            "(#{educate_type},#{educate_type_name},now(),now(),#{update_oid},#{update_program},#{login_oid})")
    void save(Qcc_eap qcc_eap) throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 删除
     * @Date  2020/3/11
     * @Time  上午 09:48
     * @Param
     * @return
     **/
    @Delete("delete from qcc_eap where id=#{id}")
    void deleteById(int id) throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 修改
     * @Date  2020/3/11
     * @Time  上午 09:50
     * @Param
     * @return
     **/
    @Update("update qcc_eap set educate_type=#{educate_type},educate_type_name=#{educate_type_name},update_program=#{update_program},update_time=now(),update_oid=#{update_oid} where id=#{id}")
    void update(Qcc_eap qcc_eap) throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 查找所有
     * @Date  2020/3/11
     * @Time  上午 09:54
     * @Param
     * @return
     **/
    @Select("select * from qcc_eap")
    Qcc_eap findAll() throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 根据ID查询
     * @Date  2020/3/11
     * @Time  上午 09:55
     * @Param
     * @return
     **/
    @Select("select * from qcc_eap where id=#{id}")
    Qcc_eap findById(int id) throws Exception;

    /**
     * @Author Wang FengCai
     * @Description 根据作业种类查询
     * @Date  2020/3/11
     * @Time  上午 11:16
     * @Param [educateType]
     * @return com.tdk.txm_java.domain.Qcc_eap
     **/
    @Select("select * from qcc_eap where educate_type like #{educateType}")
    List<Qcc_eap> findByEduTyp(String educateType);

    /**
     * @Author Wang FengCai
     * @Description 根据种类代码去数据库中查找是否存在
     * @Date  2020/3/12
     * @Time  上午 11:57
     * @Param [educate_type]
     * @return boolean
     **/
    @Select("select * from qcc_eap where educate_type=#{educate_type}")
    Qcc_eap findByEduTyp1(String educate_type);
}
