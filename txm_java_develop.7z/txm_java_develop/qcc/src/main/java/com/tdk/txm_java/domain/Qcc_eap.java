package com.tdk.txm_java.domain;

import java.util.Date;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_0304</h3>
 * @ClassName<h4></h4>
 * @ToDo<p>作业职种代码维护</p>
 * @date : 2020-03-11 09:12
 * @version:1.0
 **/
public class Qcc_eap {
    private int id;
    //受訓作業種類
    private  String  educate_type;
    //受訓作業種類名稱
    private  String  educate_type_name;
    //登录时间
    private  Date    login_time;
    //更新时间
    private  Date    update_time;
    //更新ID
    private  String  update_oid;
    //更新程序
    private  String  update_program;
    //登录ID
    private  String  login_oid;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEducate_type() {
        return educate_type;
    }

    public void setEducate_type(String educate_type) {
        this.educate_type = educate_type;
    }

    public String getEducate_type_name() {
        return educate_type_name;
    }

    public void setEducate_type_name(String educate_type_name) {
        this.educate_type_name = educate_type_name;
    }

    public Date getLogin_time() {
        return login_time;
    }

    public void setLogin_time(Date login_time) {
        this.login_time = login_time;
    }

    public Date getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(Date update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public Qcc_eap() {
    }

    @Override
    public String toString() {
        return "Qcc_eap{" +
                "id=" + id +
                ", educate_type='" + educate_type + '\'' +
                ", educate_type_name='" + educate_type_name + '\'' +
                ", login_time=" + login_time +
                ", update_time=" + update_time +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                ", login_oid='" + login_oid + '\'' +
                '}';
    }
}
