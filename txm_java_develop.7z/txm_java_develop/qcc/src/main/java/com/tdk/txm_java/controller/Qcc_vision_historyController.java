package com.tdk.txm_java.controller;

import com.tdk.txm_java.domain.Qcc_vision_history;
import com.tdk.txm_java.domain.ResultInfo;
import com.tdk.txm_java.service.ICom_employeeService;
import com.tdk.txm_java.service.IQcc_master_inspectionService;
import com.tdk.txm_java.service.IQcc_vision_historyService;
import com.tdk.txm_java.utils.JsonUtil;
import com.tdk.txm_java.utils.DateUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/*
 * @Author Yu Liqin
 * @Description //TODO a801550
 * @Date  2020/4/16
 * @Time  上午 08:26
 **/


@Controller
@RequestMapping("/qcc_vision_history")
public class Qcc_vision_historyController {
    @Autowired
    private IQcc_master_inspectionService iQccMasterInspectionService;
    @Autowired
    private IQcc_vision_historyService iQccVisionHistoryService;
    @Autowired
    private ICom_employeeService iCom_employeeService;


    @RequestMapping("/VisionSave.do")
    public void save(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws
            Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        String username = (String) session.getAttribute("username");
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                if ("date_to_now".equals(name1) || "num".equals(name1) || "chinese_name".equals(name1) || "date_of_resignation".equals(name1)) {
                    //不做处理
                } else {
                    //将每一个key值对应的一组值放到数组里去
                    String[] vals = (String[]) map.get(name1);
                    c = vals.length;
                    //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                    hashMap.put(name1, vals[b]);
                }
            }

            //如果取出的 工号为空，则不往数据库里插入数据
            if (hashMap.get("confirm_date_of_2") == null || hashMap.get("confirm_date_of_2").equals("")) {
                b++;
                if (b == c) {
                    break;
                }
                continue;
            } else {
                //取出画面的值
                String educateType1 = hashMap.get("educate_type");
                String workplaceCode1 = hashMap.get("workplace_code");
                String employee_id1 = hashMap.get("employee_id");
                String confirm_date1 = hashMap.get("confirm_date_of_2");
                //判断表qcc_vision_history中是否存在
                Qcc_vision_history qccVisionHistory1 = iQccVisionHistoryService.findByEduTypAndWorEmD(educateType1, workplaceCode1, employee_id1, confirm_date1);
                if ( qccVisionHistory1 == null || "".equals(qccVisionHistory1)) {
                    //创建对象
                    Qcc_vision_history qccVisionHistory = new Qcc_vision_history();
                    try {
                        DateUtils.convert2Date();
                        BeanUtils.populate(qccVisionHistory, hashMap);
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    } catch (InvocationTargetException e) {
                        e.printStackTrace();
                    }
                    qccVisionHistory.setLogin_oid(username);
                    //调用业务层的save()方法，写入
                    iQccVisionHistoryService.save(qccVisionHistory);

                }
                b++;
                if (b == c) {
                    break;
                }
            }
        }
        // 响应数据
        JsonUtil.writeValue(info,response);
    }
}
