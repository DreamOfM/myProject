package com.tdk.txm_java.domain;


/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_0409</h3>
 * @ClassName<h4></h4>
 * @ToDo<p></p>
 * @date : 2020-04-29 15:49
 * @version:1.0
 **/

public class EdpExcel {

    private String username;



}
