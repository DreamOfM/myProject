package com.tdk.txm_java.service;
import com.tdk.txm_java.domain.Qcc_vision_history;

/**
 * <h3>txm_java_0409</h3>
 * <p>檢查人員視力有效性評估业务层</p>
 * @author : Wang FengCai
 * @date : 2020-04-13 09:24
 **/
public interface IQcc_vision_historyService {

    void save(Qcc_vision_history qccVisHistory) throws Exception;

    /*
     * @Author Yu Liqin
     * @Description //TODO a801550  视力有效性定期评估
     * @Date  2020/4/13
     * @Time  下午 04:51
     **/

    Qcc_vision_history findByEduTypAndWorEmD(String educateType, String workplaceCode, String employee_id, String confirm_date) throws Exception;
}

