package com.tdk.txm_java.service.impl;

import com.tdk.txm_java.dao.IQcc_assessment_historyDao;
import com.tdk.txm_java.domain.Qcc_assessment_history;
import com.tdk.txm_java.service.IQcc_assessment_historyService;
import org.apache.ibatis.annotations.Select;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_0409</h3>
 * @ClassName<h4></h4>
 * @ToDo<p></p>
 * @date : 2020-04-13 09:18
 * @version:1.0
 **/
@Service
@Transactional
public class Qcc_assessment_historyServiceImpl implements IQcc_assessment_historyService {
    @Autowired
    IQcc_assessment_historyDao iQccAssHistoryDao;
    @Override
    public void save(Qcc_assessment_history qccAssHistory) throws Exception {
        //TODO 转换大写
        iQccAssHistoryDao.save(qccAssHistory);
    }

    @Override
    public void delete(int id) throws Exception {
        iQccAssHistoryDao.delete(id);
    }

    @Override
    public void update(Qcc_assessment_history qccAssHistory) throws Exception {
        //TODO 转换大写
        iQccAssHistoryDao.update(qccAssHistory);
    }

    @Override
    public Qcc_assessment_history findAll() throws Exception {
        return iQccAssHistoryDao.findAll();
    }

    @Override
    public Qcc_assessment_history findById(int id) throws Exception {
        return iQccAssHistoryDao.findById(id);
    }

    /**
     * @Author Wang FengCai
     * @Description 根据作业种类，单位代码，认定日期去历史档查询数据
     * @Date 2020/4/15
     * @Time 下午 08:20
     */
    @Override
    public Qcc_assessment_history findByEduTyAndWorCoAndConFiAndEmpId(String eduT, String workC, String conF, String empId) {
        //TODO 转换大写
        eduT.toUpperCase();
        workC.toUpperCase();
        return iQccAssHistoryDao.findByEduTyAndWorCoAndConFiAndEmpId(eduT,workC,conF,empId);
    }
}
