package txm_java;

import com.tdk.txm_java.domain.Bnd_import_fee;
import com.tdk.txm_java.service.IBnd_import_feeService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "classpath*:./applicationContext.xml")
public class carryTest {
    @Autowired
    private IBnd_import_feeService iBnd_import_feeService;

    @Test
    public void testFindAll() throws Exception {
        List<Bnd_import_fee> bnd_import_feeList = iBnd_import_feeService.findAll();
        System.out.println(bnd_import_feeList.toString());
    }

    @Test
    public void testFindOne(){

    }

    @Test
    public void testUpdate(){

    }
}
