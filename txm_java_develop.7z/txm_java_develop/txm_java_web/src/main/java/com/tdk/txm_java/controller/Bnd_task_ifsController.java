package com.tdk.txm_java.controller;

import com.tdk.txm_java.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

//CRON表达式 含
//    秒（Seconds）	    0~59的整数	        , - * /    四个字符
//    分（Minutes）	    0~59的整数	        , - * /    四个字符
//    小时（Hours）	        0~23的整数	        , - * /    四个字符
//    日期（DayofMonth）	1~31的整数    	    ,- * ? / L W C     八个字符
//    月份（Month）	        1~12的整数者 JAN-DEC	, - * /    四个字符
//    星期（DayofWeek）	    1~7的整数或者 SUN-SAT , - * ? / L C #     八个字符
//    年(可选，留空)（Year）	1970~2099	        , - * /    四个字符
//    （1）*：表示匹配该域的任意值。假如在Minutes域使用*, 即表示每分钟都会触发事件。
//    （2）?：只能用在DayofMonth和DayofWeek两个域。它也匹配域的任意值，但实际不会。因为DayofMonth和DayofWeek会相互影响。
//          例如想在每月的20日触发调度，不管20日到底是星期几，则只能使用如下写法： 13 13 15 20 * ?, 其中最后一位只能用？，而不能使用*，如果使用*表示不管星期几都会触发，实际上并不是这样。
//    （3）-：表示范围。例如在Minutes域使用5-20，表示从5分到20分钟每分钟触发一次 
//    （4）/：表示起始时间开始触发，然后每隔固定时间触发一次。例如在Minutes域使用5/20,则意味着5分钟触发一次，而25，45等分别触发一次. 
//    （5）,：表示列出枚举值。例如：在Minutes域使用5,20，则意味着在5和20分每分钟触发一次。 
//    （6）L：表示最后，只能出现在DayofWeek和DayofMonth域。如果在DayofWeek域使用5L,意味着在最后的一个星期四触发。 
//    （7）W:表示有效工作日(周一到周五),只能出现在DayofMonth域，系统将在离指定日期的最近的有效工作日触发事件。
//           例如：在 DayofMonth使用5W，如果5日是星期六，则将在最近的工作日：星期五，即4日触发。如果5日是星期天，则在6日(周一)触发；如果5日在星期一到星期五中的一天，则就在5日触发。另外一点，W的最近寻找不会跨过月份 。
//    （8）LW:这两个字符可以连用，表示在某个月最后一个工作日，即最后一个星期五。 
//    （9）#:用于确定每个月第几个星期几，只能出现在DayofMonth域。例如在4#2，表示某月的第二个星期三。
//        “0 0 12 * * ?” 每天中午十二点触发
//        “0 15 10 ? * *” 每天早上10：15触发
//        “0 15 10 * * ?” 每天早上10：15触发
//        “0 15 10 * * ? *” 每天早上10：15触发
//        “0 15 10 * * ? 2005” 2005年的每天早上10：15触发
//        “0 * 14 * * ?” 每天从下午2点开始到2点59分每分钟一次触发
//        “0 0/5 14 * * ?” 每天从下午2点开始到2：55分结束每5分钟一次触发
//        “0 0/5 14,18 * * ?” 每天的下午2点至2：55和6点至6点55分两个时间段内每5分钟一次触发
//        “0 0-5 14 * * ?” 每天14:00至14:05每分钟一次触发
//        “0 10,44 14 ? 3 WED” 三月的每周三的14：10和14：44触发
//        “0 15 10 ? * MON-FRI” 每个周一、周二、周三、周四、周五的10：15触发
@Component
public class Bnd_task_ifsController {
  @Autowired
  private IBnd_if_fsap_itemService iBnd_if_fsap_itemService;
  @Autowired
  private IBnd_if_fepo_asnService iBnd_if_fepo_asnService;
  @Autowired
  private IBnd_if_fsap_customerService iBnd_if_fsap_customerService;
  @Autowired
  private IBnd_if_fsap_vendorService iBnd_if_fsap_vendorService;
  @Autowired
  private IBnd_if_fsap_fgreturnService iBnd_if_fsap_fgreturnService;
  @Autowired
  private IBnd_if_fsap_fgreturn_soService iBnd_if_fsap_fgreturn_soService;
  @Autowired
  private IBnd_if_fsap_purchase_priceService iBnd_if_fsap_purchase_priceService;
  @Autowired
  private IBnd_if_fsap_average_priceService iBnd_if_fsap_average_priceService;
  @Autowired
  private IBnd_if_fsap_stockService iBnd_if_fsap_stockService;
  @Autowired
  private IBnd_if_fsap_sample_consumeService iBnd_if_fsap_sample_consumeService;
  @Autowired
  private IBnd_if_fsap_mbomService iBnd_if_fsap_mbomService;

  @Autowired
  private IBnd_if_fsap_routing_mbomService iBnd_if_fsap_routing_mbomService;
  @Autowired
  private IBnd_if_fsap_routingService iBnd_if_fsap_routingService;
  @Autowired
  private IBnd_if_fsap_unit_costService iBnd_if_fsap_unit_costService;
  @Autowired
  private IBnd_if_fsap_psa_mrpService iBnd_if_fsap_psa_mrpService;
  @Autowired
  private IBnd_if_fsap_iv_cancelService iBnd_if_fsap_iv_cancelService;
  @Autowired
  private IBnd_if_fsap_return_poService iBnd_if_fsap_return_poService;
  @Autowired
  private IBnd_if_fassist4_invoiceService iBnd_if_fassist4_invoiceService;
  @Autowired
  private IBnd_if_fassist4_pgiService iBnd_if_fassist4_pgiService;
//  @Scheduled(cron = "0 0 7  1 * ? ")//每天执行，处理品番主档
//  @Scheduled(cron = "0  16  8  8 * ? ")//每天执行  测试OK    ETL OK
  public void copyToItemMaster() throws Exception {
    iBnd_if_fsap_itemService.copyToMaster();
    System.out.println("iBnd_if_fsap_itemService finish");
  }
  //  @Scheduled(cron = "0 0 7  1 * ? ")//每天执行，处理顾客主档
//  @Scheduled(cron = "0  8 15  22  * ? ")//每天执行  测试OK    ETL OK
  public void copyToCustomerMaster() throws Exception {
    iBnd_if_fsap_customerService.copyToMaster();
    System.out.println("iBnd_if_fsap_customerService finish");
  }
//  @Scheduled(cron = "0   10  13   18  * ? ")//每天执行
  public void copyToVendorMaster() throws Exception {
    iBnd_if_fsap_vendorService.copyToMaster();
    System.out.println("iBnd_if_fsap_vendorService finish");
  }
//      @Scheduled(cron = "0  47  10   12  * ? ")//每天执行 测试OK
  public void copyToPurchase_price() throws Exception {
    iBnd_if_fsap_purchase_priceService.copyToMaster();
    System.out.println("iBnd_if_fsap_purchase_priceService finish");
  }
//    @Scheduled(cron = "0  38  9   8  * ? ")//每月执行 测试OK    ETL OK
  public void copyToAverage_price() throws Exception {
    iBnd_if_fsap_average_priceService.copyToMaster();
    System.out.println("iBnd_if_fsap_average_priceService finish");
  }

//    @Scheduled(cron = "0  59  9   14  * ? ")//每天执行
  public void copyToFgreturn_so() throws Exception {
    iBnd_if_fsap_fgreturn_soService.copyToMaster();
    System.out.println("iBnd_if_fsap_fgreturn_soService finish");
  }

  //  @Scheduled(cron = "0  22  8   22  * ? ")//每天执行
  public void copyToFgreturn() throws Exception {
    iBnd_if_fsap_fgreturnService.copyToMaster();
    System.out.println("iBnd_if_fsap_fgreturnService finish");
  }
//  @Scheduled(cron = "0  53  14   14  * ? ")//每天执行
  public void copyToIvCancel() throws Exception {
    iBnd_if_fsap_iv_cancelService.copyToMaster();
    System.out.println("iBnd_if_fsap_iv_cancelService finish");
  }

//    @Scheduled(cron = "0  44  8   15  * ? ")//每日执行 测试OK ,只更新TTOBP,其他档案视实际需要再开发
  public void copyToStock() throws Exception {
    iBnd_if_fsap_stockService.copyToMaster();
    System.out.println("iBnd_if_fsap_stockService finish");
  }
//    @Scheduled(cron = "0  49  14   19  * ? ")//每日执行 测试OK
  public void copyToSampleConsume() throws Exception {
    iBnd_if_fsap_sample_consumeService.copyToMaster();
    System.out.println("iBnd_if_fsap_sample_consumeService finish");
  }



  //  @Scheduled(cron = "0  43  11   1  * ? ")//每日执行

  public void copyToRoutingMbom() throws Exception {
    iBnd_if_fsap_routing_mbomService.copyToMaster();
    System.out.println("iBnd_if_fsap_routing_mbomService finish");
  }
  //  @Scheduled(cron = "0  20  10   15  * ? ")//每日执行 测试OK
  public void copyToRouting() throws Exception {
    iBnd_if_fsap_routingService.copyToMaster();
    System.out.println("iBnd_if_fsap_routingService finish");
  }

  @Scheduled(cron = "0  24  11   9   * ? ")//每日执行  测试OK
  public void copyToUnitCost() throws Exception {
    iBnd_if_fsap_unit_costService.copyToMaster();
    System.out.println("iBnd_if_fsap_unit_costService finish");
  }
//  @Scheduled(cron = "0  9  15   20   * ? ")//每日执行  测试OK
  public void copyToReturnPo() throws Exception {
    iBnd_if_fsap_return_poService.copyToMaster();
    System.out.println("iBnd_if_fsap_return_poService finish");
  }

//    @Scheduled(cron = "0  17  9   4  * ? ")//每日执行
  public void copyToPsaMrp() throws Exception {
    iBnd_if_fsap_psa_mrpService.copyToMaster();
    System.out.println("iBnd_if_fsap_psa_mrpService finish");
  }
//    @Scheduled(cron = "0  44   17   21  * ? ")//每日执行
  public void copyToMbom() throws Exception {
    iBnd_if_fsap_mbomService.copyToMaster();
    System.out.println("iBnd_if_fsap_mbomService finish");
  }
//ASSIST4
//  @Scheduled(cron = "0  13  19   22  * ? ")//每日执行
  public void copyToInvoice() throws Exception {
    iBnd_if_fassist4_invoiceService.copyToMaster();
    System.out.println("iBnd_if_fassist4_invoiceService finish");
  }
  @Scheduled(cron = "0  8  15   30  * ? ")//每日执行
  public void copyToPgi() throws Exception {
    iBnd_if_fassist4_pgiService.copyToMaster();
    System.out.println("iBnd_if_fassist4_pgiService finish");
  }
  // epo bnd_if_fepo_asn 处理写入 bnd_import_asn,处理过状态更新为Y
//@Scheduled(cron = "0 0  8-17  * * ? ")//每隔一个小时运行一次，测试OK
  public void epo_asn() throws Exception {
    iBnd_if_fepo_asnService.insert2Import_asn();
    System.out.println("epo_asn ok");
  }

}
