// 第一个关键字段不能为空
// 关刍字段不为空时，其他相应字段也不能为空
function checklist(keyfd, fdlist, num1, rs) {
    if ($("#" + keyfd + num1).val() == '' || $("#" + keyfd + num1).val() == null) {
        $("#" + keyfd + num1).attr("style", "background-color:red");
        rs = "N";
    } else {
        while ($("#" + keyfd + num1).length > 0) {
            if ($("#" + keyfd + num1).val() != '' && $("#" + keyfd + num1).val() != null && $("#" + keyfd + num1).val() != undefined) {
                for (var b = 0; b < fdlist.length; b++) {
                    rs = checknull(fdlist[b] + num1, rs);
                }
            }
            num1++
        }
    }
    return rs;
}

function checknull(fieldid, rs) {
    if ($("#" + fieldid).val() == '' || $("#" + fieldid).val() == null || $("#" + fieldid).val() == undefined) {
        $("#" + fieldid).attr("style", "background-color:red");
        rs = "N";
    } else {
        $("#" + fieldid).attr("style", "background-color:transparent");
    }
    return rs;
}

//检查所有required的元素
function checkrequired(rs) {
    $('[required]').each(function () {
        $(this).attr("style", "background-color:transparent");
        // $(this).addClass("requiredstyle");
        if ($(this).val() != '' && $(this).val() != null && $(this).val() != undefined) {

        } else {
            rs = "N";
            $(this).attr("style", "background-color:red");
        }
    });
    return rs;
}

//检查第二个ID元素的值是否大于等于ID元素的值
function comparedate(date1, date2, rs) {
    if ($("#" + date1).val() > $("#" + date2).val()) {
        $("#" + date1).attr("style", "background-color:red");
        rs = "N"
    } else {
        $("#" + date1).attr("style", "background-color:transparent");
    }
    return rs;
}
// 指定栏位，不允许输入重复值
function checkRepeatKey(keylist, num1, rs) {
    var arr_key=new Array();
    while (true) {
        var key="";
        for (var b = 0; b < keylist.length; b++) {
            key = key+$("#" + keylist[b] + num1).val();
            $("#" + keylist[b] + num1).attr("style", "background-color:transparent");
        }
        if(key==""||key.length==0) return rs;
        if(arr_key.indexOf(key)>-1){
            for (var b = 0; b < keylist.length; b++) {
                $("#" + keylist[b] + num1).attr("style", "background-color:red");
            }
            rs='N'
            return rs
        }
        arr_key.push(key)
        num1++
    }
    return rs;
}
// fieldid为需要替换的ID,val为需要替换的值
function replaceblank(fieldid, val) {
    if ($("#" + fieldid).val() == "") {
        $("#" + fieldid).attr("value", "0");
    }
}

// 检查输入值要符合数值格式
function checkdecimal(fieldid) {
    var rs = "Y";
    var reg = /^\d+(\.\d+)?$/;
    if (reg.test($("#" + fieldid).val()) == false) {
        $("#" + fieldid).attr("style", "background-color:red");
        rs = "N";
    } else {
        $("#" + fieldid).attr("style", "background-color:transparent");
    }
    return rs;
}

//取消空格
function replaceSpace(obj) {
    obj.value = obj.value.replace(/\s/gi, '')
}

//pagehelpe分页
//obj:传入的标签   url:传入controller带参数的地址   pages:总页数  pagenumber:当前页数  total:总条数  afunc:执行跳页时执行的方法
function pagebtn(obj, url, pages, pagenumber, total, afunc) {
    var temp = "<div style='float: right'>"
        + "<ul class='pagination' style='margin: 0px'><li><a id='prepage' onclick='return afunc()'>上一页</a></li></ul>"
        + "<ul class='pagination' style='margin: 0px'><li><a id=numberpage1 onclick='return afunc()'>1</a></li></ul>"
        + "<ul class='pagination' style='margin: 0px' id='numberpages'></ul>"
        + "<ul class='pagination' style='margin: 0px' id='lastpage'><li><a onclick='return afunc()' id=numberpage" + pages + ">" + pages + "</a></li></ul>"
        + "<ul class='pagination' style='margin: 0px'><li><a id='nextpage' onclick='return afunc()'>下一页</a></li></ul>"
        + "</div>"
        + "<div style='padding: 6px 12px;float: right'>总共" + pages + "页，共有" + total + "条数据</div>";
    $(obj).append(temp);
    //下一页
    var nextpage = Number(pagenumber) + Number(1);
    //上一页
    var lastpage = Number(pagenumber) - Number(1);
    $("#numberpage1").attr("href", url + "&pn=1");
    $("#prepage").attr("href", url + "&pn=" + lastpage);
    $("#nextpage").attr("href", url + "&pn=" + nextpage);
    if (pages == 1) {
        $("#numberpage" + pages).remove();
    } else {
        $("#numberpage" + pages).attr("href", url + "&pn=" + pages);
    }
    //添加页数
    if (pages > 3 && pagenumber < Number(pages) - Number(3) && pagenumber >= 4) {
        for (var i = Number(pagenumber) - Number(2); i < Number(pagenumber) + Number(3); i++) {
            var page = "<li><a onclick='return afunc()' id=numberpage" + i + ">" + i + "</a></li>";
            $("#numberpages").append(page);
            $("#numberpage" + i).attr("href", url + "&pn=" + i + "");
        }
    } else if (pages <= 6 && pagenumber <= 6) {
        for (var i = 2; i < pages; i++) {
            var page = "<li><a onclick='return afunc()' id=numberpage" + i + ">" + i + "</a></li>";
            $("#numberpages").append(page);
            $("#numberpage" + i).attr("href", url + "&pn=" + i + "");
        }
    } else if (pages > 6 && pagenumber <= 4) {
        for (var i = 2; i <= 6; i++) {
            var page = "<li><a onclick='return afunc()' id=numberpage" + i + ">" + i + "</a></li>";
            $("#numberpages").append(page);
            $("#numberpage" + i).attr("href", url + "&pn=" + i + "");
        }
    } else {
        for (var i = Number(pages) - Number(5); i < pages; i++) {
            var page = "<li><a onclick='return afunc()' id=numberpage" + i + ">" + i + "</a></li>";
            $("#numberpages").append(page);
            $("#numberpage" + i).attr("href", url + "&pn=" + i + "");
        }
    }
    $("#numberpage" + pagenumber).attr("style", "background-color:#337ab7;color:white")
}

//创建遮罩层函数体
function createMask() {
    var node = document.createElement('div');
    node.setAttribute('id', 'backdrop');
    node.style = "position:fixed;top:0;left:0;right:0;bottom:0;z-index:1000;background-color:rgba(76, 175, 80, 0.73);";
    node.style.display = "none";
    var html = '<div style="position: fixed; top: 45%; left: 45%; z-index: 1001;">';
    html += '<div style="text-align:center;">';
    html += '<img src="../img/loading.gif" style="width:60px;height:60px;">';
    html += '</div>';
    html += '</div>';
    node.innerHTML = html;
    var body = document.querySelector('body');
    body.appendChild(node);
    var backdrop = document.getElementById('backdrop');
    backdrop.style.display = 'block';
}

//开启遮罩层函数体
function showMask() {
    var backdrop = document.getElementById('backdrop');
    backdrop.style.display = 'block';
}

//关闭遮罩层函数体
function closeMask() {
    var backdrop = document.getElementById('backdrop');
    backdrop.style.display = 'none';
}


// 获取url数据
function getQueryVariable(variable) {
    var query = window.location.search.substring(1);
    var vars = query.split("&");
    for (var i = 0; i < vars.length; i++) {
        var pair = vars[i].split("=");
        if (pair[0] == variable) {
            return pair[1];
        }
    }
    return (false);
}

//将一串数字转变成日期格式 例如：1591632000000 转变成  1899-12-31
Date.prototype.Format = function (fmt) {
    var o = {
        "M+": this.getMonth() + 1,                 //月份
        "d+": this.getDate(),                    //日
        "h+": this.getHours(),                   //小时
        "m+": this.getMinutes(),                 //分
        "s+": this.getSeconds(),                 //秒
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度
        "S": this.getMilliseconds()             //毫秒
    };
    if (/(y+)/.test(fmt))
        fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt))
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
};


//获取上个月的第一天 如6月1日
function initLastMonthFrom() {
    //获取当前的系统日期
    var now = new Date();
    //设置为第一天 如7月1日
    now.setDate(1);
    //在当前月的基础上减一个月  如7-1=6即6月
    now.setMonth(now.getMonth() - 1);
    return now;
}

//获取上个月的最后一天
function initLastMonthEnd() {
    //获取系统的当前日期
    var now = new Date();
    //取上个月的最后一天，也就是本月的最大一天，也就是6月的最大一天
    now.setDate(0);
    return now;
}

//获取推移月份的指定日期  addmonth 推移月份   date_in 指定日期，0代表当前日期
function addMonthInitDate(addmonth, date_in) {
    var now = new Date();
    var year = now.getFullYear();
    var month = now.getMonth() + addmonth + 1;
    if(month==0){
        year=year-1
        month=12
    }
    if (date_in == 0) {
        return year + '-' + month + '-' + now.getDate();
    } else {
        return year + '-' + month + '-' + date_in;
    }
}

//判定文本框输入的值为0~num 的正整数
function myFunction(where, num) {
    var check = $(where).val();
    if (isNaN(check) || check < 0 || check > num || !(/^\d+$/.test(check))) {
        {
            alert('请输入正确的数值,只允许输入0~' + num + '的正整数!');
            $("#" + where.id).attr("style", "background-color:red");
            document.getElementById(where.id).value = "";
            return false;
        }
    }
}

//日期推移  str分隔符   getDay(-1,'-')  负数向前推移1天
function getDay(num, str) {
    var today = new Date();
    var nowTime = today.getTime();
    var ms = 24 * 3600 * 1000 * num;
    today.setTime(parseInt(nowTime + ms));
    var oYear = today.getFullYear();
    var oMoth = (today.getMonth() + 1).toString();
    if (oMoth.length <= 1) oMoth = '0' + oMoth;
    var oDay = today.getDate().toString();
    if (oDay.length <= 1) oDay = '0' + oDay;
    return oYear + str + oMoth + str + oDay;
}
/**
 *因为超链接，默认使用的是GET请求方式，参数中有中文，IE浏览器解析时会产生乱码的问题，
 * 试过编码，改tomcat配置文件都未能解决，所以采用如下方法，转换成POST 请求方式
 */
function cnLinkConvert(linkObject) {
    var formObject = document.createElement('form');
    document.body.appendChild(formObject);
    formObject.setAttribute('method', 'post');
    var url = linkObject.href;
    var uri = '';
    var i = url.indexOf('?');

    if (i == -1) {
        formObject.action = url;
        return true;
    }

    formObject.action = url.substring(0, i);

    if (i >= 0 && url.length >= i + 1) {
        uri = url.substring(i + 1, url.length);
    }

    var sa = uri.split('&');

    for (var i = 0; i < sa.length; i++) {
        var isa = sa[i].split('=');
        var inputObject = document.createElement('input');
        inputObject.setAttribute('type', 'hidden');
        inputObject.setAttribute('name', isa[0]);
        inputObject.setAttribute('value', isa[1]);
        formObject.appendChild(inputObject);
    }
    formObject.submit();
    return false;
}

