package com.tdk.txm_java.service.impl;

import com.tdk.txm_java.dao.IMou_request_uploadDao;
import com.tdk.txm_java.dao.IMou_request_uploadDao;
import com.tdk.txm_java.domain.Mou_request_upload;
import com.tdk.txm_java.service.IMou_request_uploadService;
import com.tdk.txm_java.service.IMou_requestService;
import com.tdk.txm_java.service.IMou_request_uploadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class Mou_request_uploadServiceImpl implements IMou_request_uploadService {

    @Autowired
    private IMou_request_uploadDao mou_request_uploadDao;

    /**
    *@Description: 查询所有数据
    *@Author: a135109
    *@time: 2019/11/6 10:35
    */
    @Override
    public List<Mou_request_upload> findAll() throws Exception {
        return mou_request_uploadDao.findAll();
    }

    /**
    *@Description: 上载
    *@Author: a135109
    *@time: 2019/11/6 10:35
    */
    @Override
    public void save(Mou_request_upload mou_request_upload) throws Exception {
        mou_request_uploadDao.save(mou_request_upload);
    }


    /**
    *@Description: 删除
    *@Author: a135109
    *@time: 2019/11/6 10:35
    */
    @Override
    public void delete() throws Exception {
        mou_request_uploadDao.delete();
    }

    /**
    *@Description: 通过id查找对象
    *@Author: a135109
    *@time: 2019/11/6 10:36
    */
    @Override
    public Mou_request_upload findById(int id) {
        return mou_request_uploadDao.findById(id);
    }

}
