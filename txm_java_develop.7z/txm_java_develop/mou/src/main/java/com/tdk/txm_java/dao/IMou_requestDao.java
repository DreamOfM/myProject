package com.tdk.txm_java.dao;

import com.tdk.txm_java.domain.Com_serialnum;
import com.tdk.txm_java.domain.Mou_balance;
import com.tdk.txm_java.domain.Mou_request;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface IMou_requestDao {
    @Select("select * from mou_request")
    public List<Mou_request> findAll() throws Exception;

    @Select("select * from mou_request where request_no=#{request_no}")
    public List<Mou_request> findByrequest_no(String request_no) throws Exception;

    @Select("select * from mou_request where id=#{id}")
    public Mou_request findById(int id) throws Exception;


    @Update("update mou_request set request_no=#{request_no}, " +
            "request_line_no=#{request_line_no}, state=#{state}, " +
            "item_no=#{item_no}, memo1=#{memo1}, " +
            "item_description_dbcs=#{item_description_dbcs}, " +
            "item_spec=#{item_spec}, sh_ratio=#{sh_ratio}, " +
            "graph_no_dr=#{graph_no_dr}, yamataka_check=#{yamataka_check}, thread_form=#{thread_form}," +
            " stove_name=#{stove_name}, mrpcode=#{mrpcode}," +
            " warehouse_code=#{warehouse_code}, buyer=#{buyer}, " +
            "on_hand_qty=#{on_hand_qty}, sale_qty=#{sale_qty}, " +
            "necessary_qty=#{necessary_qty}, security_qty=#{security_qty}, " +
            "last_month_lose_qty=#{last_month_lose_qty}, " +
            "current_month_lose_qty=#{current_month_lose_qty}, " +
            "repari_qty=#{repari_qty}, purchase_request_date=#{purchase_request_date}, " +
            "require_date=#{require_date}, purchase_request_qty=#{purchase_request_qty}," +
            " um_incoming_outgoing=#{um_incoming_outgoing}," +
            " purchase_price=#{purchase_price}, po_amt_rmb=#{po_amt_rmb}, " +
            "um_purchase=#{um_purchase}, currency=#{currency}, " +
            "po_back_order_qty=#{po_back_order_qty}, po_boarding_qty=#{po_boarding_qty}," +
            " arrived_qty=#{arrived_qty}, text_filed1=#{text_filed1}, " +
            "text_filed2=#{text_filed2}, number_filed1=#{number_filed1}, " +
            "number_filed2=#{number_filed2}, login_time=#{login_time}, " +
            "login_oid=#{login_oid}, update_time=#{update_time}, " +
            "update_oid=#{update_oid}, update_program=#{update_program}" +
            "where id=#{id}")
    void update(Mou_request mou_request);

    @Insert("insert into mou_request(id,request_no,request_line_no,state," +
            "item_no,memo1,item_description_dbcs,item_spec," +
            "sh_ratio,graph_no_dr,yamataka_check,thread_form,stove_name,mrpcode," +
            "warehouse_code,buyer,on_hand_qty,sale_qty,necessary_qty," +
            "security_qty,last_month_lose_qty,current_month_lose_qty," +
            "repari_qty,purchase_request_date," +
            "require_date,purchase_request_qty,um_incoming_outgoing," +
            "purchase_price,po_amt_rmb,um_purchase,currency,po_back_order_qty," +
            "po_boarding_qty,arrived_qty," +
            "text_filed1,text_filed2,number_filed1,number_filed2,login_time," +
            "login_oid,update_time,update_oid,update_program) values(#{id},#{request_no}," +
            "#{request_line_no},'10',#{item_no},#{memo1}," +
            "#{item_description_dbcs},#{item_spec},#{sh_ratio},#{graph_no_dr}," +
            "#{yamataka_check},#{thread_form},#{stove_name},'2','JM',#{buyer}," +
            "#{on_hand_qty},#{sale_qty},#{necessary_qty},#{security_qty}," +
            "#{last_month_lose_qty},#{current_month_lose_qty},#{repari_qty}," +
            "#{purchase_request_date},#{require_date},#{purchase_request_qty}," +
            "#{um_incoming_outgoing},#{purchase_price},#{po_amt_rmb},#{um_purchase}," +
            "#{currency},#{po_back_order_qty},#{po_boarding_qty},#{arrived_qty}," +
            "#{text_filed1},#{text_filed2},#{number_filed1},#{number_filed2}," +
            "now(),#{login_oid},now(),#{update_oid},#{update_program})")
    void save(Mou_request mou_request);

    @Delete("delete from mou_request where id=#{id}")
    void delete(int id);
}
