package com.tdk.txm_java.dao2;

import com.tdk.txm_java.domain.Mou_tma0p;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

@Repository
public interface IMou_tma0pDao {
    @Select("select * from wavedbf.tma0p left join wavedbf.tmimp on a0itnr=imitnr where a0itnr=#{a0itnr}")
    public Mou_tma0p findByitem_no(String a0itnr);
}
