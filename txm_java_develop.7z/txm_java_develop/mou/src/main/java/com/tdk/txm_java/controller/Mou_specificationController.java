package com.tdk.txm_java.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tdk.txm_java.domain.Mou_specification;
import com.tdk.txm_java.domain.ResultInfo;
import com.tdk.txm_java.service.IMou_specificationService;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

@Controller
@RequestMapping("/mou_specification")
public class Mou_specificationController {
    @Autowired
    private IMou_specificationService iMou_specificationService;

    /**
     * 修改
     *
     * @return
     * @throws Exception
     */
//    @RequestMapping("/update.do")
//    public void update(Mou_specification mou_specification) throws Exception {
//        System.out.println("hhh");
//        System.out.println("h:"+mou_specification);
//        iMou_specificationService.update(mou_specification);
//        System.out.println("hhh");
//
//    }

    //修改
    @RequestMapping("/update.do")
    public String update(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception {
        System.out.println("hhh");
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        String username= (String) httpSession.getAttribute("username");

            for (String name1 : set) {
                String[] vals = (String[]) map.get(name1);
//                int c = vals.length;
                hashMap.put(name1, vals[0]);
            }
            System.out.println(hashMap.get("id"));
            int id1 = Integer.parseInt(request.getParameter("id"));
//            Double s = Double.parseDouble(request.getParameter("dr_weight"));
            Mou_specification a = iMou_specificationService.findByid(id1);
            try {
                //double传不成功
                BeanUtils.populate(a,hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
//            a.setDr_weight(s);
            a.setUpdate_oid(username);
            String update_program="/mou_specification/update";
            a.setUpdate_program(update_program);
            iMou_specificationService.update(a);

        return "redirect:findByitem_no.do";

    }

    /**
     * 根据品名代碼来查询
     *
     * @param item_no
     * @return
     * @throws Exception
     */
    @RequestMapping("/findByitem_no.do")
    public ModelAndView findByitem_no(String item_no) throws Exception {
        Mou_specification mou_specification = iMou_specificationService.findByitem_no(item_no);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("mou-specification-list");
        System.out.println(mou_specification);
        mv.addObject("mou_specification", mou_specification);
        return mv;
    }

    /**
     * 复制
     *
     * @param item_no1
     * @return
     * @throws Exception
     */
    @RequestMapping("/findByitem_no1.do")
    public ModelAndView findByitem_no1(String item_no1) throws Exception {
        System.out.println("aaaaaaaa");
        Mou_specification mou_specification = iMou_specificationService.findByitem_no(item_no1);
        ModelAndView mv = new ModelAndView();
        System.out.println("qqqqqqqqqq");
        System.out.println(item_no1);
        mv.setViewName("mou-specification-add");
        System.out.println(mou_specification);
        mv.addObject("mou_specification", mou_specification);
        return mv;
    }

    /**
     * 新增
     */
    @RequestMapping("/save.do")
    public String save(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception {
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //测试前端数据是否传送过来？
        System.out.println(map.entrySet().toString() + "数据已传过来");
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();

        String username= (String) httpSession.getAttribute("username");
        Mou_specification mou_specification = new Mou_specification();

            for (String name1 : set) {
                String[] vals = (String[]) map.get(name1);
                int c = vals.length;
                hashMap.put(name1, vals[0]);
            }

            try {
                BeanUtils.populate(mou_specification, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            mou_specification.setLogin_oid(username);
            mou_specification.setUpdate_oid(username);
            mou_specification.setUpdate_program("/mou_specification/save");
            iMou_specificationService.save(mou_specification);

        return "redirect:findByitem_no.do";
    }

    /**
     * 删除
     */
    @RequestMapping("/delete.do")
    public String delete(int id) throws Exception {
        iMou_specificationService.detele(id);
        return "redirect:findByitem_no.do";
    }

    /**
     * check
     */
//    @RequestMapping("/check1.do")
//    public void check(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception, IOException, JsonGenerationException, JsonMappingException {
//        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
//        info.setFlag(true);
//        List<String> errorList = new ArrayList<String>();
//        Map map = request.getParameterMap();
//        Map<String, String> hashMap = new HashMap<>();
//        Set<String> set = map.keySet();
//
//        for (String name1 : set) {
//            String[] vals = (String[]) map.get(name1);
//            hashMap.put(name1, vals[0]);
//        }
//        Mou_specification mou_specification = new Mou_specification();
//
//        try {
//            BeanUtils.populate(mou_specification, hashMap);
//        } catch (IllegalAccessException e) {
//            e.printStackTrace();
//        } catch (InvocationTargetException e) {
//            e.printStackTrace();
//        }
//
//        Mou_specification mouSpecification2 = iMou_specificationService.findByitem_no(mou_specification.getItem_no());
//
//        if (mouSpecification2 != null) {
//            info.setErrorMsg("品名规格已存在");
////            String errLine = String.valueOf(0);
//            errorList.add("item_no");
//            info.setFlag(false);
//
//        }
//
//        info.setErrorList(errorList);
//        //响应数据
//        ObjectMapper mapper = new ObjectMapper();
//
//        response.setContentType("application/json;charset=utf-8");
//        mapper.writeValue(response.getOutputStream(), info);
//    }

    @RequestMapping("/check2.do")
    public void check2(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        //1.获取信息
        String item_no = request.getParameter("item_no");
        System.out.println(item_no+"11111111111111111111111");
        //2.调用service层判断是否存在
        Mou_specification mac = iMou_specificationService.findByitem_no(item_no);

        if (mac != null) {
            info.setFlag(false);
//            String errLine = String.valueOf(0);
              errorList.add("item_no");

        }
        info.setErrorList(errorList);
            // 响应数据
            ObjectMapper mapper = new ObjectMapper();
            response.setContentType("application/json;charset=utf-8");
            mapper.writeValue(response.getOutputStream(), info);


    }

    @RequestMapping("/check3.do")
    public void check3(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        //1.获取信息
        String item_no1 = request.getParameter("item_no1");

        System.out.println(item_no1+"11111");
        //2.调用service层判断是否存在
        Mou_specification mac = iMou_specificationService.findByitem_no(item_no1);
        System.out.println(mac);
        if (mac == null) {
            info.setFlag(false);
//            String errLine = String.valueOf(0);
            errorList.add("item_no1");

        }
        info.setErrorList(errorList);
        // 响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(), info);


    }
}
