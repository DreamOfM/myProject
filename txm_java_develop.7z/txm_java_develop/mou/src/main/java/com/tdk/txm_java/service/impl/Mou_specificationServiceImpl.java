package com.tdk.txm_java.service.impl;

import com.tdk.txm_java.dao.IMou_specificationDao;
import com.tdk.txm_java.domain.Mou_specification;
import com.tdk.txm_java.service.IMou_specificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class Mou_specificationServiceImpl implements IMou_specificationService {

    @Autowired
    private IMou_specificationDao iMou_specificationDao;


    public Mou_specification findByitem_no(String item_no) throws Exception {
        return iMou_specificationDao.findByitem_no(item_no);
    }

    @Override
    public List<Mou_specification> findAll() throws Exception {
        return iMou_specificationDao.findAll();
    }

    @Override
    public Mou_specification findByid(int id) throws Exception {
        return iMou_specificationDao.findByid(id);
    }

    @Override
    public void save(Mou_specification mou_specification) throws Exception {

        mou_specification.setItem_no(mou_specification.getItem_no().toUpperCase());

        iMou_specificationDao.save(mou_specification);
    }

    @Override
    public void update(Mou_specification mou_specification) throws Exception {
        mou_specification.setItem_no(mou_specification.getItem_no().toUpperCase());
        iMou_specificationDao.update(mou_specification);
    }

    @Override
    public void detele(int id) throws Exception {
        iMou_specificationDao.delete(id);
    }


}
