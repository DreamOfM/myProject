package com.tdk.txm_java.dao;

import com.tdk.txm_java.domain.Mou_specification;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IMou_specificationDao {
    @Select("select * from mou_specification")
    public List<Mou_specification> findAll() throws Exception;

    @Select("select * from mou_specification where item_no=#{item_no}")
    public Mou_specification findByitem_no(String item_no) throws Exception;

    @Select("select * from mou_specification where id=#{id}")
    public Mou_specification findByid(int id) throws Exception;


    @Update("update mou_specification set " +
            " item_no=#{item_no}," +
            " kanagata_std=#{kanagata_std}," +
            " kanagata_desc=#{kanagata_desc}," +
            " sh_ratio=#{sh_ratio}, " +
            " graph_no_dr=#{graph_no_dr}, " +
            " yamataka_check=#{yamataka_check}," +
            " memo1=#{memo1}," +
            " thread_form=#{thread_form}," +
            " dr_weight=#{dr_weight}," +
            " stove_name=#{stove_name}," +
            " item_type=#{item_type}," +
            " update_time=now(),update_oid=#{update_oid},update_program=#{update_program} where id=#{id}")
    void update(Mou_specification mou_specification);

    @Insert("insert into mou_specification(id,item_no,kanagata_std," +
            "kanagata_desc,sh_ratio,graph_no_dr,yamataka_check,memo1," +
            "thread_form,dr_weight,stove_name,item_type,login_time,login_oid," +
            "update_time,update_oid,update_program) values(#{id},#{item_no}," +
            "#{kanagata_std},#{kanagata_desc},#{sh_ratio},#{graph_no_dr}," +
            "#{yamataka_check},#{memo1},#{thread_form},#{dr_weight}," +
            "#{stove_name},#{item_type},now(),#{login_oid},now()," +
            "#{update_oid},#{update_program})")
     void save(Mou_specification mou_specification) throws Exception;

    @Delete("delete from mou_specification where id =#{id}  ")
    void delete(int id);
}
