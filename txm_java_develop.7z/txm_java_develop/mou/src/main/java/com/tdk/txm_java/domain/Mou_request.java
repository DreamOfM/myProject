package com.tdk.txm_java.domain;

public class Mou_request {
    private int id;
    private String request_no;
    private float request_line_no;
    private String state;
    private String item_no;
    private String memo1;
    private String item_description_dbcs;
    private String item_spec;
    private String sh_ratio;
    private String graph_no_dr;
    private String yamataka_check;
    private String thread_form;
    private String stove_name;
    private String mrpcode;
    private String warehouse_code;
    private String buyer;
    private double on_hand_qty;
    private double sale_qty;
    private double necessary_qty;
    private double security_qty;
    private double last_month_lose_qty;
    private double current_month_lose_qty;
    private double repari_qty;
    private String purchase_request_date;
    private String require_date;
    private double purchase_request_qty;
    private String um_incoming_outgoing;
    private double purchase_price;
    private double po_amt_rmb;
    private String um_purchase;
    private String currency;
    private double po_back_order_qty;
    private double po_boarding_qty;
    private double arrived_qty;
    private String text_filed1;
    private String text_filed2;
    private double number_filed1;
    private double number_filed2;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

    @Override
    public String toString() {
        return "Mou_request{" +
                "id=" + id +
                ", request_no='" + request_no + '\'' +
                ", request_line_no=" + request_line_no +
                ", state='" + state + '\'' +
                ", item_no='" + item_no + '\'' +
                ", memo1='" + memo1 + '\'' +
                ", item_description_dbcs='" + item_description_dbcs + '\'' +
                ", item_spec='" + item_spec + '\'' +
                ", sh_ratio='" + sh_ratio + '\'' +
                ", graph_no_dr='" + graph_no_dr + '\'' +
                ", yamataka_check='" + yamataka_check + '\'' +
                ", thread_form='" + thread_form + '\'' +
                ", stove_name='" + stove_name + '\'' +
                ", mrpcode='" + mrpcode + '\'' +
                ", warehouse_code='" + warehouse_code + '\'' +
                ", buyer='" + buyer + '\'' +
                ", on_hand_qty=" + on_hand_qty +
                ", sale_qty=" + sale_qty +
                ", necessary_qty=" + necessary_qty +
                ", security_qty=" + security_qty +
                ", last_month_lose_qty=" + last_month_lose_qty +
                ", current_month_lose_qty=" + current_month_lose_qty +
                ", repari_qty=" + repari_qty +
                ", purchase_request_date='" + purchase_request_date + '\'' +
                ", require_date='" + require_date + '\'' +
                ", purchase_request_qty=" + purchase_request_qty +
                ", um_incoming_outgoing='" + um_incoming_outgoing + '\'' +
                ", purchase_price=" + purchase_price +
                ", po_amt_rmb=" + po_amt_rmb +
                ", um_purchase='" + um_purchase + '\'' +
                ", currency='" + currency + '\'' +
                ", po_back_order_qty=" + po_back_order_qty +
                ", po_boarding_qty=" + po_boarding_qty +
                ", arrived_qty=" + arrived_qty +
                ", text_filed1='" + text_filed1 + '\'' +
                ", text_filed2='" + text_filed2 + '\'' +
                ", number_filed1=" + number_filed1 +
                ", number_filed2=" + number_filed2 +
                ", login_time='" + login_time + '\'' +
                ", login_oid='" + login_oid + '\'' +
                ", update_time='" + update_time + '\'' +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRequest_no() {
        return request_no;
    }

    public void setRequest_no(String request_no) {
        this.request_no = request_no;
    }

    public float getRequest_line_no() {
        return request_line_no;
    }

    public void setRequest_line_no(float request_line_no) {
        this.request_line_no = request_line_no;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getItem_no() {
        return item_no;
    }

    public void setItem_no(String item_no) {
        this.item_no = item_no;
    }

    public String getMemo1() {
        return memo1;
    }

    public void setMemo1(String memo1) {
        this.memo1 = memo1;
    }

    public String getItem_description_dbcs() {
        return item_description_dbcs;
    }

    public void setItem_description_dbcs(String item_description_dbcs) {
        this.item_description_dbcs = item_description_dbcs;
    }

    public String getItem_spec() {
        return item_spec;
    }

    public void setItem_spec(String item_spec) {
        this.item_spec = item_spec;
    }

    public String getSh_ratio() {
        return sh_ratio;
    }

    public void setSh_ratio(String sh_ratio) {
        this.sh_ratio = sh_ratio;
    }

    public String getGraph_no_dr() {
        return graph_no_dr;
    }

    public void setGraph_no_dr(String graph_no_dr) {
        this.graph_no_dr = graph_no_dr;
    }

    public String getYamataka_check() {
        return yamataka_check;
    }

    public void setYamataka_check(String yamataka_check) {
        this.yamataka_check = yamataka_check;
    }

    public String getThread_form() {
        return thread_form;
    }

    public void setThread_form(String thread_form) {
        this.thread_form = thread_form;
    }

    public String getStove_name() {
        return stove_name;
    }

    public void setStove_name(String stove_name) {
        this.stove_name = stove_name;
    }

    public String getMrpcode() {
        return mrpcode;
    }

    public void setMrpcode(String mrpcode) {
        this.mrpcode = mrpcode;
    }

    public String getWarehouse_code() {
        return warehouse_code;
    }

    public void setWarehouse_code(String warehouse_code) {
        this.warehouse_code = warehouse_code;
    }

    public String getBuyer() {
        return buyer;
    }

    public void setBuyer(String buyer) {
        this.buyer = buyer;
    }

    public double getOn_hand_qty() {
        return on_hand_qty;
    }

    public void setOn_hand_qty(double on_hand_qty) {
        this.on_hand_qty = on_hand_qty;
    }

    public double getSale_qty() {
        return sale_qty;
    }

    public void setSale_qty(double sale_qty) {
        this.sale_qty = sale_qty;
    }

    public double getNecessary_qty() {
        return necessary_qty;
    }

    public void setNecessary_qty(double necessary_qty) {
        this.necessary_qty = necessary_qty;
    }

    public double getSecurity_qty() {
        return security_qty;
    }

    public void setSecurity_qty(double security_qty) {
        this.security_qty = security_qty;
    }

    public double getLast_month_lose_qty() {
        return last_month_lose_qty;
    }

    public void setLast_month_lose_qty(double last_month_lose_qty) {
        this.last_month_lose_qty = last_month_lose_qty;
    }

    public double getCurrent_month_lose_qty() {
        return current_month_lose_qty;
    }

    public void setCurrent_month_lose_qty(double current_month_lose_qty) {
        this.current_month_lose_qty = current_month_lose_qty;
    }

    public double getRepari_qty() {
        return repari_qty;
    }

    public void setRepari_qty(double repari_qty) {
        this.repari_qty = repari_qty;
    }

    public String getPurchase_request_date() {
        return purchase_request_date;
    }

    public void setPurchase_request_date(String purchase_request_date) {
        this.purchase_request_date = purchase_request_date;
    }

    public String getRequire_date() {
        return require_date;
    }

    public void setRequire_date(String require_date) {
        this.require_date = require_date;
    }

    public double getPurchase_request_qty() {
        return purchase_request_qty;
    }

    public void setPurchase_request_qty(double purchase_request_qty) {
        this.purchase_request_qty = purchase_request_qty;
    }

    public String getUm_incoming_outgoing() {
        return um_incoming_outgoing;
    }

    public void setUm_incoming_outgoing(String um_incoming_outgoing) {
        this.um_incoming_outgoing = um_incoming_outgoing;
    }

    public double getPurchase_price() {
        return purchase_price;
    }

    public void setPurchase_price(double purchase_price) {
        this.purchase_price = purchase_price;
    }

    public double getPo_amt_rmb() {
        return po_amt_rmb;
    }

    public void setPo_amt_rmb(double po_amt_rmb) {
        this.po_amt_rmb = po_amt_rmb;
    }

    public String getUm_purchase() {
        return um_purchase;
    }

    public void setUm_purchase(String um_purchase) {
        this.um_purchase = um_purchase;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public double getPo_back_order_qty() {
        return po_back_order_qty;
    }

    public void setPo_back_order_qty(double po_back_order_qty) {
        this.po_back_order_qty = po_back_order_qty;
    }

    public double getPo_boarding_qty() {
        return po_boarding_qty;
    }

    public void setPo_boarding_qty(double po_boarding_qty) {
        this.po_boarding_qty = po_boarding_qty;
    }

    public double getArrived_qty() {
        return arrived_qty;
    }

    public void setArrived_qty(double arrived_qty) {
        this.arrived_qty = arrived_qty;
    }

    public String getText_filed1() {
        return text_filed1;
    }

    public void setText_filed1(String text_filed1) {
        this.text_filed1 = text_filed1;
    }

    public String getText_filed2() {
        return text_filed2;
    }

    public void setText_filed2(String text_filed2) {
        this.text_filed2 = text_filed2;
    }

    public double getNumber_filed1() {
        return number_filed1;
    }

    public void setNumber_filed1(double number_filed1) {
        this.number_filed1 = number_filed1;
    }

    public double getNumber_filed2() {
        return number_filed2;
    }

    public void setNumber_filed2(double number_filed2) {
        this.number_filed2 = number_filed2;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    public Mou_request(){

    }

    public Mou_request(int id, String request_no, float request_line_no, String state, String item_no, String memo1, String item_description_dbcs, String item_spec, String sh_ratio, String graph_no_dr, String yamataka_check, String thread_form, String stove_name, String mrpcode, String warehouse_code, String buyer, double on_hand_qty, double sale_qty, double necessary_qty, double security_qty, double last_month_lose_qty, double current_month_lose_qty, double repari_qty, String purchase_request_date, String require_date, double purchase_request_qty, String um_incoming_outgoing, double purchase_price, double po_amt_rmb, String um_purchase, String currency, double po_back_order_qty, double po_boarding_qty, double arrived_qty, String text_filed1, String text_filed2, double number_filed1, double number_filed2, String login_time, String login_oid, String update_time, String update_oid, String update_program) {
        this.id = id;
        this.request_no = request_no;
        this.request_line_no = request_line_no;
        this.state = state;
        this.item_no = item_no;
        this.memo1 = memo1;
        this.item_description_dbcs = item_description_dbcs;
        this.item_spec = item_spec;
        this.sh_ratio = sh_ratio;
        this.graph_no_dr = graph_no_dr;
        this.yamataka_check = yamataka_check;
        this.thread_form = thread_form;
        this.stove_name = stove_name;
        this.mrpcode = mrpcode;
        this.warehouse_code = warehouse_code;
        this.buyer = buyer;
        this.on_hand_qty = on_hand_qty;
        this.sale_qty = sale_qty;
        this.necessary_qty = necessary_qty;
        this.security_qty = security_qty;
        this.last_month_lose_qty = last_month_lose_qty;
        this.current_month_lose_qty = current_month_lose_qty;
        this.repari_qty = repari_qty;
        this.purchase_request_date = purchase_request_date;
        this.require_date = require_date;
        this.purchase_request_qty = purchase_request_qty;
        this.um_incoming_outgoing = um_incoming_outgoing;
        this.purchase_price = purchase_price;
        this.po_amt_rmb = po_amt_rmb;
        this.um_purchase = um_purchase;
        this.currency = currency;
        this.po_back_order_qty = po_back_order_qty;
        this.po_boarding_qty = po_boarding_qty;
        this.arrived_qty = arrived_qty;
        this.text_filed1 = text_filed1;
        this.text_filed2 = text_filed2;
        this.number_filed1 = number_filed1;
        this.number_filed2 = number_filed2;
        this.login_time = login_time;
        this.login_oid = login_oid;
        this.update_time = update_time;
        this.update_oid = update_oid;
        this.update_program = update_program;
    }
}
