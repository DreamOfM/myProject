package com.tdk.txm_java.domain;

import java.util.Date;

public class Mou_balance {
    private int id;
    private String item_no;
    private String item_spec;
    private int entry_no;
    private double rating_life;
    private String effective_date;
    private String shipped_date;
    private String stock_location;
    private String warehouse_code;
    private String job_no2;
    private String state;
    private String use_state;
    private String use_machine;
    private double complete_number;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;
    private String kanagata_desc;
    private int storage_num;



    @Override
    public String toString() {
        return "Mou_balance{" +
                "id=" + id +
                ", item_no='" + item_no + '\'' +
                ", item_spec='" + item_spec + '\'' +
                ", entry_no=" + entry_no +
                ", rating_life=" + rating_life +
                ", effective_date=" + effective_date +
                ", shipped_date=" + shipped_date +
                ", stock_location='" + stock_location + '\'' +
                ", warehouse_code='" + warehouse_code + '\'' +
                ", job_no2='" + job_no2 + '\'' +
                ", state='" + state + '\'' +
                ", use_state='" + use_state + '\'' +
                ", use_machine='" + use_machine + '\'' +
                ", complete_number=" + complete_number +
                ", login_time='" + login_time + '\'' +
                ", login_oid='" + login_oid + '\'' +
                ", update_time='" + update_time + '\'' +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                ", kanagata_desc='" + kanagata_desc + '\'' +
                ", storage_num='" + storage_num + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getItem_no() {
        return item_no;
    }

    public void setItem_no(String item_no) {
        this.item_no = item_no;
    }

    public String getItem_spec() {
        return item_spec;
    }

    public void setItem_spec(String item_spec) {
        this.item_spec = item_spec;
    }

    public int getEntry_no() {
        return entry_no;
    }

    public void setEntry_no(int entry_no) {
        this.entry_no = entry_no;
    }

    public double getRating_life() {
        return rating_life;
    }

    public void setRating_life(double rating_life) {
        this.rating_life = rating_life;
    }

    public String getEffective_date() {
        return effective_date;
    }

    public void setEffective_date(String effective_date) {
        this.effective_date = effective_date;
    }

    public String getShipped_date() {
        return shipped_date;
    }

    public void setShipped_date(String shipped_date) {
        this.shipped_date = shipped_date;
    }

    public String getStock_location() {
        return stock_location;
    }

    public void setStock_location(String stock_location) {
        this.stock_location = stock_location;
    }

    public String getWarehouse_code() {
        return warehouse_code;
    }

    public void setWarehouse_code(String warehouse_code) {
        this.warehouse_code = warehouse_code;
    }

    public String getJob_no2() {
        return job_no2;
    }

    public void setJob_no2(String job_no2) {
        this.job_no2 = job_no2;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getUse_state() {
        return use_state;
    }

    public void setUse_state(String use_state) {
        this.use_state = use_state;
    }

    public String getUse_machine() {
        return use_machine;
    }

    public void setUse_machine(String use_machine) {
        this.use_machine = use_machine;
    }

    public double getComplete_number() {
        return complete_number;
    }

    public void setComplete_number(double complete_number) {
        this.complete_number = complete_number;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    public String getKanagata_desc() { return kanagata_desc; }

    public void setKanagata_desc(String kanagata_desc) { this.kanagata_desc = kanagata_desc; }

    public int getStorage_num() {
        return storage_num; }

    public void setStorage_num(int storage_num) {
        this.storage_num = storage_num; }
    public Mou_balance(){

    }
    public Mou_balance(int id, String item_no, String item_spec, int entry_no, double rating_life, String effective_date, String shipped_date, String stock_location, String warehouse_code, String job_no2, String state, String use_state, String use_machine, double complete_number, String login_time, String login_oid, String update_time, String update_oid, String update_program,String kanagata_desc,int storage_num) {
        this.id = id;
        this.item_no = item_no;
        this.item_spec = item_spec;
        this.entry_no = entry_no;
        this.rating_life = rating_life;
        this.effective_date = effective_date;
        this.shipped_date = shipped_date;
        this.stock_location = stock_location;
        this.warehouse_code = warehouse_code;
        this.job_no2 = job_no2;
        this.state = state;
        this.use_state = use_state;
        this.use_machine = use_machine;
        this.complete_number = complete_number;
        this.login_time = login_time;
        this.login_oid = login_oid;
        this.update_time = update_time;
        this.update_oid = update_oid;
        this.update_program = update_program;
        this.kanagata_desc=kanagata_desc;
        this.storage_num=storage_num;
    }
}
