package com.tdk.txm_java.service.impl;


import com.tdk.txm_java.dao.IMou_balanceDao;
import com.tdk.txm_java.domain.Mou_balance;
import com.tdk.txm_java.domain.Mou_spec;
import com.tdk.txm_java.service.IMou_balanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class Mou_balanceServiceImpl implements IMou_balanceService {

    @Autowired
    private IMou_balanceDao iMou_balanceDao;


    public Mou_balance findByitem_noentry_no(String item_no,int entry_no) throws Exception {
        return iMou_balanceDao.findByitem_noentry_no(item_no,entry_no);
    }

    @Override
    public Mou_balance findByitem_no(String item_no) throws Exception {
        return iMou_balanceDao.findByitem_no(item_no);
    }

    @Override
    public Mou_spec findByitem_no1(String item_no) throws Exception {
        return iMou_balanceDao.findByitem_no1(item_no);
    }

    @Override
    public List<Mou_balance> findAll() throws Exception {
        return iMou_balanceDao.findAll();
    }

    @Override
    public Mou_balance findByid(int id) throws Exception {
        return iMou_balanceDao.findByid(id);
    }

    @Override
    public void save(Mou_balance mou_balance) throws Exception {
        mou_balance.setItem_no(mou_balance.getItem_no().toUpperCase());
        iMou_balanceDao.save(mou_balance);
    }

    @Override
    public void update(Mou_balance mou_balance) throws Exception {
        mou_balance.setItem_no(mou_balance.getItem_no().toUpperCase());
        iMou_balanceDao.update(mou_balance);
    }

    @Override
    public void detele(int id) throws Exception {
        iMou_balanceDao.delete(id);
    }


}
