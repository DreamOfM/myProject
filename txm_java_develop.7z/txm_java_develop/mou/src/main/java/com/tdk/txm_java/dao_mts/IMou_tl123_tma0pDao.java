package com.tdk.txm_java.dao_mts;

import com.tdk.txm_java.domain.Mou_tma0p;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

@Repository
public interface IMou_tl123_tma0pDao {
    @Select("select * from tl23_tma0p  where PRODPN=#{a0itnr}")
    public Mou_tma0p findByitem_no(String a0itnr);
}
