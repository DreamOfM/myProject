package com.tdk.txm_java.controller;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tdk.txm_java.domain.Com_serialnum;
import com.tdk.txm_java.domain.Mou_request;
import com.tdk.txm_java.domain.Mou_specification;
import com.tdk.txm_java.domain.ResultInfo;
import com.tdk.txm_java.service.ICom_serialnumService;
import com.tdk.txm_java.service.IMou_requestService;
import com.tdk.txm_java.service.IMou_request_uploadService;
import com.tdk.txm_java.service.IMou_specificationService;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

@Controller
@RequestMapping("/mou_request")
public class Mou_requestController {
    @Autowired
    private IMou_requestService iMou_requestService;
    @Autowired
    private ICom_serialnumService iCom_serialnumService;
    @Autowired
    private IMou_specificationService iMou_specificationService;
    @Autowired
    private IMou_request_uploadService iMou_request_uploadService;

    /**
     * 根据id查找
     *
     * @param id
     * @return
     * @throws Exception
     */
    @RequestMapping("/findByid.do")
    public ModelAndView findByid(String id) throws Exception {
        ModelAndView mv = new ModelAndView();
        System.out.println(id);
        mv.setViewName("mou-request-list");
        return mv;
    }

    @RequestMapping("/findByrequest_no")
    public ModelAndView findByrequest_no(String request_no) throws Exception {
        System.out.println(request_no);
        List<Mou_request> mou_request = iMou_requestService.findByrequest_no(request_no);
        System.out.println(mou_request);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("mou-request-list");
        mv.addObject("mou_request", mou_request);
        return mv;
    }

    /**
     * 删除
     *
     * @param
     * @return
     * @throws Exception
     */
    @RequestMapping("/delete.do")
    public String delete(int id) throws Exception {
        System.out.println(id + "delete's id has send");
        iMou_requestService.detele(id);
        System.out.println("mou_request's values");
        return "redirect:findByrequest_no.do";
    }


    /**
     * 新增
     *
     * @param
     * @return
     * @throws Exception
     */
    @RequestMapping("/save.do")
    public String save(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception {
        //取出前端传回的所有数据
        System.out.println("1111133333");
        Map map = request.getParameterMap();
        //测试前端数据是否传送过来？
        System.out.println("数据已传过来");


        String[] vals1 = (String[]) map.get("purchase_request_date");
        String[] vals2 = (String[]) map.get("require_date");
        Set<String> set = map.keySet();
        Map<String, String> hashMap = new HashMap<>();
        int b = 0;
        int c = 0;

        Com_serialnum com_serialnum = new Com_serialnum();
        com_serialnum.setType("mou");
        com_serialnum.setKey01("L-JX");
        com_serialnum.setKey02("RO");
        Com_serialnum mou_serialnum = iCom_serialnumService.find(com_serialnum);
        System.out.println(mou_serialnum.getSerialnum());
        // 0 代表前面补充0
        // 6代表长度为6
        // d 代表参数为正数型
        String t_request_line_no = "RO" + String.format("%08d", mou_serialnum.getSerialnum());
        iCom_serialnumService.update(com_serialnum);
        String username = (String) httpSession.getAttribute("username");
        Mou_request mou_request = new Mou_request();

        while (1 == 1) {
            for (String name1 : set) {
                if (name1.equals("purchase_request_date")) {
                    hashMap.put(name1, vals1[0]);
                } else if (name1.equals("require_date")) {
                    hashMap.put(name1, vals2[0]);
                } else {
                    String[] vals = (String[]) map.get(name1);
                    c = vals.length;
                    hashMap.put(name1, vals[b]);
                }
            }

            try {
                BeanUtils.populate(mou_request, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //添加一个判断，如果为空值或者没有输入则不往数据库里插数据
            if (mou_request.getItem_no().equals(null) || mou_request.getItem_no().equals("")) {
                b++;
                if (b == c) break;
                continue;
            }
            mou_request.setRequest_no(t_request_line_no);
            mou_request.setLogin_oid(username);
            mou_request.setBuyer(username);
            mou_request.setUpdate_oid(username);
            mou_request.setUpdate_program("/mou_request/save");

            Mou_specification mou_specification = new Mou_specification();
            mou_specification = iMou_specificationService.findByitem_no(mou_request.getItem_no());
            mou_request.setItem_spec(mou_specification.getKanagata_desc());
            mou_request.setSh_ratio(mou_specification.getSh_ratio());
            mou_request.setGraph_no_dr(mou_specification.getGraph_no_dr());
            mou_request.setYamataka_check(mou_specification.getYamataka_check());
            mou_request.setThread_form(mou_specification.getThread_form());
            mou_request.setMemo1(mou_specification.getMemo1());
            mou_request.setStove_name(mou_specification.getStove_name());
            mou_request.setPurchase_price(mou_specification.getDr_weight());
            mou_request.setPo_amt_rmb(mou_request.getPurchase_request_qty()*mou_request.getPurchase_price());


            iMou_requestService.save(mou_request);

            b++;
            if (b == c) break;
        }
        iMou_request_uploadService.delete();
        ResultInfo info = new ResultInfo();
        info.setData(t_request_line_no);
        //响应数据
        ObjectMapper mapper = new ObjectMapper();

        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(),info);
        return "redirect:findByrequest_no.do";
    }

    //修改
    @RequestMapping("/update.do")
    public String update(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession)
            throws Exception {
        //取出前端传回的所有数据

        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();

        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        System.out.println("2222222");
        System.out.println(set);
        String username = (String) httpSession.getAttribute("username");

        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //将每一个key值对应的一组值放到数组里去
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
//                //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
//                hashMap.put(name1, vals[b]);
                if(name1.equals("require_date")||name1.equals("purchase_request_date")){
                    hashMap.put(name1,vals[0]);
                }else{
                    hashMap.put(name1,vals[b]);

                }
            }

            Mou_request mou_request = new Mou_request();

            //根据key值找到集合中对应的id
            System.out.println("666666");
            System.out.println(hashMap.get("id"));
            int id1 = Integer.parseInt(hashMap.get("id"));
            System.out.println("oooooo");
            System.out.println(id1);

            //找到这个id对应数据库里的数据，并取出
            mou_request = iMou_requestService.findById(id1);

            System.out.println(mou_request);
            try {

                BeanUtils.populate(mou_request, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //调用业务层的update()方法
            mou_request.setUpdate_oid(username);
            mou_request.setUpdate_program("/mou_request/update");
            iMou_requestService.update(mou_request);
            b++;
            if (b == c) break;
        }
        return "redirect:findByid.do";
    }


    @RequestMapping("/check.do")
    public void check(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception, IOException, JsonGenerationException, JsonMappingException {
        System.out.println("rrrrrrr");
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        System.out.println(map);
        System.out.println(hashMap);
        Set<String> set = map.keySet();
        System.out.println("rrrrrrr");
        System.out.println(set);

        String[] vals1 = (String[]) map.get("purchase_request_date");
        String[] vals2 = (String[]) map.get("require_date");
        System.out.println(vals1);

        // check body
        int b = 0;   //第几笔记录
        int c = 0;   //total
//        String[] vals = (String[]) map.get("item_no");
//        c = vals.length;
        List<String> item_list=new ArrayList<>();
        while (true) {

            for (String name1 : set) {

                if (name1.equals("purchase_request_date")) {
                    hashMap.put(name1, vals1[0]);
                } else if (name1.equals("require_date")) {
                    hashMap.put(name1, vals2[0]);
                } else {
                    String[] vals = (String[]) map.get(name1);
                    c = vals.length;

//                    if(c>b)  hashMap.put(name1, vals[b]);
                    hashMap.put(name1, vals[b]);
                }
            }
            Mou_request mou_request = new Mou_request();
            System.out.println("12121212");
            System.out.println(hashMap);


//            mou_request = iMou_requestService.findByrequest_no(hashMap.getequest_no"));
            try {
                BeanUtils.populate(mou_request, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            System.out.println("222222222");
            System.out.println(mou_request);



            //添加一个判断，如果为空值或者没有输入则不往数据库里插数据
            if (mou_request.getItem_no().equals(null) || mou_request.getItem_no().equals("")) {
                b++;
                if (b == c) break;
                continue;
            }
            //检查金型是否存在
            Mou_specification mou_specification = new Mou_specification();
            mou_specification.setItem_no(mou_request.getItem_no());
            Mou_specification mouSpecification2 = iMou_specificationService.findByitem_no(mou_request.getItem_no());
            //价格的判断
            System.out.println("222333");
            System.out.println(mouSpecification2);
            if (mouSpecification2 == null) {
                info.setErrorMsg("金型不存在");
                String errLine = String.valueOf(b);
                errorList.add("item_no" + errLine);
                info.setFlag(false);
            }
            if(item_list.contains(mou_request.getItem_no())){
                info.setErrorMsg("重复请购");
                String errLine = String.valueOf(b);
                errorList.add("item_no" + errLine);
                info.setFlag(false);

            }else{
                item_list.add(mou_request.getItem_no());}

            b++;
            if (b == c) break;
        }

        info.setErrorList(errorList);
        //响应数据
        ObjectMapper mapper = new ObjectMapper();

        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(), info);
    }
}



