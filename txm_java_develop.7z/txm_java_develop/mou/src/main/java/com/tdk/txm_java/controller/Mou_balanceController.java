package com.tdk.txm_java.controller;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tdk.txm_java.domain.Mou_balance;
import com.tdk.txm_java.domain.Mou_specification;
import com.tdk.txm_java.domain.ResultInfo;
import com.tdk.txm_java.service.IMou_balanceService;
import com.tdk.txm_java.service.IMou_specificationService;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

@Controller
@RequestMapping("/mou_balance")
public class Mou_balanceController {
    @Autowired
    private IMou_balanceService iMou_balanceService;

    @Autowired
    private IMou_specificationService iMou_specificationService;


    //修改
    @RequestMapping("/update.do")
    public String update(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception {
        System.out.println("hhh");
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        String username= (String) httpSession.getAttribute("username");

        for (String name1 : set) {
            String[] vals = (String[]) map.get(name1);
//                int c = vals.length;
            hashMap.put(name1, vals[0]);
        }
        System.out.println(hashMap.get("id"));
        int id1 = Integer.parseInt(request.getParameter("id"));
        Mou_balance a = iMou_balanceService.findByid(id1);
        try {
            //double传不成功
            BeanUtils.populate(a,hashMap);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
//            a.setDr_weight(s);
        a.setUpdate_oid(username);
        String update_program="/mou_balance/update";
        a.setUpdate_program(update_program);
        iMou_balanceService.update(a);

        return "redirect:findByitem_noentry_no.do";

    }
//    /**
//     * 根据品名代碼来查询
//     * @param item_no
//     * @return
//     * @throws Exception
//     */
//    @RequestMapping("/findByitem_no.do")
//    public ModelAndView findByitem_no(String item_no) throws Exception {
//        Mou_balance mou_balance= iMou_balanceService.findByitem_no(item_no);
//        ModelAndView mv = new ModelAndView();
//        mv.setViewName("mou-balance-list");
//        System.out.println(mou_balance);
//        mv.addObject("mou_balance", mou_balance);
//        return mv;
//    }

    /**

     * @param item_no,entry_no
     * @return
     * @throws Exception
     */
    @RequestMapping("/findByitem_noentry_no.do")
    public ModelAndView findByitem_noentry_no(String item_no,@RequestParam(value="entry_no",defaultValue="0")int entry_no) throws Exception {
        if(entry_no==0){
            Mou_balance mou_balance3=iMou_balanceService.findByitem_no(item_no);
            if(mou_balance3!=null){
            entry_no=mou_balance3.getEntry_no();}
            else{
                entry_no=0;
            }
        }
        Mou_balance mou_balance= iMou_balanceService.findByitem_noentry_no(item_no,entry_no);
        System.out.println(mou_balance);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("mou-balance-list");
        mv.addObject("mou_balance", mou_balance);
        mv.addObject("item_no", item_no);
        return mv;
    }


    @RequestMapping("/save.do")
    public String save(Mou_balance mou_balance, HttpSession httpSession) throws Exception {
        System.out.println("2222222");
        System.out.println(mou_balance);
        int a=mou_balance.getStorage_num();
        String username = (String) httpSession.getAttribute("username");
        int ss=mou_balance.getEntry_no();
        for (int i=0;i<a;i++)
        {   mou_balance.setEntry_no(ss+i);
            mou_balance.setLogin_oid(username);
            mou_balance.setUpdate_oid(username);
            mou_balance.setUpdate_program("/mou_balance/save");
            iMou_balanceService.save(mou_balance);}
        return "redirect:findByitem_noentry_no.do";
    }

//    /**
//     * 删除
//     */
//    @RequestMapping("/delete.do")
//    public String delete(int id) throws Exception {
//        iMou_specificationService.detele(id);
//        return "redirect:findByitem_no.do";
//    }

    /**

     * @param item_no
     * @return
     * @throws Exception
     */
//    @RequestMapping("/findByitem_no.do")
//    public ModelAndView findByitem_no(String item_no) throws Exception {
//        System.out.println(item_no);
//        Mou_balance mou_balance= iMou_balanceService.findByitem_no(item_no);
//        System.out.println("777777");
//        System.out.println(item_no);
//        Mou_spec mou_spec=iMou_balanceService.findByitem_no1(item_no);
//        System.out.println("888888");
//        System.out.println(mou_balance);
//        System.out.println("999999");
//        System.out.println(mou_spec);
//        ModelAndView mv = new ModelAndView();
//        mv.setViewName("mou-balance-add");
//        mv.addObject("mou_balance", mou_balance);
//        mv.addObject("mou_spec", mou_spec);
//        return mv;
//    }

    @RequestMapping("/findByitem_no.do")

        public void check0(HttpServletResponse response,String item_no) throws Exception, JsonGenerationException, JsonMappingException
        {
            System.out.println("32323232");
            ResultInfo info = new ResultInfo();
            Mou_balance mou_balance= iMou_balanceService.findByitem_no(item_no);
            Mou_specification mou_specification=iMou_specificationService.findByitem_no(item_no);
            if(mou_balance!=null) {
                mou_balance.setEntry_no(mou_balance.getEntry_no()+1);
                if(mou_specification!=null){
                mou_balance.setItem_spec(mou_specification.getKanagata_desc());}
                info.setData(mou_balance);
                info.setFlag(true);
                System.out.println("212121");
            }
            if(mou_balance==null && mou_specification!=null){
                info.setData(mou_specification);
                info.setFlag(false);
            }

            //响应数据
            ObjectMapper mapper = new ObjectMapper();
            response.setContentType("application/json;charset=utf-8");
            mapper.writeValue(response.getOutputStream(),info);
    }

    @RequestMapping("/check2.do")
    public void check2(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        //1.获取信息
        String item_no = request.getParameter("item_no");
        System.out.println(item_no+"11111111111111111111111");
        //2.调用service层判断是否存在


        Mou_specification mac = iMou_specificationService.findByitem_no(item_no);
        System.out.println(item_no+"RRRRR");

        if (mac == null) {
            info.setFlag(false);
//            String errLine = String.valueOf(0);
            errorList.add("item_no");

        }
        info.setErrorList(errorList);
        // 响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(), info);


    }


}
