package com.tdk.txm_java.service;

import com.tdk.txm_java.domain.Com_serialnum;
import com.tdk.txm_java.domain.Mou_request;

import java.util.List;

public interface IMou_requestService {
    public List<Mou_request> findAll() throws Exception;

    public List<Mou_request> findByrequest_no(String request_no) throws Exception;

    public Mou_request findById(int id) throws Exception;


    void save(Mou_request mou_request) throws Exception;

    void update(Mou_request mou_request) throws Exception;

    void detele(int id) throws Exception;
}
