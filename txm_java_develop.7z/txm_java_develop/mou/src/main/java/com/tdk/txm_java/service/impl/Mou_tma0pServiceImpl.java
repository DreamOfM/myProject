package com.tdk.txm_java.service.impl;

import com.tdk.txm_java.dao2.IMou_tma0pDao;
import com.tdk.txm_java.dao_mts.IMou_tl123_tma0pDao;
import com.tdk.txm_java.domain.Com_tmimp;
import com.tdk.txm_java.domain.Mou_tma0p;
import com.tdk.txm_java.service.ICom_tmimpService;
import com.tdk.txm_java.service.IMou_tma0pService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Mou_tma0pServiceImpl implements IMou_tma0pService {
//    @Autowired
//    private IMou_tma0pDao iMou_tma0pDao;
    @Autowired
    private IMou_tl123_tma0pDao iMou_tl123_tma0pDao;
    @Autowired
    private ICom_tmimpService iCom_tmimpService;

    public Mou_tma0p findByitem_no(String a0itnr) throws Exception {
        Com_tmimp com_tmimp =iCom_tmimpService.findByItemcode(a0itnr);
        Mou_tma0p mou_tma0p=iMou_tl123_tma0pDao.findByitem_no(a0itnr);
        if(null==mou_tma0p){
            mou_tma0p=new Mou_tma0p();
        }
        mou_tma0p.setA0itnr(a0itnr);
        if(null!=com_tmimp) {
            mou_tma0p.setImspec(com_tmimp.getImspec().trim());
        }
        return mou_tma0p;
    }
}
