package com.tdk.txm_java.domain;

public class Mou_request_upload {
    private int id;
    private String item_no;
    private double on_hand_qty;
    private double sale_qty;
    private double necessary_qty;
    private double security_qty;
    private double last_month_lose_qty;
    private double current_month_lose_qty;
    private double repari_qty;
    private double purchase_request_qty;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getItem_no() {
        return item_no;
    }

    public void setItem_no(String item_no) {
        this.item_no = item_no;
    }

    public double getOn_hand_qty() {
        return on_hand_qty;
    }

    public void setOn_hand_qty(double on_hand_qty) {
        this.on_hand_qty = on_hand_qty;
    }

    public double getSale_qty() {
        return sale_qty;
    }

    public void setSale_qty(double sale_qty) {
        this.sale_qty = sale_qty;
    }

    public double getNecessary_qty() {
        return necessary_qty;
    }

    public void setNecessary_qty(double necessary_qty) {
        this.necessary_qty = necessary_qty;
    }

    public double getSecurity_qty() {
        return security_qty;
    }

    public void setSecurity_qty(double security_qty) {
        this.security_qty = security_qty;
    }

    public double getLast_month_lose_qty() {
        return last_month_lose_qty;
    }

    public void setLast_month_lose_qty(double last_month_lose_qty) {
        this.last_month_lose_qty = last_month_lose_qty;
    }

    public double getCurrent_month_lose_qty() {
        return current_month_lose_qty;
    }

    public void setCurrent_month_lose_qty(double current_month_lose_qty) {
        this.current_month_lose_qty = current_month_lose_qty;
    }

    public double getRepari_qty() {
        return repari_qty;
    }

    public void setRepari_qty(double repari_qty) {
        this.repari_qty = repari_qty;
    }

    public double getPurchase_request_qty() {
        return purchase_request_qty;
    }

    public void setPurchase_request_qty(double purchase_request_qty) {
        this.purchase_request_qty = purchase_request_qty;
    }

    @Override
    public String toString() {
        return "Mou_request_upload{" +
                "id=" + id +
                ", item_no='" + item_no + '\'' +
                ", on_hand_qty=" + on_hand_qty +
                ", sale_qty=" + sale_qty +
                ", necessary_qty=" + necessary_qty +
                ", security_qty=" + security_qty +
                ", last_month_lose_qty=" + last_month_lose_qty +
                ", current_month_lose_qty=" + current_month_lose_qty +
                ", repari_qty=" + repari_qty +
                ", purchase_request_qty=" + purchase_request_qty +
                '}';
    }

    public Mou_request_upload(){

    }
    public Mou_request_upload(int id, String item_no, double on_hand_qty, double sale_qty, double necessary_qty, double security_qty, double last_month_lose_qty, double current_month_lose_qty, double repari_qty, double purchase_request_qty) {
        this.id = id;
        this.item_no = item_no;
        this.on_hand_qty = on_hand_qty;
        this.sale_qty = sale_qty;
        this.necessary_qty = necessary_qty;
        this.security_qty = security_qty;
        this.last_month_lose_qty = last_month_lose_qty;
        this.current_month_lose_qty = current_month_lose_qty;
        this.repari_qty = repari_qty;
        this.purchase_request_qty = purchase_request_qty;
    }
}

