package com.tdk.txm_java.service.impl;


import com.tdk.txm_java.dao.IMou_requestDao;
import com.tdk.txm_java.domain.Com_serialnum;
import com.tdk.txm_java.domain.Mou_request;
import com.tdk.txm_java.service.IMou_requestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class Mou_requestServiceImpl implements IMou_requestService {

    @Autowired
    private IMou_requestDao iMou_requestDao;


    public List<Mou_request> findByrequest_no(String request_no) throws Exception {
        return iMou_requestDao.findByrequest_no(request_no);
    }

    @Override
    public List<Mou_request> findAll() throws Exception {
        return iMou_requestDao.findAll();
    }

    @Override
    public Mou_request findById(int id) throws Exception {
        return iMou_requestDao.findById(id);
    }


    @Override
    public void save(Mou_request mou_request) throws Exception {
        mou_request.setItem_no(mou_request.getItem_no().toUpperCase());
        iMou_requestDao.save(mou_request);
    }

    @Override
    public void update(Mou_request mou_request) throws Exception {
        mou_request.setItem_no(mou_request.getItem_no().toUpperCase());
        iMou_requestDao.update(mou_request);
    }

    @Override
    public void detele(int id) throws Exception {
        iMou_requestDao.delete(id);
    }


}
