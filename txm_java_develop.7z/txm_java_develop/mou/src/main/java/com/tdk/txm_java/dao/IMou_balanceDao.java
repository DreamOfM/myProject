package com.tdk.txm_java.dao;

import com.tdk.txm_java.domain.Mou_balance;
import com.tdk.txm_java.domain.Mou_spec;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IMou_balanceDao {
    @Select("select * from mou_balance")
    public List<Mou_balance> findAll() throws Exception;

    @Select("select * from mou_balance where id=#{id}")
    public Mou_balance findByid(int id) throws Exception;

    @Select("select * from mou_balance where item_no=#{item_no} and entry_no=#{entry_no}")
    public Mou_balance findByitem_noentry_no(@Param("item_no") String item_no,@Param("entry_no") int entry_no) throws Exception;

    @Select("select item_no,max(entry_no) entry_no " +
            "from mou_balance where item_no=#{item_no} group by item_no")
    public Mou_balance findByitem_no(String item_no) throws Exception;

    @Select("select item_no,kanagata_desc from mou_specification where item_no=#{item_no}")
    public Mou_spec findByitem_no1(String item_no) throws Exception;

    @Update("update mou_balance set id=#{id}," +
            " item_no=#{item_no}," +
            " item_spec=#{item_spec}, " +
            "entry_no=#{entry_no}, " +
            "rating_life=#{rating_life}," +
            "effective_date=#{effective_date}, " +
            "stock_location=#{stock_location}," +
            " warehouse_code=#{warehouse_code}," +
            " job_no2=#{job_no2}," +
            " state=#{state}," +
            " use_state=#{use_state}, " +
            "use_machine=#{use_machine}," +
            " complete_number=#{complete_number}, " +
            "login_time=#{login_time}," +
            " login_oid=#{login_oid}," +
            " update_time=now(), " +
            "update_oid=#{update_oid}, " +
            "update_program=#{update_program}" +
            "where id=#{id}")
    void update(Mou_balance mou_balance);


    @Insert("insert into mou_balance(item_no," +
            "item_spec,entry_no,rating_life,effective_date," +
            "stock_location,warehouse_code,job_no2,state,use_state," +
            "use_machine,complete_number,login_time,login_oid," +
            "update_time,update_oid,update_program) values(#{item_no}," +
            "#{item_spec},#{entry_no},#{rating_life},#{effective_date}," +
            "#{stock_location},#{warehouse_code},#{job_no2}," +
            "'5','保管中',#{use_machine},#{complete_number}," +
            "now(),#{login_oid},now(),#{update_oid}," +
            "#{update_program})")
    void save(Mou_balance mou_balance);

    @Delete("delete from mou_balance where id=#{id}")
    void delete(int id);

}
