package com.tdk.txm_java.service;

import com.tdk.txm_java.domain.Mou_tma0p;

public interface IMou_tma0pService {
    public Mou_tma0p findByitem_no(String a0itnr) throws Exception;
}
