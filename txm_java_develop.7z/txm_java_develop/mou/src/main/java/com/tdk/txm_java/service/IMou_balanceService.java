package com.tdk.txm_java.service;

import com.tdk.txm_java.domain.Mou_balance;
import com.tdk.txm_java.domain.Mou_spec;

import java.util.List;

public interface IMou_balanceService {
    public List<Mou_balance> findAll() throws Exception;

    public Mou_balance findByitem_noentry_no(String item_no,int entry_no) throws Exception;

    public Mou_balance findByitem_no(String item_no) throws Exception;

    public Mou_balance findByid(int id) throws Exception;

    public Mou_spec findByitem_no1(String item_no) throws Exception;

    void save(Mou_balance mou_balance) throws Exception;

    void update(Mou_balance mou_balance) throws Exception;

    void detele(int id) throws Exception;
}
