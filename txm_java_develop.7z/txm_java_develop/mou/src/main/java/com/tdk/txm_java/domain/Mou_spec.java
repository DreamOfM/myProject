package com.tdk.txm_java.domain;

public class Mou_spec {
    private String item_no;
    private String kanagata_desc;

    public String getItem_no() {
        return item_no;
    }

    public void setItem_no(String item_no) {
        this.item_no = item_no;
    }

    public String getKanagata_desc() {
        return kanagata_desc;
    }

    public void setKanagata_desc(String kanagata_desc) {
        this.kanagata_desc = kanagata_desc;
    }

    public Mou_spec(){

    }

    public Mou_spec(String item_no, String kanagata_desc) {
        this.item_no = item_no;
        this.kanagata_desc = kanagata_desc;
    }
}
