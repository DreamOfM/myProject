package com.tdk.txm_java.controller;

import com.tdk.txm_java.domain.Mou_tma0p;

import com.tdk.txm_java.service.IMou_tma0pService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


@Controller
@RequestMapping("/mou_tma0p")
public class Mou_tma0pController {
    @Autowired
    private IMou_tma0pService iMou_tma0pService;

    /**
     * 根据品名代碼来查询
     *
     * @param a0itnr
     * @return
     * @throws Exception
     */
    @RequestMapping("/findByitem_no.do")
    public ModelAndView findByitem_no(String a0itnr) throws Exception {
        Mou_tma0p mou_tma0p = iMou_tma0pService.findByitem_no(a0itnr);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("mou-spec-list");
        mv.addObject("mou_tma0p", mou_tma0p);
        System.out.println("qqqqqqqq");
        System.out.println(mou_tma0p);
        return mv;
    }

}
