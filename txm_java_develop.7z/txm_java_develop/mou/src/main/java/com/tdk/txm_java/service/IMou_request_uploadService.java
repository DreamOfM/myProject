package com.tdk.txm_java.service;

import com.tdk.txm_java.domain.Mou_request_upload;

import java.util.List;

public interface IMou_request_uploadService {

    /**
    *@Description: 查询全部
    *@Author: a135109
    *@time: 2019/11/6 10:32
    */
    public List<Mou_request_upload> findAll() throws Exception;

    /**
     *@Description: 通过id查询
     *@Author: a135109
     *@time: 2019/11/6 10:33
     */
    Mou_request_upload findById(int id);

    /**
     *@Description: 上载数据
     *@Author: a135109
     *@time: 2019/11/6 10:32
     */
    void save(Mou_request_upload mou_request_upload) throws Exception;

    /**
    *@Description: 删除
    *@Author: a135109
    *@time: 2019/11/6 10:32
    */
    void delete() throws Exception;

}
