package com.tdk.txm_java.domain;

public class Mou_specification {
    private int id;
    private String item_no;
    private String kanagata_desc;
    private String kanagata_std;
    private String sh_ratio;
    private String graph_no_dr;
    private String yamataka_check;
    private String memo1;
    private String thread_form;
    private double dr_weight;
    private String stove_name;
    private String item_type;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getItem_no() {
        return item_no;
    }

    public void setItem_no(String item_no) {
        this.item_no = item_no;
    }

    public String getKanagata_desc() {
        return kanagata_desc;
    }

    public void setKanagata_desc(String kanagata_desc) {
        this.kanagata_desc = kanagata_desc;
    }

    public String getKanagata_std() {
        return kanagata_std;
    }

    public void setKanagata_std(String kanagata_std) {
        this.kanagata_std = kanagata_std;
    }

    public String getSh_ratio() {
        return sh_ratio;
    }

    public void setSh_ratio(String sh_ratio) {
        this.sh_ratio = sh_ratio;
    }

    public String getGraph_no_dr() {
        return graph_no_dr;
    }

    public void setGraph_no_dr(String graph_no_dr) {
        this.graph_no_dr = graph_no_dr;
    }

    public String getYamataka_check() {
        return yamataka_check;
    }

    public void setYamataka_check(String yamataka_check) {
        this.yamataka_check = yamataka_check;
    }

    public String getMemo1() {
        return memo1;
    }

    public void setMemo1(String memo1) {
        this.memo1 = memo1;
    }

    public String getThread_form() {
        return thread_form;
    }

    public void setThread_form(String thread_form) {
        this.thread_form = thread_form;
    }

    public double getDr_weight() {
        return dr_weight;
    }

    public void setDr_weight(double dr_weight) {
        this.dr_weight = dr_weight;
    }

    public String getStove_name() {
        return stove_name;
    }

    public void setStove_name(String stove_name) {
        this.stove_name = stove_name;
    }

    public String getItem_type() {
        return item_type;
    }

    public void setItem_type(String item_type) {
        this.item_type = item_type;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    @Override
    public String toString() {
        return "Mou_specification{" +
                "id=" + id +
                ", item_no='" + item_no + '\'' +
                ", kanagata_desc='" + kanagata_desc + '\'' +
                ", kanagata_std='" + kanagata_std + '\'' +
                ", sh_ratio='" + sh_ratio + '\'' +
                ", graph_no_dr='" + graph_no_dr + '\'' +
                ", yamataka_check='" + yamataka_check + '\'' +
                ", memo1='" + memo1 + '\'' +
                ", thread_form='" + thread_form + '\'' +
                ", dr_weight=" + dr_weight +
                ", stove_name='" + stove_name + '\'' +
                ", item_type='" + item_type + '\'' +
                ", login_time='" + login_time + '\'' +
                ", login_oid='" + login_oid + '\'' +
                ", update_time='" + update_time + '\'' +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                '}';
    }

    public Mou_specification(){

    }
    public Mou_specification(int id, String item_no, String kanagata_desc, String kanagata_std, String sh_ratio, String graph_no_dr, String yamataka_check, String memo1, String thread_form, double dr_weight, String stove_name, String item_type, String login_time, String login_oid, String update_time, String update_oid, String update_program) {
        this.id = id;
        this.item_no = item_no;
        this.kanagata_desc = kanagata_desc;
        this.kanagata_std = kanagata_std;
        this.sh_ratio = sh_ratio;
        this.graph_no_dr = graph_no_dr;
        this.yamataka_check = yamataka_check;
        this.memo1 = memo1;
        this.thread_form = thread_form;
        this.dr_weight = dr_weight;
        this.stove_name = stove_name;
        this.item_type = item_type;
        this.login_time = login_time;
        this.login_oid = login_oid;
        this.update_time = update_time;
        this.update_oid = update_oid;
        this.update_program = update_program;
    }
}