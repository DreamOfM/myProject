package com.tdk.txm_java.controller;

import com.tdk.txm_java.domain.Mou_request;
import com.tdk.txm_java.domain.Mou_request_upload;
import com.tdk.txm_java.service.IMou_request_uploadService;
import com.tdk.txm_java.service.IMou_requestService;
import com.tdk.txm_java.utils.ExcelUtils;
import com.tdk.txm_java.utils.UploadUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 *@Description: 上载中间表Controller层
 *@Author: a135109
 *@time: 2019/11/6 10:16
 */

@Controller
@RequestMapping("/mou_upload")
public class Mou_request_uploadController {

    @Autowired
    private IMou_request_uploadService iMou_request_uploadService;
    @Autowired
    private IMou_requestService iMou_requestServiceService;

    /**
     *@Description: 查询中间表
     *@Author: a135109
     *@time: 2019/11/6 10:15
     */
    @RequestMapping("/findAll.do")
    public ModelAndView find() throws Exception{
        List<Mou_request_upload> list = new ArrayList<>();
        //获取中间表信息,若未输入信息，则会遍历所有数据
        list = iMou_request_uploadService.findAll();
        ModelAndView mv = new ModelAndView();
        mv.setViewName("mou-request-add");
        mv.addObject("mou_request",list);
        return mv;
    }

    /**
     * @Description: 上载数据
     * @Author: a135109
     * @time: 2019/11/6 10:17
     */
    @RequestMapping("/upload.do")
    public String upload(MultipartFile imgFile, HttpServletRequest request) throws Exception {
        System.out.println("wwwwwww");
        UploadUtils uploadUtils = new UploadUtils();
        String filePath = uploadUtils.upload(imgFile, request);
        //导入LoadExcle方法
        String columns[] = {"item_no","on_hand_qty", "sale_qty", "necessary_qty", "security_qty", "last_month_lose_qty", "current_month_lose_qty", "repari_qty", "purchase_request_qty"};
        //创建对象
        Mou_request_upload mou_request_upload1 = new Mou_request_upload();
        //从Excel获取数据列表
        List<Map<String, Object>> list = ExcelUtils.LoadExcle(filePath, columns);
        //创建新的对象列表
        System.out.println("erererer");
        System.out.println(list);
        List<Mou_request_upload> ls = new ArrayList<>();
        //将map转为foc_upload对象，并存到对象list
        for (Map ma : list) {
            mou_request_upload1 = ExcelUtils.mapToBean(ma,Mou_request_upload.class);
            ls.add(mou_request_upload1);
        }
        System.out.println("qtqtqtqt");
        System.out.println(ls);
        //将获取的数据上载到中间表
        iMou_request_uploadService.delete();
        for (Mou_request_upload mou_request_upload:ls) {
        iMou_request_uploadService.save(mou_request_upload);
        }

        ModelAndView mv = new ModelAndView();
        mv.setViewName("mou-request-add");
        mv.addObject("mou_request_upload1", ls);
        return "redirect:findAll.do";
    }


    /**
     *@Description: 删除数据
     *@Author: a135109
     *@time: 2019/11/6 10:18
     */
    @RequestMapping("/delete.do")
    public String delete(int ids[]) throws Exception{
        System.out.println(ids);
        if(ids != null && ids.length > 0){
            //1.遍历数组
            for (int id : ids) {
                //2.单条删除
                iMou_request_uploadService.delete();
            }
        }
        return "redirect:findAll.do";
    }

}
