package com.tdk.txm_java.domain;

public class Mou_tma0p {
    private String a0itnr;
    private String a0kyou;
    private String imspec;
//    private String a0kaga;
    private String a0pval;
    private String a0pvap;
    private String a0pvam;
    private float a0daba;
    private float a0dabp;
    private float a0dabm;

    public String getA0itnr() {
        return a0itnr;
    }

    public void setA0itnr(String a0itnr) {
        this.a0itnr = a0itnr;
    }

    public String geta0kyou() {
        return a0kyou;
    }

    public void seta0kyou(String a0kyou) {
        this.a0kyou = a0kyou;
    }

    public String getImspec() {
        return imspec;
    }

    public void setImspec(String imspec) {
        this.imspec = imspec;
    }

    public String getA0pval() {
        return a0pval;
    }

    public void setA0pval(String a0pval) {
        this.a0pval = a0pval;
    }

    public String getA0pvap() {
        return a0pvap;
    }

    public void setA0pvap(String a0pvap) {
        this.a0pvap = a0pvap;
    }

    public String getA0pvam() {
        return a0pvam;
    }

    public void setA0pvam(String a0pvam) {
        this.a0pvam = a0pvam;
    }

    public float getA0daba() {
        return a0daba;
    }

    public void setA0daba(float a0daba) {
        this.a0daba = a0daba;
    }

    public float getA0dabp() {
        return a0dabp;
    }

    public void setA0dabp(float a0dabp) {
        this.a0dabp = a0dabp;
    }

    public float getA0dabm() {
        return a0dabm;
    }

    public void setA0dabm(float a0dabm) {
        this.a0dabm = a0dabm;
    }

    @Override
    public String toString() {
        return "Mou_tma0p{" +
                "a0itnr='" + a0itnr + '\'' +
                ", a0kyou='" + a0kyou + '\'' +
                ", imspec='" + imspec + '\'' +
                ", a0pval='" + a0pval + '\'' +
                ", a0pvap='" + a0pvap + '\'' +
                ", a0pvam='" + a0pvam + '\'' +
                ", a0daba=" + a0daba +
                ", a0dabp=" + a0dabp +
                ", a0dabm=" + a0dabm +
                '}';
    }

    public Mou_tma0p(){

    }
    public Mou_tma0p(String a0itnr, String a0kyou, String imspec, String a0pval, String a0pvap, String a0pvam, float a0daba, float a0dabp, float a0dabm) {
        this.a0itnr = a0itnr;
        this.a0kyou = a0kyou;
        this.imspec = imspec;
        this.a0pval = a0pval;
        this.a0pvap = a0pvap;
        this.a0pvam = a0pvam;
        this.a0daba = a0daba;
        this.a0dabp = a0dabp;
        this.a0dabm = a0dabm;
    }
}
