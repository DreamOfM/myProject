package com.tdk.txm_java.dao;

import com.tdk.txm_java.domain.Mou_request_upload;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IMou_request_uploadDao {
    /**
    *@Description: 查询所有信息
    *@Author: a135109
    *@time: 2019/11/6 10:27
    */
    @Select("select * from mou_request_upload")
    public List<Mou_request_upload> findAll() throws Exception;

    /**
     *@Description: /通过id查找
     *@Author: a135109
     *@time: 2019/11/6 10:29
     */
    @Select("select * from mou_request_upload where  id = #{id}")
    public Mou_request_upload findById (int id);

    /**
     *@Description: 存入中间表
     *@Author: a135109
     *@time: 2019/11/6 10:26
     */
    @Insert("insert into mou_request_upload(id,item_no,on_hand_qty,sale_qty,necessary_qty,security_qty,last_month_lose_qty,current_month_lose_qty,repari_qty,purchase_request_qty) " +
            "values(#{id},#{item_no},#{on_hand_qty},#{sale_qty},#{necessary_qty},#{security_qty},#{last_month_lose_qty},#{current_month_lose_qty},#{repari_qty},#{purchase_request_qty})")
    void save(Mou_request_upload mou_request_upload);

    /**
    *@Description: 删除
    *@Author: a135109
    *@time: 2019/11/6 10:25
    */
    @Delete("delete from mou_request_upload")
    void delete();

}
