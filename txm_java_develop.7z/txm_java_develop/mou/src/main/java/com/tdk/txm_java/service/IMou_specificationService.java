package com.tdk.txm_java.service;

import com.tdk.txm_java.domain.Mou_specification;

import java.util.List;

public interface IMou_specificationService {
    public List<Mou_specification> findAll() throws Exception;

    public Mou_specification findByitem_no(String item_no) throws Exception;

    public Mou_specification findByid(int id) throws Exception;

    void save(Mou_specification mou_specification) throws Exception;

    void update(Mou_specification mou_specification) throws Exception;

    void detele(int id) throws Exception;
}
