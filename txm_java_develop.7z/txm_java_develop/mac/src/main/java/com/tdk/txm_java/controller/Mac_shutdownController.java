package com.tdk.txm_java.controller;


import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tdk.txm_java.domain.Mac_movement;
import com.tdk.txm_java.domain.Mac_shutdown;
import com.tdk.txm_java.domain.Mac_shutdown_reason;
import com.tdk.txm_java.domain.ResultInfo;
import com.tdk.txm_java.service.IMac_movementService;
import com.tdk.txm_java.service.IMac_shutdownService;
import com.tdk.txm_java.service.IMac_shutdown_reasonService;
import com.tdk.txm_java.utils.ExcelUtils;
import com.tdk.txm_java.utils.UploadUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

@Controller
@RequestMapping("/mac_shutdown")
public class Mac_shutdownController {

    @Autowired
    private IMac_shutdownService mac_shutdownService;
    @Autowired
    private IMac_shutdown_reasonService mac_shutdown_reasonService;
    @Autowired
    private IMac_movementService mac_movementService;

    /**
    *@Description: 查询
    *@Author: a135109
    *@time: 2019/12/9 10:30
    */
    @RequestMapping("/findByName")
    public ModelAndView findByName(String product_differentiation,String equipment_name,String machine_number,String date,String class_name) throws Exception {
        //引入PageHelper分页插件
        //查询之前需要调用,,传入页码，以及每页的大小
        List<Mac_shutdown> ls = mac_shutdownService.findByName(product_differentiation,equipment_name,machine_number,date,class_name);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("mac-shutdown-list");
        mv.addObject("product_differentiation",product_differentiation);
        mv.addObject("equipment_name",equipment_name);
        mv.addObject("machine_number",machine_number);
        mv.addObject("date",date);
        mv.addObject("class_name",class_name);
        mv.addObject("mac_shutdown",ls);
        return mv;
    }

    /**
     *@Description: 新增设备信息
     *@Author: a135109
     *@time: 2019/12/4 11:57
     */
    @RequestMapping("/save.do")
    public void save(HttpServletRequest request, HttpServletResponse response,HttpSession httpSession) throws Exception {
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //测试前端数据是否传送过来？
        System.out.println(map.entrySet().toString() + "数据已传过来");
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        Mac_shutdown mac_shutdown = new Mac_shutdown();
        while (1 == 1) {
            for (String name1 : set) {
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                hashMap.put(name1, vals[b]);
            }
            try {
                BeanUtils.populate(mac_shutdown, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //添加一个判断，如果为空值或者没有输入则不往数据库里插数据
            if (mac_shutdown.getShutdown_reason_code().equals(null) || mac_shutdown.getShutdown_reason_code().equals("")) {
                b++;
                if (b == c) break;
                continue;
            }
            Mac_shutdown_reason mac_r = mac_shutdown_reasonService.findByKey(mac_shutdown.getProduct_differentiation(),mac_shutdown.getEquipment_name(),mac_shutdown.getShutdown_reason_code());
            String username= (String) httpSession.getAttribute("username");
            mac_shutdown.setShutdown_type(mac_r.getShutdown_type());
            mac_shutdown.setUpdate_oid(username);
            mac_shutdown.setLogin_oid(username);
            mac_shutdown.setUpdate_program("/mac_shutdown/save.do");
            mac_shutdownService.save(mac_shutdown);
            b++;
            if (b == c) break;
        }
    }

    /**
    *@Description: 删除
    *@Author: a135109
    *@time: 2019/12/10 10:55
    */
    @RequestMapping("/delete.do")
    public String delete(int ids[],int sid, RedirectAttributes attr) throws Exception{
        System.out.println(ids);
        if(ids != null && ids.length > 0){
            //1.遍历数组
            for (int id : ids) {
                //2.单条删除
                mac_shutdownService.delete(id);
            }
        }
        attr.addAttribute("id",sid);
        return "redirect:/mac_shutdown/back_find.do";
    }

    /**
    *@Description: 修改
    *@Author: a135109
    *@time: 2019/12/10 10:55
    */
    @RequestMapping("/update.do")
    public String update(HttpServletRequest request, HttpServletResponse response,HttpSession httpSession) throws Exception {
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        int b=0;
        int c=0;
        while (1==1){
            for(String name1 : set){
                String[] vals = (String[]) map.get(name1);
                c=vals.length;
                hashMap.put(name1,vals[b]);
            }
            Mac_shutdown a = new Mac_shutdown();
            System.out.println(hashMap.get("id"));
            int id1 = Integer.parseInt(hashMap.get("id"));
            a=mac_shutdownService.findById(id1);
            try {
                BeanUtils.populate(a,hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            System.out.println(a.toString());
            String username= (String) httpSession.getAttribute("username");
            a.setUpdate_oid(username);
            a.setUpdate_program("/mac_shutdown/update");
            mac_shutdownService.update(a);
            b++;
            if(b==c) break;
        }
        return "redirect:findByName.do";
    }

    /**
    *@Description: 数据验证
    *@Author: a135109
    *@time: 2019/12/9 14:00
    */
    @RequestMapping("/confirm.do")
    public ModelAndView confirm(int id) throws Exception{
        //通过id找到该条数据
        Mac_movement mac_movement = mac_movementService.findById(id);
        //获取该条数据的字段
        String product_differentiation = mac_movement.getProduct_differentiation();
        String equipment_name = mac_movement.getEquipment_name();
        String machine_number = mac_movement.getMachine_number();
        String date = mac_movement.getDate();
        String class_name = mac_movement.getClass_name();
        ModelAndView mv = new ModelAndView();
        mv.setViewName("mac-shutdown-add");
        mv.addObject("product_differentiation",product_differentiation);
        mv.addObject("equipment_name",equipment_name);
        mv.addObject("machine_number",machine_number);
        mv.addObject("date",date);
        mv.addObject("class_name",class_name);
        mv.addObject("id",id);
        return mv;
    }

    /**
    *@Description: 数据返回
    *@Author: a135109
    *@time: 2020/2/21 14:45
    */
    @RequestMapping("/back_find.do")
    public ModelAndView back_find(int id) throws Exception{
        //通过id找到该条数据
        Mac_movement mac_movement = mac_movementService.findById(id);
        //获取该条数据的字段
        String product_differentiation = mac_movement.getProduct_differentiation();
        String equipment_name = mac_movement.getEquipment_name();
        String machine_number = mac_movement.getMachine_number();
        String date = mac_movement.getDate();
        String class_name = mac_movement.getClass_name();
        List<Mac_shutdown> ls = mac_shutdownService.findByName(product_differentiation,equipment_name,machine_number,date,class_name);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("mac-shutdown-list");
        mv.addObject("product_differentiation",product_differentiation);
        mv.addObject("equipment_name",equipment_name);
        mv.addObject("machine_number",machine_number);
        mv.addObject("date",date);
        mv.addObject("class_name",class_name);
        mv.addObject("sid",id);
        mv.addObject("mac_shutdown",ls);
        return mv;
    }

    /**
    *@Description: 验证
    *@Author: a135109
    *@time: 2019/12/21 16:57
    */
    @RequestMapping("/check.do")
    public void check(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception, IOException, JsonGenerationException, JsonMappingException {
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        info.setFlag(true);
        List<String> errorList=new ArrayList<String>();
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        Mac_shutdown mac_shutdown = new Mac_shutdown();
        int b = 0;   //第几笔记录
        int c = 0;   //total
        while (true) {
            //一条数据
            for (String name : set) {
                String[] vals = (String[]) map.get(name);
                c = vals.length;
                hashMap.put(name, vals[b]);
            }
            //hashmap找到对应的对象
            try {
                BeanUtils.populate(mac_shutdown, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            String product_differentiation = mac_shutdown.getProduct_differentiation();
            String equipment_name = mac_shutdown.getEquipment_name();
            String machine_number = mac_shutdown.getMachine_number();
            String date = mac_shutdown.getDate();
            String class_name = mac_shutdown.getClass_name();
            String shutdown_reason_code = mac_shutdown.getShutdown_reason_code();
            //查找是否存在停机原因，不存在返回false
            Mac_shutdown_reason mac_r = mac_shutdown_reasonService.findByKey(product_differentiation,equipment_name,shutdown_reason_code);
            //查找是否存在稼动,不存在返回falsse
            List<Mac_movement> mac_m = mac_movementService.findByKey(product_differentiation,equipment_name,date,class_name,machine_number);
            //查找是否存在停机，存在返回false
            Mac_shutdown mac = mac_shutdownService.findByKey(product_differentiation,equipment_name,machine_number,date,class_name,shutdown_reason_code);
            if (mac_m==null){
                info.setFlag(false);
                String errLine= String.valueOf(b);
                errorList.add("product_differentiation"+errLine);
                errorList.add("equipment_name"+errLine);
                errorList.add("date"+errLine);
                errorList.add("class_name"+errLine);
                errorList.add("machine_number"+errLine);
                info.setErrorMsg("不存在稼动信息");
            }
            else if(mac!=null){
                info.setFlag(false);
                String errLine= String.valueOf(b);
                errorList.add("shutdown_reason_code"+errLine);
                info.setErrorMsg("停机原因代码重复");
            } else if(mac_r==null&&!shutdown_reason_code.equals("")){
                info.setFlag(false);
                String errLine= String.valueOf(b);
                errorList.add("shutdown_reason_code"+errLine);
                info.setErrorMsg("停机原因代码不存在");
            }
            b++;
            if (b==c)break;
        }
        info.setErrorList(errorList);
        // 响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(),info);
    }

    /**
     *@Description: 上载数据
     *@Author: a135109
     *@time: 2020/1/15 10:44
     */
    @RequestMapping("/upload.do")
    public ModelAndView upload(MultipartFile imgFile, HttpServletRequest request) throws Exception{
        UploadUtils uploadUtils = new UploadUtils();
        String filePath = uploadUtils.upload(imgFile,request);
        //导入LoadExcle方法
        String columns[] = {"product_differentiation","equipment_name","date","class_name","machine_number","shutdown_reason_code","shutdown_time"};
        //创建对象
        Mac_shutdown mac_shutdown = new Mac_shutdown();
        //从Excel获取数据列表
        List<Map<String, Object>> list =  ExcelUtils.LoadExcle(filePath,columns);
        //创建新的对象列表
        List<Mac_shutdown> ls = new ArrayList<>();
        //将map转为对象，并存到对象list
        for (Map ma: list) {
            mac_shutdown = ExcelUtils.mapToBean(ma, Mac_shutdown.class);
            if (!mac_shutdown.getProduct_differentiation().equals("")&&!mac_shutdown.getEquipment_name().equals("")&&!mac_shutdown.getDate().equals("")){
                ls.add(mac_shutdown);
            }
        }
        //将获取的数据上载到中间表
        ModelAndView mv = new ModelAndView();
        mv.setViewName("mac-shutdown-upload");
        mv.addObject("mac_shutdown",ls);
        return mv;
    }
}
