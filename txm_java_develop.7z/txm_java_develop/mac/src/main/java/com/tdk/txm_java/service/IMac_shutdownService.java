package com.tdk.txm_java.service;

import com.tdk.txm_java.domain.Mac_shutdown;

import java.util.List;

public interface IMac_shutdownService {

    public List<Mac_shutdown> findAll() throws Exception;

    public Mac_shutdown findById(int id) throws Exception;

    public List<Mac_shutdown> findByName(String product_differentiation,String equipment_name,String machine_number,String date,String class_name) throws Exception;

    public Mac_shutdown findByKey(String product_differentiation,String equipment_name,String machine_number,String date,String class_name,String shutdown_reason_code) throws Exception;

    void save(Mac_shutdown mac_shutdown) throws Exception;

    void update(Mac_shutdown mac_shutdown) throws Exception;

    void delete(int id) throws Exception;
}
