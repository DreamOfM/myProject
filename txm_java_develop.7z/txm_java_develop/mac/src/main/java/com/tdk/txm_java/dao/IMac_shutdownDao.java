package com.tdk.txm_java.dao;


import com.tdk.txm_java.domain.Mac_shutdown;
import org.apache.ibatis.annotations.*;

import java.util.List;

public interface IMac_shutdownDao {

    /**
     *@Description: 查询所有信息
     *@Author: a135109
     *@time: 2019/12/2 16:59
     */
    @Select("select * from mac_shutdown")
    public List<Mac_shutdown> findAll() throws Exception;

    /**
     *@Description: 通过id查找
     *@Author: a135109
     *@time: 2019/12/2 17:00
     */
    @Select("select * from mac_shutdown where id=#{id}")
    public Mac_shutdown findById(int id) throws Exception;
    
    /**
    *@Description: 通过Key值查找
    *@Author: a135109
    *@time: 2019/12/23 11:29
    */
    @Select("select * from mac_shutdown where product_differentiation=#{product_differentiation} and equipment_name=#{equipment_name} and  machine_number=#{machine_number} and date=#{date} and class_name=#{class_name} and shutdown_reason_code=#{shutdown_reason_code}")
    public Mac_shutdown findByKey(@Param("product_differentiation") String product_differentiation,@Param("equipment_name") String equipment_name,@Param("machine_number") String machine_number,@Param("date") String date,@Param("class_name") String class_name,@Param("shutdown_reason_code") String shutdown_reason_code) throws Exception;


    /**
     *@Description: 条件查询
     *@Author: a135109
     *@time: 2019/12/9 11:38
     */
    @Select("select * from mac_shutdown where product_differentiation=#{product_differentiation} and equipment_name=#{equipment_name} and  machine_number=#{machine_number} and date=#{date} and class_name=#{class_name} order by shutdown_reason_code asc")
    public List<Mac_shutdown> findByName(@Param("product_differentiation") String product_differentiation,@Param("equipment_name") String equipment_name,@Param("machine_number") String machine_number,@Param("date") String date,@Param("class_name") String class_name) throws Exception;

    /**
     *@Description: 添加数据
     *@Author: a135109
     *@time: 2019/12/3 8:19
     */
    @Insert("insert into mac_shutdown(date,class_name,product_differentiation,equipment_name,machine_number,shutdown_reason_code,shutdown_type,shutdown_time,machine_type,update_time,update_oid,update_program,login_time,login_oid) values(#{date},#{class_name},#{product_differentiation},#{equipment_name},#{machine_number},#{shutdown_reason_code},#{shutdown_type},#{shutdown_time},#{machine_type},now(),#{update_oid},#{update_program},now(),#{login_oid}) ")
    void save(Mac_shutdown mac_shutdown);

    /**
     *@Description: 通过id更新
     *@Author: a135109
     *@time: 2019/12/3 8:19
     */
    @Update("update mac_shutdown set date=#{date}, class_name=#{class_name}, product_differentiation=#{product_differentiation}, equipment_name=#{equipment_name}, machine_number=#{machine_number}, shutdown_reason_code=#{shutdown_reason_code}, shutdown_type=#{shutdown_type}, shutdown_time=#{shutdown_time}, machine_type=#{machine_type},update_oid=#{update_oid}, update_program=#{update_program} where id =#{id}  ")
    void update(Mac_shutdown mac_shutdown);

    /**
     *@Description: 通过id删除对象
     *@Author: a135109
     *@time: 2019/12/2 17:02
     */
    @Delete("delete from mac_shutdown where id =#{id}  ")
    void delete(int id);

}
