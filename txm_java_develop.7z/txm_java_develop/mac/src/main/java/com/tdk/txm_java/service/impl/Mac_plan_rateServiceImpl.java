package com.tdk.txm_java.service.impl;

import com.tdk.txm_java.dao.IMac_plan_rateDao;
import com.tdk.txm_java.domain.Mac_plan_rate;
import com.tdk.txm_java.service.IMac_plan_rateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class Mac_plan_rateServiceImpl implements IMac_plan_rateService {

    @Autowired
    private IMac_plan_rateDao mac_plan_rateDao;

    @Override
    public List<Mac_plan_rate> findAll() throws Exception {
        return mac_plan_rateDao.findAll();
    }

    @Override
    public List<Mac_plan_rate> findByName(String product_differentiation, String equipment_name, String date) throws Exception {
        return mac_plan_rateDao.findByName(product_differentiation,equipment_name,date);
    }

    @Override
    public Mac_plan_rate findById(int id) throws Exception {
        return mac_plan_rateDao.findById(id);
    }

    @Override
    public void save(Mac_plan_rate mac_plan_rate) throws Exception {
        mac_plan_rateDao.save(mac_plan_rate);
    }

    @Override
    public void update(Mac_plan_rate mac_plan_rate) throws Exception {
        mac_plan_rateDao.update(mac_plan_rate);
    }

    @Override
    public void delete(int id) throws Exception {
        mac_plan_rateDao.delete(id);
    }
    
}
