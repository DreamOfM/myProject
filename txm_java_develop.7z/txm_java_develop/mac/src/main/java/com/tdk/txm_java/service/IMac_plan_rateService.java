package com.tdk.txm_java.service;


import com.tdk.txm_java.domain.Mac_plan_rate;

import java.util.List;

public interface IMac_plan_rateService {

    public List<Mac_plan_rate> findAll() throws Exception;

    public List<Mac_plan_rate> findByName(String product_differentiation, String equipment_name, String date) throws Exception;

    public Mac_plan_rate findById(int id) throws Exception;

    void save(Mac_plan_rate mac_plan_rate) throws Exception;

    void update(Mac_plan_rate mac_plan_rate) throws Exception;

    void delete(int id) throws Exception;
}
