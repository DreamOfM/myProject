package com.tdk.txm_java.dao;

import com.tdk.txm_java.domain.Mac_shutdown_reason;
import org.apache.ibatis.annotations.*;

import java.util.List;

public interface IMac_shutdown_reasonDao {

    /**
     *@Description: 查询所有信息
     *@Author: a135109
     *@time: 2019/12/2 16:59
     */
    @Select("select * from mac_shutdown_reason")
    public List<Mac_shutdown_reason> findAll() throws Exception;

    /**
    *@Description: 通过key值查找
    *@Author: a135109
    *@time: 2019/12/21 17:10
    */
    @Select("select * from mac_shutdown_reason where product_differentiation=#{product_differentiation} and equipment_name=#{equipment_name} and shutdown_reason_code=#{shutdown_reason_code}")
    public Mac_shutdown_reason findByKey(@Param("product_differentiation") String product_differentiation,@Param("equipment_name") String equipment_name,@Param("shutdown_reason_code") String shutdown_reason_code) throws Exception;

    /**
     *@Description: 通过id查找
     *@Author: a135109
     *@time: 2019/12/2 17:00
     */
    @Select("select * from mac_shutdown_reason where id=#{id}")
    public Mac_shutdown_reason findById(int id) throws Exception;

    /**
     *@Description: 通过设备名查找
     *@Author: a135109
     *@time: 2019/12/4 14:46
     */
    @Select("select * from mac_shutdown_reason where product_differentiation=#{product_differentiation} and equipment_name=#{equipment_name} order by shutdown_reason_code asc")
    public List<Mac_shutdown_reason> findByName(@Param("product_differentiation") String product_differentiation,@Param("equipment_name") String equipment_name) throws Exception;

    /**
     *@Description: 添加数据
     *@Author: a135109
     *@time: 2019/12/3 8:19
     */
    @Insert("insert into mac_shutdown_reason(product_differentiation,equipment_name,shutdown_reason_code,shutdown_type,shutdown_description,update_time,update_oid,update_program,login_time,login_oid) values(#{product_differentiation},#{equipment_name},#{shutdown_reason_code},#{shutdown_type},#{shutdown_description},now(),#{update_oid},#{update_program},now(),#{login_oid}) ")
    void save(Mac_shutdown_reason mac_shutdown_reason);

    /**
     *@Description: 通过id更新
     *@Author: a135109
     *@time: 2019/12/3 8:19
     */
    @Update("update mac_shutdown_reason set product_differentiation=#{product_differentiation}, equipment_name=#{equipment_name}, shutdown_reason_code=#{shutdown_reason_code}, shutdown_type=#{shutdown_type}, shutdown_description=#{shutdown_description},update_oid=#{update_oid}, update_program=#{update_program} where id =#{id}  ")
    void update(Mac_shutdown_reason mac_shutdown_reason);

    /**
     *@Description: 通过id删除对象
     *@Author: a135109
     *@time: 2019/12/2 17:02
     */
    @Delete("delete from mac_shutdown_reason where id =#{id}  ")
    void delete(int id);
}
