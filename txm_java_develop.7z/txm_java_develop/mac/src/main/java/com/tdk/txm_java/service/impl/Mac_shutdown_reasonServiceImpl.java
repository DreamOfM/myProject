package com.tdk.txm_java.service.impl;


import com.tdk.txm_java.dao.IMac_shutdown_reasonDao;
import com.tdk.txm_java.domain.Mac_shutdown_reason;
import com.tdk.txm_java.service.IMac_shutdown_reasonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class Mac_shutdown_reasonServiceImpl implements IMac_shutdown_reasonService {

    @Autowired
    private IMac_shutdown_reasonDao mac_shutdown_reasonDao;

    @Override
    public List<Mac_shutdown_reason> findAll() throws Exception {
        return mac_shutdown_reasonDao.findAll();
    }

    @Override
    public List<Mac_shutdown_reason> findByName(String product_differentiation,String equipment_name) throws Exception {
        return mac_shutdown_reasonDao.findByName(product_differentiation,equipment_name);
    }

    @Override
    public Mac_shutdown_reason findByKey(String product_differentiation,String equipment_name,String shutdown_reason_code) throws Exception {
        return mac_shutdown_reasonDao.findByKey(product_differentiation,equipment_name,shutdown_reason_code);
    }

    @Override
    public Mac_shutdown_reason findById(int id) throws Exception {
        return mac_shutdown_reasonDao.findById(id);
    }

    @Override
    public void save(Mac_shutdown_reason mac_shutdown_reason) throws Exception {
        mac_shutdown_reason.setEquipment_name(mac_shutdown_reason.getEquipment_name().toUpperCase());
        mac_shutdown_reason.setProduct_differentiation(mac_shutdown_reason.getProduct_differentiation().toUpperCase());
        mac_shutdown_reason.setShutdown_reason_code(mac_shutdown_reason.getShutdown_reason_code().toUpperCase());
        mac_shutdown_reason.setShutdown_type(mac_shutdown_reason.getShutdown_type().toUpperCase());
        mac_shutdown_reasonDao.save(mac_shutdown_reason);
    }

    @Override
    public void update(Mac_shutdown_reason mac_shutdown_reason) throws Exception {
        mac_shutdown_reasonDao.update(mac_shutdown_reason);
    }

    @Override
    public void delete(int id) throws Exception {
        mac_shutdown_reasonDao.delete(id);
    }
}
