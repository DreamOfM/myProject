package com.tdk.txm_java.service;


import com.tdk.txm_java.domain.Mac_movement;

import java.util.List;

public interface IMac_movementService {

    public List<Mac_movement> findAll() throws Exception;

    public Mac_movement findById(int id) throws Exception;

    public List<Mac_movement> findByKey(String product_differentiation,String equipment_name,String date,String class_name,String machine_number) throws Exception;

    public List<Mac_movement> findByName(String product_differentiation,String equipment_name,String date,String class_name) throws Exception;

    void save(Mac_movement mac_movement) throws Exception;

    void update(Mac_movement mac_movement) throws Exception;

    void delete(int id) throws Exception;
    
}
