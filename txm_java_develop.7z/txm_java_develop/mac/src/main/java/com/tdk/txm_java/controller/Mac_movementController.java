package com.tdk.txm_java.controller;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tdk.txm_java.domain.Mac_movement;
import com.tdk.txm_java.domain.Mac_shutdown;
import com.tdk.txm_java.domain.Mac_shutdown_reason;
import com.tdk.txm_java.domain.ResultInfo;
import com.tdk.txm_java.service.IMac_movementService;
import com.tdk.txm_java.service.IMac_shutdownService;
import com.tdk.txm_java.service.IMac_shutdown_reasonService;
import com.tdk.txm_java.utils.ExcelUtils;
import com.tdk.txm_java.utils.UploadUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

import static com.tdk.txm_java.utils.ExcelUtils.beanToMap;
import static com.tdk.txm_java.utils.ExcelUtils.outExcel;

@Controller
@RequestMapping("/mac_movement")
public class Mac_movementController {

    @Autowired
    private IMac_movementService mac_movementService;
    @Autowired
    private IMac_shutdown_reasonService mac_shutdown_reasonService;
    @Autowired
    private IMac_shutdownService mac_shutdownService;

    /**
     *@Description: 通过输入信息查询
     *@Author: a135109
     *@time: 2019/12/4 14:41
     */
    @RequestMapping("/findByName")
    public ModelAndView findByName(String product_differentiation,String equipment_name,String date,String class_name) throws Exception {
        List<Mac_movement> ls = mac_movementService.findByName(product_differentiation,equipment_name,date,class_name);
        //List<Mac_movement> ls = mac_movementService.findAll();
//        List<Map<String,Object>> list = new ArrayList<>();
//        for (Mac_movement mac:ls) {
//            list.add(beanToMap(mac));
//        }
//        System.out.println(list+"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
//        String[] head = {"product_differentiation","equipment_name","date","class_name","machine_number","work_time"};
//        String filePath = outExcel("mac_movement",head,head,list,1);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("mac-movement-list");
        mv.addObject("mac_movement", ls);
        mv.addObject("product_differentiation",product_differentiation);
        mv.addObject("equipment_name",equipment_name);
        mv.addObject("date",date);
        mv.addObject("class_name",class_name);
       // mv.addObject("filePath",filePath);
        return mv;
    }

    /**
    *@Description: 更新
    *@Author: a135109
    *@time: 2019/12/6 15:06
    */
    @RequestMapping("/update")
    public String update(HttpServletRequest request, HttpServletResponse response,HttpSession httpSession) throws Exception {
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        int b=0;
        int c=0;
        while (1==1){
            for(String name1 : set){
                String[] vals = (String[]) map.get(name1);
                c=vals.length;
                hashMap.put(name1,vals[b]);
            }
            Mac_movement a = new Mac_movement();
            System.out.println(hashMap.get("id"));
            int id1 = Integer.parseInt(hashMap.get("id"));
            a=mac_movementService.findById(id1);
            try {
                BeanUtils.populate(a,hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            System.out.println(a.toString());
            String username= (String) httpSession.getAttribute("username");
            a.setUpdate_oid(username);
            a.setUpdate_program("/update.do");
            mac_movementService.update(a);
            b++;
            if(b==c) break;
        }
        return "redirect:findByName.do";
    }

    /**
    *@Description: 删除移动信息
    *@Author: a135109
    *@time: 2019/12/6 15:34
    */
    @RequestMapping("/delete.do")
    public String delete(int ids[],String product_differentiation,String equipment_name,String date,String class_name, RedirectAttributes attr) throws Exception{
        System.out.println(ids);
        if(ids != null && ids.length > 0){
            //1.遍历数组
            for (int id : ids) {
                //2.若不存在其他相同稼动，则删除关联停机原因
                Mac_movement mac_movement = mac_movementService.findById(id);
                String machine_number = mac_movement.getMachine_number();
                List<Mac_movement> ls_m = mac_movementService.findByKey(product_differentiation,equipment_name,date,class_name,machine_number);
                if (ls_m.size()==1){
                    List<Mac_shutdown> ls = mac_shutdownService.findByName(product_differentiation,equipment_name,machine_number,date,class_name);
                    for (Mac_shutdown mac_shutdown:ls) {
                        mac_shutdownService.delete(mac_shutdown.getId());
                    }
                }
                //3.单条删除
                mac_movementService.delete(id);
            }
        }
        //传递条件
        attr.addAttribute("product_differentiation",product_differentiation);
        attr.addAttribute("equipment_name",equipment_name);
        attr.addAttribute("date",date);
        attr.addAttribute("class_name",class_name);
        return "redirect:findByName.do";
    }

    /**
     *@Description: 新增设备信息
     *@Author: a135109
     *@time: 2019/12/4 11:57
     */
    @RequestMapping("/save.do")
    public String save(HttpServletRequest request, HttpServletResponse response,HttpSession httpSession) throws Exception {
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        List<String> errorList=new ArrayList<String>();
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        Mac_movement mac_movement = new Mac_movement();

        while (1 == 1) {
            for (String name : set) {
                String[] vals = (String[]) map.get(name);
                c = vals.length;
                if(b<c) {
                    hashMap.put(name, vals[b]);
                }
            }
            try {
                BeanUtils.populate(mac_movement, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //添加一个判断，如果为空值或者没有输入则不往数据库里插数据
            if (null==mac_movement.getMachine_number()||mac_movement.getMachine_number().equals(null) || mac_movement.getMachine_number().equals("")) {
                b++;
                if (b == c) break;
                continue;
            }
            String username= (String) httpSession.getAttribute("username");
            mac_movement.setUpdate_oid(username);
            mac_movement.setUpdate_program("/mac_movement/save.do");
            mac_movement.setLogin_oid(username);
            mac_movementService.save(mac_movement);
            b++;
            if (b == c) break;
        }
        return "redirect:findByName.do";
    }

   /**
   *@Description: 验证
   *@Author: a135109
   *@time: 2019/12/19 14:00
   */
    @RequestMapping("/check.do")
    public void check(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception, IOException, JsonGenerationException, JsonMappingException {
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        info.setFlag(true);
        List<String> errorList=new ArrayList<String>();
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        Mac_movement mac_movement = new Mac_movement();
        int b = 0;   //第几笔记录
        int c = 0;   //total
        while (true) {
            //一条数据
            for (String name : set) {
                String[] vals = (String[]) map.get(name);
                c = vals.length;
                hashMap.put(name, vals[b]);
            }
            //hashmap找到对应的对象
            try {
                BeanUtils.populate(mac_movement, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //查找存在的对象
            String product_differentiation = mac_movement.getProduct_differentiation();
            String equipment_name = mac_movement.getEquipment_name();
            String date = mac_movement.getDate();
            String class_name= mac_movement.getClass_name();
            String machine_number= mac_movement.getMachine_number();
            //校验停机原因主档
            List<Mac_shutdown_reason> mac_r = mac_shutdown_reasonService.findByName(product_differentiation, equipment_name);
            //校验稼动是否存在
//            Mac_movement mac = mac_movementService.findByKey(product_differentiation,equipment_name,date,class_name,machine_number);
            //停机原因主档为空或者存在稼动，报错
            if (mac_r.isEmpty()) {
                info.setFlag(false);
                String errLine = String.valueOf(b);
                errorList.add("product_differentiation" + errLine);
                errorList.add("equipment_name" + errLine);
                info.setErrorMsg("设备不存在");
            }
//                else if (mac!=null){
//                info.setFlag(false);
//                String errLine= String.valueOf(b);
//                errorList.add("machine_number"+errLine);
//                info.setErrorMsg("机台号码已存在");
//            }
            b++;
            if (b==c)break;
        }
        info.setErrorList(errorList);
        info.getErrorMsg();
        // 响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(),info);
    }

    /**
     *@Description: 数据传到新增页面
     *@Author: a135109
     *@time: 2019/12/5 15:41
     */
    @RequestMapping("/confirm.do")
    public ModelAndView confirm(String product_differentiation,String equipment_name,String date,String class_name){
        ModelAndView mv = new ModelAndView();
        mv.setViewName("mac-movement-add");
        mv.addObject("product_differentiation",product_differentiation);
        mv.addObject("equipment_name",equipment_name);
        mv.addObject("date",date);
        mv.addObject("class_name",class_name);
        return mv;
    }

    /**
    *@Description: 验证是否存在
    *@Author: a135109
    *@time: 2019/12/19 10:24
    */
    @RequestMapping("/checkName.do" )
    public void checkName(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        //1.获取信息
        String product_differentiation = request.getParameter("product_differentiation");
        String equipment_name = request.getParameter("equipment_name");
        //2.调用service层判断是否存在
        List<Mac_shutdown_reason> mac = mac_shutdown_reasonService.findByName(product_differentiation, equipment_name);
        if (mac.isEmpty()) {
            info.setErrorMsg("设备不存在");
            info.setFlag(false);
        }else {
            info.setFlag(true);
        }
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(),info);
    }

    /**
    *@Description: 设备停机主档
    *@Author: a135109
    *@time: 2019/12/19 15:57
    */
    @RequestMapping("/shutdown.do")
    public ModelAndView shutdown(int id) throws Exception{
        System.out.println(id);
        //通过id找到该条数据
        Mac_movement mac_movement = mac_movementService.findById(id);
        //获取该条数据的字段
        String product_differentiation = mac_movement.getProduct_differentiation();
        String equipment_name = mac_movement.getEquipment_name();
        String machine_number = mac_movement.getMachine_number();
        String date = mac_movement.getDate();
        String class_name = mac_movement.getClass_name();
        List<Mac_shutdown> ls = mac_shutdownService.findByName(product_differentiation,equipment_name,machine_number,date,class_name);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("mac-shutdown-list");
        mv.addObject("product_differentiation",product_differentiation);
        mv.addObject("equipment_name",equipment_name);
        mv.addObject("machine_number",machine_number);
        mv.addObject("date",date);
        mv.addObject("class_name",class_name);
        mv.addObject("sid",id);
        mv.addObject("mac_shutdown",ls);
        return mv;
    }

  /**
  *@Description: 上载数据
  *@Author: a135109
  *@time: 2020/1/15 10:44
  */
    @RequestMapping("/upload.do")
    public ModelAndView upload(MultipartFile imgFile, HttpServletRequest request) throws Exception{
        UploadUtils uploadUtils = new UploadUtils();
        String filePath = uploadUtils.upload(imgFile,request);
        //导入LoadExcle方法
        String columns[] = {"product_differentiation","equipment_name","date","class_name","machine_number","work_time","unittime_product_num","input_quantity","nondefective_quantity","operate_id","security_id"};
        //创建对象
        Mac_movement mac_movement = new Mac_movement();
        //从Excel获取数据列表
        List<Map<String, Object>> list =  ExcelUtils.LoadExcle(filePath,columns);
        //创建新的对象列表
        List<Mac_movement> ls = new ArrayList<>();
        //将map转为对象，并存到对象list
        for (Map ma: list) {
            mac_movement = ExcelUtils.mapToBean(ma, Mac_movement.class);
            if (!mac_movement.getProduct_differentiation().equals("")&&!mac_movement.getEquipment_name().equals("")&&!mac_movement.getDate().equals("")){
                ls.add(mac_movement);
            }
        }
        ModelAndView mv = new ModelAndView();
        mv.setViewName("mac-movement-upload");
        mv.addObject("mac_movement",ls);
        return mv;
    }

    //导出EXCEL
    @RequestMapping("/download.do")
    public ModelAndView download(String product_differentiation,String equipment_name,String date,String class_name,MultipartFile imgFile) throws Exception {
        //List<Mac_movement> ls = mac_movementService.findByName(product_differentiation,equipment_name,date,class_name);
        System.out.println(imgFile);
        List<Mac_movement> ls = mac_movementService.findAll();
        List<Map<String,Object>> list = new ArrayList<>();
        for (Mac_movement mac:ls) {
            list.add(beanToMap(mac));
        }
        System.out.println(list+"xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        String[] head = {"product_differentiation","equipment_name","date","class_name","machine_number","work_time"};
        String filePath = outExcel("mac_movement",head,head,list,1);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("mac-movement-list");
        mv.addObject("mac_movement", ls);
        mv.addObject("product_differentiation",product_differentiation);
        mv.addObject("equipment_name",equipment_name);
        mv.addObject("date",date);
        mv.addObject("class_name",class_name);
        return mv;
    }

}
