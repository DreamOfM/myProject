package com.tdk.txm_java.service.impl;

import com.tdk.txm_java.dao.IMac_movementDao;
import com.tdk.txm_java.domain.Mac_movement;
import com.tdk.txm_java.service.IMac_movementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class Mac_movementServiceImpl implements IMac_movementService {

    @Autowired
    private IMac_movementDao mac_movementDao;

    @Override
    public List<Mac_movement> findAll() throws Exception {
        return mac_movementDao.findAll();
    }

    @Override
    public Mac_movement findById(int id) throws Exception {
        return mac_movementDao.findById(id);
    }

    @Override
    public List<Mac_movement> findByKey(String product_differentiation, String equipment_name, String date, String class_name, String machine_number) throws Exception {
        return mac_movementDao.findByKey(product_differentiation,equipment_name,date,class_name,machine_number);
    }

    @Override
    public List<Mac_movement> findByName(String product_differentiation, String equipment_name, String date, String class_name) throws Exception {
        return mac_movementDao.findByName(product_differentiation,equipment_name,date,class_name);
    }

    @Override
    public void save(Mac_movement mac_movement) throws Exception {
        mac_movement.setEquipment_name(mac_movement.getEquipment_name().toUpperCase());
        mac_movement.setProduct_differentiation(mac_movement.getProduct_differentiation().toUpperCase());
        mac_movement.setClass_name(mac_movement.getClass_name().toUpperCase());
        mac_movement.setMachine_number(mac_movement.getMachine_number().toUpperCase());
        mac_movementDao.save(mac_movement);
    }

    @Override
    public void update(Mac_movement mac_movement) throws Exception {
        mac_movementDao.update(mac_movement);
    }

    @Override
    public void delete(int id) throws Exception {
        mac_movementDao.delete(id);
    }
    
}
