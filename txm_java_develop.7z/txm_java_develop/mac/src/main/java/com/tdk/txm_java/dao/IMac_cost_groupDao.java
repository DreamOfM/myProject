package com.tdk.txm_java.dao;

import com.tdk.txm_java.domain.Mac_cost_group;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface IMac_cost_groupDao {

    /**
    *@Description: 查询所有信息
    *@Author: a135109
    *@time: 2019/12/2 16:59
    */
    @Select("select * from mac_cost_group")
    public List<Mac_cost_group> findAll() throws Exception;

    /**
    *@Description: 条件查询
    *@Author: a135109
    *@time: 2019/12/10 14:32
    */
    @Select("select * from mac_cost_group where product_differentiation=#{product_differentiation} and equipment_name=#{equipment_name} and machine_number=#{machine_number} ")
    public Mac_cost_group findByName(@Param("product_differentiation") String product_differentiation, @Param("equipment_name") String equipment_name,@Param("machine_number") String machine_number) throws Exception;

    /**
    *@Description: 通过id查找
    *@Author: a135109
    *@time: 2019/12/2 17:00
    */
    @Select("select * from mac_cost_group where id=#{id}")
    public Mac_cost_group findById(int id) throws Exception;

    /**
    *@Description: 添加数据
    *@Author: a135109
    *@time: 2019/12/3 8:19
    */
    @Insert("insert into mac_cost_group(product_differentiation,equipment_name,machine_number,cost_group,update_time,update_oid,update_program,login_time,login_oid) values(#{product_differentiation},#{equipment_name},#{machine_number},#{cost_group},now(),#{update_oid},#{update_program},now(),#{login_oid}) ")
    void save(Mac_cost_group mac_cost_group);

    /**
    *@Description: 通过id更新
    *@Author: a135109
    *@time: 2019/12/3 8:19
    */
    @Update("update mac_cost_group set  product_differentiation=#{product_differentiation}, equipment_name=#{equipment_name}, machine_number=#{machine_number}, cost_group=#{cost_group},update_oid=#{update_oid}, update_program=#{update_program} where id=#{id}  ")
    void update(Mac_cost_group mac_cost_group);

    /**
    *@Description: 通过id删除对象
    *@Author: a135109
    *@time: 2019/12/2 17:02
    */
    @Delete("delete from mac_cost_group where id =#{id}  ")
    void delete(int id);
}
