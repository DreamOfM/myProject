package com.tdk.txm_java.service.impl;

import com.tdk.txm_java.dao.IMac_equipmentDao;
import com.tdk.txm_java.domain.Mac_equipment;
import com.tdk.txm_java.service.IMac_equipmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class Mac_equipmentServiceImpl implements IMac_equipmentService {

    @Autowired
    private IMac_equipmentDao mac_equipmentDao;

    @Override
    public List<Mac_equipment> findAll() throws Exception {
        return mac_equipmentDao.findAll();
    }

    @Override
    public List<Mac_equipment> findByName(String equipment_name) throws Exception {
        return mac_equipmentDao.findByName(equipment_name);
    }

    @Override
    public Mac_equipment findByKey(String equipment_name) throws Exception {
        return mac_equipmentDao.findByKey(equipment_name);
    }

    @Override
    public Mac_equipment findById(int id) throws Exception {
        return mac_equipmentDao.findById(id);
    }

    @Override
    public void save(Mac_equipment mac_equipment) throws Exception {
        mac_equipment.setEquipment_name(mac_equipment.getEquipment_name().toUpperCase());
        mac_equipmentDao.save(mac_equipment);
    }

    @Override
    public void update(Mac_equipment mac_equipment) throws Exception {
        mac_equipmentDao.update(mac_equipment);
    }

    @Override
    public void delete(int id) throws Exception {
        mac_equipmentDao.delete(id);
    }
    
}
