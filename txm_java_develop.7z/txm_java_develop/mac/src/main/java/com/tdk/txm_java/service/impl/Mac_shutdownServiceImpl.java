package com.tdk.txm_java.service.impl;

import com.tdk.txm_java.dao.IMac_shutdownDao;
import com.tdk.txm_java.domain.Mac_shutdown;
import com.tdk.txm_java.service.IMac_shutdownService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class Mac_shutdownServiceImpl implements IMac_shutdownService {

    @Autowired
    private IMac_shutdownDao mac_shutdownDao;

    @Override
    public List<Mac_shutdown> findAll() throws Exception {
        return mac_shutdownDao.findAll();
    }

    @Override
    public Mac_shutdown findById(int id) throws Exception {
        return mac_shutdownDao.findById(id);
    }

    @Override
    public List<Mac_shutdown> findByName(String product_differentiation, String equipment_name, String machine_number, String date, String class_name) throws Exception {
        return mac_shutdownDao.findByName(product_differentiation,equipment_name,machine_number,date,class_name);
    }

    @Override
    public Mac_shutdown findByKey(String product_differentiation, String equipment_name, String machine_number, String date, String class_name, String shutdown_reason_code) throws Exception {
        return mac_shutdownDao.findByKey(product_differentiation,equipment_name,machine_number,date,class_name,shutdown_reason_code);
    }

    @Override
    public void save(Mac_shutdown mac_shutdown) throws Exception {
        mac_shutdown.setEquipment_name(mac_shutdown.getEquipment_name().toUpperCase());
        mac_shutdown.setProduct_differentiation(mac_shutdown.getProduct_differentiation().toUpperCase());
        mac_shutdown.setClass_name(mac_shutdown.getClass_name().toUpperCase());
        mac_shutdown.setMachine_number(mac_shutdown.getMachine_number().toUpperCase());
        mac_shutdown.setShutdown_reason_code(mac_shutdown.getShutdown_reason_code().toUpperCase());
        mac_shutdownDao.save(mac_shutdown);
    }

    @Override
    public void update(Mac_shutdown mac_shutdown) throws Exception {
        mac_shutdownDao.update(mac_shutdown);
    }

    @Override
    public void delete(int id) throws Exception {
        mac_shutdownDao.delete(id);
    }
    
}
