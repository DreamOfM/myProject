package com.tdk.txm_java.service.impl;

import com.tdk.txm_java.dao.IMac_cost_groupDao;
import com.tdk.txm_java.domain.Mac_cost_group;
import com.tdk.txm_java.service.IMac_cost_groupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class Mac_cost_groupServiceImpl implements IMac_cost_groupService {

    @Autowired
    private IMac_cost_groupDao mac_cost_groupDao;

    @Override
    public List<Mac_cost_group> findAll() throws Exception {
        return mac_cost_groupDao.findAll();
    }

    @Override
    public Mac_cost_group findByName(String product_differentiation, String equipment_name, String machine_number) throws Exception {
        return mac_cost_groupDao.findByName(product_differentiation,equipment_name,machine_number);
    }

    @Override
    public Mac_cost_group findById(int id) throws Exception {
        return mac_cost_groupDao.findById(id);
    }

    @Override
    public void save(Mac_cost_group mac_cost_group) throws Exception {
        mac_cost_groupDao.save(mac_cost_group);
    }

    @Override
    public void update(Mac_cost_group mac_cost_group) throws Exception {
        mac_cost_groupDao.update(mac_cost_group);
    }

    @Override
    public void delete(int id) throws Exception {
        mac_cost_groupDao.delete(id);
    }
    
}
