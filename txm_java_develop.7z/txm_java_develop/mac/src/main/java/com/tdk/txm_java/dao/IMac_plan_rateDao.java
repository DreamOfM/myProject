package com.tdk.txm_java.dao;

import com.tdk.txm_java.domain.Mac_plan_rate;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IMac_plan_rateDao {

    /**
    *@Description: 查询所有信息
    *@Author: a135109
    *@time: 2019/12/2 16:59
    */
    @Select("select * from mac_plan_rate")
    public List<Mac_plan_rate> findAll() throws Exception;

    /**
    *@Description: 条件查询
    *@Author: a135109
    *@time: 2019/12/10 14:32
    */
    @Select("select * from mac_plan_rate where " +
            "product_differentiation=(case #{product_differentiation} when '' then product_differentiation else #{product_differentiation} end) " +
            "and equipment_name=(case #{equipment_name} when '' then equipment_name else #{equipment_name} end) " +
            "and date=(case #{date} when '' then date else #{date} end) ")
    public List<Mac_plan_rate> findByName(@Param("product_differentiation") String product_differentiation, @Param("equipment_name") String equipment_name, @Param("date") String date) throws Exception;

    /**
    *@Description: 通过id查找
    *@Author: a135109
    *@time: 2019/12/2 17:00
    */
    @Select("select * from mac_plan_rate where id=#{id}")
    public Mac_plan_rate findById(int id) throws Exception;

    /**
    *@Description: 添加数据
    *@Author: a135109
    *@time: 2019/12/3 8:19
    */
    @Insert("insert into mac_plan_rate(product_differentiation,equipment_name,date,plan_rate,update_time,update_oid,update_program,login_time,login_oid) values(#{product_differentiation},#{equipment_name},#{date},#{plan_rate},now(),#{update_oid},#{update_program},now(),#{login_oid}) ")
    void save(Mac_plan_rate mac_plan_rate);

    /**
    *@Description: 通过id更新
    *@Author: a135109
    *@time: 2019/12/3 8:19
    */
    @Update("update mac_plan_rate set  product_differentiation=#{product_differentiation}, equipment_name=#{equipment_name}, date=#{date}, plan_rate=#{plan_rate},update_oid=#{update_oid}, update_program=#{update_program} where id=#{id}  ")
    void update(Mac_plan_rate mac_plan_rate);

    /**
    *@Description: 通过id删除对象
    *@Author: a135109
    *@time: 2019/12/2 17:02
    */
    @Delete("delete from mac_plan_rate where id =#{id}  ")
    void delete(int id);
}
