package com.tdk.txm_java.service;


import com.tdk.txm_java.domain.Mac_cost_group;

import java.util.List;

public interface IMac_cost_groupService {

    public List<Mac_cost_group> findAll() throws Exception;

    public Mac_cost_group findByName(String product_differentiation,String equipment_name,String machine_number) throws Exception;

    public Mac_cost_group findById(int id) throws Exception;

    void save(Mac_cost_group mac_cost_group) throws Exception;

    void update(Mac_cost_group mac_cost_group) throws Exception;

    void delete(int id) throws Exception;
}
