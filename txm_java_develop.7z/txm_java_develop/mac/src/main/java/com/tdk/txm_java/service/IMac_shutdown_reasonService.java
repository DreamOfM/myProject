package com.tdk.txm_java.service;

import com.tdk.txm_java.domain.Mac_shutdown_reason;

import java.util.List;

public interface IMac_shutdown_reasonService {

    public List<Mac_shutdown_reason> findAll() throws Exception;

    public List<Mac_shutdown_reason> findByName(String product_differentiation,String equipment_name) throws Exception;

    public Mac_shutdown_reason findByKey(String product_differentiation,String equipment_name,String shutdown_reason_code) throws Exception;

    public Mac_shutdown_reason findById(int id) throws Exception;

    void save(Mac_shutdown_reason mac_shutdown_reason) throws Exception;

    void update(Mac_shutdown_reason mac_shutdown_reason) throws Exception;

    void delete(int id) throws Exception;

}

