package com.tdk.txm_java.service;

import com.tdk.txm_java.domain.Mac_equipment;

import java.util.List;

public interface IMac_equipmentService {

    public List<Mac_equipment> findAll() throws Exception;

    public List<Mac_equipment> findByName(String equipment_name) throws Exception;

    public Mac_equipment findByKey(String equipment_name) throws Exception;

    public Mac_equipment findById(int id) throws Exception;

    void save(Mac_equipment mac_equipment) throws Exception;

    void update(Mac_equipment mac_equipment) throws Exception;

    void delete(int id) throws Exception;
    
}
