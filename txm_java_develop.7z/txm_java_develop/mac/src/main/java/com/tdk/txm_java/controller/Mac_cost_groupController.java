package com.tdk.txm_java.controller;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.tdk.txm_java.domain.Mac_cost_group;
import com.tdk.txm_java.domain.ResultInfo;
import com.tdk.txm_java.service.IMac_cost_groupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/mac_cost_group")

public class Mac_cost_groupController {
    @Autowired
    private IMac_cost_groupService mac_cost_groupService;

    /**
     * @Description: 条件查询
     * @Author: a135109
     * @time: 2019/12/10 14:23
     */
    @RequestMapping("/findByName")
    public ModelAndView findByName(String product_differentiation, String equipment_name, String machine_number) throws Exception {
        Mac_cost_group mac_cost_group = mac_cost_groupService.findByName(product_differentiation, equipment_name, machine_number);
        System.out.println("ssss" + mac_cost_group);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("mac-cost-group");
        mv.addObject("mac_cost_group", mac_cost_group);
        return mv;
    }

    /**
     * @Description: 添加数据
     * @Author: a135109
     * @time: 2019/12/10 15:41
     */
    @RequestMapping("/save.do")
    public String save(Mac_cost_group mac_cost_group,HttpSession httpSession) throws Exception {
        String username= (String) httpSession.getAttribute("username");
        mac_cost_group.setUpdate_oid(username);
        mac_cost_group.setLogin_oid(username);
        mac_cost_group.setUpdate_program("/mac_cost_group/save.do");
        mac_cost_groupService.save(mac_cost_group);
        return "redirect:findByName.do";
    }

    /**
     * @Description: 更新数据
     * @Author: a135109
     * @time: 2019/12/10 16:26
     */
    @RequestMapping("/update.do")
    public void update(HttpServletRequest request, HttpServletResponse response,HttpSession httpSession) throws Exception {
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        //1.获取信息
        int id = Integer.parseInt(request.getParameter("id"));
        String cost_group = request.getParameter("cost_group");
        String username=(String) httpSession.getAttribute("username");
        //2.调用service层判断是否存在
        Mac_cost_group mac = mac_cost_groupService.findById(id);
        //修改对象
        mac.setCost_group(cost_group);
        mac.setUpdate_oid(username);
        mac.setUpdate_program("/mac_cost_group/update");
        mac_cost_groupService.update(mac);
        // 响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        info.setFlag(true);
        mapper.writeValue(response.getOutputStream(),info);
    }

    /**
     * @Description: 删除数据
     * @Author: a135109
     * @time: 2019/12/10 16:26
     */
    @RequestMapping("/delete.do")
    public String delete(int id) throws Exception {
        System.out.println(id + "ddd");
        mac_cost_groupService.delete(id);
        return "redirect:findByName.do";
    }

    /**
     * @Description: 验证
     * @Author: a135109
     * @time: 2019/12/11 14:37
     */
    @RequestMapping(value="/checkName.do" )
    protected void mac_cost_group(HttpServletRequest request, HttpServletResponse response) throws Exception {
        //1.获取信息
        String product_differentiation = request.getParameter("product_differentiation");
        String equipment_name = request.getParameter("equipment_name");
        String machine_number = request.getParameter("machine_number");
        //2.调用service层判断是否存在
        Mac_cost_group mac = mac_cost_groupService.findByName(product_differentiation, equipment_name, machine_number);
        response.setContentType("application/json;charset=utf-8");
        if (mac == null) {
            response.getWriter().write("true");
        } else {
            response.getWriter().write("false");
        }
    }
}

