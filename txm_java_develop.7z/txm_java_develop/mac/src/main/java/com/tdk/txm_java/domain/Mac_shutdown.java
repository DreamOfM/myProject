package com.tdk.txm_java.domain;


public class Mac_shutdown {

    private int id;
    private String date; //日期
    private String class_name; //班别
    private String product_differentiation; //製品區分
    private String equipment_name; //工程設備名
    private String machine_number; //機台號碼
    private String shutdown_reason_code; //停機原因代碼
    private String shutdown_type; //停機型態
    private Double shutdown_time; //停机时间
    private String machine_type; //機台歸類
    private String login_time;//登录时间
    private String login_oid;//登录人员
    private String update_time;//更新时间
    private String update_oid;//更新人员
    private String update_program;//更新程序

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getClass_name() {
        return class_name;
    }

    public void setClass_name(String class_name) {
        this.class_name = class_name;
    }

    public String getProduct_differentiation() {
        return product_differentiation;
    }

    public void setProduct_differentiation(String product_differentiation) {
        this.product_differentiation = product_differentiation;
    }

    public String getEquipment_name() {
        return equipment_name;
    }

    public void setEquipment_name(String equipment_name) {
        this.equipment_name = equipment_name;
    }

    public String getMachine_number() {
        return machine_number;
    }

    public void setMachine_number(String machine_number) {
        this.machine_number = machine_number;
    }

    public String getShutdown_reason_code() {
        return shutdown_reason_code;
    }

    public void setShutdown_reason_code(String shutdown_reason_code) {
        this.shutdown_reason_code = shutdown_reason_code;
    }

    public String getShutdown_type() {
        return shutdown_type;
    }

    public void setShutdown_type(String shutdown_type) {
        this.shutdown_type = shutdown_type;
    }

    public Double getShutdown_time() {
        return shutdown_time;
    }

    public void setShutdown_time(Double shutdown_time) {
        this.shutdown_time = shutdown_time;
    }

    public String getMachine_type() {
        return machine_type;
    }

    public void setMachine_type(String machine_type) {
        this.machine_type = machine_type;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    public Mac_shutdown(int id, String date, String class_name, String product_differentiation, String equipment_name, String machine_number, String shutdown_reason_code, String shutdown_type, Double shutdown_time, String machine_type, String login_time, String login_oid, String update_time, String update_oid, String update_program) {
        this.id = id;
        this.date = date;
        this.class_name = class_name;
        this.product_differentiation = product_differentiation;
        this.equipment_name = equipment_name;
        this.machine_number = machine_number;
        this.shutdown_reason_code = shutdown_reason_code;
        this.shutdown_type = shutdown_type;
        this.shutdown_time = shutdown_time;
        this.machine_type = machine_type;
        this.login_time = login_time;
        this.login_oid = login_oid;
        this.update_time = update_time;
        this.update_oid = update_oid;
        this.update_program = update_program;
    }

    public Mac_shutdown() {
    }

    @Override
    public String toString() {
        return "Mac_shutdown{" +
                "id=" + id +
                ", date='" + date + '\'' +
                ", class_name='" + class_name + '\'' +
                ", product_differentiation='" + product_differentiation + '\'' +
                ", equipment_name='" + equipment_name + '\'' +
                ", machine_number='" + machine_number + '\'' +
                ", shutdown_reason_code='" + shutdown_reason_code + '\'' +
                ", shutdown_type='" + shutdown_type + '\'' +
                ", shutdown_time=" + shutdown_time +
                ", machine_type='" + machine_type + '\'' +
                ", login_time='" + login_time + '\'' +
                ", login_oid='" + login_oid + '\'' +
                ", update_time='" + update_time + '\'' +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                '}';
    }
}
