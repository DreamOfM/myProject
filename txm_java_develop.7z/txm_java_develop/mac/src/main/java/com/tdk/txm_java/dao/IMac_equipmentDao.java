package com.tdk.txm_java.dao;

import com.tdk.txm_java.domain.Mac_equipment;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface IMac_equipmentDao {

    /**
     *@Description: 查询所有信息
     *@Author: a135109
     *@time: 2019/12/2 16:59
     */
    @Select("select * from mac_equipment")
    public List<Mac_equipment> findAll() throws Exception;

    /**
    *@Description: 通过设备名查找
    *@Author: a135109
    *@time: 2019/12/4 14:46
    */
    @Select("select * from mac_equipment where equipment_name=#{equipment_name}")
    public List<Mac_equipment> findByName(String equipment_name) throws Exception;

    /**
     *@Description: 通过设备名查找
     *@Author: a135109
     *@time: 2019/12/4 14:46
     */
    @Select("select * from mac_equipment where equipment_name=#{equipment_name}")
    public Mac_equipment findByKey(String equipment_name) throws Exception;

    /**
     *@Description: 通过id查找
     *@Author: a135109
     *@time: 2019/12/2 17:00
     */
    @Select("select * from mac_equipment where id=#{id}")
    public Mac_equipment findById(int id) throws Exception;

    /**
     *@Description: 添加数据
     *@Author: a135109
     *@time: 2019/12/3 8:19
     */
    @Insert("insert into mac_equipment(equipment_name,equipment_name_description,update_time,update_oid,update_program,login_time,login_oid) values(#{equipment_name},#{equipment_name_description},now(),#{update_oid},#{update_program},now(),#{login_oid}) ")
    void save(Mac_equipment Mac_equipment);

    /**
     *@Description: 通过id更新
     *@Author: a135109
     *@time: 2019/12/3 8:19
     */
    @Update("update mac_equipment set equipment_name=#{equipment_name}, equipment_name_description=#{equipment_name_description},update_oid=#{update_oid}, update_program=#{update_program} where id =#{id}  ")
    void update(Mac_equipment mac_equipment);

    /**
     *@Description: 通过id删除对象
     *@Author: a135109
     *@time: 2019/12/2 17:02
     */
    @Delete("delete from mac_equipment where id =#{id}  ")
    void delete(int id);
}
