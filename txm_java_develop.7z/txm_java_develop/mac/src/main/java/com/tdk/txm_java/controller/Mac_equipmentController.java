package com.tdk.txm_java.controller;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tdk.txm_java.domain.Mac_equipment;
import com.tdk.txm_java.domain.ResultInfo;
import com.tdk.txm_java.service.IMac_equipmentService;
import com.tdk.txm_java.utils.ExcelUtils;
import com.tdk.txm_java.utils.UploadUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

@Controller
@RequestMapping("/mac_equipment")

public class Mac_equipmentController {

    @Autowired
    private IMac_equipmentService mac_equipmentService;

    /**
    *@Description: 查询所有设备信息
    *@Author: a135109
    *@time: 2019/12/4 11:58
    */
    @RequestMapping("/findAll.do")
    public ModelAndView findAll(@RequestParam(value="pn",defaultValue="1")Integer pn, @RequestParam(value = "PageSize", defaultValue = "5") Integer ps) throws Exception {
        PageHelper.startPage(pn,ps);
        ModelAndView mv = new ModelAndView();
        List<Mac_equipment> ls = mac_equipmentService.findAll();
        PageInfo page = new PageInfo(ls,ps);
        mv.setViewName("mac-equipment-list");
        mv.addObject("mac_equipment",ls);
        mv.addObject("pageInfo", page);
        return mv;
    }
    
    /**
    *@Description: 通过输入设备工程名查询
    *@Author: a135109
    *@time: 2019/12/4 14:41
    */
    @RequestMapping("/findByName")
    public ModelAndView findByName(String equipment_name) throws Exception {
        Mac_equipment mac_equipment = mac_equipmentService.findByKey(equipment_name);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("mac-equipment-list");
        mv.addObject("mac_equipment", mac_equipment);
        return mv;
    }

    /**
    *@Description: 新增设备信息
    *@Author: a135109
    *@time: 2019/12/4 11:57
    */
    @RequestMapping("/save.do")
    public void save(HttpServletRequest request, HttpServletResponse response,HttpSession httpSession) throws Exception {
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //测试前端数据是否传送过来？
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
       Mac_equipment mac_equipment = new Mac_equipment();
        while (1 == 1) {
            for (String name1 : set) {
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                hashMap.put(name1, vals[b]);
            }
            try {
                BeanUtils.populate(mac_equipment, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //添加一个判断，如果为空值或者没有输入则不往数据库里插数据
            if (mac_equipment.getEquipment_name().equals(null) || mac_equipment.getEquipment_name().equals("")) {
                b++;
                if (b == c) break;
                continue;
            }
            String username= (String) httpSession.getAttribute("username");
            mac_equipment.setUpdate_oid(username);
            mac_equipment.setUpdate_program("/mac_equipment/save");
            mac_equipment.setLogin_oid(username);
            mac_equipmentService.save(mac_equipment);
            b++;
            if (b == c) break;
        }
    }

    /**
    *@Description: 删除设备信息
    *@Author: a135109
    *@time: 2019/12/4 11:58
    */
    @RequestMapping("/delete.do")
    public String delete(int id) throws Exception {
        mac_equipmentService.delete(id);
        return "redirect:findByName.do";
    }

    /**
    *@Description: 修改设备信息
    *@Author: a135109
    *@time: 2019/12/5 9:00
    */
    @RequestMapping("/update.do")
    public void update(HttpServletRequest request, HttpServletResponse response,HttpSession httpSession) throws Exception {
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        //1.获取信息
        int id = Integer.parseInt(request.getParameter("id"));
        String equipment_name_description = request.getParameter("equipment_name_description");
        //2.调用service层判断是否存在
        Mac_equipment mac = mac_equipmentService.findById(id);
        mac.setEquipment_name_description(equipment_name_description);
        String username= (String) httpSession.getAttribute("username");
        mac.setUpdate_oid(username);
        mac.setUpdate_program("/mac_equipment/update");
        mac_equipmentService.update(mac);
        // 响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        info.setFlag(true);
        mapper.writeValue(response.getOutputStream(),info);
    }

    /**
    *@Description: ajax验证
    *@Author: a135109
    *@time: 2019/12/16 11:54
    */
    @RequestMapping("/check.do")
    public void check(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception, IOException, JsonGenerationException, JsonMappingException {
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        info.setFlag(true);
        List<String> errorList=new ArrayList<String>();
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        Mac_equipment mac_equipment = new Mac_equipment();
        int b = 0;   //第几笔记录
        int c = 0;   //total
        while (true) {
            //一条数据
            for (String name : set) {
                String[] vals = (String[]) map.get(name);
                c = vals.length;
                hashMap.put(name, vals[b]);
            }
            //hashmap找到对应的对象
            try {
                BeanUtils.populate(mac_equipment, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //查找存在的对象
            String equipment_name = mac_equipment.getEquipment_name();
            Mac_equipment mac = mac_equipmentService.findByKey(equipment_name);
            if (mac!=null){
                info.setFlag(false);
                String errLine= String.valueOf(b);
                errorList.add("equipment_name"+errLine);
            }
            b++;
            if (b==c)break;
        }
        info.setErrorList(errorList);
        // 响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(),info);
    }

    /**
     *@Description: 上载数据
     *@Author: a135109
     *@time: 2020/1/15 10:44
     */
    @RequestMapping("/upload.do")
    public ModelAndView upload(MultipartFile imgFile, HttpServletRequest request) throws Exception{
        UploadUtils uploadUtils = new UploadUtils();
        String filePath = uploadUtils.upload(imgFile,request);
        //导入LoadExcle方法
        String columns[] = {"equipment_name","equipment_name_description"};
        //创建对象
        Mac_equipment mac_equipment = new Mac_equipment();
        //从Excel获取数据列表
        List<Map<String, Object>> list =  ExcelUtils.LoadExcle(filePath,columns);
        //创建新的对象列表
        List<Mac_equipment> ls = new ArrayList<>();
        //将map转为对象，并存到对象list
        for (Map ma: list) {
            mac_equipment = ExcelUtils.mapToBean(ma, Mac_equipment.class);
            ls.add(mac_equipment);
        }
        //将获取的数据上载到中间表
        ModelAndView mv = new ModelAndView();
        mv.setViewName("mac-equipment-upload");
        mv.addObject("mac_equipment",ls);
        return mv;
    }


}
