package com.tdk.txm_java.dao;


import com.tdk.txm_java.domain.Mac_movement;
import org.apache.ibatis.annotations.*;
import org.springframework.security.core.parameters.P;

import java.util.List;

public interface IMac_movementDao {

    /**
     *@Description: 查询所有信息
     *@Author: a135109
     *@time: 2019/12/2 16:59
     */
    @Select("select * from mac_movement")
    public List<Mac_movement> findAll() throws Exception;

    /**
     *@Description: 通过id查找
     *@Author: a135109
     *@time: 2019/12/2 17:00
     */
    @Select("select * from mac_movement where id=#{id}")
    public Mac_movement findById(int id) throws Exception;

    /**
    *@Description: 通过key值查找
    *@Author: a135109
    *@time: 2019/12/19 14:12
    */
    @Select("select * from mac_movement where product_differentiation=#{product_differentiation} and equipment_name=#{equipment_name} and date=#{date} and class_name=#{class_name} and machine_number=#{machine_number}")
    public List<Mac_movement> findByKey(@Param("product_differentiation") String product_differentiation, @Param("equipment_name") String equipment_name, @Param("date") String date,@Param("class_name") String class_name,@Param("machine_number") String machine_number) throws Exception;
    
    /**
    *@Description: 通过输入的信息查询
    *@Author: a135109
    *@time: 2019/12/6 12:00
    */
    @Select("select * from mac_movement where product_differentiation=#{product_differentiation} and equipment_name=#{equipment_name} and date=#{date} and class_name=#{class_name} order by machine_number asc")
    public List<Mac_movement> findByName(@Param("product_differentiation") String product_differentiation, @Param("equipment_name") String equipment_name, @Param("date") String date,@Param("class_name") String class_name) throws Exception;

    /**
     *@Description: 添加数据
     *@Author: a135109
     *@time: 2019/12/3 8:19
     */
    @Insert("insert into mac_movement(date,class_name,product_differentiation,equipment_name,machine_number,work_time,unittime_product_num,input_quantity,nondefective_quantity,machine_type,operate_id,security_id,update_time,update_oid,update_program,login_time,login_oid) " +
            "values(#{date},#{class_name},#{product_differentiation},#{equipment_name},#{machine_number},#{work_time},#{unittime_product_num},#{input_quantity},#{nondefective_quantity},#{machine_type},#{operate_id},#{security_id},now(),#{update_oid},#{update_program},now(),#{login_oid}) ")
    void save(Mac_movement mac_movement);

    /**
     *@Description: 通过id更新
     *@Author: a135109
     *@time: 2019/12/3 8:19
     */
    @Update("update mac_movement set date=#{date}, class_name=#{class_name}, product_differentiation=#{product_differentiation}, equipment_name=#{equipment_name}, machine_number=#{machine_number}, work_time=#{work_time}, unittime_product_num=#{unittime_product_num}, input_quantity=#{input_quantity}, nondefective_quantity=#{nondefective_quantity}, machine_type=#{machine_type}, operate_id=#{operate_id}, security_id=#{security_id},update_oid=#{update_oid}, update_program=#{update_program} where id =#{id}  ")
    void update(Mac_movement mac_movement);

    /**
     *@Description: 通过id删除对象
     *@Author: a135109
     *@time: 2019/12/2 17:02
     */
    @Delete("delete from mac_movement where id =#{id}  ")
    void delete(int id);
}
