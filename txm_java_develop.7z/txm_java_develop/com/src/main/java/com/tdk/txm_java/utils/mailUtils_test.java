package com.tdk.txm_java.utils;


import static com.tdk.txm_java.utils.mailUtils.sendmail;


public class mailUtils_test {
    public static void main(String[] args) {
        String to_mail_address="tianxu_guo@cn.tdk.com";
            String mail_subject="Mail Testw";
            String mail_content="电子邮件测试内容";
            String filePath="D:\\AS400.KMP";
//            String filePath="";
            sendmail(to_mail_address,mail_subject,mail_content,filePath);


}
}
