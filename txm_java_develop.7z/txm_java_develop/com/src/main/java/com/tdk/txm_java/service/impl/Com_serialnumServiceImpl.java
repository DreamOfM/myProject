package com.tdk.txm_java.service.impl;

import com.tdk.txm_java.dao.ICom_serialnumDao;
import com.tdk.txm_java.domain.Com_serialnum;
import com.tdk.txm_java.service.ICom_serialnumService;
import org.apache.xmlbeans.impl.xb.xsdschema.Public;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Calendar;

@Service
@Transactional
public class Com_serialnumServiceImpl implements ICom_serialnumService {
    @Autowired
    private ICom_serialnumDao iCom_serialnumDao;

    @Override
    public void update(Com_serialnum com_serialnum) throws Exception {
        iCom_serialnumDao.update(com_serialnum);
    }
    //查找
    @Override
    public Com_serialnum find(Com_serialnum com_serialnum) throws Exception {
        return iCom_serialnumDao.find(com_serialnum);
    }
    //查找
    @Override
    public Com_serialnum findByKey(String type, String key01, String key02) throws Exception {
        Com_serialnum com_serialnum = new Com_serialnum();
        com_serialnum.setType(type);
        com_serialnum.setKey01(key01);
        com_serialnum.setKey02(key02);
        return iCom_serialnumDao.find(com_serialnum);
    }
    //查找并流水号加1   JIT2100001= 前缀+年（21)+流水号，如果跨年，流水号从1开始
    @Override
    public String findAndUpdate(String type, String key01, String key02, int length) throws Exception{
        Com_serialnum com_serialnum = new Com_serialnum();
        com_serialnum.setType(type);
        com_serialnum.setKey01(key01);
        com_serialnum.setKey02(key02);
        Com_serialnum com_serialnum2 = iCom_serialnumDao.find(com_serialnum);
        Calendar cal = Calendar.getInstance();
        String yy= String.valueOf(cal.get(Calendar.YEAR));
        yy= yy.substring(2,4); //年 第3和第4位
        int serialnum=com_serialnum2.getSerialnum()+1;
        String serialnum_return = com_serialnum2.getPrefix_letter()+yy+String.format("%0"+length+"d",serialnum);//JTI2012345
        if(com_serialnum2.getPrefix_yy()==yy) {
            com_serialnum2.setSerialnum(serialnum);
        } else {
            com_serialnum2.setPrefix_yy(yy);
            com_serialnum2.setSerialnum(1);
        }

        iCom_serialnumDao.update(com_serialnum2);
        return serialnum_return;
    }

}
