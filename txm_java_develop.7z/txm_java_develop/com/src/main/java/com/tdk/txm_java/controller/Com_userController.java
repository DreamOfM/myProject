package com.tdk.txm_java.controller;


import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tdk.txm_java.domain.Com_permission;
import com.tdk.txm_java.domain.Com_role;
import com.tdk.txm_java.domain.Com_userInfo;
import com.tdk.txm_java.domain.ResultInfo;
import com.tdk.txm_java.service.ICom_permissionService;
import com.tdk.txm_java.service.ICom_userService;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

@Controller
@RequestMapping("/user")
//@PreAuthorize("hasRole('ROLE_ADMIN')")
public class
Com_userController {

    @Autowired
    private ICom_userService com_userService;
    @Autowired
    private ICom_permissionService iCom_permissionService;

    //给用户添加角色
    @RequestMapping("/addRoleToUser.do")
    public String addRoleToUser(@RequestParam(name = "username", required = true) String username, @RequestParam(name = "ids", required = true) String[] roleIds) {
        com_userService.addRoleToUser(username, roleIds);
        return "redirect:findAll.do";
    }

    //查询用户以及用户可以添加的角色
    @RequestMapping("/findUserByUsernameAndAllRole.do")
    public ModelAndView findUserByUsernameAndAllRole(@RequestParam(name = "username", required = true) String username) throws Exception {
        ModelAndView mv = new ModelAndView();
        //1.根据用户id查询用户
        Com_userInfo userInfo = com_userService.findByUsername(username);
        //2.根据用户id查询可以添加的角色
        List<Com_role> otherRoles = com_userService.findOtherRoles(username);
        mv.addObject("user", userInfo);
        mv.addObject("roleList", otherRoles);
        mv.setViewName("user-role-add");
        return mv;
    }

    //查询指定id的用户
    @RequestMapping("/findByUsername.do")
    public ModelAndView findByUsername(String username) throws Exception {

        ModelAndView mv = new ModelAndView();
       Com_userInfo com_userInfo = com_userService.findByUsername(username);
        List<Com_role> otherRoles = com_userService.findOtherRoles(username);
        mv.addObject("user", com_userInfo);
        mv.addObject("roleList", otherRoles);
        mv.setViewName("com-user-show");
        System.out.println(com_userInfo+"------------------");
        return mv;
    }

    //查询指定id的用户
    @RequestMapping("/showByUsername.do")
    public ModelAndView showByUsername(String username,HttpSession httpSession) throws Exception {
        ModelAndView mv = new ModelAndView();
        if(username==null) {
            username = (String) httpSession.getAttribute("username");
        }
        Com_userInfo com_userInfo = com_userService.findByUsername(username);
        List<Com_permission> com_permissions = iCom_permissionService.findByUsernameMenuLevel(username,2);
        Com_permission com_permission= iCom_permissionService.findById(com_userInfo.getPermissionid());
        if(com_permission==null){
            com_permission=new Com_permission();
            com_permission.setId(0);
            com_permission.setPermission_name("空白页");
        }
        mv.addObject("user", com_userInfo);
        mv.addObject("com_permissions", com_permissions);
        mv.addObject("com_permission01", com_permission);
        mv.setViewName("usr-info");
        return mv;
    }

    //用户添加
    @RequestMapping("/save.do")

    public String save(Com_userInfo com_userInfo) throws Exception {

        com_userService.save(com_userInfo);
        return "redirect:findAll.do";
    }

    //删除
    @RequestMapping("/delete.do")

    public String delete(String username) {
        com_userService.delete(username);
        return "redirect:findAll.do";
    }

    //用户修改
    @RequestMapping("/update.do")

    public String update(HttpServletRequest request,
                         HttpServletResponse response) throws Exception {
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {

                String[] vals = (String[]) map.get(name1);//将每一个key值对应的一组值放到数组里去
                c = vals.length;
                hashMap.put(name1, vals[b]);
            }
            Com_userInfo com_userInfo=new Com_userInfo();
            String username1 = hashMap.get("username");
            com_userInfo = com_userService.findByUsername(username1);
            System.out.println("1"+com_userInfo);
            System.out.println(hashMap);
            try {
                BeanUtils.populate(com_userInfo, hashMap);
                System.out.println(com_userInfo);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            if(com_userInfo.getPermissionid()==0){
                com_userInfo.setHome_page("pages/welcome.jsp");
            }else {
                Com_permission com_permission = iCom_permissionService.findById(com_userInfo.getPermissionid());
                com_userInfo.setHome_page(com_permission.getUrl());
            }
            com_userService.update(com_userInfo);
            b++;
            if (b == c) break;
        }
        return "redirect:findAll.do";
    }
    //用户修改密码并记录修改日期
    @RequestMapping("/updatePwd.do")
    public String updatePwd(Com_userInfo com_userInfo) throws Exception {
        com_userService.updatePwd(com_userInfo);
        return "redirect:findAll.do";
    }
    //初始化密码
    @RequestMapping("/initializePwd.do")
    public String initializePwd(Com_userInfo com_userInfo) throws Exception {

        com_userService.initializePwd(com_userInfo);
        return "redirect:findAll.do";
    }


    @RequestMapping("/findAll.do")
//    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ModelAndView findAll(@RequestParam(value="pn",defaultValue="1")Integer pn, @RequestParam(value = "PageSize", defaultValue = "5") Integer ps) throws Exception {
        //引入PageHelper分页插件
        //查询之前需要调用,,传入页码，以及每页的大小
//        PageHelper.startPage(pn,ps);

        List<Com_userInfo> userList = com_userService.findAll();

        //startPage后面紧跟的是这个查询就是一个分页查询
        //使用pageInfo包装查询后的结果，只需要将Pageinfo交给页面就行了
        //封装了详细的分页信息，包括我们查出来的数据,传入连续显示的数据
//        PageInfo page = new PageInfo(userList,ps);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("com-user-list");
        mv.addObject("userList", userList);
//        mv.addObject("pageInfo", page);
        return mv;
    }

    @RequestMapping("/check.do")
    public void check(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception, IOException, JsonGenerationException, JsonMappingException {
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        info.setFlag(true);
        List<String> errorList=new ArrayList<String>();
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();

        //check head
        for (String name1 : set) {
            String[] vals = (String[]) map.get(name1);
            hashMap.put(name1, vals[0]);
        }
        String old_password=hashMap.get("old_password");
        String username=hashMap.get("username");
        Com_userInfo com_userInfo=com_userService.findByUsername(username);

        if(com_userInfo==null){
            info.setErrorMsg("用户名不存在");
            errorList.add("username");
            info.setFlag(false);
        }else {
            BCryptPasswordEncoder bcryptPasswordEncoder = new BCryptPasswordEncoder();
            boolean flag = bcryptPasswordEncoder.matches(old_password,com_userInfo.getPassword());
            if(!flag){
                info.setErrorMsg("密码不对");
                errorList.add("old_password");
                info.setFlag(false);
            }
        }
        //新密码要符合策略


        info.setErrorList(errorList);
        //响应数据
        ObjectMapper mapper = new ObjectMapper();

        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(),info);
    }

}
