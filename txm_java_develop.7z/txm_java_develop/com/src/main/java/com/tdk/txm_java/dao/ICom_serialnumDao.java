package com.tdk.txm_java.dao;
import com.tdk.txm_java.domain.Com_serialnum;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ICom_serialnumDao {
    //更新
    @Update("update com_serialnum set serialnum =serialnum+1 " +
            "where type =#{type} and key01=#{key01} and key02=#{key02} ")
    void update(Com_serialnum com_serialnum) throws Exception;

    //查询
    @Select("select * from com_serialnum where type =#{type} and key01=#{key01} and key02=#{key02}")
    public Com_serialnum find(Com_serialnum com_serialnum) throws Exception ;


}
