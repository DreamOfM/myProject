package com.tdk.txm_java.service;
import com.tdk.txm_java.domain.Com_sysLog;

import java.util.List;

public interface ICom_sysLogService {

    public void save(Com_sysLog sysLog) throws Exception;

    List<Com_sysLog> findAll() throws Exception;
}
