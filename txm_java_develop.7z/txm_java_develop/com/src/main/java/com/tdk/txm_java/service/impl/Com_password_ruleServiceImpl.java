package com.tdk.txm_java.service.impl;


import com.tdk.txm_java.dao.ICom_password_ruleDao;
import com.tdk.txm_java.domain.Com_password_rule;
import com.tdk.txm_java.service.ICom_password_ruleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class Com_password_ruleServiceImpl implements ICom_password_ruleService {


    @Autowired
    private ICom_password_ruleDao iCom_password_ruleDao;

    @Override
    public Com_password_rule findAll() throws Exception {
        return iCom_password_ruleDao.findAll();
    }

    @Override
    public String checkPassword(String password) throws Exception {
        Com_password_rule com_password_rule=iCom_password_ruleDao.findAll();
        String msg=null;
//        if(password.length()>com_password_rule.getLen_max()){
//            msg="长度不能超出"+com_password_rule.getLen_max();
//        }
//        if(password.length()<com_password_rule.getLen_min()){
//            msg="长度不能小出"+com_password_rule.getLen_min();
//        }
        if(!password.matches(com_password_rule.getAllow_letters())){
            msg="密码只能由数字和字母组成,长度在6-16之间";
        }
        return msg;
    }

}
