package com.tdk.txm_java.domain;

import java.util.Date;
import java.util.List;

public class Com_rate {
    private String currency;
    private Integer rate_date;
    private String type;
    private double rate;

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public int getRate_date() {
        return rate_date;
    }

    public void setRate_date(int rate_date) {
        this.rate_date = rate_date;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    @Override
    public String toString() {
        return "Com_rate{" +
                "currency='" + currency + '\'' +
                ", rate_date=" + rate_date +
                ", type='" + type + '\'' +
                ", rate=" + rate +
                '}';
    }
}
