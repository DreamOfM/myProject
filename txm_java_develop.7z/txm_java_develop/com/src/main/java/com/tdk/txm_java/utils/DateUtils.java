package com.tdk.txm_java.utils;

import org.apache.commons.beanutils.ConversionException;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.Converter;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.*;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DateUtils {

    //日期转换成字符串
    public static String date2String(Date date, String patt) {
        SimpleDateFormat sdf = new SimpleDateFormat(patt);
        String format = sdf.format(date);
        return format;
    }

    //字符串转换成日期
    public static Date string2Date(String str, String patt) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat(patt);
        Date parse = sdf.parse(str);
        return parse;
    }

    //7位字符串转换成日期
    //传入参数 1200520  日期格式“YYYYMMDD"   传出参数 date:20200520
    public static Date string72Date(String str, String patt) throws ParseException {
        String str8 = "20000000";
        if (str.length() == 7) {
            str8 = "20" + str.substring(str.length() - 6, str.length());
        }
        SimpleDateFormat sdf = new SimpleDateFormat(patt);
        Date parse = string2Date(str8, patt);
        return parse;
    }

    //判断日期是多少天以前
    public static int calculateDays(Date datein) throws ParseException {
        Date date = new Date();
        int days = (int) ((date.getTime() - datein.getTime()) / (1000 * 3600 * 24));
        return days;
    }

    //日期推移月数  (date 具体到秒  datetype yyyy-MM-dd HH:mm:ss)  未测试
    public static String DateAddMonth(String date, String dateType, int month) {
        String nowDate = null;
        SimpleDateFormat format = new SimpleDateFormat(dateType);
        try {
            Date parse = format.parse(date);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(parse);
            calendar.add(Calendar.MONTH, month);
            nowDate = format.format(calendar.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return nowDate;
    }

    //年月推移月数
    public static String MonthAddMonth(String yyyymm, int month) {
        int int_yyyymm = Integer.parseInt(yyyymm);
        int_yyyymm = int_yyyymm + month;
        if (int_yyyymm % 100 > 88) {
            int_yyyymm = int_yyyymm - 88;
        } else if (int_yyyymm % 100 > 12) {
            int_yyyymm = int_yyyymm + 88;
        }
        return String.valueOf(int_yyyymm);
    }


    /**
     * 使用java 8的Period的对象计算两个LocalDate对象的时间差，严格按照年、月、日计算，如：2018-03-12 与 2014-05-23 相差 3 年 9 个月 17 天
     */
    public static Period calculateTimeDifferenceByPeriod(LocalDate oldDay) {
        int year = oldDay.getYear();
        Month month = oldDay.getMonth();
        int dayOfMonth = oldDay.getDayOfMonth();
        LocalDate today = LocalDate.now();
        System.out.println("Today：" + today);
        LocalDate oldDate = LocalDate.of(year, month, dayOfMonth);
        System.out.println("OldDate：" + oldDate);

        Period p = Period.between(oldDate, today);
        System.out.printf("目标日期距离今天的时间差：%d 年 %d 个月 %d 天\n", p.getYears(), p.getMonths(), p.getDays());
        return p;
    }

    //TODO 增加一个Date参数的方法，在方法里面进行转换

    /**
     * 使用java 8的Period的对象计算两个LocalDate对象的时间差，严格按照年、月、日计算，如：2018-03-12 与 2014-05-23 相差 3 年 9 个月 17 天
     */
    public static Period calculateTimeDifferenceByPeriod2(LocalDate nowDay, LocalDate oldDay) {

        int year = nowDay.getYear();
        Month month = nowDay.getMonth();
        int dayOfMonth = nowDay.getDayOfMonth();

        int oldYear = oldDay.getYear();
        Month oldMonth = oldDay.getMonth();
        int oldDayOfMonth = oldDay.getDayOfMonth();
        LocalDate oldD = LocalDate.of(oldYear, oldMonth, oldDayOfMonth);
        LocalDate nowD = LocalDate.of(year, month, dayOfMonth);
        Period p = Period.between(oldD, nowD);
        return p;
    }

    /**
     * Date转换成LocalDate
     **/
    public static LocalDate date2LocalDate(Date date) {
        if (null == date) {
            return null;
        }
        return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }

    /**
     * LocalDate转换成Date
     **/
    public static Date localDate2Date(LocalDate localDate) {
        if (null == localDate) {
            return null;
        }
        ZonedDateTime zonedDateTime = localDate.atStartOfDay(ZoneId.systemDefault());
        return Date.from(zonedDateTime.toInstant());
    }

    /**
     * 判断日期的显示格式
     **/
    public static String dateDisplay(Period p) {
        String date_to_now = null;
        if (p.getYears() > 0 && p.getMonths() > 0 && p.getDays() > 0) {
            date_to_now = p.getYears() + "年" + p.getMonths() + "个月" + p.getDays() + "天";
        } else if (p.getYears() == 0 && p.getMonths() > 0 && p.getDays() > 0) {
            date_to_now = p.getMonths() + "个月" + p.getDays() + "天";
        } else if (p.getYears() == 0 && p.getMonths() == 0 && p.getDays() > 0) {
            date_to_now = p.getDays() + "天";
        } else if (p.getYears() > 0 && p.getMonths() == 0 && p.getDays() > 0) {
            date_to_now = p.getYears() + "年" + p.getDays() + "天";
        } else if (p.getYears() > 0 && p.getMonths() == 0 && p.getDays() == 0) {
            date_to_now = p.getYears() + "年";
        } else if (p.getYears() == 0 && p.getMonths() > 0 && p.getDays() == 0) {
            date_to_now = p.getMonths() + "个月";
        } else if (p.getYears() > 0 && p.getMonths() > 0 && p.getDays() == 0) {
            date_to_now = date_to_now = p.getYears() + "年" + p.getMonths() + "个月";
        }
        return date_to_now;
    }

    /**
     * 获得当前日期 yyyy-MM-dd HH:mm:ss
     *
     * @return 2019-08-27 14:12:40
     */
    public static String getCurrentTime() {
        // 小写的hh取得12小时，大写的HH取的是24小时
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();
        return df.format(date);
    }

    /**
     * 获取系统当前时间戳
     *
     * @return 1566889186583
     */
    public static String getSystemTime() {
        String current = String.valueOf(System.currentTimeMillis());
        return current;
    }


    /**
     * 获取当前日期 yy-MM-dd
     *
     * @return 2019-08-27
     */
    public static String getDateByString() {
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(date);
    }


    /**
     * @Author Wang FengCai
     * @Description 获取前或后a天的日期
     * @Date 2020/9/15
     * @Time 下午 04:02
     **/
    public static String getDateBefore(int a) {
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        Calendar calendar = Calendar.getInstance();
        //获得后a天的日期
        calendar.add(Calendar.DATE, a);
        return df.format(calendar.getTime());
    }


    /**
     * @Author Wang FengCai
     * @Description domian 是date类型的前提下，字符串类型的日期转换成日期格式
     * @Date 2020/5/22
     * @Time 下午 01:31
     **/
    public static void convert2Date() {
        ConvertUtils.register((arg0, arg1) -> {
            if (arg1 == null) {
                return null;
            }
            if (!(arg1 instanceof String)) {
                throw new ConversionException("只支持字符串转换 !");
            }
            String str = (String) arg1;
            if (str.trim().equals("")) {
                return null;
            }
            SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd");
            try {
                return sd.parse(str);
            } catch (ParseException e) {
                throw new RuntimeException(e);
            }
        }, Date.class);
    }


    /**
     * @Author Wang FengCai
     * @Description 用于验证日期格式
     * @Date 2020/9/10
     * @Time 下午 01:16
     **/
    public static boolean isDate(String date) {
        /**
         * 判断日期格式和范围
         */
        boolean dateType = true;
        if(date.length()==8){
            String rexp = "^((\\d{2}(([02468][048])|([13579][26]))[\\-\\/\\s]?((((0?[13578])|(1[02]))[\\-\\/\\s]?((0?[1-9])|([1-2][0-9])|(3[01])))|(((0?[469])|(11))[\\-\\/\\s]?((0?[1-9])|([1-2][0-9])|(30)))|(0?2[\\-\\/\\s]?((0?[1-9])|([1-2][0-9])))))|(\\d{2}(([02468][1235679])|([13579][01345789]))[\\-\\/\\s]?((((0?[13578])|(1[02]))[\\-\\/\\s]?((0?[1-9])|([1-2][0-9])|(3[01])))|(((0?[469])|(11))[\\-\\/\\s]?((0?[1-9])|([1-2][0-9])|(30)))|(0?2[\\-\\/\\s]?((0?[1-9])|(1[0-9])|(2[0-8]))))))";
            Pattern pat = Pattern.compile(rexp);
            Matcher mat = pat.matcher(date);
            dateType = mat.matches();
        }
        else{
            dateType = false;
        }
        return dateType;
    }

}
