package com.tdk.txm_java.dao;


import com.tdk.txm_java.domain.Com_permission;
import com.tdk.txm_java.domain.Com_permission2;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ICom_permissionDao {
    // 查询所有信息
    @Select("select * from com_permission order by sort_num")
    public List<Com_permission> findAll() throws Exception;
    // 查询所有信息按等级
    @Select("select * from com_permission where menu_level=#{menu_level} order by sort_num")
    @Results({
            @Result(id = true, property = "id", column = "id"),
            @Result(property = "menu_level", column = "menu_level"),
            @Result(property = "root_menu", column = "root_menu"),
            @Result(property = "permission_code", column = "permission_code"),
            @Result(property = "permission_name", column = "permission_name"),
            @Result(property = "url", column = "url"),
            @Result(property = "sort_num", column = "sort_num"),
            @Result(property = "com_permission2s",column = "permission_code",javaType = List.class,many = @Many(select = "com.tdk.txm_java.dao.ICom_permissionDao.findLowLevel"))
    })
    public List<Com_permission> findByMenuLevel(int menu_level) throws Exception;
    // 查询下级菜单
    @Select("select * from com_permission where father_menu =#{permission_code} order by sort_num")
    public List<Com_permission2> findLowLevel(String permission_code) throws Exception;

    // 查询按ID
    @Select("select * from com_permission where id=#{id} ")
    public Com_permission findById(int id) throws Exception;

    //查询与role关联的所有的权限
    @Select("select * from com_permission where id in (select permissionId from com_role_permission where roleId=#{id} )")
    public List<Com_permission> findByRoleId(String roleid) throws Exception;

    //查询与username关联的所有的权限
    @Select("select * from com_permission where id in (select a.permissionId from com_role_permission a where a.roleId in (select r.roleId from com_user_role r where r.userid=#{username})) ")
    public List<Com_permission> findByUsername(String username) throws Exception;

    @Select("select * from com_permission where menu_level=#{menu_level} and  id in (select a.permissionId from com_role_permission a where a.roleId in (select r.roleId from com_user_role r where r.userid=#{username})) order by root_menu,sort_num ")
    public List<Com_permission> findByUsernameMenuLevel(@Param("username") String username, @Param("menu_level") int menu_level) throws Exception;


    @Insert("insert into com_permission(menu_level,root_menu,father_menu,permission_code,permission_name,permission_name_en,url,sort_num) values(#{menu_level},#{root_menu},#{father_menu},#{permission_code},#{permission_name},#{permission_name_en},#{url},#{sort_num})")
    void save(Com_permission com_permission);

    @Update("update com_permission set  id=#{id}, menu_level=#{menu_level}, root_menu=#{root_menu}, father_menu=#{father_menu}, permission_code=#{permission_code}, permission_name=#{permission_name}, permission_name_en=#{permission_name_en}, url=#{url}, sort_num=#{sort_num} where id =#{id}  ")
    void update(Com_permission com_permission);

    @Delete("delete from com_permission where id=#{id}")
    void delete(int id);
}
