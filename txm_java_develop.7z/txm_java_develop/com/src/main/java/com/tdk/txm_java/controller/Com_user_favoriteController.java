package com.tdk.txm_java.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tdk.txm_java.domain.Com_department;
import com.tdk.txm_java.domain.Com_user_favorite;
import com.tdk.txm_java.domain.Com_userInfo;
import com.tdk.txm_java.service.ICom_departmentService;
import com.tdk.txm_java.service.ICom_user_favoriteService;
import com.tdk.txm_java.service.ICom_userService;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Controller
@RequestMapping("/com_user_favorite")
//@SessionAttributes(value = {"departments","username","userInfo"})
public class Com_user_favoriteController {


    @Autowired
    private ICom_user_favoriteService com_user_favoriteService;


    public String deleteById(int id) throws Exception {
        com_user_favoriteService.deleteById(id);
        System.out.println(id);
        return "redirect:findByMenuLevel.do";
    }
//    public String save(Com_user_favorite com_user_favorite) throws Exception {
//        com_user_favoriteService.deleteById(id);
//        System.out.println(id);
//        return "redirect:findByMenuLevel.do";
//    }
}


