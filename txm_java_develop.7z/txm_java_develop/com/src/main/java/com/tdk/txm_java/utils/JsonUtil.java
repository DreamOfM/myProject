package com.tdk.txm_java.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class JsonUtil {
    /**
     * 直接将传入的对象序列化为json，并且写回客户端
     * @param obj
     */
    public static void writeValue(Object obj, HttpServletResponse response) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(),obj);
    }
    /**
     * 将传入的对象序列化为json，返回
     * 这个方法的作用和上面这个方法的作用是一样的，不同之处在与，不需要传入HttpServletResponse这个对象的参数，若将来需要要使用
     * 日志记录画面（前提是方法的参数中不能有HttpServletRequest 和 HttpServletResponse 等参数，只能是需要用到的参数，参数很多
     * 可以直接用对象来接收）的话，还是使用这个会比较好一些，这个的用法是 “CommonUtil.writeValueAsString(info);”
     * @param obj
     * @return
     */
    public String writeValueAsString(Object obj) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.writeValueAsString(obj);
    }
}
