package com.tdk.txm_java.dao;


import com.tdk.txm_java.domain.Com_company;
import org.apache.ibatis.annotations.*;

import java.util.List;

public interface ICom_companyDao {

    @Select("select * from com_company")
    List<Com_company> findAll() throws Exception;
    /**
     *因为com_company这个表是共用的，这里设置type=02 的代表时进口的
     */
    @Select("select * from com_company where type='02'")
    public List<Com_company> findAll2forward() throws Exception;

    @Insert("insert into com_company (company_code,type,company_name,login_time,login_oid,update_oid,update_program) values(#{company_code},#{type},#{company_name},now(),#{login_oid},#{update_oid},#{update_program})")
    void save(Com_company com_company) throws Exception;

    @Update("update com_company set company_code=#{company_code},type=#{type},company_name=#{company_name},update_oid=#{update_oid},update_program=#{update_program}  where id =#{id}")
    void update(Com_company com_company) throws Exception;
    @Select("select * from com_company where type=#{type} ")
    List<Com_company> findByType(String type) throws Exception;

    @Select("select * from com_company where company_code=#{company_code}")
    List<Com_company> findByCompany_code(String company_code) throws Exception;

    /**
     *进口货代维护，根据货代查询
     */
    @Select("select * from com_company where company_code=#{company_code}")
    Com_company findByCompanyCode(String company_code) throws Exception;

    @Delete("delete from com_company where id=#{id}")
    void delete(int id) throws Exception;

}
