package com.tdk.txm_java.service;


import com.tdk.txm_java.domain.Com_password_rule;

public interface ICom_password_ruleService {
    Com_password_rule findAll() throws Exception;
    String checkPassword(String password) throws Exception;

}
