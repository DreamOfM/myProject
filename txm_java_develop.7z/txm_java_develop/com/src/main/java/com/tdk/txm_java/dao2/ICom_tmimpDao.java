package com.tdk.txm_java.dao2;

import com.tdk.txm_java.domain.Com_tmimp;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ICom_tmimpDao {

    @Select("select count(*) from wavedbf.tmimp ")
    Integer findByTable();
    @Select("select * from wavedbf.tmimp where imitnr=#{itemcode}")
    Com_tmimp findByItemcode(String itemcode);
//    @Select("select imitnr,imspec,imegnr from wavedbf.tmimp where imitnr like concat(#{itemcode},'%')) and imspec like concat(#{imspec},'%')) ")
    @Select("select imitnr,imspec,imegnr from wavedbf.tmimp where imittp='1' and imltdt>((YEAR(CURRENT_DATE)-1900)*10000 + MONTH(CURRENT_DATE)*100+ day(CURRENT_DATE)) and imitnr like #{itemcode} and imspec like #{imspec} ")
//    @Select("select imitnr,imspec,imegnr from wavedbf.tmimp where imittp='1' and imltdt>1200100 and imitnr like #{itemcode} and imspec like #{imspec} ")
    List<Com_tmimp> findByItemSpec(@Param("itemcode") String itemcode, @Param("imspec") String imspec);
    //查询所有包含已失效的品名
    @Select("select imitnr,imspec,imegnr from wavedbf.tmimp where imittp='1' and imitnr like #{itemcode} and imspec like #{imspec} ")
    List<Com_tmimp> findByItemSpec2All(@Param("itemcode") String itemcode, @Param("imspec") String imspec);
}
