package com.tdk.txm_java.domain;

public class Com_user_favorite {
    private Integer id;
    private String username;
    private Integer permissionid;
    private String permission_name;
    private String self_name;

    public String getSelf_name() {
        return self_name;
    }

    public void setSelf_name(String self_name) {
        this.self_name = self_name;
    }



    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Integer getPermissionid() {
        return permissionid;
    }

    public void setPermissionid(Integer permissionid) {
        this.permissionid = permissionid;
    }

    public String getPermission_name() {
        return permission_name;
    }

    public void setPermission_name(String permission_name) {
        this.permission_name = permission_name;
    }

    @Override
    public String toString() {
        return "Com_user_favorite{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", permissionid=" + permissionid +
                ", permission_name='" + permission_name + '\'' +
                '}';
    }
}
