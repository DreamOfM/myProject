package com.tdk.txm_java.dao;

import com.tdk.txm_java.domain.Com_sysLog;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface ICom_sysLogDao {

    @Insert("insert into syslog(visitTime,username,ip,url,executionTime,method) values(#{visitTime},#{username},#{ip},#{url},#{executionTime},#{method})")
    public void save(Com_sysLog sysLog) throws Exception;

    @Select("select * from sysLog")
    List<Com_sysLog> findAll() throws Exception;
}
