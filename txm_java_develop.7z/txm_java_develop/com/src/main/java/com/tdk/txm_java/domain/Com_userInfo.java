package com.tdk.txm_java.domain;

import java.sql.Date;
import java.util.List;

//与数据库中users对应
public class Com_userInfo {
    private String userid;
    private String password;
    private String username;
    private String name_cn;
    private String department;
    private String phone;
    private String email;
    private int status;
    private Date pwd_change_time;
    private String user_login_time;
    private String login_time;
    private String statusStr;
    private String hmoe_page;
    private String login_oid;//更新操作员代码
    private String update_time;//更新時間
    private String update_terminal_id;//更新操作员代码
    private String update_oid;//更新操作员代码
    private String update_program;//更新程式名稱
    private List<Com_role> com_roles;
    private String mrpcode;
    private String employee_id;
    private String home_page;
    private String roleid;
    private int permissionid;
    private String permission_name;

    public String getRoleid() {
        return roleid;
    }

    public void setRoleid(String roleid) {
        this.roleid = roleid;
    }

    public int getPermissionid() {
        return permissionid;
    }

    public void setPermissionid(int permissionid) {
        this.permissionid = permissionid;
    }

    public String getPermission_name() {
        return permission_name;
    }

    public void setPermission_name(String permission_name) {
        this.permission_name = permission_name;
    }

    public String getHmoe_page() {
        return hmoe_page;
    }

    public void setHmoe_page(String hmoe_page) {
        this.hmoe_page = hmoe_page;
    }

    public String getUser_login_time() {
        return user_login_time;
    }

    public void setUser_login_time(String user_login_time) {
        this.user_login_time = user_login_time;
    }

    public String getEmployee_id() {
        return employee_id;
    }

    public void setEmployee_id(String employee_id) {
        this.employee_id = employee_id;
    }



    public String getMrpcode() {
        return mrpcode;
    }

    public void setMrpcode(String mrpcode) {
        this.mrpcode = mrpcode;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public Date getpwd_change_time() {
        return pwd_change_time;
    }

    public void setpwd_change_time(Date pwd_change_time) {
        this.pwd_change_time = pwd_change_time;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }

    public String getStatusStr() {
        //状态0 未开启 1 开启
        if (status == 0) {
            statusStr = "未开启";
        } else if (status == 1) {
            statusStr = "开启";
        }
        return statusStr;
    }

    public void setStatusStr(String statusStr) {
        this.statusStr = statusStr;
    }

    public List<Com_role> getCom_roles() {
        return com_roles;
    }

    public void setCom_roles(List<Com_role> com_roles) {
        this.com_roles = com_roles;
    }

    public String getName_cn() {
        return name_cn;
    }

    public void setName_cn(String name_cn) {
        this.name_cn = name_cn;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_terminal_id() {
        return update_terminal_id;
    }

    public void setUpdate_terminal_id(String update_terminal_id) {
        this.update_terminal_id = update_terminal_id;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    public String getHome_page() {
        return home_page;
    }

    public void setHome_page(String home_page) {
        this.home_page = home_page;
    }

    @Override
    public String toString() {
        return "Com_userInfo{" +
                "userid='" + userid + '\'' +
                ", password='" + password + '\'' +
                ", username='" + username + '\'' +
                ", name_cn='" + name_cn + '\'' +
                ", department='" + department + '\'' +
                ", phone='" + phone + '\'' +
                ", email='" + email + '\'' +
                ", status=" + status +
                ", pwd_change_time=" + pwd_change_time +
                ", user_login_time='" + user_login_time + '\'' +
                ", login_time='" + login_time + '\'' +
                ", statusStr='" + statusStr + '\'' +
                ", hmoe_page='" + hmoe_page + '\'' +
                ", login_oid='" + login_oid + '\'' +
                ", update_time='" + update_time + '\'' +
                ", update_terminal_id='" + update_terminal_id + '\'' +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                ", com_roles=" + com_roles +
                ", mrpcode='" + mrpcode + '\'' +
                ", employee_id='" + employee_id + '\'' +
                ", home_page='" + home_page + '\'' +
                '}';
    }
}
