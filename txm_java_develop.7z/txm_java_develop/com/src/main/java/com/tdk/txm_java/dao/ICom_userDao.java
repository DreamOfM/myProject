package com.tdk.txm_java.dao;


import com.tdk.txm_java.domain.Com_role;
import com.tdk.txm_java.domain.Com_userInfo;
import org.apache.ibatis.annotations.*;

import java.util.List;

public interface ICom_userDao {

    @Select("select * from com_user where username=#{username}")
    @Results({
            @Result(id = true, property = "userid", column = "userid"),

            @Result(property = "com_roles",column = "userid",javaType = List.class,many = @Many(select = "com.tdk.txm_java.dao.ICom_roleDao.findRoleByUserId"))
    })
    public Com_userInfo findByUsername(String username) throws Exception;

    @Select("select * from com_user")
    List<Com_userInfo> findAll() throws Exception;

    @Select("select * from com_user userId=#{username} and password=#{password} ")
    Com_userInfo findByUsernamePwd(@Param("username") String username, @Param("password") String password) throws Exception;

    @Insert("insert into com_user(userid,email,username,name_cn,employee_id,department,mrpcode,password,phone,status,home_page,permissionid" +
            ",login_time) " +
            "values(#{username},#{email},#{username},#{name_cn},#{employee_id},#{department},#{mrpcode},#{password},#{phone},#{status},#{home_page},#{permissionid}," +
            "#{login_time})")
    void save(Com_userInfo userInfo) throws Exception;

    @Select("select * from com_role where roleid not in (select roleId from com_user_role where userId=#{username})")
    List<Com_role> findOtherRoles(String username);

    @Update("UPDATE com_user SET   username=#{username},name_cn=#{name_cn},employee_id=#{employee_id},mrpcode=#{mrpcode}, department=#{department}, phone=#{phone}, email=#{email}, status=#{status},home_page=#{home_page},permissionid=#{permissionid} " +
            " where userid=#{userid}")
    void update(Com_userInfo com_userInfo);

    @Update("UPDATE com_user SET  password=#{password}, pwd_change_time=now() where username=#{username}")
    void updatePwd(Com_userInfo com_userInfo);

    @Update("UPDATE com_user SET  password=#{password}, pwd_change_time=20000101 where username=#{username}")
    void initializePwd(Com_userInfo com_userInfo);

    @Update("UPDATE com_user SET  user_login_time=now() where username=#{username}")
    void updateUserlogintime(String username);

    @Delete("delete from com_user where username=#{username}")
    void delete(String username);

    @Insert("insert into com_user_role(userId,roleId,login_time) values(#{username},#{roleId},now())")
    void addRoleToUser(@Param("username") String username, @Param("roleId") String roleId);
}
