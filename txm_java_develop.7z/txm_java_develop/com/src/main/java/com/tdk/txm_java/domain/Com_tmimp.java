package com.tdk.txm_java.domain;

import lombok.Data;

//与数据库中users对应
@Data
public class Com_tmimp {
    private String imitnr;
    private String imspec;
    private String imegnr;
    private String immrpc;
    private String imittp;
    private String imitza;
    private String imbond; //保税标识
    private String imitdd;  //中文品名
    private String imioum; //在库单位
    private String impium; //监管单位
    private Double impicf;  //监管换算系数
    private Double imgnbr;
    private Integer count;

}
