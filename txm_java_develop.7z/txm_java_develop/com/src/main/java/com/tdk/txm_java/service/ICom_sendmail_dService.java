package com.tdk.txm_java.service;


import com.tdk.txm_java.domain.Com_sendmail_d;

import java.util.List;

public interface ICom_sendmail_dService {

    List<Com_sendmail_d> findAll() throws Exception;
    Com_sendmail_d findBytype_subtype(String mail_type, String mail_subtype) throws Exception;
}
