package com.tdk.txm_java.dao;


import com.tdk.txm_java.domain.Com_sendmail_d;
import org.apache.ibatis.annotations.*;

import java.util.List;

public interface ICom_sendmail_dDao {

    @Select("select * from Com_sendmail_d")
    List<Com_sendmail_d> findAll() throws Exception;

    @Select("select * from Com_sendmail_d where mail_type=#{mail_type} and mail_subtype=#{mail_subtype}")
    public Com_sendmail_d findBytype_subtype(@Param("mail_type") String mail_type, @Param("mail_subtype") String mail_subtype) throws Exception;

}
