package com.tdk.txm_java.service;


import com.tdk.txm_java.domain.Com_company;
import com.tdk.txm_java.domain.Com_role;

import java.util.List;

public interface ICom_companyService {
    List<Com_company> findAll() throws Exception;
    List<Com_company> findByType(String type) throws Exception;

}
