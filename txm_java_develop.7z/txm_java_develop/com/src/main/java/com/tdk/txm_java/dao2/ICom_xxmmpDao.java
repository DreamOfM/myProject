package com.tdk.txm_java.dao2;

import com.tdk.txm_java.domain.Com_xxmmp;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

@Repository
public interface ICom_xxmmpDao {

    @Select("select count(*) from wavedbf.xxmmp ")
    Integer findByTable();
    @Select("select * from wavedbf.xxmmp where mmemno=#{mmemno}")
    Com_xxmmp findByMmemno(String mmemno);
}
