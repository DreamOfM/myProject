package com.tdk.txm_java.dao;


import com.tdk.txm_java.domain.Com_employee;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface ICom_employeeDao {

    @Select("select * from com_employee")
    List<Com_employee> findAll() throws Exception;

    @Insert("insert into com_employee" +
            "(" +
            "mmemno,mmdnam,mmdept,mmcoop,mmdvcd,mmrsgn,mmhire,mmwork,mmpos5,mmp5nm,mmpos4,mmp4nm,mmpos3,mmp3nm" +
            ",login_time )" +
            "values(" +
            "#{mmemno},#{mmdnam},#{mmdept},#{mmcoop},#{mmdvcd},#{mmrsgn},#{mmhire},#{mmwork},#{mmpos5},#{mmp5nm},#{mmpos4},#{mmp4nm},#{mmpos3},#{mmp3nm}" +
            ",now())")
    void save(Com_employee com_employee);

    @Update("update com_employee set" +
            "mmemno=#{mmemno}, mmdnam=#{mmdnam}, mmdept=#{mmdept}, mmcoop=#{mmcoop}, mmdvcd=#{mmdvcd}, mmrsgn=#{mmrsgn}, mmhire=#{mmhire}, mmwork=#{mmwork}, mmpos5=#{mmpos5}, mmp5nm=#{mmp5nm}, mmpos4=#{mmpos4}, mmp4nm=#{mmp4nm}, mmpos3=#{mmpos3}, mmp3nm=#{mmp3nm}" +
            "where id =#{id}  ")
    void update(Com_employee com_employee);

    @Delete("delete from com_employee where id =#{id}  ")
    void delete(int id);

    @Delete("truncate com_employee  ")
    void deleteAll();

    @Insert({
            "<script>",
            "insert into com_employee  (mmemno,mmdnam,mmdept,mmcoop,mmdvcd,mmrsgn,mmhire,mmwork,mmpos5,mmp5nm,mmpos4,mmp4nm,mmpos3,mmp3nm" +
                    ",login_time,login_oid,update_oid,update_program) values ",
            "<foreach collection='list'  item='item' index='index' separator=','>",
            "(#{item.mmemno},#{item.mmdnam},#{item.mmdept},#{item.mmcoop},#{item.mmdvcd},#{item.mmrsgn},#{item.mmhire},#{item.mmwork},#{item.mmpos5},#{item.mmp5nm},#{item.mmpos4},#{item.mmp4nm},#{item.mmpos3},#{item.mmp3nm}" +
                    ",now(),'sys','sys','copyFromEhr')",
            "</foreach>",
            "</script>"
    })
    void saveByList(List<Com_employee> com_employees);

    @Select("select * from com_employee where mmemno=#{mmemno} limit 1")
    Com_employee findByMmemno(String mmemno) throws Exception;

    @Select("select   DISTINCT mmemno, mmdnam, mmdnas, mmdept, mmcoop, mmdvcd, mmhire, mmrsgn, mmwork, mmpos5, mmp5nm, mmp5ns, mmpos4, mmp4nm, mmp4ns, mmpos3, mmp3nm, mmp3ns, mmstat  FROM com_employee " +
            "where mmdept=#{mmdept} and mmrsgn is null")
    List<Com_employee> findByDept(String mmdept) throws Exception;

    @Select("select   DISTINCT mmemno, mmdnam, mmdnas, mmdept, mmcoop, mmdvcd, mmhire, mmrsgn, mmwork, mmpos5, mmp5nm, mmp5ns, mmpos4, mmp4nm, mmp4ns, mmpos3, mmp3nm, mmp3ns, mmstat  FROM com_employee " +
            "where mmdept=#{mmdept} and mmcoop=#{department} and mmrsgn is null")
    List<Com_employee> findByDeptCode(@Param("department") String department,@Param("mmdept") String mmdept) throws Exception;

    @Select("select * from com_employee where mmrsgn >=date_sub(CURDATE() ,interval 2 day)")
    List<Com_employee> findLeaveIn2days() throws Exception;
}
