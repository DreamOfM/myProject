package com.tdk.txm_java.service;


import com.tdk.txm_java.domain.Com_user_role;

import java.util.List;

public interface ICom_user_roleService {
    List<Com_user_role> findAll() throws Exception;
    void save(Com_user_role com_user_role) throws Exception;
    void update(Com_user_role com_user_role) throws Exception;
    void delete(String roleid) throws Exception;

}
