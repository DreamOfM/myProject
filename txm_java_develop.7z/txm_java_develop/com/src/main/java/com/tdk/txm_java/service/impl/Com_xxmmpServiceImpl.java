package com.tdk.txm_java.service.impl;


import com.tdk.txm_java.dao2.ICom_xxmmpDao;
import com.tdk.txm_java.dao3.ICom_ehr_twa7pDao;
import com.tdk.txm_java.domain.Com_xxmmp;
import com.tdk.txm_java.service.ICom_xxmmpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class Com_xxmmpServiceImpl implements ICom_xxmmpService {


    @Autowired
    private ICom_xxmmpDao com_xxmmpDao;
    @Autowired
    private ICom_ehr_twa7pDao iCom_ehr_twa7pDao;


    @Override
    public Com_xxmmp findByEmployee_id(String employee_id) throws Exception {
        return com_xxmmpDao.findByMmemno(employee_id);
        //return iCom_ehr_twa7pDao.findByMmemno(employee_id);
    }
}
