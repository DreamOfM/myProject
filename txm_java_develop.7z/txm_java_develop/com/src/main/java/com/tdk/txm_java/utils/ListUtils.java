package com.tdk.txm_java.utils;

import org.apache.commons.beanutils.ConversionException;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.Converter;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.*;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class ListUtils {

    //对比二个对象list是否相同
    public static Boolean compareList(List<Object> list1,List<Object> list2) {
        if(list1.size() != list2.size())  return false;
        if(list1.getClass() != list2.getClass())  return false;

        for(Object object:list1){
            if(!list2.contains(object)){
                return false;
            }
        }
        for(Object object:list2){
            if(!list1.contains(object)){
                return false;
            }
        }
        return true;
    }
    //对比二个对象list是否相同
    public static Boolean compareListVa(List<Object> list1,List<Object> list2) {
        if(list1.size() != list2.size())  return false;
        if(list1.getClass() != list2.getClass())  return false;

        for(int i=0; i<list1.size();i++){
            if (!list1.get(i).toString().equals(list2.get(i).toString())) {
                return false;
            }
        }
        return true;
    }
//    比较二个不是对象 的list是否相同
    public static <T extends Comparable<T>> boolean compare(List<T> a, List<T> b) {
        if(a.size() != b.size())
            return false;
        Collections.sort(a);
        Collections.sort(b);
        for(int i=0;i<a.size();i++){
            if(!a.get(i).equals(b.get(i)))
                return false;
        }
        return true;
    }

}
