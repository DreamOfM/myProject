package com.tdk.txm_java.domain;


import lombok.Data;

import java.io.Serializable;
@Data
public class Com_serialnum implements Serializable {
    private String type;
    private String key01;
    private String key02;
    private String prefix_letter;
    private String prefix_yy;
    private int serialnum;

}
