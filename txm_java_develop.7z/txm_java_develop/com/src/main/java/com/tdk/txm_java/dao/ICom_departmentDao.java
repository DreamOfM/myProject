package com.tdk.txm_java.dao;

import com.tdk.txm_java.domain.Com_department;
import org.apache.ibatis.annotations.*;

import java.util.List;

public interface ICom_departmentDao {

    @Select("select * from com_department")
    List<Com_department> findAll() throws Exception;

    @Select("select  DISTINCT mrpcode from com_department  order by mrpcode ")
    List<String> findMrps() throws Exception;

    @Insert("insert into com_department(code,mrp_controller) values(#{code},#{mrp_controller})")
    void save(Com_department com_department) throws Exception;

    @Update("UPDATE com_department SET  code=#{code}, mrp_controller=#{mrp_controller} , mrpcode=#{mrpcode}where code=#{code}")
    void update(Com_department com_department);

    @Delete("delete from com_department where code=#{code}")
    void delete(String code);
}
