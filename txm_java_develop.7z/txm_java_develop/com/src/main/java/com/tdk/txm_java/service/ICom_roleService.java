package com.tdk.txm_java.service;


import com.tdk.txm_java.domain.Com_role;

import java.util.List;

public interface ICom_roleService {
    List<Com_role> findAll() throws Exception;
    void save(Com_role com_role) throws Exception;
    void update(Com_role com_role) throws Exception;
    void delete(String roleid) throws Exception;

}
