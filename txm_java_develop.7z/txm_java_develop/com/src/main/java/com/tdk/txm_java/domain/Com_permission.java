package com.tdk.txm_java.domain;

import java.util.List;

public class Com_permission {

    private int id;
    private int menu_level;
    private String root_menu;
    private String father_menu;
    private String permission_code;
    private String permission_name;
    private String permission_name_en;
    private String url;
    private int sort_num;
    private List<Com_role> roles;
    private List<Com_permission2>  com_permission2s;

    public Com_permission(int sort_num) {
        this.sort_num = sort_num;
    }

    public Com_permission(){}



    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMenu_level() {
        return menu_level;
    }

    public void setMenu_level(int menu_level) {
        this.menu_level = menu_level;
    }

    public String getRoot_menu() {
        return root_menu;
    }

    public void setRoot_menu(String root_menu) {
        this.root_menu = root_menu;
    }

    public String getFather_menu() {
        return father_menu;
    }

    public void setFather_menu(String father_menu) {
        this.father_menu = father_menu;
    }

    public String getPermission_code() {
        return permission_code;
    }

    public void setPermission_code(String permission_code) {
        this.permission_code = permission_code;
    }

    public String getPermission_name() {
        return permission_name;
    }

    public void setPermission_name(String permission_name) {
        this.permission_name = permission_name;
    }

    public String getPermission_name_en() {
        return permission_name_en;
    }

    public void setPermission_name_en(String permission_name_en) {
        this.permission_name_en = permission_name_en;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public int getSort_num() {
        return sort_num;
    }

    public void setSort_num(int sort_num) {
        this.sort_num = sort_num;
    }

    public List<Com_role> getRoles() {
        return roles;
    }

    public void setRoles(List<Com_role> roles) {
        this.roles = roles;
    }

    public List<Com_permission2> getCom_permission2s() {
        return com_permission2s;
    }

    public void setCom_permission2s(List<Com_permission2> com_permission2s) {
        this.com_permission2s = com_permission2s;
    }

    @Override
    public String toString() {
        return "Com_permission{" +
                "id=" + id +
                ", menu_level=" + menu_level +
                ", root_menu='" + root_menu + '\'' +
                ", father_menu='" + father_menu + '\'' +
                ", permission_code='" + permission_code + '\'' +
                ", permission_name='" + permission_name + '\'' +
                ", permission_name_en='" + permission_name_en + '\'' +
                ", url='" + url + '\'' +
                ", sort_num=" + sort_num +
                ", roles=" + roles +
                ", com_permission2s=" + com_permission2s +
                '}';
    }
}

