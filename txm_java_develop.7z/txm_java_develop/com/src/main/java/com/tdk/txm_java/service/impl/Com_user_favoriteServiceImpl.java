package com.tdk.txm_java.service.impl;


import com.tdk.txm_java.dao.ICom_user_favoriteDao;
import com.tdk.txm_java.domain.Com_user_favorite;
import com.tdk.txm_java.service.ICom_user_favoriteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class Com_user_favoriteServiceImpl implements ICom_user_favoriteService {


    @Autowired
    private ICom_user_favoriteDao iCom_user_favorite;

    @Override
    public List<Com_user_favorite> findAll() throws Exception {
        return iCom_user_favorite.findAll();
    }


    @Override
    public List<Com_user_favorite> findByUsername(String username) throws Exception {
        return iCom_user_favorite.findByUsername(username);
    }

    @Override
    public void save(Com_user_favorite com_user_favorite) throws Exception {
        iCom_user_favorite.save(com_user_favorite);
    }

    @Override
    public void update(Com_user_favorite com_user_favorite) throws Exception {
        iCom_user_favorite.update(com_user_favorite);
    }


    @Override
    public void deleteByUsername(String username) {
        iCom_user_favorite.deleteByUsername(username);
    }

    @Override
    public void deleteById(Integer id) {
        iCom_user_favorite.deleteById(id);
    }



}
