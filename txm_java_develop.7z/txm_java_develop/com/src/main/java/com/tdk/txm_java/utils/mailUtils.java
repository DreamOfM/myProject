package com.tdk.txm_java.utils;

import com.tdk.txm_java.domain.Com_PopupAuthenticator;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.*;
import java.util.Properties;


public class mailUtils {

//1   pom增以下依赖
//            <dependency>
//            <groupId>javax.activation</groupId>
//            <artifactId>activation</artifactId>
//            <version>1.1</version>
//        </dependency>
//        <dependency>
//            <groupId>javax.mail</groupId>
//            <artifactId>mail</artifactId>
//            <version>1.4</version>
//        </dependency>
//2    调用方式
//    String to_mail_address="tianxu_guo@cn.tdk.com,xiaoni_chen@cn.tdk.com";
//    String mail_subject="Mail Testw";
//    String mail_content="电子邮件测试内容";
//      如果要发送附件，文件地址要提供服务器的地址
//    String filePath="D:\\AS400.KMP";
//    //            String filePath="";
//    sendmail(to_mail_address,mail_subject,mail_content,filePath);

    public static void sendmail(String to_mail_address,String mail_subject,String mail_content,String filePath) {

        try{
            String userName="InfoTdk";//"myEmail@163.com";
            String password="tdkinfo";
            String smtp_server="10.23.0.16";//"smtp.163.com";
            String from_mail_address=userName;
            Authenticator auth=new Com_PopupAuthenticator(userName,password);
            Properties mailProps=new Properties();
            mailProps.put("mail.smtp.host", smtp_server);
            mailProps.put("mail.smtp.auth", "true");
            mailProps.put("username", userName);
            mailProps.put("password", password);

            Session mailSession=Session.getDefaultInstance(mailProps, auth);
            mailSession.setDebug(true);
            MimeMessage message=new MimeMessage(mailSession);
            message.setFrom(new InternetAddress(from_mail_address));
            //多值
            if (to_mail_address.contains(",")) {
                String[] split = to_mail_address.split(",");
                InternetAddress[] adr = new InternetAddress[split.length];
                for (int i = 0; i < split.length; i++) {
                    adr[i] = new InternetAddress(split[i]);
                }

                message.setRecipients(Message.RecipientType.TO, adr);

            } else{
                //单人
                message.setRecipient(Message.RecipientType.TO, new InternetAddress(to_mail_address));

            }
            message.setSubject(MimeUtility.encodeText(mail_subject, "UTF-8", "B"));
//            message.setSubject(MimeUtility.encodeText(mail_subject));
            MimeMultipart multi=new MimeMultipart();
            BodyPart textBodyPart=new MimeBodyPart();
            textBodyPart.setText(mail_content);
//            textBodyPart.setFileName("37af4739a11fc9d6b311c712.jpg");
// 根据附件路径获取文件,
            if (filePath != null && !"".equals(filePath)) {
                FileDataSource dataSource = new FileDataSource(filePath);
                textBodyPart.setDataHandler(new DataHandler(dataSource));
//MimeUtility.encodeWord可以避免文件名乱码
                textBodyPart.setFileName(MimeUtility.encodeWord(dataSource.getFile().getName()));
            }
            multi.addBodyPart(textBodyPart);
            message.setContent(multi);
            message.saveChanges();
            Transport.send(message);
        }catch(Exception ex){
            System.err.println("邮件发送失败的原因是："+ex.getMessage());
            System.err.println("具体的错误原因");
            ex.printStackTrace(System.err);
        }

    }

}
