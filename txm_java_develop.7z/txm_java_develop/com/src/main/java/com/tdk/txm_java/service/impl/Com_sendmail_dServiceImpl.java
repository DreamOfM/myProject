package com.tdk.txm_java.service.impl;


import com.tdk.txm_java.dao.ICom_sendmail_dDao;
import com.tdk.txm_java.domain.Com_sendmail_d;
import com.tdk.txm_java.service.ICom_sendmail_dService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class Com_sendmail_dServiceImpl implements ICom_sendmail_dService {


    @Autowired
    private ICom_sendmail_dDao iCom_sendmail_dDao;

    @Override
    public List<Com_sendmail_d> findAll() throws Exception {
        return iCom_sendmail_dDao.findAll();
    }

    @Override
    public Com_sendmail_d findBytype_subtype(String mail_type,String mail_subtype) throws Exception {
        return iCom_sendmail_dDao.findBytype_subtype(mail_type,mail_subtype);
    }

}
