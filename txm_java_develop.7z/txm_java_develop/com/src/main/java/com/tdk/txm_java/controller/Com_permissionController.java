package com.tdk.txm_java.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tdk.txm_java.domain.Com_department;
import com.tdk.txm_java.domain.Com_permission;
import com.tdk.txm_java.domain.Com_userInfo;
import com.tdk.txm_java.domain.Com_user_role;
import com.tdk.txm_java.service.*;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static com.tdk.txm_java.utils.DateUtils.calculateDays;

@Controller
@RequestMapping("/com_permission")
@SessionAttributes(value = {"departments","mrps","username","userInfo"})
public class Com_permissionController {


    @Autowired
    private ICom_permissionService com_permissionService;
    @Autowired
    private ICom_departmentService com_departmentService;
    @Autowired
    private ICom_userService iCom_userService;
    @Autowired
    private ICom_password_ruleService iCom_password_ruleService;
    @Autowired
    private ICom_user_roleService iCom_user_roleService;

   //查询全部
    @RequestMapping("/findAll.do")
    public ModelAndView findAll() throws Exception {
        System.out.println(1);
        ModelAndView mv = new ModelAndView();
        List<Com_permission> ls = com_permissionService.findByMenuLevel(1);
        List<Com_permission> ls2 = com_permissionService.findByMenuLevel(2);
        mv.setViewName("main");
        mv.addObject("com_permission", ls);
        mv.addObject("com_permission2", ls2);

        return mv;
    }

    //查询用户的全部权限
     @RequestMapping("/findByUsernameMenuLevel.do")
    public ModelAndView findByUsername(String username) throws Exception {
         HttpSession httpSession = null;
        System.out.println(username);
        if(username==null){
            username= (String) httpSession.getAttribute("username");
        }

        ModelAndView mv = new ModelAndView();
         Com_userInfo com_userInfo=iCom_userService.findByUsername(username);
         mv.setViewName("usr-pwd-change");
         Com_user_role com_user_role=new Com_user_role();
         com_user_role.setUserid(username);
         com_user_role.setRoleid("user");
         iCom_user_roleService.save(com_user_role);
         if(com_userInfo.getpwd_change_time()!=null) {
             int days = calculateDays(com_userInfo.getpwd_change_time());
             //取得密码变更天数
             if(days<iCom_password_ruleService.findAll().getDays()){
                 mv.setViewName("main");
             }
         }
        List<Com_permission> ls = com_permissionService.findByUsernameMenuLevel(username,1);
        List<Com_permission> ls2 = com_permissionService.findByUsernameMenuLevel(username,2);
        List<Com_department> departments = com_departmentService.findAll();
        List<String> mrps = com_departmentService.findMrps();

        mv.addObject("com_permission", ls);
        mv.addObject("com_permission2", ls2);
        mv.addObject("username", username);

         if(null==com_userInfo.getHome_page() || " "==com_userInfo.getHome_page()||com_userInfo.getHome_page().length()<10){
             com_userInfo.setHome_page("pages/welcome.jsp");
         }
        mv.addObject("userInfo", com_userInfo);
        mv.addObject("departments", departments);
        mv.addObject("mrps", mrps);
        return mv;
    }
    //查询用户的全部权限
    @RequestMapping("/findByUsername2.do")
    public ModelAndView findByUsername2(String username, HttpSession httpSession) throws Exception {
        System.out.println(username);
        if(username==null){
            username= (String) httpSession.getAttribute("username");
        }
        ModelAndView mv = new ModelAndView();
        List<Com_permission> ls = com_permissionService.findByUsernameMenuLevel(username,1);
        List<Com_permission> ls2 = com_permissionService.findByUsernameMenuLevel(username,2);
        mv.setViewName("usr-permission-list");
        mv.addObject("com_permission", ls);
        mv.addObject("com_permission2", ls2);
        return mv;
    }

    //查询全部一级菜单
    @RequestMapping("/findByMenuLevel.do")
    public ModelAndView findByLevel(@RequestParam(value="pn",defaultValue="1")Integer pn, @RequestParam(value = "PageSize", defaultValue = "5") Integer ps) throws Exception {
        //引入PageHelper分页插件
        //查询之前需要调用,,传入页码，以及每页的大小
        PageHelper.startPage(pn,ps);

        ModelAndView mv = new ModelAndView();
        List<Com_permission> ls = com_permissionService.findByMenuLevel(1);
        //startPage后面紧跟的是这个查询就是一个分页查询
        //使用pageInfo包装查询后的结果，只需要将Pageinfo交给页面就行了
        //封装了详细的分页信息，包括我们查出来的数据,传入连续显示的数据
        PageInfo page = new PageInfo(ls,ps);
        mv.setViewName("com-permission-list");
        mv.addObject("com_permission", ls);
        mv.addObject("pageInfo", page);
        System.out.println(ls);
        return mv;
    }


    //保存
    @RequestMapping("/save.do")
    public String save(Com_permission com_permission) throws Exception {
        System.out.println(com_permission);
        com_permissionService.save(com_permission);
        return "redirect:findByMenuLevel.do";
    }

    //修改
    @RequestMapping("/update.do")
    public String update(HttpServletRequest request, HttpServletResponse response) throws Exception {
        Map map = request.getParameterMap();
        Map<String, String> map2 = new HashMap<>();
        Set<String> set = map.keySet();

        int b=0;
        int c=0;
        while (1==1){
        for(String name1 : set){
            String[] vals = (String[]) map.get(name1);
            c=vals.length;
             map2.put(name1,vals[b]);

        }
        Com_permission a = new Com_permission();
        try {
            BeanUtils.populate(a,map2);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        System.out.println(a.toString());
            com_permissionService.update(a);
        b++;
        if(b==c) break;
        }
        return "redirect:findByMenuLevel.do";

    }
    //删除
    @RequestMapping("/delete.do")

    public String delete(int id) throws Exception {
        com_permissionService.delete(id);
        System.out.println(id);
        return "redirect:findByMenuLevel.do";
    }
}


