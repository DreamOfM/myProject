package com.tdk.txm_java.domain;

//与数据库中users对应
public class Com_password_rule {
    private int days;
    private int len_min;
    private int len_max;
    private String allow_letters;

    public int getDays() {
        return days;
    }

    public void setDays(int days) {
        this.days = days;
    }

    public int getLen_min() {
        return len_min;
    }

    public void setLen_min(int len_min) {
        this.len_min = len_min;
    }

    public int getLen_max() {
        return len_max;
    }

    public void setLen_max(int len_max) {
        this.len_max = len_max;
    }

    public String getAllow_letters() {
        return allow_letters;
    }

    public void setAllow_letters(String allow_letters) {
        this.allow_letters = allow_letters;
    }

    @Override
    public String toString() {
        return "Com_password_rule{" +
                "days=" + days +
                ", len_min=" + len_min +
                ", len_max=" + len_max +
                ", allow_letters='" + allow_letters + '\'' +
                '}';
    }
}
