package com.tdk.txm_java.service;


import com.tdk.txm_java.domain.Com_role;
import com.tdk.txm_java.domain.Com_user_favorite;

import java.util.List;

public interface ICom_user_favoriteService {
    List<Com_user_favorite> findAll() throws Exception;
    List<Com_user_favorite> findByUsername(String username) throws Exception;

    void save(Com_user_favorite com_user_favorite) throws Exception;
    void update(Com_user_favorite com_user_favorite) throws Exception;

    void deleteByUsername(String username);
    void deleteById(Integer id);
}
