package com.tdk.txm_java.service.impl;


import com.tdk.txm_java.dao.ICom_companyDao;
import com.tdk.txm_java.domain.Com_company;
import com.tdk.txm_java.domain.Com_role;
import com.tdk.txm_java.service.ICom_companyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class Com_companyServiceImpl implements ICom_companyService {


    @Autowired
    private ICom_companyDao iCom_companyDao;

    @Override
    public List<Com_company> findAll() throws Exception {
        return iCom_companyDao.findAll();
    }

    @Override
    public List<Com_company> findByType(String type) throws Exception {
        return iCom_companyDao.findByType(type);
    }
}
