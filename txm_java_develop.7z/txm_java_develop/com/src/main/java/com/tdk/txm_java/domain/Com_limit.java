package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Com_limit {
    private Integer start;
    private Integer end;

}