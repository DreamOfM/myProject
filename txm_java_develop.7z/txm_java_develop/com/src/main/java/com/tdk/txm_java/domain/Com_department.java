package com.tdk.txm_java.domain;

import java.io.Serializable;
import java.util.List;

//与数据库中users对应
public class Com_department implements Serializable{
    private String code;
    private String mrp_controller;
    private String mrpcode;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMrp_controller() {
        return mrp_controller;
    }

    public void setMrp_controller(String mrp_controller) {
        this.mrp_controller = mrp_controller;
    }

    public String getMrpcode() {
        return mrpcode;
    }

    public void setMrpcode(String mrpcode) {
        this.mrpcode = mrpcode;
    }

    @Override
    public String toString() {
        return "Com_department{" +
                "code='" + code + '\'' +
                ", mrp_controller='" + mrp_controller + '\'' +
                ", mrpcode='" + mrpcode + '\'' +
                '}';
    }
}
