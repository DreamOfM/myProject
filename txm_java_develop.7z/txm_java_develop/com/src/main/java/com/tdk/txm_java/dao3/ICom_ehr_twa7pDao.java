package com.tdk.txm_java.dao3;

import com.tdk.txm_java.domain.Com_employee;
import com.tdk.txm_java.domain.Com_xxmmp;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface ICom_ehr_twa7pDao {

    @Select("select  DISTINCT a7emno as mmemno,a7dnam as mmdnam,a7dept as mmdept,a7coop as mmcoop,a7dvcd as mmdvcd,case a7rsgn when ' '  then null else a7rsgn  end as mmrsgn,case a7hire when ' '  then null else a7hire  end as mmhire, a7pos5 as mmpos5,a7p5nm as mmp5nm,a7pos4 as mmpos4,a7p4nm as mmp4nm,a7pos3 as mmpos3,a7p3nm as mmp3nm  from twa7p  ")
    List<Com_employee> findAll();


    @Select("select * from twa7p where a7emno=#{mmemno}")
    @Results({
            @Result(property = "mmemno", column = "a7emno"),
            @Result(property = "mmdnam", column = "a7dnam"),
            @Result(property = "mmdept", column = "a7dept"),
            @Result(property = "mmcoop", column = "a7coop"),
            @Result(property = "mmdvcd", column = "a7dvcd"),
            @Result(property = "mmrsgn", column = "a7rsgn"),
            @Result(property = "mmhire", column = "a7hire"),
            @Result(property = "mmpos5", column = "a7pos5"),
            @Result(property = "mmp5nm", column = "a7p5nm"),
            @Result(property = "mmpos4", column = "a7pos4"),
            @Result(property = "mmp4nm", column = "a7p4nm"),
            @Result(property = "mmpos3", column = "a7pos3"),
            @Result(property = "mmp3nm", column = "a7p3nm")
    })
    Com_xxmmp findByMmemno(String mmemno);
}
