package com.tdk.txm_java.utils;

//import jdk.swing.interop.SwingInterOpUtils;
import com.tdk.txm_java.dao.ICom_employeeDao;
import com.tdk.txm_java.domain.Com_employee;
import com.tdk.txm_java.service.ICom_userService;
//import jdk.swing.interop.SwingInterOpUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.text.SimpleDateFormat;
import java.util.*;

public class BCryptPasswordEncoderUtils {
    private static BCryptPasswordEncoder bCryptPasswordEncoder=new BCryptPasswordEncoder();
    public static String encodePassword(String password){
        return bCryptPasswordEncoder.encode(password);
    }
    @Autowired
    private ICom_employeeDao iCom_employeeDao;
    
    public static void main(String[] args) {
//        String password="123";
//        String pwd = encodePassword(password);
//        System.out.println(pwd);
        //$2a$10$tJHudmJh6MRPdiL7mv0yfe0nZJbDHuhl7sSTnqNC4DauMik9ppi4K
        //$2a$10$Ce8LB3jdYDZ2f6HB281zA.4eC7v6ziJdK8MMWg0Yu8ETMg5ToMpIe
        //$2a$10$Lm6owhkHDNhlORo21snlXOrPQmFQoqFd1VL2X1XGXD/U2ADZzWqYC
        //$2a$10$St/JxkXxMAZ6vFvYTKu16Opt87Fxu.nwoNMlcioncgio2zzBoWicy
//        System.out.print(pwd.length());
//        Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("CTT"));
//        int differ = 1;
//        for(long i=1;i<=3650;i+=30) {
//            Date newDate = calendar.getTime();
//            System.out.println(i);
//            System.out.println(newDate);
//            long x=i * 24 * 60 * 60 * 1000;
//            newDate.setTime(newDate.getTime() + x);
//
//            System.out.println(i * 24 * 60 * 60 * 1000);
//            System.out.println(newDate);
//        }

//        List<Com_employee>  com_employees=
//        SimpleDateFormat sf = new SimpleDateFormat("YYYYMMdd");
//        String lastDay ;
//        Calendar cal = Calendar.getInstance();
//        System.out.println("cal=="+cal);
//        lastDay = sf.format(cal.getTime());
//        System.out.println(lastDay);
//        cal.set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), 25);
//        lastDay = sf.format(cal.getTime());
//        String aa=lastDay;
//        System.out.println(lastDay);
//        System.out.println(aa);
//        cal.add(Calendar.MONTH, 1);
//        lastDay = sf.format(cal.getTime());
//        System.out.println(lastDay);
//        cal.add(Calendar.DATE, -1);
//        lastDay = sf.format(cal.getTime());
//        System.out.println(lastDay);

//        Calendar cal = Calendar.getInstance();
//                可抵扣日期为上月25前  -- 当前日期小于15号，截止日期为上月25号
//        if(cal.get(Calendar.DAY_OF_MONTH)>15){
//            cal.set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), 25);
//        }else{
//            //    (3月&12月为当月25号前)     -- 当前日期大于15号，截止日期为当月25号
//        }
//        System.out.println(cal);
//        cal.set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), 28);
//        System.out.println(cal);
//        int xx= cal.get(Calendar.YEAR)*10000 +cal.get(Calendar.MONTH)*100+ 25 ;
//        System.out.println(xx);
//        cal.add(Calendar.MONTH,-1);
//        int xx2= cal.get(Calendar.YEAR)*10000 +cal.get(Calendar.MONTH)*100+ 25 ;
//        System.out.println(xx);
//        System.out.println(xx2);
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        System.out.println(sdf.format(date));
        SimpleDateFormat sdf2 = new SimpleDateFormat("yyyyMM");
        System.out.println(sdf2.format(date));
        String create_month= DateUtils.date2String(new Date(),"YYYYMMdd");
        System.out.println(create_month);
        create_month= DateUtils.date2String(new Date(),"YYYYMMDD");
        System.out.println(create_month);
        Calendar cal = Calendar.getInstance();
        cal.set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), 21);
        String year=String.valueOf(cal.YEAR);
        String m=String.valueOf(cal.get(cal.MONTH));

        String date_1= String.valueOf(cal.get(Calendar.YEAR)*10000 +cal.get(Calendar.MONTH)*100+21);
        String date_2= String.valueOf(cal.get(Calendar.YEAR)*10000 +cal.get(Calendar.MONTH)*100+21);
//        List<Integer> a = Arrays.asList(1,2,3,4);
//        List<Integer> b = Arrays.asList(4,3,2,1);
//        System.out.println(ListUtils.compare(a, b));
//
//        Com_employee com_employee=new Com_employee();
//        com_employee.setMmemno("1");
//        Com_employee com_employee2=new Com_employee();
//        com_employee2.setMmemno("1");
//        List<Object> list1=new ArrayList<>();
//        List<Object> list2=new ArrayList<>();
//        list1.add(com_employee);
//        list2.add(com_employee2);
//        com_employee.setMmemno("2");
//        com_employee2.setMmemno("2");
//        list1.add(com_employee);
//        list2.add(com_employee2);
//        System.out.println(ListUtils.compareListVa(list1, list2));
//        Boolean xx=ListUtils.compareListVa(list1, list2);
    }
}
