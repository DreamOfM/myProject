package com.tdk.txm_java.controller;

import com.tdk.txm_java.dao.ICom_employeeDao;
import com.tdk.txm_java.dao3.ICom_ehr_twa7pDao;
import com.tdk.txm_java.dao4.ICom_uid_delidDao;
import com.tdk.txm_java.domain.Com_employee;
import com.tdk.txm_java.service.ICom_employeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;

import static com.tdk.txm_java.utils.mailUtils.sendmail;

/**
 * 类名称：TimerTask
 * 类描述：定时器任务
 * 创建人：geekfly
 * 创建时间：Aug 29, 2016 10:56:27 AM
 *
 * @version V1.0
 */
//CRON表达式 含
//    秒（Seconds）	    0~59的整数	        , - * /    四个字符
//    分（Minutes）	    0~59的整数	        , - * /    四个字符
//    小时（Hours）	        0~23的整数	        , - * /    四个字符
//    日期（DayofMonth）	1~31的整数    	    ,- * ? / L W C     八个字符
//    月份（Month）	        1~12的整数者 JAN-DEC	, - * /    四个字符
//    星期（DayofWeek）	    1~7的整数或者 SUN-SAT , - * ? / L C #     八个字符
//    年(可选，留空)（Year）	1970~2099	        , - * /    四个字符
//    （1）*：表示匹配该域的任意值。假如在Minutes域使用*, 即表示每分钟都会触发事件。
//    （2）?：只能用在DayofMonth和DayofWeek两个域。它也匹配域的任意值，但实际不会。因为DayofMonth和DayofWeek会相互影响。
//          例如想在每月的20日触发调度，不管20日到底是星期几，则只能使用如下写法： 13 13 15 20 * ?, 其中最后一位只能用？，而不能使用*，如果使用*表示不管星期几都会触发，实际上并不是这样。
//    （3）-：表示范围。例如在Minutes域使用5-20，表示从5分到20分钟每分钟触发一次 
//    （4）/：表示起始时间开始触发，然后每隔固定时间触发一次。例如在Minutes域使用5/20,则意味着5分钟触发一次，而25，45等分别触发一次. 
//    （5）,：表示列出枚举值。例如：在Minutes域使用5,20，则意味着在5和20分每分钟触发一次。 
//    （6）L：表示最后，只能出现在DayofWeek和DayofMonth域。如果在DayofWeek域使用5L,意味着在最后的一个星期四触发。 
//    （7）W:表示有效工作日(周一到周五),只能出现在DayofMonth域，系统将在离指定日期的最近的有效工作日触发事件。
//           例如：在 DayofMonth使用5W，如果5日是星期六，则将在最近的工作日：星期五，即4日触发。如果5日是星期天，则在6日(周一)触发；如果5日在星期一到星期五中的一天，则就在5日触发。另外一点，W的最近寻找不会跨过月份 。
//    （8）LW:这两个字符可以连用，表示在某个月最后一个工作日，即最后一个星期五。 
//    （9）#:用于确定每个月第几个星期几，只能出现在DayofMonth域。例如在4#2，表示某月的第二个星期三。
//        “0 0 12 * * ?” 每天中午十二点触发
//        “0 15 10 ? * *” 每天早上10：15触发
//        “0 15 10 * * ?” 每天早上10：15触发
//        “0 15 10 * * ? *” 每天早上10：15触发
//        “0 15 10 * * ? 2005” 2005年的每天早上10：15触发
//        “0 * 14 * * ?” 每天从下午2点开始到2点59分每分钟一次触发
//        “0 0/5 14 * * ?” 每天从下午2点开始到2：55分结束每5分钟一次触发
//        “0 0/5 14,18 * * ?” 每天的下午2点至2：55和6点至6点55分两个时间段内每5分钟一次触发
//        “0 0-5 14 * * ?” 每天14:00至14:05每分钟一次触发
//        “0 10,44 14 ? 3 WED” 三月的每周三的14：10和14：44触发
@Component
public class Com_task_sysController {
    @Autowired
    private ICom_employeeService iCom_employeeService;
    @Autowired
    private ICom_uid_delidDao  iCom_uid_delidDao;

//    每天定时同步ehr的工号信息
//    @Scheduled(cron = "0 0  8-17 * * ?")
////    public void copyFromEhr() throws Exception {
////        iCom_employeeService.copyFromEhr();
////    }
//        @Scheduled(cron = "0 57  8-17 * * ?")
//    public void deleteUID() {
////            iCom_employeeService
//            iCom_uid_delidDao.deleteById();
//    }

//    @Scheduled(cron = "0 0 8  ? * MON-FRI")//工作日早上8点触发
//    public void run_ok() throws IOException {
//        File file = new File("");
//        String filePath2 = file.getCanonicalPath();
//        if (filePath2 == "C:\\Program Files\\Apache Software Foundation\\Tomcat 9.0\\webapps\\txm_java_web") {
//            String to_mail_address = "tianxu_guo@cn.tdk.com";
//            String mail_subject = String.valueOf(InetAddress.getLocalHost());
//            String mail_content = filePath2;
////        String filePath="D:\\AS400.KMP";
//            String filePath = "";
//            sendmail(to_mail_address, mail_subject, mail_content, filePath);
//            System.out.println("job2 start");
//        }
//    }


}