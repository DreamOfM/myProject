package com.tdk.txm_java.service.impl;


import com.tdk.txm_java.dao.ICom_roleDao;
import com.tdk.txm_java.domain.Com_role;
import com.tdk.txm_java.service.ICom_roleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class Com_roleServiceImpl implements ICom_roleService {


    @Autowired
    private ICom_roleDao iCom_roleDao;

    @Override
    public List<Com_role> findAll() throws Exception {
        return iCom_roleDao.findAll();
    }

    @Override
    public void save(Com_role com_role) throws Exception {
        iCom_roleDao.save(com_role);

    }

    @Override
    public void update(Com_role com_role) throws Exception {
        iCom_roleDao.update(com_role);

    }

    @Override
    public void delete(String roleid) throws Exception {
iCom_roleDao.delete(roleid);
    }
}
