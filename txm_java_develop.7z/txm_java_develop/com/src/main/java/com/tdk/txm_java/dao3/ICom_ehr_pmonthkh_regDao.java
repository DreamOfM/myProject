package com.tdk.txm_java.dao3;


import org.apache.ibatis.annotations.Param;

import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;


@Repository
public interface ICom_ehr_pmonthkh_regDao {
    @Select("select  AbsLev+PersonalLev  from pmonthkh_reg where Badge=#{badge}  and  DATEDIFF(mm,term,#{month})=0")
    Double findByNoMonth(@Param("badge") String badge,@Param("month") String month);

}

