package com.tdk.txm_java.utils;

import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

/**
*@Description: 上传工具类
*@Author: a135109
*@time: 2020/1/8 11:28
*/
public class UploadUtils {
    public String upload(MultipartFile imgFile, HttpServletRequest request) throws Exception {
        //1. 获取上传的目录路径
        String path = request.getSession().getServletContext().getRealPath("/upload");
        //2. 以天为单位，一天创建一个文件夹，保存当天上传的文件
        String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());

        //3. 创建目录
        File file = new File(path,date);
        if (!file.exists()){
            // 创建目录或子目录
            file.mkdirs();
        }

        //4. 文件上传
        //4.1 获取原始文件名
        String fileName = imgFile.getOriginalFilename();
        fileName = UUID.randomUUID().toString() + fileName.substring(fileName.lastIndexOf("."));
        //4.2 文件上传
        imgFile.transferTo(new File(file,fileName));

        String returnFile = new String(file.getAbsolutePath()+"\\"+fileName);
        return returnFile;
    }

}
