package com.tdk.txm_java.service.impl;


import com.tdk.txm_java.dao.ICom_departmentDao;
import com.tdk.txm_java.domain.Com_department;
import com.tdk.txm_java.service.ICom_departmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class Com_departmentServiceImpl implements ICom_departmentService {


    @Autowired
    private ICom_departmentDao iCom_departmentDao;

    @Override
    public List<Com_department> findAll() throws Exception {
        return iCom_departmentDao.findAll();
    }

    @Override
    public List<String> findMrps() throws Exception {
        return iCom_departmentDao.findMrps();
    }

    @Override
    public void save(Com_department com_department) throws Exception {
        iCom_departmentDao.save(com_department);

    }

    @Override
    public void update(Com_department com_department) throws Exception {
        iCom_departmentDao.update(com_department);

    }

    @Override
    public void delete(String code) throws Exception {
    iCom_departmentDao.delete(code);
    }
}
