package com.tdk.txm_java.service.impl;


import com.tdk.txm_java.dao2.ICom_tmbppDao;
import com.tdk.txm_java.domain.Com_rate;
import com.tdk.txm_java.domain.Com_tmbpp;
import com.tdk.txm_java.service.ICom_rateService;
import com.tdk.txm_java.service.ICom_tmbppService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Service
@Transactional
public class Com_tmbppServiceImpl implements ICom_tmbppService {


    @Autowired
    private ICom_tmbppDao com_tmbppDao;
    @Autowired
    private ICom_rateService iCom_rateService;


    @Override
    public Integer findByTable() throws Exception {
        return com_tmbppDao.findByTable();
    }
//取得AS400 TMBPP的相应最低单价
    @Override
    public Double findByItemcode(String itemcode) throws Exception {
        List<Com_tmbpp> com_tmbpps= com_tmbppDao.findByItemcode(itemcode);
        Double low_price=0.00000;
        String currency="";
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
        Date today = new Date();
        int date7 = Integer.parseInt(format.format(today)) - 19000000;
        for(Com_tmbpp com_tmbpp:com_tmbpps) {
            if (date7>=Integer.parseInt(com_tmbpp.getBpstdt())&&date7<=Integer.parseInt(com_tmbpp.getBpltdt())) {
                currency = com_tmbpp.getSucurr();
                if (low_price == 0) {
                    low_price = com_tmbpp.getBpppr1();
                } else {
                    low_price = com_tmbpp.getBpppr1() > low_price ? low_price : com_tmbpp.getBpppr1();
                }
            }
        }
        if(low_price>0&&!currency.equals("RMB")&&!currency.equals("   ")){
            Com_rate com_rate = new Com_rate();
            com_rate.setCurrency(currency);
            com_rate.setType("D");
            low_price = low_price * iCom_rateService.findByCurDateType(com_rate);

        }
        return  low_price;
    }
}
