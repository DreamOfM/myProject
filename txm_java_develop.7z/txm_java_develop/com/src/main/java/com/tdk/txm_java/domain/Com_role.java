package com.tdk.txm_java.domain;

import java.util.List;

public class Com_role {
    private String roleid;
    private String role_desc;
    private List<Com_permission> permissions;
    private List<Com_userInfo> users;

    public List<Com_permission> getPermissions() {
        return permissions;
    }

    public void setPermissions(List<Com_permission> permissions) {
        this.permissions = permissions;
    }

    public String getRoleid() {
        return roleid;
    }

    public void setRoleid(String roleid) {
        this.roleid = roleid;
    }

    public String getRole_desc() {
        return role_desc;
    }

    public void setRole_desc(String role_desc) {
        this.role_desc = role_desc;
    }


    public List<Com_userInfo> getUsers() {
        return users;
    }

    public void setUsers(List<Com_userInfo> users) {
        this.users = users;
    }
}
