package com.tdk.txm_java.service;


import com.tdk.txm_java.domain.Com_rate;
import com.tdk.txm_java.domain.Com_xxmmp;

public interface ICom_xxmmpService {
    Com_xxmmp findByEmployee_id(String employee_id) throws Exception;

}
