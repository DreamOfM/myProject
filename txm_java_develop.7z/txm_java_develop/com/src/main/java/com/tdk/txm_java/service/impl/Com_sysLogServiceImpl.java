package com.tdk.txm_java.service.impl;

import com.tdk.txm_java.dao.ICom_sysLogDao;
import com.tdk.txm_java.domain.Com_sysLog;
import com.tdk.txm_java.service.ICom_sysLogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class Com_sysLogServiceImpl implements ICom_sysLogService {

    @Autowired
    private ICom_sysLogDao sysLogDao;

    @Override
    public List<Com_sysLog> findAll() throws Exception {
        return sysLogDao.findAll();
    }

    @Override
    public void save(Com_sysLog sysLog) throws Exception {
        sysLogDao.save(sysLog);
    }
}
