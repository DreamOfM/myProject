package com.tdk.txm_java.dao2;

import com.tdk.txm_java.domain.Com_rate;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ICom_rateDao {

    @Select("select count(*) from wavedbf.txknp ")
    Integer findByTable();
    @Select("select KNEXRT from wavedbf.txknp where kncurr=#{currency} and KNTRDT=#{rate_date} and KNEXTP=#{type}   ")
    Double findByCurDateType(Com_rate com_rate);
}
