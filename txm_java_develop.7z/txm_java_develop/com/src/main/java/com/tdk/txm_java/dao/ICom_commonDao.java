package com.tdk.txm_java.dao;


import com.tdk.txm_java.domain.Com_common;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.security.core.parameters.P;

import java.util.List;

public interface ICom_commonDao {

    @Select("select * from com_common")
    List<Com_common> findAll() throws Exception;

    @Select("select * from com_common where key1=#{key1} ")
    Com_common  findByKey1(String key1) throws Exception;

    @Select("select * from com_common where key1=#{key1}  and  key2=#{key2} ")
    Com_common  findByKeys(@Param("key1") String key1,@Param("key2") String key2) throws Exception;

}
