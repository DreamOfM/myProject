package com.tdk.txm_java.service;


import com.tdk.txm_java.domain.Com_tmbpp;
import com.tdk.txm_java.domain.Com_xxmmp;

import java.util.List;

public interface ICom_tmbppService {
    Integer findByTable() throws Exception;
    Double findByItemcode(String itemcode) throws Exception;

}
