package com.tdk.txm_java.dao;


import com.tdk.txm_java.domain.Com_user_role;
import org.apache.ibatis.annotations.*;

import java.util.List;

public interface ICom_user_roleDao {


    @Select("select * from com_user_role")
    List<Com_user_role> findAll() throws Exception;

    @Select("select * from com_user_role where userid=#{userid} and roleid=#{roleid} ")
    Com_user_role findByUserRole(Com_user_role com_user_role) throws Exception;

    @Delete("delete from com_user_role where usereid=#{userid}")
    void delete(String userid);

    @Insert("insert into com_user_role(userid,roleid,login_time) values(#{userid},#{roleid},now())")
    void save(Com_user_role com_user_role) throws Exception;

    @Update("UPDATE com_user_role SET   where userid=#{userid}")
    void update(Com_user_role com_user_role);


}
