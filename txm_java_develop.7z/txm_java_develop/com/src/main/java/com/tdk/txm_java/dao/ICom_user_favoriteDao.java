package com.tdk.txm_java.dao;


import com.tdk.txm_java.domain.Com_user_favorite;
import org.apache.ibatis.annotations.*;

import java.util.List;

public interface ICom_user_favoriteDao {

    @Select("select * from com_user_favorite")
    List<Com_user_favorite> findAll() throws Exception;

    @Select("select * from com_user_favorite where username=#{username} ")
    List<Com_user_favorite>  findByUsername(String username) throws Exception;

    @Update("UPDATE com_user_favorite SET  username=#{username}, permissionid=#{permissionid},permission_name=#{permission_name},self_name=#{self_name} where id=#{id}")
    void update(Com_user_favorite com_user_favorite);

    @Insert("insert into com_user_favorite(username, permissionid,permission_name,self_name) values(#{username}, #{permissionid},#{permission_name},#{self_name})")
    void save(Com_user_favorite com_user_favorite);

    @Delete("delete com_user_favorite where username=#{username}")
    void deleteByUsername(String username);

    @Delete("delete com_user_favorite where id=#{id}")
    void deleteById(Integer id);

}
