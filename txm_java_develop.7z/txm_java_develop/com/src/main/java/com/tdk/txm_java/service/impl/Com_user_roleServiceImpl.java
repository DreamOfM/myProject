package com.tdk.txm_java.service.impl;


import com.tdk.txm_java.dao.ICom_user_roleDao;
import com.tdk.txm_java.domain.Com_user_role;
import com.tdk.txm_java.service.ICom_user_roleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class Com_user_roleServiceImpl implements ICom_user_roleService {


    @Autowired
    private ICom_user_roleDao iCom_user_roleDao;

    @Override
    public List<Com_user_role> findAll() throws Exception {
        return iCom_user_roleDao.findAll();
    }


    @Override
    public void save(Com_user_role com_user_role) throws Exception {
        if(iCom_user_roleDao.findByUserRole(com_user_role)==null) {
            iCom_user_roleDao.save(com_user_role);
        }
    }

    @Override
    public void update(Com_user_role com_user_role) throws Exception {
        iCom_user_roleDao.update(com_user_role);

    }

    @Override
    public void delete(String roleid) throws Exception {
iCom_user_roleDao.delete(roleid);
    }
}
