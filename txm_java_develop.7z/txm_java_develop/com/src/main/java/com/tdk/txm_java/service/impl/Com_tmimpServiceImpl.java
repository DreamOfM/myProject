package com.tdk.txm_java.service.impl;


import com.tdk.txm_java.dao2.ICom_tmimpDao;
import com.tdk.txm_java.domain.Com_tmimp;
import com.tdk.txm_java.service.ICom_tmimpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class Com_tmimpServiceImpl implements ICom_tmimpService {


    @Autowired
    private ICom_tmimpDao com_tmimpDao;


    @Override
    public Com_tmimp findByItemcode(String itemcode) throws Exception {
        return com_tmimpDao.findByItemcode(itemcode);
    }

    @Override
    public List<Com_tmimp> findByItemSpec(String itemcode, String imspec) throws Exception {
        return com_tmimpDao.findByItemSpec(itemcode,imspec);
    }

    @Override
    public List<Com_tmimp> findByItemSpec2All(String itemcode, String imspec) throws Exception {
        return com_tmimpDao.findByItemSpec2All(itemcode,imspec);
    }
}
