package com.tdk.txm_java.service.impl;


import com.tdk.txm_java.dao2.ICom_rateDao;
import com.tdk.txm_java.domain.Com_rate;
import com.tdk.txm_java.service.ICom_rateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.Date;

@Service
@Transactional
public class Com_rateServiceImpl implements ICom_rateService {


    @Autowired
    private ICom_rateDao com_rateDao;


    @Override
    public Integer findByTable() throws Exception {
        return com_rateDao.findByTable();
    }

    @Override
    public Double findByCurDateType(Com_rate com_rate) throws Exception {
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
        Date today = new Date();
        int date7 = Integer.parseInt(format.format(today)) - 19000000;
        com_rate.setRate_date(date7);
        return com_rateDao.findByCurDateType(com_rate);
    }
}
