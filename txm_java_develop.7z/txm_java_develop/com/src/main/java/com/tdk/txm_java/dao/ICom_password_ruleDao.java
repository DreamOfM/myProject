package com.tdk.txm_java.dao;


import com.tdk.txm_java.domain.Com_password_rule;
import org.apache.ibatis.annotations.*;


public interface ICom_password_ruleDao {


        @Select("select * from com_password_rule")
        Com_password_rule findAll() throws Exception;

    }



