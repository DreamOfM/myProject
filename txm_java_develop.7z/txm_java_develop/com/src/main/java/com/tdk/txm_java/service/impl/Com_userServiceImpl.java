package com.tdk.txm_java.service.impl;


import com.tdk.txm_java.dao.ICom_userDao;
import com.tdk.txm_java.domain.Com_role;
import com.tdk.txm_java.domain.Com_userInfo;
import com.tdk.txm_java.service.ICom_userService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import java.text.SimpleDateFormat;
import java.util.ArrayList;

import java.util.Date;
import java.util.List;

@Service("userService")
@Transactional
public class Com_userServiceImpl implements ICom_userService {


    @Autowired
    private ICom_userDao com_userDao;
    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    @Override
    public void addRoleToUser(String username, String[] roleIds) {

        for(String roleId:roleIds){
            com_userDao.addRoleToUser(username,roleId);
        }
    }

    @Override
    public void delete(String username) {
        com_userDao.delete(username);
    }

    @Override
    public List<Com_role> findOtherRoles(String username) {
        return com_userDao.findOtherRoles(username);
    }

    @Override
    public Com_userInfo findByUsername(String username) throws Exception{

        return  com_userDao.findByUsername(username);
    }
    @Override
    public Com_userInfo findByUsernamePwd(String username,String pwd) throws Exception{
       String pwd2=bCryptPasswordEncoder.encode(pwd);
        return  com_userDao.findByUsernamePwd(username,pwd2);
    }

    @Override
    public void save(Com_userInfo com_userInfo) throws Exception {
        //对密码进行加密处理
        com_userInfo.setPassword(bCryptPasswordEncoder.encode(com_userInfo.getPassword()));

        if(null==com_userInfo.getHome_page() || ""==com_userInfo.getHome_page()){
            com_userInfo.setHome_page("pages/welcome.jsp");
        }
        com_userDao.save(com_userInfo);
    }

    @Override
    public void update(Com_userInfo com_userInfo) throws Exception {
        com_userInfo.setPassword(bCryptPasswordEncoder.encode(com_userInfo.getPassword()));
        com_userDao.update(com_userInfo);
    }

    @Override
    public void updatePwd(Com_userInfo com_userInfo) throws Exception {
        com_userInfo.setPassword(bCryptPasswordEncoder.encode(com_userInfo.getPassword()));
        com_userDao.updatePwd(com_userInfo);
    }

    //初始化密码等于帐号
    @Override
    public void initializePwd(Com_userInfo com_userInfo) throws Exception {
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//        Date date = sdf.parse("2000-01-01");
//        com_userInfo.setpwd_change_time((java.sql.Date) date);
        com_userInfo.setPassword(bCryptPasswordEncoder.encode(com_userInfo.getUsername()));
        com_userDao.initializePwd(com_userInfo);
    }


    @Override
    public List<Com_userInfo> findAll() throws Exception {
        return com_userDao.findAll();
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Com_userInfo com_userInfo = null;
        System.out.println(username);
        try {
            com_userInfo = com_userDao.findByUsername(username);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(com_userInfo);
        System.out.println(com_userInfo.toString());

//        记录登陆时间
        com_userDao.updateUserlogintime(username);

        //处理自己的用户对象封装成UserDetails
        //  User user=new User(userInfo.getUsername(),"{noop}"+userInfo.getPassword(),getAuthority(userInfo.getRoles()));
        User user = new User(com_userInfo.getUsername(), com_userInfo.getPassword(), com_userInfo.getStatus() == 0 ? false : true, true, true, true, getAuthority(com_userInfo.getCom_roles()));
        System.out.println(user);

        return user;
    }

    //作用就是返回一个List集合，集合中装入的是角色描述
    public List<SimpleGrantedAuthority> getAuthority(List<Com_role> roles) {

        List<SimpleGrantedAuthority> list = new ArrayList<>();
        for (Com_role com_role : roles) {
//            list.add(new SimpleGrantedAuthority("ROLE_" + com_role.getRoleid()));
            list.add(new SimpleGrantedAuthority("ROLE_USER"));
        }
        return list;
    }
}
