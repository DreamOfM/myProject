package com.tdk.txm_java.service;


import com.tdk.txm_java.domain.Com_department;

import java.util.List;

public interface ICom_departmentService  {
    List<Com_department> findAll() throws Exception;

    List<String> findMrps() throws Exception;

    void save(Com_department com_department) throws Exception;
    void update(Com_department com_department) throws Exception;

    void delete(String username)throws Exception;
}
