package com.tdk.txm_java.service.impl;


import com.tdk.txm_java.dao.ICom_employeeDao;
import com.tdk.txm_java.dao3.ICom_ehr_twa7pDao;
import com.tdk.txm_java.domain.Com_employee;
import com.tdk.txm_java.service.ICom_employeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class Com_employeeServiceImpl implements ICom_employeeService {


    @Autowired
    private ICom_employeeDao com_employeeDao;
    @Autowired
    private ICom_ehr_twa7pDao iCom_ehr_twa7pDao;


    @Override
    public Com_employee findByEmployee_id(String employee_id) throws Exception {
        return com_employeeDao.findByMmemno(employee_id);
    }

    @Override
    public void copyFromEhr() {
        List<Com_employee> ces = iCom_ehr_twa7pDao.findAll();
        if(ces.size()>0) {
            com_employeeDao.deleteAll();
            //数据量太大，分批保存
            if (ces.size() > 2000) {
                List<Com_employee> ces02 = new ArrayList<>();
                int a = 1;
                for (Com_employee com_employee : ces) {
                    ces02.add(com_employee);
                    if (a == 2000) {
                        com_employeeDao.saveByList(ces02);
                        ces02.clear();
                        a = 1;
                    }
                    a++;
                }
                if (ces02.size() > 0){
                    com_employeeDao.saveByList(ces02);
                }
            } else {
                com_employeeDao.saveByList(ces);
            }
        }

    }

    @Override
    public List<Com_employee> findByDept(String mmdept) throws Exception {
        return com_employeeDao.findByDept(mmdept);
    }

    @Override
    public List<Com_employee> findByDeptCode(String department,String mmdept) throws Exception {
        return com_employeeDao.findByDeptCode(department,mmdept);
    }
}
