package com.tdk.txm_java.service;

import com.tdk.txm_java.domain.Com_permission;

import java.util.List;

public interface ICom_permissionService {

    public List<Com_permission> findAll() throws Exception;
    public List<Com_permission> findByMenuLevel(int menu_level) throws Exception;
    public List<Com_permission> findByUsername(String username) throws Exception;
    public List<Com_permission> findByUsernameMenuLevel(String username, int menu_level) throws Exception;

    Com_permission findById(int id) throws Exception;

    public List<Com_permission> findByRoleid(String roleid) throws Exception;

    void save(Com_permission com_permission) throws Exception;

    void update(Com_permission com_permission) throws Exception;
    void delete(int id) throws Exception;



}
