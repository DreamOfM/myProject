package com.tdk.txm_java.service;


import com.tdk.txm_java.domain.Com_role;
import com.tdk.txm_java.domain.Com_userInfo;
import org.springframework.security.core.userdetails.UserDetailsService;

import java.util.List;

public interface ICom_userService extends UserDetailsService {
    List<Com_userInfo> findAll() throws Exception;

    void save(Com_userInfo com_userInfo) throws Exception;
    void update(Com_userInfo com_userInfo) throws Exception;
    void updatePwd(Com_userInfo com_userInfo) throws Exception;
    void initializePwd(Com_userInfo com_userInfo) throws Exception;

    Com_userInfo findByUsername(String username) throws Exception;
    public Com_userInfo findByUsernamePwd(String username,String pwd) throws Exception;
    List<Com_role> findOtherRoles(String userId) throws Exception;

    void addRoleToUser(String userId, String[] roleIds);
    void delete(String username);
}
