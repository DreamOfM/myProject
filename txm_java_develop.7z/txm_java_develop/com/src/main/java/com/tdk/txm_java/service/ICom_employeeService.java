package com.tdk.txm_java.service;


import com.tdk.txm_java.domain.Com_employee;

import java.util.List;

public interface ICom_employeeService {
    Com_employee findByEmployee_id(String employee_id) throws Exception;
    void copyFromEhr() throws Exception;
    List<Com_employee> findByDept(String mmdept) throws Exception;

    List<Com_employee> findByDeptCode(String department, String mmdept) throws Exception;
}
