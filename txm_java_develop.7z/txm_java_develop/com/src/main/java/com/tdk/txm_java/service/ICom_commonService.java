package com.tdk.txm_java.service;


import com.tdk.txm_java.domain.Com_common;

import java.util.List;

public interface ICom_commonService {
    List<Com_common> findAll() throws Exception;
  Com_common findByKey1(String key1) throws Exception;

    Com_common findByKeys(String key1, String key2) throws Exception;
}
