package com.tdk.txm_java.service.impl;


import com.tdk.txm_java.dao.ICom_commonDao;
import com.tdk.txm_java.domain.Com_common;
import com.tdk.txm_java.service.ICom_commonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class Com_commonServiceImpl implements ICom_commonService {


    @Autowired
    private ICom_commonDao iCom_commonDao;

    @Override
    public List<Com_common> findAll() throws Exception {
        return iCom_commonDao.findAll();
    }

    @Override
    public Com_common findByKey1(String key1) throws Exception {
        return iCom_commonDao.findByKey1(key1);
    }

    @Override
    public Com_common findByKeys(String key1,String key2) throws Exception {
        return iCom_commonDao.findByKeys(key1,key2);
    }

}
