package com.tdk.txm_java.service.impl;


import com.tdk.txm_java.dao.ICom_permissionDao;
import com.tdk.txm_java.domain.Com_permission;
import com.tdk.txm_java.service.ICom_permissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class Com_permissionServiceImpl implements ICom_permissionService {

    @Autowired
    private ICom_permissionDao com_permissionDao;

    @Override
    public List<Com_permission> findAll() throws Exception {
        return com_permissionDao.findAll();
    }

    @Override
    public List<Com_permission> findByMenuLevel(int menu_level) throws Exception {
        return com_permissionDao.findByMenuLevel(menu_level);
    }

    @Override
    public List<Com_permission> findByUsername(String username) throws Exception {
        return com_permissionDao.findByUsername(username);
    }

    @Override
    public List<Com_permission> findByUsernameMenuLevel(String username, int menu_level) throws Exception {
        return com_permissionDao.findByUsernameMenuLevel(username,menu_level);
    }
    @Override
    public Com_permission findById(int id) throws Exception{
        return com_permissionDao.findById(id);
    }
    @Override
    public List<Com_permission> findByRoleid(String roleid) throws Exception {
        return com_permissionDao.findByUsername(roleid);
    }

    @Override
    public void save(Com_permission com_permission) throws Exception {
        com_permissionDao.save(com_permission);
    }

    @Override
    public void update(Com_permission com_permission) throws Exception {
        com_permissionDao.update(com_permission);
    }

    @Override
    public void delete(int id) throws Exception {
        com_permissionDao.delete(id);
    }


}
