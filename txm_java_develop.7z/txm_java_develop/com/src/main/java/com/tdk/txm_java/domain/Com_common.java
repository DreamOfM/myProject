package com.tdk.txm_java.domain;

public class Com_common {
    private String key1;
    private String key2;
    private String char1;
    private Integer int1;

    public String getKey1() {
        return key1;
    }

    public void setKey1(String key1) {
        this.key1 = key1;
    }

    public String getKey2() {
        return key2;
    }

    public void setKey2(String key2) {
        this.key2 = key2;
    }

    public String getChar1() {
        return char1;
    }

    public void setChar1(String char1) {
        this.char1 = char1;
    }

    public Integer getInt1() {
        return int1;
    }

    public void setInt1(Integer int1) {
        this.int1 = int1;
    }

    @Override
    public String toString() {
        return "Com_common{" +
                "key1='" + key1 + '\'' +
                ", key2='" + key2 + '\'' +
                ", char1='" + char1 + '\'' +
                ", int1=" + int1 +
                '}';
    }
}
