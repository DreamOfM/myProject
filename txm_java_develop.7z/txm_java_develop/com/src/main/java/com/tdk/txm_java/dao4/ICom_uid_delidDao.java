package com.tdk.txm_java.dao4;

import com.tdk.txm_java.domain.Com_employee;
import com.tdk.txm_java.domain.Com_xxmmp;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface ICom_uid_delidDao {

    @Select(" call  DeleteUserByUserId('test2')  ")
    List<String> deleteById();

}
