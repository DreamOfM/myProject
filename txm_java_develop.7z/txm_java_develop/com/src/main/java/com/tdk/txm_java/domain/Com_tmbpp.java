package com.tdk.txm_java.domain;

//与数据库中users对应
public class Com_tmbpp {
    private String bpitnr;
    private String bpvdnr;
    private String bpstdt;
    private String bpltdt;
    private String sustdt;
    private Double bpppr1;
    private String sucurr;

    public String getBpitnr() {
        return bpitnr;
    }

    public void setBpitnr(String bpitnr) {
        this.bpitnr = bpitnr;
    }

    public String getBpvdnr() {
        return bpvdnr;
    }

    public void setBpvdnr(String bpvdnr) {
        this.bpvdnr = bpvdnr;
    }

    public String getBpstdt() {
        return bpstdt;
    }

    public void setBpstdt(String bpstdt) {
        this.bpstdt = bpstdt;
    }

    public String getBpltdt() {
        return bpltdt;
    }

    public void setBpltdt(String bpltdt) {
        this.bpltdt = bpltdt;
    }

    public String getSustdt() {
        return sustdt;
    }

    public void setSustdt(String sustdt) {
        this.sustdt = sustdt;
    }

    public Double getBpppr1() {
        return bpppr1;
    }

    public void setBpppr1(Double bpppr1) {
        this.bpppr1 = bpppr1;
    }

    public String getSucurr() {
        return sucurr;
    }

    public void setSucurr(String sucurr) {
        this.sucurr = sucurr;
    }

    @Override
    public String toString() {
        return "Com_tmbpp{" +
                "bpitnr='" + bpitnr + '\'' +
                ", bpvdnr='" + bpvdnr + '\'' +
                ", bpstdt='" + bpstdt + '\'' +
                ", bpltdt='" + bpltdt + '\'' +
                ", sustdt='" + sustdt + '\'' +
                ", bpppr1='" + bpppr1 + '\'' +
                ", sucurr='" + sucurr + '\'' +
                '}';
    }
}
