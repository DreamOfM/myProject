package com.tdk.txm_java.controller;

import com.tdk.txm_java.domain.Com_role;
import com.tdk.txm_java.service.ICom_roleService;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Controller
@RequestMapping("/com_role")
public class Com_roleController {


    @Autowired
    private ICom_roleService iCom_roleService;


       //查询全部
    @RequestMapping("/findAll.do")
    public ModelAndView findAll() throws Exception {
        ModelAndView mv = new ModelAndView();
        List<Com_role> cr = iCom_roleService.findAll();
        System.out.println(cr);
        mv.setViewName("com-role-list");
        mv.addObject("roleList", cr);
        return mv;
    }

    //保存
    @RequestMapping("/save.do")
    public String save(Com_role com_role) throws Exception {
        iCom_roleService.save(com_role);
        return "redirect:findAll.do";
    }

    //修改
    @RequestMapping("/update.do")
    public String update(HttpServletRequest request, HttpServletResponse response) throws Exception {
        Map map = request.getParameterMap();
        Map<String, String> map2 = new HashMap<>();
        Set<String> set = map.keySet();

        int b=0;
        int c=0;
        while (1==1){
        for(String name1 : set){
            String[] vals = (String[]) map.get(name1);
            c=vals.length;
             map2.put(name1,vals[b]);

        }
            Com_role a = new Com_role();
        try {
            BeanUtils.populate(a,map2);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        System.out.println("udpate"+a.toString());
            iCom_roleService.update(a);
        b++;
        if(b==c) break;
        }
        return "redirect:findAll.do";

    }

    //删除
    @RequestMapping("/delete.do")

    public String delete(String roleid) throws Exception {
        iCom_roleService.delete(roleid);
        return "redirect:findAll.do";
    }

}


