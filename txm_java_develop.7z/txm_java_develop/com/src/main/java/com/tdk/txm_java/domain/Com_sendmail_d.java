package com.tdk.txm_java.domain;

public class Com_sendmail_d {
    private String mail_type;
    private String mail_subtype;
    private String mail_address;

    public String getMail_type() {
        return mail_type;
    }

    public void setMail_type(String mail_type) {
        this.mail_type = mail_type;
    }

    public String getMail_subtype() {
        return mail_subtype;
    }

    public void setMail_subtype(String mail_subtype) {
        this.mail_subtype = mail_subtype;
    }

    public String getMail_address() {
        return mail_address;
    }

    @Override
    public String toString() {
        return "com_sendmail_d{" +
                "mail_type='" + mail_type + '\'' +
                ", mail_subtype='" + mail_subtype + '\'' +
                ", mail_address='" + mail_address + '\'' +
                '}';
    }

    public void setMail_address(String mail_address) {
        this.mail_address = mail_address;
    }
}
