package com.tdk.txm_java.service;

import com.tdk.txm_java.domain.Com_serialnum;

public interface ICom_serialnumService {
    //更新
     void  update(Com_serialnum com_serialnum) throws Exception;
    //查找
    Com_serialnum find(Com_serialnum com_serialnum) throws Exception;

    //查找
    Com_serialnum findByKey(String type, String key01, String key02) throws Exception;
    //查找并流水号加1   JIT2100001= 前缀+年（21)+流水号，如果跨年，流水号从1开始
    String findAndUpdate(String type, String key01, String key02, int length) throws Exception;
}
