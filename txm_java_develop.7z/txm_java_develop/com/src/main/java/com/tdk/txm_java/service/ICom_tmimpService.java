package com.tdk.txm_java.service;


import com.tdk.txm_java.domain.Com_tmimp;

import java.util.List;

public interface ICom_tmimpService {
    Com_tmimp findByItemcode(String itemcode) throws Exception;
    List<Com_tmimp> findByItemSpec(String itemcode,String imspec) throws Exception;
    List<Com_tmimp> findByItemSpec2All(String itemcode,String imspec) throws Exception;

}
