package com.tdk.txm_java.dao;


import com.tdk.txm_java.domain.Com_role;
import org.apache.ibatis.annotations.*;

import java.util.List;

public interface ICom_roleDao {

    //根据用户id查询出所有对应的角色
    @Select("select * from com_role where roleid in (select roleid from com_user_role where userId=#{userId})")

    @Results({
            @Result(id = true, property = "roleid", column = "roleid"),
            @Result(property = "role_desc", column = "role_desc"),
            @Result(property = "permissions",column = "roleid",javaType = List.class,many = @Many(select = "com.tdk.txm_java.dao.ICom_permissionDao.findByRoleId"))
    })
    public List<Com_role> findRoleByUserId(String userId) throws Exception;

    @Select("select * from com_role")
    List<Com_role> findAll() throws Exception;

    @Delete("delete from com_role where roleid=#{roleid}")
    void delete(String roleid);

    @Insert("insert into com_role(roleid,role_desc) values(#{roleid},#{role_desc})")
    void save(Com_role com_role) throws Exception;

    @Update("UPDATE com_role SET   where roleid=#{roleid}")
    void update(Com_role com_role);


}
