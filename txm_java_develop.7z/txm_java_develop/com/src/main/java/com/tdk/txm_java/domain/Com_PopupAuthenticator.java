package com.tdk.txm_java.domain;
//用于邮件发送
import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;

public class Com_PopupAuthenticator extends Authenticator {
    private String username;
    private String password;
    public Com_PopupAuthenticator(String username, String pwd){
        this.username=username;
        this.password=pwd;
    }
    public PasswordAuthentication getPasswordAuthentication(){
        return new PasswordAuthentication(this.username,this.password);
    }



}
