package com.tdk.txm_java.domain;

//与数据库中users对应
public class Com_xxmmp {
    //工号
    private String mmemno;
    //姓名
    private String mmdnam;
    //单位代码
    private String mmdept;
    //部门
    private String mmcoop;
    //组织事业部
    private String mmdvcd;
    //辞职日
    private String mmrsgn;
    //入社日
    private String mmhire;
    //就业证
    private String mmwork;
    //职位代码
    private String mmpos5;
    //职位名称
    private String mmp5nm;
    //职称代码
    private String mmpos4;
    //职称名称
    private String mmp4nm;
    //职种代码
    private String mmpos3;
    //职种名称
    private String mmp3nm;

    public String getMmemno() {
        return mmemno;
    }

    public void setMmemno(String mmemno) {
        this.mmemno = mmemno;
    }

    public String getMmdnam() {
        return mmdnam;
    }

    public void setMmdnam(String mmdnam) {
        this.mmdnam = mmdnam;
    }

    public String getMmdept() {
        return mmdept;
    }

    public void setMmdept(String mmdept) {
        this.mmdept = mmdept;
    }

    public String getMmcoop() {
        return mmcoop;
    }

    public void setMmcoop(String mmcoop) {
        this.mmcoop = mmcoop;
    }

    public String getMmdvcd() {
        return mmdvcd;
    }

    public void setMmdvcd(String mmdvcd) {
        this.mmdvcd = mmdvcd;
    }

    public String getMmrsgn() {
        return mmrsgn;
    }

    public void setMmrsgn(String mmrsgn) {
        this.mmrsgn = mmrsgn;
    }

    public String getMmhire() {
        return mmhire;
    }

    public void setMmhire(String mmhire) {
        this.mmhire = mmhire;
    }

    public String getMmwork() {
        return mmwork;
    }

    public void setMmwork(String mmwork) {
        this.mmwork = mmwork;
    }

    public String getMmpos5() {
        return mmpos5;
    }

    public void setMmpos5(String mmpos5) {
        this.mmpos5 = mmpos5;
    }

    public String getMmp5nm() {
        return mmp5nm;
    }

    public void setMmp5nm(String mmp5nm) {
        this.mmp5nm = mmp5nm;
    }

    public String getMmpos4() {
        return mmpos4;
    }

    public void setMmpos4(String mmpos4) {
        this.mmpos4 = mmpos4;
    }

    public String getMmp4nm() {
        return mmp4nm;
    }

    public void setMmp4nm(String mmp4nm) {
        this.mmp4nm = mmp4nm;
    }

    public String getMmpos3() {
        return mmpos3;
    }

    public void setMmpos3(String mmpos3) {
        this.mmpos3 = mmpos3;
    }

    public String getMmp3nm() {
        return mmp3nm;
    }

    public void setMmp3nm(String mmp3nm) {
        this.mmp3nm = mmp3nm;
    }

    @Override
    public String toString() {
        return "Com_xxmmp{" +
                "mmemno='" + mmemno + '\'' +
                ", mmdnam='" + mmdnam + '\'' +
                ", mmdept='" + mmdept + '\'' +
                ", mmcoop='" + mmcoop + '\'' +
                ", mmdvcd='" + mmdvcd + '\'' +
                ", mmrsgn='" + mmrsgn + '\'' +
                ", mmhire='" + mmhire + '\'' +
                ", mmwork='" + mmwork + '\'' +
                ", mmpos5='" + mmpos5 + '\'' +
                ", mmp5nm='" + mmp5nm + '\'' +
                ", mmpos4='" + mmpos4 + '\'' +
                ", mmp4nm='" + mmp4nm + '\'' +
                ", mmpos3='" + mmpos3 + '\'' +
                ", mmp3nm='" + mmp3nm + '\'' +
                '}';
    }
}
