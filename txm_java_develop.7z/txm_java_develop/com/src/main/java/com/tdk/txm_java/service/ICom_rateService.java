package com.tdk.txm_java.service;


import com.tdk.txm_java.domain.Com_department;
import com.tdk.txm_java.domain.Com_rate;

import java.util.List;

public interface ICom_rateService {
    Integer findByTable() throws Exception;
    Double findByCurDateType(Com_rate com_rate) throws Exception;

}
