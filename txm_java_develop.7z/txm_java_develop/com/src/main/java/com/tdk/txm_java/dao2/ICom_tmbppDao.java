package com.tdk.txm_java.dao2;

import com.tdk.txm_java.domain.Com_tmbpp;
import com.tdk.txm_java.domain.Com_xxmmp;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ICom_tmbppDao {

    @Select("select count(*) from wavedbf.tmbpp left join wavedbf.tmsup on bpvdnr=suvdnr where bpitnr='80028677' and suvsts='1' and bpltdt>1190000 ")
    Integer findByTable();
    @Select("select * from wavedbf.tmbpp left join wavedbf.tmsup on bpvdnr=suvdnr where bpitnr=#{itemcode} and suvsts='1' and bpstdt>=((YEAR(CURRENT_DATE)-1900)*10000 + MONTH(CURRENT_DATE)*100+day(CURRENT_DATE)) and bpltdt<=((YEAR(CURRENT_DATE)-1900)*10000 + MONTH(CURRENT_DATE)*100+day(CURRENT_DATE)) ")
    List<Com_tmbpp> findByItemcode(String itemcode);
}
