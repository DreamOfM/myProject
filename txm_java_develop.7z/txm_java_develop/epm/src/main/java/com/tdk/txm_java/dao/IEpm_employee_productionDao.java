package com.tdk.txm_java.dao;


import com.tdk.txm_java.domain.Epm_daily_report;
import com.tdk.txm_java.domain.Epm_employee_production;
import com.tdk.txm_java.domain.Epm_st_count;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IEpm_employee_productionDao {

    // 查询所有信息
    @Select("select * from epm_employee_production")
    public List<Epm_employee_production> findAll() throws Exception;

    @Insert("insert into epm_employee_production" +
            "(employee_no,employee_name,date,class_type,dept_code,item_no,processing_code,input_quantity,input_minutes,login_time,login_oid,update_oid,update_program)" +
            "values(#{employee_no},#{employee_name},#{date},#{class_type},#{dept_code},#{item_no},#{processing_code},#{input_quantity},#{input_minutes},now(),#{login_oid},#{update_oid},#{update_program})")
    void save(Epm_employee_production epm_employee_production);

    @Update("update epm_employee_production set  " +
            " date=#{date}, class_type=#{class_type},dept_code=#{dept_code}, item_no=#{item_no}, processing_code=#{processing_code}, input_quantity=#{input_quantity}, input_minutes=#{input_minutes}, login_time=#{login_time}, login_oid=#{login_oid}, update_oid=#{update_oid}, update_program=#{update_program}" +
            "where id =#{id}  ")
    void update(Epm_employee_production epm_employee_production);

    @Delete("delete from epm_employee_production where id =#{id}  ")
    void delete(int id);

    /**
     *@Description: 通过工号查询
     *@Author: a135109
     *@time: 2020/5/28 15:05
     */
    @Select("select * from epm_employee_production where employee_no = #{employee_no} and class_type=#{class_type} and date=#{date}")
    @Results({
            @Result(property = "epm_st_count", column = "{item_no=item_no,processing_code=processing_code}", javaType = Epm_st_count.class, one = @One(select = "com.tdk.txm_java.dao.IEpm_st_countDao.findByKey")),
    })
    public List<Epm_employee_production> findByKey(@Param("employee_no") String employee_no,@Param("class_type") String class_type,@Param("date") String date) throws Exception;

    /**
     *@Description: 日作业报表查询
     *@Author: a135109
     *@time: 2020/6/2 11:11
     */
    @Select("select *,CONCAT(Round(efficiency_t*100,3),'%') as efficiency_t_100  from epm_employee_production" +
            " left join epm_employee_performance on epm_employee_production.employee_no = epm_employee_performance.employee_no and epm_employee_production.date = epm_employee_performance.date and epm_employee_production.processing_code = epm_employee_performance.processing_code  " +
            "left join epm_employee_production_v01 v01 on epm_employee_production.employee_no = v01.employee_no and epm_employee_production.date = v01.date  " +
            "where " +
            "epm_employee_production.employee_no = #{employee_no} and " +
            "epm_employee_production.date between (case #{date_1} when '' then epm_employee_production.date else #{date_1} end) and (case #{date_2} when '' then epm_employee_production.date else #{date_2} end) " +
            "order by epm_employee_production.date")
    @Results({
            @Result(property = "epm_st_count", column = "{item_no=item_no,processing_code=processing_code}", javaType = Epm_st_count.class, one = @One(select = "com.tdk.txm_java.dao.IEpm_st_countDao.findByKey")),
    })
    public List<Epm_employee_production> findByDailyReport(@Param("employee_no") String employee_no,@Param("date_1") String date_1,@Param("date_2") String date_2) throws Exception;

    /**
     *@Description: 月作业报表查询
     *@Author: a135109
     *@time: 2020/6/2 15:44
     */
    @Select("select * from epm_employee_production where " +
            "employee_no = #{employee_no} and " +
            "date between (case #{date_1} when '' then date else #{date_1} end) and (case #{date_2} when '' then date else #{date_2} end) " +
            "order by employee_no ")
    @Results({
            @Result(property = "epm_st_count", column = "{item_no=item_no,processing_code=processing_code}", javaType = Epm_st_count.class, one = @One(select = "com.tdk.txm_java.dao.IEpm_st_countDao.findByKey")),
    })
    public List<Epm_employee_production> findByMonthlyReport(@Param("employee_no") String dept_code,@Param("date_1") String date_1,@Param("date_2") String date_2) throws Exception;

    @Select("select * from epm_employee_production where id=#{id}")
    public Epm_employee_production findById(int id) throws Exception;

    @Select("select * from epm_employee_production where employee_no=#{employee_no} and date=#{date} and class_type=#{class_type} and  item_no=#{item_no} and processing_code=#{processing_code}")
    public Epm_employee_production findByUniKey(@Param("employee_no") int employee_no,@Param("date") String date,@Param("class_type") String class_type,@Param("item_no") String item_no,@Param("processing_code") String processing_code) throws Exception;

    //2021.02.06 加department参数
    @Select("select * from epm_employee_production where  item_no=#{item_no} and processing_code=#{processing_code} and department=#{department}")
     public List<Epm_employee_production> findByStKey(@Param("item_no") String item_no,@Param("processing_code") String processing_code, @Param("department")String department) throws Exception;

    @Select("select *, Round((st_value*input_quantity/input_minutes ),5)  as efficiency  from epm_employee_production " +
            "left join epm_employee_performance on epm_employee_production.employee_no = epm_employee_performance.employee_no and epm_employee_production.date = epm_employee_performance.date and epm_employee_production.processing_code = epm_employee_performance.processing_code  " +
            "left join epm_employee_production_v01 v01 on epm_employee_production.employee_no = v01.employee_no and epm_employee_production.date = v01.date  " +
            "left join epm_st_count on  epm_employee_production.item_no=epm_st_count.item_no and  epm_employee_production.processing_code=epm_st_count.processing_code " +
            "left join epm_processing_code  on  epm_employee_production.processing_code=epm_processing_code.processing_code " +
            "left join epm_processing_item  on  epm_employee_production.item_no=epm_processing_item.item_no  " +
            " where epm_employee_production.date >=#{date_from} " +
            "order by epm_employee_production.employee_no")
    public List<Epm_daily_report> findStartDate(String date_from) throws Exception;

}
