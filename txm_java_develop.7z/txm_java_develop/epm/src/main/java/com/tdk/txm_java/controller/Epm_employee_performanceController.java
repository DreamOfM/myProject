package com.tdk.txm_java.controller;


import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tdk.txm_java.domain.*;
import com.tdk.txm_java.service.ICom_employeeService;
import com.tdk.txm_java.service.IEpm_employee_performanceService;
import com.tdk.txm_java.service.IEpm_performance_benchmarkService;
import com.tdk.txm_java.service.IEpm_processing_codeService;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

@Controller
@RequestMapping("/epm_performance")
public class Epm_employee_performanceController {
    @Autowired
    private IEpm_employee_performanceService iEpm_employee_performanceService;
    @Autowired
    private ICom_employeeService iCom_employeeService;
    @Autowired
    private IEpm_processing_codeService iEpm_processing_codeService;
    @Autowired
    private IEpm_performance_benchmarkService iEpm_performance_benchmarkService;

    @RequestMapping("/check01.do")
    public void check01(HttpServletRequest request, HttpServletResponse response, String employee_no) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        //查询工号是否存在
        if (iCom_employeeService.findByEmployee_id(employee_no) == null || "".equals(iCom_employeeService.findByEmployee_id(employee_no))) {
            info.setErrorMsg("工号在人事主档不存在");
            info.setFlag(false);
        }
        //响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(), info);
    }


    @RequestMapping("/check02.do")
    public void check02(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        System.out.println("0909");
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        info.setFlag(true);
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //测试前端数据是否传送过来
        System.out.println(map.entrySet().toString() + "数据已传过来");
        List<String> errorList=new ArrayList<String>();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        Epm_employee_performance epm_employee_performance = new Epm_employee_performance();
        while (1 == 1) {
            for (String name1 : set) {
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                if(b<c) {
                    hashMap.put(name1, vals[b]);
                }
            }
            try {
                BeanUtils.populate(epm_employee_performance, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            String processing_code= epm_employee_performance.getProcessing_code();

            if (processing_code!="") {
                Epm_processing_code epm = iEpm_processing_codeService.findByprocessing_code(processing_code);
                if ( epm==null) {
                    info.setFlag(false);
                    String errLine = String.valueOf(b);
                    errorList.add("processing_code" + errLine);
                    info.setErrorMsg("工程代码不存在");
                }
                //检查资料是否重复
                iEpm_employee_performanceService.findByUkey(epm_employee_performance);
                if( iEpm_employee_performanceService.findByUkey(epm_employee_performance)!=null){
                    info.setFlag(false);
                    String errLine = String.valueOf(b);
                    errorList.add("performance_code" + errLine);
                    info.setErrorMsg("资料重复，请检查");
                }

            }
            b++;
            if (b == c) break;
        }
        info.setErrorList(errorList);
//        info.getErrorMsg();
        // 响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(),info);
    }

    @RequestMapping("/findByemployee_date.do")
    public ModelAndView findByeployee_date(String mmemno,String date,String class_type) throws Exception {
        System.out.println(mmemno);
        //取出前端传回的数据
        Com_employee com_employee = iCom_employeeService.findByEmployee_id(mmemno);
        //调用业层的方法查询
        List<Epm_employee_performance> epm_employee_performance = iEpm_employee_performanceService.findByemployee_date(mmemno,date,class_type);
        //创建视图对象
        ModelAndView modelAndView = new ModelAndView();
        //使用addObject()设置需要返回的值
        modelAndView.addObject("epm_employee_performance",epm_employee_performance);
        modelAndView.addObject("date",date);
        modelAndView.addObject("class_type",class_type);
        modelAndView.addObject("employee_no",mmemno);
        if (com_employee!=null){
            modelAndView.addObject("mmdept",com_employee.getMmdept());
            modelAndView.addObject("employee_name",com_employee.getMmdnam());
        }
        //通过setViewName()方法跳转到指定的页面
        modelAndView.setViewName("epm-performance-list");
        //返回视图解析对象
        return modelAndView;
    }


    @RequestMapping("/findByperformance_code")
    public void findProName(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String performance_code = request.getParameter("performance_code");
        Epm_performance_benchmark epm_performance_benchmark = iEpm_performance_benchmarkService.findByperformance_code(performance_code);
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("text/html");
        mapper.writeValue(response.getOutputStream(), epm_performance_benchmark);
    }


    @RequestMapping("/update.do")
    public void update(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        //取出前端传回的所有数据
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
//        List<Epm_employee_performance> epm_employee_performance = new ArrayList<Epm_employee_performance>();
        List<String> errorList = new ArrayList<String>();
        String username = (String) session.getAttribute("username");
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //将每一个key值对应的一组值放到数组里去
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                hashMap.put(name1, vals[b]);
            }
            //取出ID
            int id = Integer.parseInt(hashMap.get("id"));
            //创建对象
            Epm_employee_performance epm_employee_performance = iEpm_employee_performanceService.findById(id);
            //更新的程序
            epm_employee_performance.setUpdate_oid(username);
            epm_employee_performance.setUpdate_program("/epm_performance/update");
            try {
                BeanUtils.populate(epm_employee_performance, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //调用业务层的update()方法
            iEpm_employee_performanceService.update(epm_employee_performance);
            b++;
            if (b == c) {
                break;
            }
        }
        info.setErrorList(errorList);
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(), info);

    }

    @RequestMapping("/save.do")
    public void save(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception {
        //取出前端传回的所有数据
        System.out.println("1111133333");
        Map map = request.getParameterMap();
        //测试前端数据是否传送过来？
        System.out.println("数据已传过来");
        String username = (String) httpSession.getAttribute("username");

        Set<String> set = map.keySet();
        Map<String, String> hashMap = new HashMap<>();
        int b = 0;
        int c = 0;

        Epm_employee_performance epm_employee_performance = new Epm_employee_performance();

        while (1 == 1) {
            for (String name1 : set) {
                    String[] vals = (String[]) map.get(name1);
                    c = vals.length;
                    hashMap.put(name1, vals[b]);
            }

            try {
                BeanUtils.populate(epm_employee_performance, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //添加一个判断，如果为空值或者没有输入则不往数据库里插数据
            if (epm_employee_performance.getProcessing_code().equals(null) || epm_employee_performance.getProcessing_code().equals("")) {
                b++;
                if (b == c) break;
                continue;
            }
            epm_employee_performance.setLogin_oid(username);
            epm_employee_performance.setUpdate_oid(username);
            epm_employee_performance.setUpdate_program("/epm_performance/save");

            iEpm_employee_performanceService.save(epm_employee_performance);

            b++;
            if (b == c) break;
        }

        ResultInfo info = new ResultInfo();
        //响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(),info);
    }


    @RequestMapping("/delete.do")
    public String delete(int id,String employee_no,String class_type,String date, RedirectAttributes attr) throws Exception {
        System.out.println(id + "delete's id has send");
        iEpm_employee_performanceService.delete(id);
        //传递条件
        attr.addAttribute("class_type",class_type);
        attr.addAttribute("mmemno",employee_no);
        attr.addAttribute("date",date);
        return "redirect:findByemployee_date.do";
    }


    @RequestMapping("/findByemployee_no.do")
    public void check0(HttpServletResponse response,String employee_no) throws Exception, JsonGenerationException, JsonMappingException
    {
        System.out.println("32323232");
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        Com_employee com_employee= iCom_employeeService.findByEmployee_id(employee_no);
        System.out.println("ioioi"+com_employee);
        if(com_employee!=null) {
            info.setData(com_employee);
            info.setFlag(true);
            System.out.println("212121");
        }
       else{
            info.setErrorMsg("工号在人事主档不存在");
            info.setFlag(false);
        }

        //响应数据
        info.setErrorList(errorList);
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(),info);
    }
}
