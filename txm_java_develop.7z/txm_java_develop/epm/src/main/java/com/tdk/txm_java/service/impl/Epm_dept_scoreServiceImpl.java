package com.tdk.txm_java.service.impl;


import com.tdk.txm_java.dao.IEpm_dept_scoreDao;
import com.tdk.txm_java.domain.*;
import com.tdk.txm_java.service.IEpm_dept_scoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class Epm_dept_scoreServiceImpl implements IEpm_dept_scoreService {


    @Autowired
    private IEpm_dept_scoreDao iEpm_dept_scoreDao;

    @Override
    public List<Epm_dept_score> findAll() throws Exception {
        return iEpm_dept_scoreDao.findAll();
    }

    @Override
    public void save(Epm_dept_score epm_dept_score) throws Exception {
        iEpm_dept_scoreDao.save(epm_dept_score);
    }

    @Override
    public void update(Epm_dept_score epm_dept_score) throws Exception {
        iEpm_dept_scoreDao.update(epm_dept_score);
    }

    @Override
    public void delete(int id) throws Exception {
        iEpm_dept_scoreDao.delete(id);
    }

    @Override
    public Epm_dept_score findById(int id) throws Exception {
        return iEpm_dept_scoreDao.findById(id);
    }

    @Override
    public Epm_dept_score findByDept(String dept_code) throws Exception {
        return iEpm_dept_scoreDao.findByDept(dept_code);
    }

    @Override
    public Epm_dept_score findByDeptCode(String department,String dept_code) throws Exception {
        return iEpm_dept_scoreDao.findByDeptCode(department,dept_code);
    }


    @Override
    public List<Epm_dept_score> findByGroupDept(String group_dept_code) throws Exception{
        return iEpm_dept_scoreDao.findByGroupDept(group_dept_code);
    }
    @Override
    public List<Epm_dept_score> findAllGroupDept() throws Exception{
        return  iEpm_dept_scoreDao.findAllGroupDept();
    }
    @Override
    public List<Epm_dept_score> findLikeGroupDept(String dept_code) throws Exception{
        String like_dept_code=dept_code.trim().trim()+"%";
        return  iEpm_dept_scoreDao.findLikeGroupDept(like_dept_code);
    }
}
