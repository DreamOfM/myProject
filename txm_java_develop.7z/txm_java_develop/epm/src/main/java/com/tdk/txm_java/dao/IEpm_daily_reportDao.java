package com.tdk.txm_java.dao;


import com.tdk.txm_java.domain.Epm_daily_report;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.springframework.stereotype.Repository;

@Repository
public interface IEpm_daily_reportDao {

    @Insert("insert into epm_daily_report" +
            "(employee_no,credate,dept_code,class_type,employee_name,item_no,item_spec,processing_code,processing_name,input_quantity,input_minutes,efficiency,efficiency_t,performance_code,item,score,mark" +
//            "(employee_no,dept_code,class_type,employee_name,item_no,item_spec,processing_code,processing_name,input_quantity,efficiency" +
            " )" +
            "values(#{employee_no_s},#{date},#{dept_code},#{class_type},#{employee_name},#{item_no},#{item_spec},#{processing_code},#{processing_name},#{input_quantity},#{input_minutes},#{efficiency},#{efficiency_t},#{performance_code},#{item},#{score},#{mark}" +
//            "values(#{employee_no_s},#{dept_code},#{class_type},#{employee_name},#{item_no},#{item_spec},#{processing_code},#{processing_name},#{input_quantity},#{efficiency}" +
            " )")
    void save(Epm_daily_report epm_daily_report);

    @Delete("delete  from epm_daily_report  ")
    void deleteAll();

    @Delete("delete  from epm_daily_report where credate>=#{date_from}  ")
    void deleteStartDate(String date_from);

}
