package com.tdk.txm_java.service;




import com.tdk.txm_java.domain.Epm_dept_score;
import com.tdk.txm_java.domain.Epm_monthly_report;

import java.util.List;

public interface IEpm_dept_scoreService {
    List<Epm_dept_score> findAll() throws Exception;
    void save(Epm_dept_score epm_dept_score) throws Exception;
    void update(Epm_dept_score epm_dept_score) throws Exception;
    void delete(int id) throws Exception;
    Epm_dept_score findById(int id) throws Exception;
    Epm_dept_score findByDept(String dept_code) throws Exception;
    Epm_dept_score findByDeptCode(String department,String dept_code) throws Exception;

    List<Epm_dept_score>  findByGroupDept(String group_dept_code) throws Exception;

    List<Epm_dept_score> findAllGroupDept() throws Exception;

    List<Epm_dept_score> findLikeGroupDept(String like_dept_code) throws Exception;
}
