package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Epm_employee_production {
    private int id;
    private int employee_no;
    private String department;
    private String date;
    private String class_type;
    private String dept_code;
    private String item_no;
    private String processing_code;
    private Double input_quantity;
    private Double input_minutes;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;
    private String employee_name;
    private String item;
    private String mark;
    private String efficiency_t_100;
    private Epm_st_count epm_st_count;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getEmployee_no() {
        return employee_no;
    }

    public void setEmployee_no(int employee_no) {
        this.employee_no = employee_no;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getClass_type() {
        return class_type;
    }

    public void setClass_type(String class_type) {
        this.class_type = class_type;
    }

    public String getDept_code() {
        return dept_code;
    }

    public void setDept_code(String dept_code) {
        this.dept_code = dept_code;
    }

    public String getItem_no() {
        return item_no;
    }

    public void setItem_no(String item_no) {
        this.item_no = item_no;
    }

    public String getProcessing_code() {
        return processing_code;
    }

    public void setProcessing_code(String processing_code) {
        this.processing_code = processing_code;
    }

    public Double getInput_quantity() {
        return input_quantity;
    }

    public void setInput_quantity(Double input_quantity) {
        this.input_quantity = input_quantity;
    }

    public Double getInput_minutes() {
        return input_minutes;
    }

    public void setInput_minutes(Double input_minutes) {
        this.input_minutes = input_minutes;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    public String getEmployee_name() {
        return employee_name;
    }

    public void setEmployee_name(String employee_name) {
        this.employee_name = employee_name;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getMark() {
        return mark;
    }

    public void setMark(String mark) {
        this.mark = mark;
    }

    public String getEfficiency_t_100() {
        return efficiency_t_100;
    }

    public void setEfficiency_t_100(String efficiency_t_100) {
        this.efficiency_t_100 = efficiency_t_100;
    }

    public Epm_st_count getEpm_st_count() {
        return epm_st_count;
    }

    public void setEpm_st_count(Epm_st_count epm_st_count) {
        this.epm_st_count = epm_st_count;
    }

    @Override
    public String toString() {
        return "Epm_employee_production{" +
                "id=" + id +
                ", employee_no=" + employee_no +
                ", department='" + department + '\'' +
                ", date='" + date + '\'' +
                ", class_type='" + class_type + '\'' +
                ", dept_code='" + dept_code + '\'' +
                ", item_no='" + item_no + '\'' +
                ", processing_code='" + processing_code + '\'' +
                ", input_quantity=" + input_quantity +
                ", input_minutes=" + input_minutes +
                ", login_time='" + login_time + '\'' +
                ", login_oid='" + login_oid + '\'' +
                ", update_time='" + update_time + '\'' +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                ", employee_name='" + employee_name + '\'' +
                ", item='" + item + '\'' +
                ", mark='" + mark + '\'' +
                ", efficiency_t_100='" + efficiency_t_100 + '\'' +
                ", epm_st_count=" + epm_st_count +
                '}';
    }
}
