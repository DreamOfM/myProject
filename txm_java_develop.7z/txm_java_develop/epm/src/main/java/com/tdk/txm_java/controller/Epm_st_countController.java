package com.tdk.txm_java.controller;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.tdk.txm_java.domain.*;
import com.tdk.txm_java.service.IEpm_employee_productionService;
import com.tdk.txm_java.service.IEpm_processing_codeService;
import com.tdk.txm_java.service.IEpm_processing_itemService;
import com.tdk.txm_java.service.IEpm_st_countService;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

@Controller
@RequestMapping("/epm_st_count")
public class Epm_st_countController {

    @Autowired
    private IEpm_st_countService epm_st_countService;

    @Autowired
    private IEpm_processing_itemService epm_processing_itemService;

    @Autowired
    private IEpm_processing_codeService epm_processing_codeService;

    @Autowired
    private IEpm_employee_productionService epm_employee_productionService;

    /**
     *@Description: 查询全部ST
     *@Author: a135109
     *@time: 2020/5/29 15:25
     */
    @RequestMapping("/findAll")
    public void findAll(HttpServletRequest request, HttpServletResponse response) throws Exception{
        List<Epm_st_count> ls = epm_st_countService.findAll();
        // 响应数据
        ObjectMapper mapper = new ObjectMapper();
        // 集合转json
        String jsonStr = mapper.writeValueAsString(ls);
        response.setContentType("text/html");
        mapper.writeValue(response.getOutputStream(),jsonStr);
    }



    /**
     *@Description: 查询所有品名
     *@Author: a135109
     *@time: 2020/5/25 9:55
     */
    @RequestMapping("/findAllItem")
    public void findAllItem (HttpServletRequest request, HttpServletResponse response) throws Exception{
        List<Epm_processing_item> ls = epm_processing_itemService.findAll();
        // 响应数据
        ObjectMapper mapper = new ObjectMapper();
        // 集合转json
        String jsonStr = mapper.writeValueAsString(ls);
        response.setContentType("text/html");
        mapper.writeValue(response.getOutputStream(),jsonStr);
    }

    /**
     *@Description: 查询所有品名
     *@Author: a135109
     *@time: 2020/5/25 9:55
     */
    @RequestMapping("/findAllItemByDept")
    public void findAllItemByDept (HttpServletRequest request, HttpServletResponse response) throws Exception{
        String department = request.getParameter("department");
        List<Epm_processing_item> ls = epm_processing_itemService.findAllByDept(department);
        // 响应数据
        ObjectMapper mapper = new ObjectMapper();
        // 集合转json
        String jsonStr = mapper.writeValueAsString(ls);
        response.setContentType("text/html");
        mapper.writeValue(response.getOutputStream(),jsonStr);
    }


    /**
     *@Description: 通过item_no与processing_code查询
     *@Author: a135109
     *@time: 2020/5/29 16:50
     */
    @RequestMapping("/findByKey")
    public void findByKey (HttpServletRequest request, HttpServletResponse response) throws Exception{
        String item_no = request.getParameter("item_no");
        String processing_code = request.getParameter("processing_code");
        Epm_st_count epm_st_count = epm_st_countService.findBykey(item_no,processing_code);
        // 响应数据
        ObjectMapper mapper = new ObjectMapper();
        // 集合转json
        response.setContentType("text/html");
        mapper.writeValue(response.getOutputStream(),epm_st_count);
    }

    /**
     *@Description: 查询所有工程名
     *@Author: a135109
     *@time: 2020/5/26 13:10
     */
    @RequestMapping("/findAllCode")
    public void findAllCode (HttpServletRequest request, HttpServletResponse response) throws Exception{
        List<Epm_processing_code> ls = epm_processing_codeService.findAll();
        // 响应数据
        ObjectMapper mapper = new ObjectMapper();
        // 集合转json
        String jsonStr = mapper.writeValueAsString(ls);
        response.setContentType("text/html");
        mapper.writeValue(response.getOutputStream(),jsonStr);
    }


    /**
     *@Description: 查询所有工程名
     *@Author: a135109
     *@time: 2020/5/26 13:10
     */
    @RequestMapping("/findAllCodeByDept")
    public void findAllCodeByDept (HttpServletRequest request, HttpServletResponse response) throws Exception{
        String department = request.getParameter("department");
        List<Epm_processing_code> ls = epm_processing_codeService.findAllByDept(department);
        // 响应数据
        ObjectMapper mapper = new ObjectMapper();
        // 集合转json
        String jsonStr = mapper.writeValueAsString(ls);
        response.setContentType("text/html");
        mapper.writeValue(response.getOutputStream(),jsonStr);
    }

    /**
     *@Description: 通过品名代码查询ST表
     *@Author: a135109
     *@time: 2020/5/25 9:56
     */
    @RequestMapping("/findByItemNo")
    public ModelAndView findByName(String item_no) throws Exception {
        Epm_processing_item epm_processing_item = epm_processing_itemService.findByItem_no(item_no);
        List<Epm_st_count> ls = epm_st_countService.findByItemNo(item_no);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("epm-st-list");
        mv.addObject("item_no",item_no);
        mv.addObject("epm_processing_item",epm_processing_item);
        mv.addObject("epm_st_count",ls);
        return mv;
    }


    /**
     *@Description: 通过部门品名代码查询ST表
     *@Author: a171773
     *@time: 2021/01/21 9:56
     */
    @RequestMapping("/findByDeptItemNo")
    public ModelAndView findByDeptName(String department,String item_no) throws Exception {
        Epm_processing_item epm_processing_item = epm_processing_itemService.findBydeptItem_no(department,item_no);
        List<Epm_st_count> ls = epm_st_countService.findBydeptItemNo(department,item_no);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("epm-st-list");
        mv.addObject("department",department);
        mv.addObject("item_no",item_no);
        mv.addObject("epm_processing_item",epm_processing_item);
        mv.addObject("epm_st_count",ls);
        return mv;
    }




    /**
     *@Description: 修改ST表
     *@Author: a135109
     *@time: 2020/5/25 14:48
     */
    @RequestMapping("/update")
    public String update(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception {
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        int b=0;
        int c=0;
        while (1==1){
            for(String name1 : set){
                String[] vals = (String[]) map.get(name1);
                c=vals.length;
                hashMap.put(name1,vals[b]);
            }
            Epm_st_count epm = new Epm_st_count();
            int id1 = Integer.parseInt(hashMap.get("id"));
            System.out.println(id1);
            if (id1!=0){
                System.out.println(id1);
                epm=epm_st_countService.findById(id1);
                try {
                    BeanUtils.populate(epm,hashMap);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    e.printStackTrace();
                }
                String username= (String) httpSession.getAttribute("username");
                epm.setUpdate_oid(username);
                epm.setUpdate_program("/update.do");
                epm_st_countService.update(epm);
            }
            b++;
            if(b==c) break;
        }
       // return "redirect:findByItemNo.do";
        return "redirect:findByDeptItemNo.do";
    }


    @RequestMapping("/check")
    public void check(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        info.setFlag(true);
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //测试前端数据是否传送过来
        System.out.println(map.entrySet().toString() + "数据已传过来");
        List<String> errorList=new ArrayList<String>();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        Epm_st_count epm_st_count = new Epm_st_count();
        while (1 == 1) {
            for (String name1 : set) {
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                hashMap.put(name1, vals[b]);
            }
            try {
                BeanUtils.populate(epm_st_count, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            String item_no = epm_st_count.getItem_no();
            String processing_code= epm_st_count.getProcessing_code();
            String department=epm_st_count.getDepartment();
           // Epm_st_count epm = epm_st_countService.findBykey(item_no,processing_code);
            //2021.01.29
            Epm_st_count epm = epm_st_countService.findBykey1(item_no,processing_code,department);
            if (epm!=null) {
                info.setFlag(false);
                String errLine = String.valueOf(b);
                errorList.add("processing_code" + errLine);
                info.setErrorMsg("工程代码存在");
            }
            b++;
            if (b == c) break;
        }
        info.setErrorList(errorList);
        info.getErrorMsg();
        // 响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(),info);
    }


    /**
     *@Description: 保存
     *@Author: a135109
     *@time: 2020/5/26 11:06
     */
    @RequestMapping("/save")
    public void save(HttpServletRequest request, HttpServletResponse response,HttpSession httpSession) throws Exception {
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //测试前端数据是否传送过来
        System.out.println(map.entrySet().toString() + "数据已传过来");
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        Epm_st_count epm_st_count = new Epm_st_count();
        while (1 == 1) {
            for (String name1 : set) {
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                hashMap.put(name1, vals[b]);
            }
            try {
                BeanUtils.populate(epm_st_count, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //添加一个判断，如果为空值或者没有输入则不往数据库里插数据
           // if (epm_st_count.getProcessing_code().equals(null) || epm_st_count.getProcessing_code().equals("")) {
            if (epm_st_count.getProcessing_code().equals(null) || epm_st_count.getProcessing_code().equals("") || epm_st_count.getDepartment().equals("")) {
                b++;
                if (b == c) break;
                continue;
            }
            String username= (String) httpSession.getAttribute("username");
            epm_st_count.setUpdate_oid(username);
            epm_st_count.setLogin_oid(username);
            epm_st_count.setUpdate_program("/epm_st_count/save.do");
            epm_st_countService.save(epm_st_count);
            b++;
            if (b == c) break;
        }
    }

    /**
     *@Description: 删除
     *@Author: a135109
     *@time: 2020/5/27 8:42
     */
    @RequestMapping("/delete.do")
    public String delete(int ids[], String item_no,String department, RedirectAttributes attr) throws Exception{
        System.out.println(ids);
        if(ids != null && ids.length > 0){
            //遍历数组
            for (int id : ids) {
                //单条删除
                epm_st_countService.delete(id);
            }
        }
        //传递条件
        attr.addAttribute("item_no",item_no);
        return "redirect:findByItemNo.do";
    }

    /**
     *@Description: 删除前检查在Epm_employee_production是否存在
     *@Author: a135109
     *@time: 2020/5/30 16:46
     */
    @RequestMapping("/checkEmployeeProdution")
    public void checkEmployeeProdution(HttpServletRequest request,HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        info.setFlag(true);
        String ids[] = request.getParameter("Json").split(",");
        if(ids != null && ids.length > 0){
            //遍历数组
            for (String sid : ids) {
                //单条删除
                int id = Integer.parseInt(sid);
                Epm_st_count epm_st_count = epm_st_countService.findById(id);
                String item_no = epm_st_count.getItem_no();
                String processing_code = epm_st_count.getProcessing_code();
                String department=epm_st_count.getDepartment();
               // List<Epm_employee_production> epm_employee_production = epm_employee_productionService.findByStKey(item_no,processing_code);
               //add 2021.02.02
                List<Epm_employee_production> epm_employee_production = epm_employee_productionService.findByStKey(item_no,processing_code,department);
                if (!epm_employee_production.isEmpty()){
                    info.setFlag(false);
                    info.setErrorMsg("删除失败："+epm_st_count.getProcessing_code()+"在日生产状况存在");
                }
            }
        }
        // 响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(),info);
    }
}
