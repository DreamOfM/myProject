package com.tdk.txm_java.controller;


import com.tdk.txm_java.domain.*;
import com.tdk.txm_java.service.*;
import net.sf.jsqlparser.expression.StringValue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

//报表
@Controller
@RequestMapping("/epm_report")
public class Epm_reportController {
    @Autowired
    private IEpm_employee_productionService iEpm_employee_productionService;

    @Autowired
    private IEpm_employee_performanceService iEpm_employee_performanceService;

    @Autowired
    private IEpm_performance_benchmarkService iEpm_performance_benchmarkService;

    @Autowired
    private IEpm_dept_scoreService iEpm_dept_scoreService;

    @Autowired
    private IEpm_monthly_reportService iEpm_monthly_reportService;

    @Autowired
    private ICom_employeeService iCom_employeeService;

    @RequestMapping("/findByDailyReport")
    public ModelAndView findByDailyReport(String mmemno,String date_1,String date_2) throws Exception {
        System.out.println(date_1+""+date_2);
        Com_employee com_employee = iCom_employeeService.findByEmployee_id(mmemno);
        List<Epm_employee_production> ls = iEpm_employee_productionService.findByDailyReport(mmemno,date_1,date_2);
        System.out.println(ls);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("epm-daily-report-list");
        mv.addObject("com_xxmmp",com_employee);
        mv.addObject("date_1",date_1);
        mv.addObject("date_2",date_2);
        mv.addObject("epm_employee_production",ls);
        return mv;
    }

    @RequestMapping("/findByMonthlyReport")
    public ModelAndView findByMonthlyReport(String dept_code,String date_1,String date_2) throws Exception {
        ModelAndView mv = new ModelAndView();
        String err_msg=null;
        //建立一个Epm_dept_score对象，查找股别对应的分数基准
//        Epm_dept_score epm_dept_score = iEpm_dept_scoreService.findByDept(dept_code);

        List<Epm_dept_score> epm_dept_scores=iEpm_dept_scoreService.findLikeGroupDept(dept_code);
        //如果找不到，返回错误信息
//        if(epm_dept_score==null){
        if(epm_dept_scores.size()==0){
            err_msg=dept_code+"  没有维护相应的绩效基准";
        } else {
            List<Epm_monthly_report> sortList_t=new ArrayList<>();
            for(Epm_dept_score epm_dept_score:epm_dept_scores) {
                //建立一个空的list,存放Epm_monthly_report对象
                List<Epm_monthly_report> sortList = iEpm_monthly_reportService.creatMonthDataByDept(epm_dept_score.getGroup_dept_code(), date_1, date_2);
            sortList_t.addAll(sortList);
            }
            mv.addObject("date_1", date_1);
            mv.addObject("date_2", date_2);
            mv.addObject("dept_code", dept_code);
            mv.addObject("epm_monthly_report", sortList_t);
            mv.addObject("epm_dept_score",epm_dept_scores.get(0));
        }
        mv.setViewName("epm-monthly-report-list");
        mv.addObject("err_msg",err_msg);
        return mv;
    }
}
