package com.tdk.txm_java.service;




import com.tdk.txm_java.domain.Epm_performance_benchmark;

import java.util.List;

public interface IEpm_performance_benchmarkService {
    List<Epm_performance_benchmark> findAll() throws Exception;
    Epm_performance_benchmark findByperformance_code(String performance_code) throws Exception;
    void save(Epm_performance_benchmark epm_performance_benchmark) throws Exception;
    void update(Epm_performance_benchmark epm_performance_benchmark) throws Exception;
    void delete(int id) throws Exception;
    Epm_performance_benchmark findByEff(Double eff) throws Exception;
}
