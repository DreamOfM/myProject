package com.tdk.txm_java.dao;


import com.tdk.txm_java.domain.Epm_monthly_report;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IEpm_monthly_reportDao {

    // 查询所有信息
    @Select("select * from epm_monthly_report ")
    public List<Epm_monthly_report> findAll() throws Exception;

    @Insert("insert into epm_monthly_report" +
            "(create_month,employee_no,employee_name,date_from,date_to,dept_code,efficiency,eff_score,b_score,c_score,d_score,sum_score,ranking,flag" +
            ",login_time,login_oid,update_oid,update_program )" +
            "values(#{create_month},#{employee_no},#{employee_name},#{date_from},#{date_to},#{dept_code},#{efficiency},#{eff_score},#{b_score},#{c_score},#{d_score},#{sum_score},#{ranking},#{flag}" +
            ",now(),#{login_oid},#{update_oid},#{update_program})")
    void save(Epm_monthly_report epm_monthly_report);

    @Update("update epm_monthly_report  " +
            " efficiency=#{efficiency}, eff_score=#{eff_score}, b_score=#{b_score}, c_score=#{c_score}, d_score=#{d_score}, sum_score=#{sum_score}, ranking=#{ranking}, flag=#{flag}" +
            ", login_oid=#{login_oid}, update_oid=#{update_oid}, update_program=#{update_program} " +
            "where id =#{id}  ")
    void update(Epm_monthly_report epm_monthly_report);

    @Delete("delete from epm_monthly_report  where id =#{id}  ")
    void delete(int id);

    @Delete("delete from epm_monthly_report  where create_month =#{create_month}  ")
    void deleteByMonth(String create_month);

}
