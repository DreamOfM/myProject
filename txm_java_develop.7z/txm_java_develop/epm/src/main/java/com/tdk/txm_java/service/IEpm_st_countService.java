package com.tdk.txm_java.service;




import com.tdk.txm_java.domain.Epm_st_count;

import java.util.List;

public interface IEpm_st_countService {
    List<Epm_st_count> findAll() throws Exception;
    void save(Epm_st_count epm_st_count) throws Exception;
    void update(Epm_st_count epm_st_count) throws Exception;
    void delete(int id) throws Exception;
    List<Epm_st_count> findByItemNo(String item_no) throws Exception;
    List<Epm_st_count> findBydeptItemNo(String department,String item_no) throws Exception;  //2021.01.22 add

    List<Epm_st_count> findByProcessing_code(String processing_code) throws Exception;
    List<Epm_st_count> findByProcessing_deptcode(String department,String processing_code) throws Exception;  //2021.01.21追加
    List<Epm_st_count> findByItem(String item_no) throws Exception;
    List<Epm_st_count> findBydeptItem(String department,String item_no) throws Exception;  //2021.01.21追加
    Epm_st_count findBykey(String item_no,String processing_code) throws Exception;
    Epm_st_count findBykey1(String item_no,String processing_code,String department) throws Exception;  //2021.01.29追加
    Epm_st_count findById(int id) throws Exception;
}
