package com.tdk.txm_java.service.impl;


import com.tdk.txm_java.dao.IEpm_performance_benchmarkDao;
import com.tdk.txm_java.domain.Epm_performance_benchmark;
import com.tdk.txm_java.service.IEpm_performance_benchmarkService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class Epm_performance_benchmarkServiceImpl implements IEpm_performance_benchmarkService {


    @Autowired
    private IEpm_performance_benchmarkDao iEpm_performance_benchmarkDao;

    @Override
    public List<Epm_performance_benchmark> findAll() throws Exception {
        return iEpm_performance_benchmarkDao.findAll();
    }

    @Override
    public Epm_performance_benchmark findByperformance_code(String performance_code) throws Exception {
        return iEpm_performance_benchmarkDao.findByperformance_code(performance_code);
    }

    @Override
    public void save(Epm_performance_benchmark epm_performance_benchmark) throws Exception {
        iEpm_performance_benchmarkDao.save(epm_performance_benchmark);
    }

    @Override
    public void update(Epm_performance_benchmark epm_performance_benchmark) throws Exception {
        iEpm_performance_benchmarkDao.update(epm_performance_benchmark);
    }

    @Override
    public void delete(int id) throws Exception {
        iEpm_performance_benchmarkDao.delete(id);
    }

    @Override
    public Epm_performance_benchmark findByEff(Double eff) throws Exception {
        if (eff>1.2){
            eff = 1.2;
        }else if (eff<0){
            eff = 0.0;
        }
        return iEpm_performance_benchmarkDao.findByEff(eff);
    }


}
