package com.tdk.txm_java.service.impl;


import com.tdk.txm_java.dao.IEpm_processing_itemDao;
import com.tdk.txm_java.domain.Epm_processing_item;
import com.tdk.txm_java.service.IEpm_processing_itemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class Epm_processing_itemServiceImpl implements IEpm_processing_itemService {


    @Autowired
    private IEpm_processing_itemDao iEpm_processing_itemDao;

    @Override
    public List<Epm_processing_item> findAll() throws Exception {
        return iEpm_processing_itemDao.findAll();
    }

    @Override
    public List<Epm_processing_item> findAllByDept(String department) throws Exception {
        return iEpm_processing_itemDao.findAllByDept(department);
    }

    @Override
    public void save(Epm_processing_item epm_processing_item) throws Exception {
        epm_processing_item.setItem_no(epm_processing_item.getItem_no().toUpperCase());
        iEpm_processing_itemDao.save(epm_processing_item);
    }

    @Override
    public void update(Epm_processing_item epm_processing_item) throws Exception {
        epm_processing_item.setItem_no(epm_processing_item.getItem_no().toUpperCase());
        iEpm_processing_itemDao.update(epm_processing_item);
    }

    @Override
    public void delete(int id) throws Exception {
        iEpm_processing_itemDao.delete(id);
    }

    @Override
    public Epm_processing_item findByItem_no(String item_no) throws Exception {
        return iEpm_processing_itemDao.findByItem_no(item_no);
    }

    @Override
    public Epm_processing_item findBydeptItem_no(String department,String item_no) throws Exception {
        return iEpm_processing_itemDao.findBydeptItem_no(department,item_no);
    }

    @Override
    public Epm_processing_item findById(int id) throws Exception {
        return iEpm_processing_itemDao.findById(id);
    }


}
