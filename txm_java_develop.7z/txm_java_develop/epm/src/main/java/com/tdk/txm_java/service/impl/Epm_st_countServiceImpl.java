package com.tdk.txm_java.service.impl;


import com.tdk.txm_java.dao.IEpm_st_countDao;
import com.tdk.txm_java.domain.Epm_st_count;
import com.tdk.txm_java.service.IEpm_st_countService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class Epm_st_countServiceImpl implements IEpm_st_countService {


    @Autowired
    private IEpm_st_countDao iEpm_st_countDao;

    @Override
    public List<Epm_st_count> findAll() throws Exception {
        return iEpm_st_countDao.findAll();
    }

    @Override
    public void save(Epm_st_count epm_st_count) throws Exception {
        iEpm_st_countDao.save(epm_st_count);
    }

    @Override
    public void update(Epm_st_count epm_st_count) throws Exception {
        iEpm_st_countDao.update(epm_st_count);
    }

    @Override
    public void delete(int id) throws Exception {
        iEpm_st_countDao.delete(id);
    }

    @Override
    public List<Epm_st_count> findByItemNo(String item_no) throws Exception {
        return iEpm_st_countDao.findByItemNo(item_no);
    }

//2021.01.22
    @Override
    public List<Epm_st_count> findBydeptItemNo(String department,String item_no) throws Exception {
        return iEpm_st_countDao.findBydeptItemNo(department,item_no);
    }

    @Override
    public List<Epm_st_count> findByProcessing_code(String processing_code) throws Exception {
        return iEpm_st_countDao.findByProcessing_code(processing_code);
    }

    @Override
    public List<Epm_st_count> findByProcessing_deptcode(String department,String processing_code) throws Exception {
        return iEpm_st_countDao.findByProcessing_deptcode(department,processing_code);
    }

    @Override
    public List<Epm_st_count> findByItem(String item_no) throws Exception {
        return iEpm_st_countDao.findByItem(item_no);
    }



    @Override
    public List<Epm_st_count> findBydeptItem(String department,String item_no) throws Exception {
        return iEpm_st_countDao.findBydeptItem(department,item_no);
    }

    @Override
    public Epm_st_count findById(int id) throws Exception {
        return iEpm_st_countDao.findById(id);
    }

    @Override
    public Epm_st_count findBykey(String item_no, String processing_code) throws Exception {
        return iEpm_st_countDao.findByKey(item_no,processing_code);
    }

    @Override
    public Epm_st_count findBykey1(String item_no, String processing_code,String department) throws Exception {
        return iEpm_st_countDao.findByKey1(item_no,processing_code,department);
    }


}
