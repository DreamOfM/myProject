package com.tdk.txm_java.controller;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.tdk.txm_java.domain.Epm_processing_code;
import com.tdk.txm_java.domain.Epm_st_count;
import com.tdk.txm_java.domain.ResultInfo;
import com.tdk.txm_java.service.IEpm_processing_codeService;
import com.tdk.txm_java.service.IEpm_st_countService;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

@Controller
@RequestMapping("/epm_processing_code")
public class Epm_processing_codeController {
    @Autowired
    private IEpm_processing_codeService iEpm_processing_codeService;

    @Autowired
    private IEpm_st_countService iEpm_st_countService;



    /**
     * 修改
     *
     * @return
     * @throws Exception
     */

    //修改
    @RequestMapping("/update.do")
    public String update(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception {
        System.out.println("hhh");
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        String username = (String) httpSession.getAttribute("username");

        for (String name1 : set) {
            String[] vals = (String[]) map.get(name1);
            hashMap.put(name1, vals[0]);
        }
        System.out.println("aaaa");
        System.out.println(hashMap.get("id"));
        int id1 = Integer.parseInt(request.getParameter("id"));
        Epm_processing_code a = iEpm_processing_codeService.findByid(id1);
        System.out.println("1212");
        System.out.println(a);
        try {
            //double传不成功
            BeanUtils.populate(a, hashMap);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

        a.setUpdate_oid(username);
        String update_program = "/epm_processing_code/update";
        a.setUpdate_program(update_program);
        iEpm_processing_codeService.update(a);

        return "redirect:findByprocessing_code.do";

    }

    /**
     * 根据品名代碼来查询
     *
     * @param processing_code
     * @return
     * @throws Exception
     */
    @RequestMapping("/findByprocessing_code.do")
    public ModelAndView findByprocessing_code(String processing_code) throws Exception {
        Epm_processing_code epm_processing_code = iEpm_processing_codeService.findByprocessing_code(processing_code);
        ModelAndView mv = new ModelAndView();
//        if (processing_code != "" && epm_processing_code == null) {
//            mv.setViewName("epm-processing-add");
//        } else {
            mv.setViewName("epm-processing-list");
            System.out.println(epm_processing_code);
//        }
            mv.addObject("epm_processing_code", epm_processing_code);
            return mv;

    }

    /**
     * 根据部门+品名代碼来查询
     * @param department
     * @param processing_code
     *
     * @return
     * @throws Exception
     */
    @RequestMapping("/findByprocessing_deptcode.do")
    public ModelAndView findByprocessing_deptcode(String department,String processing_code) throws Exception {
        Epm_processing_code epm_processing_code = iEpm_processing_codeService.findByprocessing_deptcode(department,processing_code);
        ModelAndView mv = new ModelAndView();
//        if (processing_code != "" && epm_processing_code == null) {
//            mv.setViewName("epm-processing-add");
//        } else {
        mv.setViewName("epm-processing-list");
        System.out.println(epm_processing_code);
//        }
        mv.addObject("epm_processing_code", epm_processing_code);
        return mv;

    }




    /**
     * 新增
     */
    @RequestMapping("/save.do")
    public String save(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception {
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //测试前端数据是否传送过来？
        System.out.println(map.entrySet().toString() + "数据已传过来");
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();

        String username = (String) httpSession.getAttribute("username");
        Epm_processing_code epm_processing_code = new Epm_processing_code();

        for (String name1 : set) {
            String[] vals = (String[]) map.get(name1);
            int c = vals.length;
            hashMap.put(name1, vals[0]);
        }

        try {
            BeanUtils.populate(epm_processing_code, hashMap);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        epm_processing_code.setLogin_oid(username);
        epm_processing_code.setUpdate_oid(username);
        epm_processing_code.setUpdate_program("/epm_processing_code/save");
        iEpm_processing_codeService.save(epm_processing_code);

        return "redirect:findByprocessing_code.do";
    }

    /**
     * 删除
     */
    @RequestMapping("/delete.do")
    public String delete(int id) throws Exception {
        iEpm_processing_codeService.delete(id);
        return "redirect:findByprocessing_code.do";
    }

//ST表已存在，不可删除
    @RequestMapping("/check.do")
    public void check3(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        //1.获取信息
        String department=request.getParameter("department");
        String processing_code = request.getParameter("processing_code");

        System.out.println(processing_code + "11111");
        //2.调用service层判断是否存在

        List<Epm_st_count> mac = iEpm_st_countService.findByProcessing_deptcode(department,processing_code);
       // List<Epm_st_count> mac = iEpm_st_countService.findByProcessing_code(processing_code);
        System.out.println(mac);
        if (!mac.isEmpty()) {
            info.setFlag(false);
            errorList.add("department");
            errorList.add("processing_code");
        } else {
            info.setFlag(true);
        }
        info.setErrorList(errorList);
        // 响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(), info);

    }

    @RequestMapping("/check1.do")
    public void check1(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        //1.获取信息
        String department=request.getParameter("department");
        String processing_code = request.getParameter("processing_code");
        System.out.println(processing_code + "11111");
        //2.调用service层判断是否存在
       // Epm_processing_code mac = iEpm_processing_codeService.findByprocessing_code(processing_code);
        Epm_processing_code mac = iEpm_processing_codeService.findByprocessing_deptcode(department,processing_code);
        System.out.println(mac);
        if (mac!=null) {
            info.setFlag(false);
            errorList.add("department");
            errorList.add("processing_code");
        } else {
            info.setFlag(true);
        }
        info.setErrorList(errorList);
        // 响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(), info);

    }

    /**
     *@Description: 通过工程代码查找工程名称(json)
     *@Author: a135109
     *@time: 2020/5/26 15:22
     */
    @RequestMapping("/findProName")
    public void findProName(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String processing_code = request.getParameter("processing_code");
        Epm_processing_code epm_processing_code = iEpm_processing_codeService.findByprocessing_code(processing_code);
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("text/html");
        mapper.writeValue(response.getOutputStream(),epm_processing_code);
    }

    /**
     *@Description: 通过工程代码和部门代码查找工程名称(json)
     *@Author: a171773
     *@time: 2021/01/27 15:22
     */
    @RequestMapping("/findProNameByCodeDept")
    public void findProNameByCodeDept(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String processing_code = request.getParameter("processing_code");
        String department=request.getParameter("department");
        Epm_processing_code epm_processing_code = iEpm_processing_codeService.findByprocessing_deptcode(department,processing_code);
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("text/html");
        mapper.writeValue(response.getOutputStream(),epm_processing_code);
    }
}
