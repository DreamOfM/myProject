package com.tdk.txm_java.service.impl;

import com.tdk.txm_java.dao.IEpm_daily_reportDao;
import com.tdk.txm_java.dao.IEpm_employee_productionDao;
import com.tdk.txm_java.dao3.IEpm_ehr_daily_reportDao;
import com.tdk.txm_java.domain.*;
import com.tdk.txm_java.service.*;
import com.tdk.txm_java.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;


@Service
@Transactional
public class Epm_daily_reportServiceImpl implements IEpm_daily_reportService {

    @Autowired
    private IEpm_ehr_daily_reportDao  iEpm_ehr_daily_reportDao;
    @Autowired
    private IEpm_daily_reportDao iEpm_daily_reportDao;
    @Autowired
    private IEpm_daily_reportService iEpm_daily_reportService;
    @Autowired
    private IEpm_employee_productionDao iEpm_employee_productionDao;


    @Override
    public void save(Epm_daily_report epm_daily_report) throws Exception {
        iEpm_daily_reportDao.save(epm_daily_report);
    }

    @Override
    public void saveEhr(Epm_daily_report epm_daily_report) throws Exception {
        iEpm_ehr_daily_reportDao.save(epm_daily_report);
    }

    @Override
    public void deleteAll() throws Exception {
       iEpm_ehr_daily_reportDao.deleteAll();
    }
    @Override
    public void deleteStartDate(String date_from) throws Exception {
        iEpm_daily_reportDao.deleteStartDate(date_from);
    }

    @Override
    public void snedDataToEhr() throws Exception {
//        取得上月21号日期
        Calendar cal = Calendar.getInstance();
        String date_from= String.valueOf(cal.get(Calendar.YEAR)*10000 +cal.get(Calendar.MONTH)*100+21);
        iEpm_ehr_daily_reportDao.deleteAll();
        iEpm_daily_reportDao.deleteStartDate(date_from);
        List< Epm_daily_report> epm_daily_reportList=iEpm_employee_productionDao.findStartDate(date_from);
        for(Epm_daily_report epm_daily_report:epm_daily_reportList) {
            // 0 代表前面补充0 7代表长度为 d 代表参数为正数型
            epm_daily_report.setEmployee_no_s(String.format("%07d",epm_daily_report.getEmployee_no()));
            if(null==epm_daily_report.getEfficiency()){
                epm_daily_report.setEfficiency(0.0);
            } else{
                if(epm_daily_report.getEfficiency()>=10.0) epm_daily_report.setEfficiency(9.99999);
            }
            if(null==epm_daily_report.getEfficiency_t()){
                epm_daily_report.setEfficiency_t(0.0);
            } else{
                if(epm_daily_report.getEfficiency_t()>=10.0) epm_daily_report.setEfficiency_t(9.99999);
            }
            if(null==epm_daily_report.getPerformance_code()){
                epm_daily_report.setPerformance_code("");
            }
            if(null==epm_daily_report.getProcessing_name()){
                epm_daily_report.setProcessing_name("");
            }
            if(null==epm_daily_report.getItem()){
                epm_daily_report.setItem("");
            }
            if(null==epm_daily_report.getItem_spec()){
                epm_daily_report.setItem_spec("");
            }
            if(null==epm_daily_report.getScore()){
                epm_daily_report.setScore(0.0);
            }
            if(null==epm_daily_report.getMark()){
                epm_daily_report.setMark("");
            }
            iEpm_ehr_daily_reportDao.save(epm_daily_report);
           save(epm_daily_report);
        }
    }
}
