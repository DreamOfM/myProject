package com.tdk.txm_java.dao;


import com.tdk.txm_java.domain.Epm_employee_performance;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IEpm_employee_performanceDao {

    // 查询所有信息
    @Select("select * from epm_employee_performance")
    public List<Epm_employee_performance> findAll() throws Exception;

    @Select("select * from epm_employee_performance  where employee_no=#{employee_no} and date=#{date} and class_type=#{class_type} and processing_code=#{processing_code} and  performance_code=#{performance_code}")
    public Epm_employee_performance findByUkey(Epm_employee_performance epm_employee_performance) throws Exception;

    @Select("select * from epm_employee_performance where employee_no=#{employee_no} and date=#{date} and class_type=#{class_type}")
    public List<Epm_employee_performance> findByemployee_date(@Param("employee_no") String employee_no,@Param("date")String date,@Param("class_type")String class_type) throws Exception;

    @Insert("insert into epm_employee_performance" +
            "(employee_no,employee_name,date,class_type,dept_code,processing_code,performance_code,item,score,mark,number,login_time,login_oid,update_oid,update_program )" +
            "values(#{employee_no},#{employee_name},#{date},#{class_type},#{dept_code},#{processing_code},#{performance_code},#{item},#{score},#{mark},#{number},now(),#{login_oid},#{update_oid},#{update_program})")
    void save(Epm_employee_performance epm_employee_performance);

    @Update("update epm_employee_performance set  " +
            "employee_no=#{employee_no},employee_name=#{employee_name}, date=#{date}, class_type=#{class_type}, dept_code=#{dept_code},processing_code=#{processing_code}, performance_code=#{performance_code}, item=#{item}, score=#{score}, mark=#{mark}, number=#{number}, login_time=#{login_time}, login_oid=#{login_oid}, update_oid=#{update_oid}, update_program=#{update_program} " +
            "where id =#{id}  ")
    void update(Epm_employee_performance epm_employee_performance);

    @Delete("delete from epm_employee_performance where id =#{id}  ")
    void delete(int id);

    @Select("select * from epm_employee_performance where id=#{id}")
    public Epm_employee_performance findById(int id) throws Exception;

    /**
     *@Description: 月作业报表查询
     *@Author: a135109
     *@time: 2020/6/2 15:44
     */
    @Select("select * from epm_employee_performance where " +
            "employee_no = #{employee_no} and " +
            "date between (case #{date_1} when '' then date else #{date_1} end) and (case #{date_2} when '' then date else #{date_2} end) " +
            "order by employee_no")
    public List<Epm_employee_performance> findByMonthlyReport(@Param("employee_no") int employee_no, @Param("date_1") String date_1, @Param("date_2") String date_2) throws Exception;


}
