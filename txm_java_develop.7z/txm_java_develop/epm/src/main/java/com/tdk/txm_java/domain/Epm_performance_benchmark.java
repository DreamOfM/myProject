package com.tdk.txm_java.domain;

public class Epm_performance_benchmark {
    private int id;
    private String type;
    private String performance_code;
    private String item;
    private int score;
    private String mark;
    private Double efficiency_min;
    private Double efficiency_max;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPerformance_code() {
        return performance_code;
    }

    public void setPerformance_code(String performance_code) {
        this.performance_code = performance_code;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public String getMark() {
        return mark;
    }

    public void setMark(String mark) {
        this.mark = mark;
    }

    public Double getEfficiency_min() {
        return efficiency_min;
    }

    public void setEfficiency_min(Double efficiency_min) {
        this.efficiency_min = efficiency_min;
    }

    public Double getEfficiency_max() {
        return efficiency_max;
    }

    public void setEfficiency_max(Double efficiency_max) {
        this.efficiency_max = efficiency_max;
    }

    @Override
    public String toString() {
        return "Epm_performance_benchmark{" +
                "id=" + id +
                ", type='" + type + '\'' +
                ", performance_code='" + performance_code + '\'' +
                ", item='" + item + '\'' +
                ", score=" + score +
                ", mark='" + mark + '\'' +
                ", efficiency_min=" + efficiency_min +
                ", efficiency_max=" + efficiency_max +
                '}';
    }
}
