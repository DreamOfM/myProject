package com.tdk.txm_java.service;




import com.tdk.txm_java.domain.Epm_employee_performance;

import java.util.List;

public interface IEpm_employee_performanceService {
    List<Epm_employee_performance> findAll() throws Exception;

    Epm_employee_performance findByUkey(Epm_employee_performance epm_employee_performance) throws Exception;

    List<Epm_employee_performance> findByemployee_date(String employee_no, String date, String class_type) throws Exception;
    void save(Epm_employee_performance epm_employee_performance) throws Exception;
    void update(Epm_employee_performance epm_employee_performance) throws Exception;
    Epm_employee_performance findById(int id) throws Exception;
    void delete(int id) throws Exception;
    List<Epm_employee_performance> findByMonthlyReport(int employee_no,String date_1,String date_2) throws Exception;

}
