package com.tdk.txm_java.dao3;


import com.tdk.txm_java.domain.Epm_monthly_report;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IEpm_ehr_monthly_reportDao {

    @Insert("insert into epm_monthly_report" +
            "(cremonth,employee_no,employee_name,date_from,date_to,dept_code,efficiency,eff_score,b_score,c_score,d_score,sum_score,ranking,flag" +
            ",senddate )" +
            "values(#{create_month},#{employee_no_s},#{employee_name},#{date_from},#{date_to},#{dept_code},#{efficiency},#{eff_score},#{b_score},#{c_score},#{d_score},#{sum_score},#{ranking},#{flag}" +
            ",getdate()  )")
    void save(Epm_monthly_report epm_monthly_report);


    @Delete("delete  from epm_monthly_report  where cremonth =#{create_month}  ")
    void deleteByMonth(String create_month);

}
