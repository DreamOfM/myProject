package com.tdk.txm_java.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tdk.txm_java.domain.Com_employee;
import com.tdk.txm_java.domain.Epm_employee_production;
import com.tdk.txm_java.domain.ResultInfo;
import com.tdk.txm_java.service.ICom_employeeService;
import com.tdk.txm_java.service.IEpm_employee_productionService;
import com.tdk.txm_java.utils.DateUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

import static java.time.LocalDate.now;

@Controller
@RequestMapping("/epm_employee_production")
public class Epm_employee_productionController {
    @Autowired
    private IEpm_employee_productionService iEpm_employee_productionService;

    @Autowired
    private ICom_employeeService iCom_employeeService;

    /**
     *@Description: 查询工号
     *@Author: a135109
     *@time: 2020/5/28 13:39
     */
    @RequestMapping("/findByMmemno")
    public ModelAndView findByMmemno(String mmemno,String class_type,String date) throws Exception {
        Com_employee com_employee = iCom_employeeService.findByEmployee_id(mmemno);
        List<Epm_employee_production> ls = iEpm_employee_productionService.findByKey(mmemno,class_type,date);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("epm-employee-production-list");
        mv.addObject("com_xxmmp",com_employee);
        mv.addObject("class_type",class_type);
        mv.addObject("date",date);
        mv.addObject("epm_employee_production",ls);
        return mv;
    }
    @RequestMapping("/addByMmemno")
    public ModelAndView addByMmemno(String mmemno,String class_type,String date) throws Exception {
        Com_employee com_employee = iCom_employeeService.findByEmployee_id(mmemno);
        List<Epm_employee_production> ls = iEpm_employee_productionService.findByKey(mmemno,class_type,date);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("epm-employee-production-add");
        if(class_type==null){
            class_type="A";
        }
        if(date==null){
            date= DateUtils.getDateBefore(-1);
        }
        mv.addObject("mmemno",com_employee.getMmemno());
        mv.addObject("mmdnam",com_employee.getMmdnam());
        mv.addObject("com_xxmmp",com_employee);
        mv.addObject("class_type",class_type);
        mv.addObject("date", DateUtils.getDateBefore(-1));
        mv.addObject("epm_employee_production",ls);
        return mv;
    }
    /**
    *@Description: 查询股别
    *@Author: a135109
    *@time: 2020/6/19 9:10
    */@RequestMapping("/findByMmdept")
    public ModelAndView findByMmdept(String mmdept) throws Exception {
        List<Com_employee> ls = iCom_employeeService.findByDept(mmdept);
        System.out.println(ls);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("epm-employee-list");
        mv.addObject("mmdept",mmdept);
        mv.addObject("com_employee",ls);
        return mv;
    }

    @RequestMapping("/findByMmdept2")
    public ModelAndView findByMmdept2(String mmdept) throws Exception {
        List<Com_employee> ls = iCom_employeeService.findByDept(mmdept);
        List<Epm_employee_production> epm_employee_productions=new ArrayList<>();
        for(Com_employee com_employee:ls){
            Epm_employee_production epm_employee_production=new Epm_employee_production();
            epm_employee_production.setEmployee_no(Integer.parseInt(com_employee.getMmemno()));
            epm_employee_production.setEmployee_name(com_employee.getMmdnam());
            epm_employee_productions.add(epm_employee_production);
        }
        ModelAndView mv = new ModelAndView();
        mv.setViewName("epm-employee-list-new");
        mv.addObject("mmdept",mmdept);
        mv.addObject("com_employee",ls);
        return mv;
    }

    @RequestMapping("/findByMmdeptcode2")
    public ModelAndView findByMmdeptcode2(String department, String mmdept) throws Exception {
        List<Com_employee> ls = iCom_employeeService.findByDeptCode(department,mmdept);
        List<Epm_employee_production> epm_employee_productions=new ArrayList<>();
        for(Com_employee com_employee:ls){
            Epm_employee_production epm_employee_production=new Epm_employee_production();
            epm_employee_production.setEmployee_no(Integer.parseInt(com_employee.getMmemno()));
            epm_employee_production.setEmployee_name(com_employee.getMmdnam());
            epm_employee_productions.add(epm_employee_production);
        }
        ModelAndView mv = new ModelAndView();
        mv.setViewName("epm-employee-list-new");
        mv.addObject("mmdept",mmdept);
        mv.addObject("department",department);
        mv.addObject("com_employee",ls);
        return mv;
    }

    /**
     *@Description: 修改ST表
     *@Author: a135109
     *@time: 2020/5/25 14:48
     */
    @RequestMapping("/update")
    public String update(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception {
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        int b=0;
        int c=0;
        while (1==1){
            for(String name1 : set){
                String[] vals = (String[]) map.get(name1);
                c=vals.length;
                if(b<c) {
                    hashMap.put(name1, vals[b]);
                }
            }
            Epm_employee_production epm = new Epm_employee_production();
            int id1 = Integer.parseInt(hashMap.get("id"));
            System.out.println(id1);
            if (id1!=0){
                System.out.println(id1);
                epm=iEpm_employee_productionService.findById(id1);
                try {
                    BeanUtils.populate(epm,hashMap);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    e.printStackTrace();
                }
                String username= (String) httpSession.getAttribute("username");
                epm.setUpdate_oid(username);
                epm.setUpdate_program("/update.do");
                iEpm_employee_productionService.update(epm);
            }
            b++;
            if(b==c) break;
        }
        return "redirect:findByMmemno.do";
    }

    /**
     *@Description: 删除
     *@Author: a135109
     *@time: 2020/5/27 8:42
     */
    @RequestMapping("/delete.do")
    public String delete(int ids[],String mmemno,String class_type,String date, RedirectAttributes attr) throws Exception{
        System.out.println(ids);
        if(ids != null && ids.length > 0){
            //遍历数组
            for (int id : ids) {
                //单条删除
                iEpm_employee_productionService.delete(id);
            }
        }
        //传递条件
        attr.addAttribute("mmemno",mmemno);
        attr.addAttribute("class_type",class_type);
        attr.addAttribute("date",date);
        return "redirect:findByMmemno.do";
    }

    @RequestMapping("/check.do")
    public void check(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        info.setFlag(true);
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //测试前端数据是否传送过来
        System.out.println(map.entrySet().toString() + "数据已传过来");
        List<String> errorList=new ArrayList<String>();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        Epm_employee_production epm_employee_production = new Epm_employee_production();
        while (1 == 1) {
            for (String name1 : set) {
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                hashMap.put(name1, vals[b]);
            }
            try {
                BeanUtils.populate(epm_employee_production, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            int employee_no = epm_employee_production.getEmployee_no();
            String date = epm_employee_production.getDate();
            String class_type = epm_employee_production.getClass_type();
            String item_no = epm_employee_production.getItem_no();
            String processing_code= epm_employee_production.getProcessing_code();
            Epm_employee_production epm = iEpm_employee_productionService.findByUniKey(employee_no,date,class_type,item_no,processing_code);
            if (epm!=null) {
                info.setFlag(false);
                String errLine = String.valueOf(b);
                errorList.add("item_no" + errLine);
                errorList.add("processing_code" + errLine);
                info.setErrorMsg("已存在");
            }
            b++;
            if (b == c) break;
        }
        info.setErrorList(errorList);
        info.getErrorMsg();
        // 响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(),info);
    }

    @RequestMapping("/save")
    public void save(HttpServletRequest request, HttpServletResponse response,HttpSession httpSession) throws Exception {
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //测试前端数据是否传送过来
        System.out.println(map.entrySet().toString() + "数据已传过来");
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        Epm_employee_production epm_employee_production = new Epm_employee_production();
        while (1 == 1) {
            for (String name1 : set) {
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                hashMap.put(name1, vals[b]);
            }
            try {
                BeanUtils.populate(epm_employee_production, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //添加一个判断，如果为空值或者没有输入则不往数据库里插数据
            if (epm_employee_production.getItem_no().equals(null) || epm_employee_production.getItem_no().equals("")) {
                b++;
                if (b == c) break;
                continue;
            }
            String username= (String) httpSession.getAttribute("username");
            epm_employee_production.setUpdate_oid(username);
            epm_employee_production.setLogin_oid(username);
            epm_employee_production.setUpdate_program("/employee_production/save.do");
            iEpm_employee_productionService.save(epm_employee_production);
            b++;
            if (b == c) break;
        }
    }

    /**
     *@Description: 通过工号查询(json)
     *@Author: a135109
     *@time: 2020/5/26 15:22
     */
    @RequestMapping("/findMno")
    public void findMno(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String mmemno = request.getParameter("mmemno");
        Com_employee com_employee = iCom_employeeService.findByEmployee_id(mmemno);
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("text/html");
        mapper.writeValue(response.getOutputStream(),com_employee);
    }

}
