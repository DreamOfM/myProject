package com.tdk.txm_java.dao;


import com.tdk.txm_java.domain.Epm_st_count;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IEpm_st_countDao {

    // 查询所有信息
    @Select("select * from epm_st_count left join epm_processing_code on epm_st_count.processing_code = epm_processing_code.processing_code left join epm_processing_item on epm_st_count.item_no = epm_processing_item.item_no ")
    public List<Epm_st_count> findAll() throws Exception;

    //追加部门2021.01.29
    @Insert("insert into epm_st_count" +
            "(item_no,processing_code,st_value,login_time,login_oid,update_oid,update_program,department )" +
            "values(#{item_no},#{processing_code},#{st_value},now(),#{login_oid},#{update_oid},#{update_program},#{department})")
    void save(Epm_st_count epm_st_count);

    @Update("update epm_st_count set  " +
            "item_no=#{item_no}, processing_code=#{processing_code}, st_value=#{st_value}," +
            " update_oid=#{update_oid}, update_program=#{update_program} " +
            "where id =#{id}  ")
    void update(Epm_st_count epm_st_count);

    @Delete("delete from epm_st_count where id =#{id}  ")
    void delete(int id);

    @Select("select * from epm_st_count left join epm_processing_code on epm_st_count.processing_code = epm_processing_code.processing_code left join epm_processing_item on epm_st_count.item_no = epm_processing_item.item_no where epm_st_count.item_no=#{item_no}")
    public List<Epm_st_count> findByItemNo(String item_no) throws Exception;

    @Select("select * from epm_st_count left join epm_processing_code on epm_st_count.processing_code = epm_processing_code.processing_code and epm_st_count.department = epm_processing_code.department left join epm_processing_item on epm_st_count.item_no = epm_processing_item.item_no and epm_st_count.department = epm_processing_item.department where epm_st_count.item_no=#{item_no} and epm_st_count.department=#{department}")
    public List<Epm_st_count> findBydeptItemNo(@Param("department") String department,@Param("item_no") String item_no) throws Exception;

    @Select("select * from epm_st_count where processing_code=#{processing_code}")
    public List<Epm_st_count> findByProcessing_code(String processing_code) throws Exception;

    @Select("select * from epm_st_count where department=#{department} and processing_code=#{processing_code} ")
    public List<Epm_st_count> findByProcessing_deptcode(@Param("department") String department,@Param("processing_code") String processing_code) throws Exception;

    @Select("select * from epm_st_count where item_no=#{item_no}")
    public List<Epm_st_count> findByItem(String item_no) throws Exception;

    @Select("select * from epm_st_count where department=#{department} and item_no=#{item_no}")
    public List<Epm_st_count> findBydeptItem(@Param("department") String department,@Param("item_no") String item_no) throws Exception;

    @Select("select * from epm_st_count where id=#{id}")
    public Epm_st_count findById(int id) throws Exception;

    @Select("select * from epm_st_count left join epm_processing_item on epm_st_count.item_no = epm_processing_item.item_no left join epm_processing_code on epm_st_count.processing_code = epm_processing_code.processing_code where epm_st_count.item_no=#{item_no} and epm_st_count.processing_code=#{processing_code}")
    public Epm_st_count findByKey(@Param("item_no") String item_no,@Param("processing_code") String processing_code) throws Exception;

    @Select("select * from epm_st_count left join epm_processing_item on epm_st_count.item_no = epm_processing_item.item_no left join epm_processing_code on epm_st_count.processing_code = epm_processing_code.processing_code  where epm_st_count.item_no=#{item_no} and epm_st_count.processing_code=#{processing_code} and epm_st_count.department=#{department}")
    public Epm_st_count findByKey1(@Param("item_no") String item_no,@Param("processing_code") String processing_code,@Param("department") String department) throws Exception;
}
