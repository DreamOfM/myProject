package com.tdk.txm_java.service.impl;


import com.tdk.txm_java.dao.IEpm_employee_productionDao;
import com.tdk.txm_java.domain.Epm_employee_production;
import com.tdk.txm_java.service.IEpm_employee_productionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class Epm_employee_productionServiceImpl implements IEpm_employee_productionService {


    @Autowired
    private IEpm_employee_productionDao iEpm_employee_productionDao;

    @Override
    public List<Epm_employee_production> findAll() throws Exception {
        return iEpm_employee_productionDao.findAll();
    }

    @Override
    public void save(Epm_employee_production epm_employee_production) throws Exception {
        iEpm_employee_productionDao.save(epm_employee_production);
    }

    @Override
    public void update(Epm_employee_production epm_employee_production) throws Exception {
        iEpm_employee_productionDao.update(epm_employee_production);
    }

    @Override
    public void delete(int id) throws Exception {
        iEpm_employee_productionDao.delete(id);
    }
    @Override
    public List<Epm_employee_production> findByKey(String employee_no,String class_type,String date) throws Exception {
        return iEpm_employee_productionDao.findByKey(employee_no,class_type,date);
    }

    @Override
    public Epm_employee_production findById(int id) throws Exception {
        return iEpm_employee_productionDao.findById(id);
    }

    @Override
    public Epm_employee_production findByUniKey(int employee_no, String date, String class_type, String item_no, String processing_code) throws Exception {
        return iEpm_employee_productionDao.findByUniKey(employee_no,date,class_type,item_no,processing_code);
    }

   // @Override
   // public List<Epm_employee_production> findByStKey(String item_no, String processing_code) throws Exception {
        //return iEpm_employee_productionDao.findByStKey(item_no,processing_code);
    //}

    @Override
    public List<Epm_employee_production> findByStKey(String item_no, String processing_code,String department) throws Exception {
        return iEpm_employee_productionDao.findByStKey(item_no,processing_code,department);
    }


    @Override
    public List<Epm_employee_production> findByDailyReport(String employee_no, String date_1, String date_2) throws Exception {
        if (date_2==""){ date_2 = new String(date_1);}
        List<Epm_employee_production> epm_employee_productions = iEpm_employee_productionDao.findByDailyReport(employee_no,date_1,date_2);
        return epm_employee_productions;
    }

    @Override
    public List<Epm_employee_production> findByMonthlyReport(String employee_no, String date_1, String date_2) throws Exception {
        if (date_2==""){ date_2 = new String(date_1);}
        List<Epm_employee_production> epm_employee_productions = iEpm_employee_productionDao.findByMonthlyReport(employee_no,date_1,date_2);
        return epm_employee_productions;
    }


}
