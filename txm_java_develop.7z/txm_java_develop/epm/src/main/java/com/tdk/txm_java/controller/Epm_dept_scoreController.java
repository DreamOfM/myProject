package com.tdk.txm_java.controller;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.tdk.txm_java.domain.Com_employee;
import com.tdk.txm_java.domain.Epm_dept_score;
import com.tdk.txm_java.domain.ResultInfo;
import com.tdk.txm_java.service.ICom_employeeService;
import com.tdk.txm_java.service.IEpm_dept_scoreService;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.*;

@Controller
@RequestMapping("/epm_dept_score")
public class Epm_dept_scoreController {
    @Autowired
    private IEpm_dept_scoreService iEpm_dept_scoreService;

    @Autowired
    private ICom_employeeService iCom_employeeService;

    @RequestMapping("/findByDept")
    public ModelAndView findByDept(String dept_code) throws Exception {
        Epm_dept_score epm_dept_score = iEpm_dept_scoreService.findByDept(dept_code);
        List<Epm_dept_score> epm_dept_scores=iEpm_dept_scoreService.findAll();
        System.out.println(epm_dept_score);
        ModelAndView mv = new ModelAndView();
        if(epm_dept_score==null) {
            mv.setViewName("epm-dept-score-add");
        }else {
            mv.setViewName("epm-dept-score-list");

            mv.addObject("epm_dept_score", epm_dept_score);
        }
        mv.addObject("dept_code", dept_code);
        mv.addObject("epm_dept_scores", epm_dept_scores);
        return mv;
    }

    @RequestMapping("/findByDeptCode")
    public ModelAndView findByDeptcode(String department,String dept_code) throws Exception {
        Epm_dept_score epm_dept_score = iEpm_dept_scoreService.findByDeptCode(department,dept_code);
        List<Epm_dept_score> epm_dept_scores=iEpm_dept_scoreService.findAll();
        System.out.println(epm_dept_score);
        ModelAndView mv = new ModelAndView();
        if(epm_dept_score==null) {
            mv.setViewName("epm-dept-score-add");
        }else {
            mv.setViewName("epm-dept-score-list");

            mv.addObject("epm_dept_score", epm_dept_score);
        }
        mv.addObject("department", department);
        mv.addObject("dept_code", dept_code);
        mv.addObject("epm_dept_scores", epm_dept_scores);
        return mv;
    }


    @RequestMapping("/delete.do")
    public String delete(int id) throws Exception{
        iEpm_dept_scoreService.delete(id);
        return "redirect:findByDept.do";
    }

    @RequestMapping("/save.do")
    public void save(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception {
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        info.setFlag(true);
        List<String> errorList=new ArrayList<String>();
        Epm_dept_score epm_dept_score= new Epm_dept_score();
        Map map = request.getParameterMap();
        BeanUtils.populate(epm_dept_score, map);
        String username= (String) httpSession.getAttribute("username");
        //Epm_dept_score epm = iEpm_dept_scoreService.findByDept(epm_dept_score.getDept_code());
        Epm_dept_score epm = iEpm_dept_scoreService.findByDeptCode(epm_dept_score.getDepartment(),epm_dept_score.getDept_code());
        //通过人数主档判断股别是否存在
        List<Com_employee> cls = iCom_employeeService.findByDept(epm_dept_score.getDept_code());
        if (epm!=null){
            info.setFlag(false);
            errorList.add("dept_code");
            info.setErrorMsg("添加失败，已存在");
        }else if ( cls.size()==0){
            info.setFlag(false);
            errorList.add("dept_code");
            info.setErrorMsg("股别不存在");
        }else {
            epm_dept_score.setUpdate_oid(username);
            epm_dept_score.setLogin_oid(username);
            epm_dept_score.setUpdate_program("/epm_dept_score/save");
            iEpm_dept_scoreService.save(epm_dept_score);
        }
        // 响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(),info);
    }

    @RequestMapping("/update.do")
    public void update(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception {
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        info.setFlag(true);
        Map<String,String[]> map = request.getParameterMap();
        Epm_dept_score epm = new Epm_dept_score();
        BeanUtils.populate(epm,map);
        Epm_dept_score epm_dept_score = new Epm_dept_score();
        epm_dept_score=iEpm_dept_scoreService.findById(epm.getId());
        BeanUtils.populate(epm_dept_score,map);
        String username= (String) httpSession.getAttribute("username");
        epm_dept_score.setUpdate_oid(username);
        epm_dept_score.setUpdate_program("/update.do");
        iEpm_dept_scoreService.update(epm_dept_score);
        // 响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(),info);
    }
}
