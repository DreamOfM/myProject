package com.tdk.txm_java.dao;


import com.tdk.txm_java.domain.Epm_performance_benchmark;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IEpm_performance_benchmarkDao {

    // 查询所有信息
    @Select("select * from epm_performance_benchmark")
    public List<Epm_performance_benchmark> findAll() throws Exception;

    @Select("select * from epm_performance_benchmark where performance_code=#{performance_code}")
    public Epm_performance_benchmark findByperformance_code(String performance_code) throws Exception;

    @Insert("insert into epm_performance_benchmark" +
            "(type,performance_code,item,score,mark,efficiency_min,efficiency_max )" +
            "values(#{type},#{performance_code},#{item},#{score},#{mark},#{efficiency_min},#{efficiency_max})")
    void save(Epm_performance_benchmark epm_performance_benchmark);

    @Update("update epm_performance_benchmark set  " +
            "type=#{type}, performance_code=#{performance_code}, item=#{item}, score=#{score}, mark=#{mark}, efficiency_min=#{efficiency_min}, efficiency_max=#{efficiency_max} " +
            "where id =#{id}  ")
    void update(Epm_performance_benchmark epm_performance_benchmark);

    @Delete("delete from epm_performance_benchmark where id =#{id}  ")
    void delete(int id);

    @Select("select * from epm_performance_benchmark where efficiency_min <=#{eff}  and efficiency_max>#{eff}")
    public Epm_performance_benchmark findByEff(Double eff) throws Exception;

}
