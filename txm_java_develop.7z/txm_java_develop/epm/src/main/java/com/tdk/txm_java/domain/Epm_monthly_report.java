package com.tdk.txm_java.domain;


import lombok.Data;

@Data
public class Epm_monthly_report {
    private String create_month;
    private int employee_no;
    private String employee_no_s;
    private String date_from;
    private String date_to;
    private String dept_code;
    private String group_dept_code;
    private String employee_name;
    private double efficiency;
    private String efficiency100;
    private double eff_score;
    private int b_score;
    private int c_score;
    private int d_score;
    private double sum_score;
    private int ranking;//排名
    private String flag;  //判断标志：判断是否取消考核
    private String leave_h;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;
}
