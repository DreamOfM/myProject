package com.tdk.txm_java.service;





import com.tdk.txm_java.domain.Epm_monthly_report;

import java.util.List;

public interface IEpm_monthly_reportService {
    List<Epm_monthly_report> findAll() throws Exception;
    void save(Epm_monthly_report epm_monthly_report) throws Exception;
    void update(Epm_monthly_report epm_monthly_report) throws Exception;
    void delete(int id) throws Exception;
//    List<Epm_monthly_report> creatMonthData(String dept_code) throws Exception;

    void creatMonthData(String month) throws Exception;

    List<Epm_monthly_report> creatMonthDataByDept(String dept_code, String date_1, String date_2) throws Exception;
}
