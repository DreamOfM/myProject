package com.tdk.txm_java.dao;


import com.tdk.txm_java.domain.Epm_processing_code;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IEpm_processing_codeDao {

    // 查询所有信息
    @Select("select * from epm_processing_code")
    public List<Epm_processing_code> findAll() throws Exception;


    // 按部门查询所有信息 2021.01.27
    @Select("select * from epm_processing_code  where department=#{department} ")
    public List<Epm_processing_code> findAllByDept(String department) throws Exception;

    @Select("select * from epm_processing_code where id=#{id}")
    public Epm_processing_code findByid(int id) throws Exception;

    @Select("select * from epm_processing_code where processing_code=#{processing_code}")
    public Epm_processing_code findByprocessing_code(String processing_code) throws Exception;

    @Select("select * from epm_processing_code where department=#{department} and processing_code=#{processing_code}")
    public Epm_processing_code findByprocessing_deptcode(@Param("department") String department, @Param("processing_code") String processing_code) throws Exception;


    @Insert("insert into epm_processing_code" +
            "(department,processing_code,processing_name,login_time,login_oid,update_oid,update_program )" +
            "values(#{department},#{processing_code},#{processing_name},now(),#{login_oid},#{update_oid},#{update_program})")
    void save(Epm_processing_code epm_processing_code);


    @Update("update epm_processing_code set  " +
            "processing_code=#{processing_code}, processing_name=#{processing_name}, login_time=#{login_time}, login_oid=#{login_oid},update_oid=#{update_oid}, update_program=#{update_program} " +
            "where id =#{id}  ")
    void update(Epm_processing_code epm_processing_code);

    @Delete("delete from epm_processing_code where id =#{id}  ")
    void delete(int id);

}
