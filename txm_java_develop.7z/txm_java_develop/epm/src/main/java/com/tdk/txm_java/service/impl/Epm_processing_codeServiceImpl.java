package com.tdk.txm_java.service.impl;


import com.tdk.txm_java.dao.IEpm_processing_codeDao;
import com.tdk.txm_java.domain.Epm_processing_code;
import com.tdk.txm_java.service.IEpm_processing_codeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class Epm_processing_codeServiceImpl implements IEpm_processing_codeService {


    @Autowired
    private IEpm_processing_codeDao iEpm_processing_codeDao;

    @Override
    public List<Epm_processing_code> findAll() throws Exception {
        return iEpm_processing_codeDao.findAll();
    }

    @Override
    public List<Epm_processing_code> findAllByDept(String department) throws Exception {
        return iEpm_processing_codeDao.findAllByDept(department);
    }

    @Override
    public Epm_processing_code findByid(int id) throws Exception {
        return iEpm_processing_codeDao.findByid(id);
    }

    @Override
    public Epm_processing_code findByprocessing_code(String processing_code) throws Exception {
        return iEpm_processing_codeDao.findByprocessing_code(processing_code);
    }

    @Override
    public Epm_processing_code findByprocessing_deptcode(String department,String processing_code) throws Exception {
        return iEpm_processing_codeDao.findByprocessing_deptcode(department,processing_code);
    }

    @Override
    public void save(Epm_processing_code epm_processing_code) throws Exception {
        epm_processing_code.setDepartment(epm_processing_code.getDepartment());
        epm_processing_code.setProcessing_code(epm_processing_code.getProcessing_code().toUpperCase());

        iEpm_processing_codeDao.save(epm_processing_code);
    }



    @Override
    public void update(Epm_processing_code epm_processing_code) throws Exception {
        epm_processing_code.setProcessing_code(epm_processing_code.getProcessing_code().toUpperCase());
        iEpm_processing_codeDao.update(epm_processing_code);
    }

    @Override
    public void delete(int id) throws Exception {
        iEpm_processing_codeDao.delete(id);
    }


}
