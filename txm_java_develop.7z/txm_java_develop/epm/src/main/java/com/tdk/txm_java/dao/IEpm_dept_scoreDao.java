package com.tdk.txm_java.dao;


import com.tdk.txm_java.domain.Epm_dept_score;
import org.apache.ibatis.annotations.*;
import org.springframework.security.core.parameters.P;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IEpm_dept_scoreDao {

    // 查询所有信息
    @Select("select * from epm_dept_score order by  dept_code")
    public List<Epm_dept_score> findAll() throws Exception;

    @Insert("insert into epm_dept_score" +
            "(dept_code,department,score_b,score_c,score_d,group_dept_code,login_time,login_oid,update_oid,update_program )" +
            "values(#{dept_code},#{department},#{score_b},#{score_c},#{score_d},#{group_dept_code},now(),#{login_oid},#{update_oid},#{update_program})")
    void save(Epm_dept_score epm_dept_score);

    @Update("update epm_dept_score set  " +
            "dept_code=#{dept_code}, department=#{department},score_b=#{score_b}, score_c=#{score_c}, score_d=#{score_d},group_dept_code=#{group_dept_code},login_time=#{login_time}, login_oid=#{login_oid}, update_oid=#{update_oid}, update_program=#{update_program} " +
            "where id =#{id}  ")
    void update(Epm_dept_score epm_dept_score);

    @Delete("delete from epm_dept_score where id =#{id}  ")
    void delete(int id);

    @Select("select * from epm_dept_score where dept_code=#{dept_code}")
    public Epm_dept_score findByDept(String dept_code) throws Exception;

    @Select("select * from epm_dept_score where department=#{department} and dept_code=#{dept_code}")
    public Epm_dept_score findByDeptCode(@Param("department") String department,@Param("dept_code") String dept_code) throws Exception;

    @Select("select * from epm_dept_score where group_dept_code=#{group_dept_code} or dept_code=#{group_dept_code} order by group_dept_code")
    public List<Epm_dept_score> findByGroupDept(String group_dept_code) throws Exception;

    @Select("select  DISTINCT score_b,score_c,score_d,group_dept_code  from epm_dept_score where group_dept_code like  #{like_dept_code} or  dept_code like  #{like_dept_code}  order by group_dept_code")
    public List<Epm_dept_score> findLikeGroupDept(String like_dept_code) throws Exception;

    @Select("select  DISTINCT score_b,score_c,score_d,group_dept_code from epm_dept_score order by group_dept_code ")
    public List<Epm_dept_score> findAllGroupDept() throws Exception;

    @Select("select * from epm_dept_score where id=#{id}")
    public Epm_dept_score findById(int id) throws Exception;
}
