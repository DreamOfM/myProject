package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Epm_dept_score {
    private int id;
    private String department;
    private String dept_code;
    private Integer score_b;
    private Integer score_c;
    private Integer score_d;
    private String group_dept_code;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getDept_code() {
        return dept_code;
    }

    public void setDept_code(String dept_code) {
        this.dept_code = dept_code;
    }

    public Integer getScore_b() {
        return score_b;
    }

    public void setScore_b(Integer score_b) {
        this.score_b = score_b;
    }

    public Integer getScore_c() {
        return score_c;
    }

    public void setScore_c(Integer score_c) {
        this.score_c = score_c;
    }

    public Integer getScore_d() {
        return score_d;
    }

    public void setScore_d(Integer score_d) {
        this.score_d = score_d;
    }

    public String getGroup_dept_code() {
        return group_dept_code;
    }

    public void setGroup_dept_code(String group_dept_code) {
        this.group_dept_code = group_dept_code;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    @Override
    public String toString() {
        return "Epm_dept_score{" +
                "id=" + id +
                ", department='" + department + '\'' +
                ", dept_code='" + dept_code + '\'' +
                ", score_b=" + score_b +
                ", score_c=" + score_c +
                ", score_d=" + score_d +
                ", group_dept_code='" + group_dept_code + '\'' +
                ", login_time='" + login_time + '\'' +
                ", login_oid='" + login_oid + '\'' +
                ", update_time='" + update_time + '\'' +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                '}';
    }
}
