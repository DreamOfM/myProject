package com.tdk.txm_java.dao3;


import com.tdk.txm_java.domain.Epm_daily_report;
import com.tdk.txm_java.domain.Epm_monthly_report;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.springframework.stereotype.Repository;

@Repository
public interface IEpm_ehr_daily_reportDao {

    @Insert("insert into epm_daily_report" +
            "(employee_no,credate,dept_code,class_type,employee_name,item_no,item_spec,processing_code,processing_name,input_quantity,input_minutes,efficiency,efficiency_t,performance_code,item,score,mark" +
            ",senddate )" +
            "values(#{employee_no_s},#{date},#{dept_code},#{class_type},#{employee_name},#{item_no},#{item_spec},#{processing_code},#{processing_name},#{input_quantity},#{input_minutes},#{efficiency},#{efficiency_t},#{performance_code},#{item},#{score},#{mark}" +
            ",getdate()  )")
    void save(Epm_daily_report epm_daily_report);

    @Delete("delete  from epm_daily_report  ")
    void deleteAll();

}
