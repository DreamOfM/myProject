package com.tdk.txm_java.service;




import com.tdk.txm_java.domain.Epm_employee_production;

import java.util.List;

public interface IEpm_employee_productionService {
    List<Epm_employee_production> findAll() throws Exception;
    void save(Epm_employee_production epm_employee_production) throws Exception;
    void update(Epm_employee_production epm_employee_production) throws Exception;
    void delete(int id) throws Exception;
    List<Epm_employee_production> findByKey(String employee_no,String class_type,String date) throws Exception;
    Epm_employee_production findById(int id) throws Exception;
    Epm_employee_production findByUniKey(int employee_no,String date,String class_type,String item_no,String processing_code) throws Exception;
    //List<Epm_employee_production> findByStKey(String item_no,String processing_code) throws Exception;
    List<Epm_employee_production> findByStKey(String item_no,String processing_code,String department) throws Exception;
    List<Epm_employee_production> findByDailyReport(String employee_no,String date_1,String date_2) throws Exception;
    List<Epm_employee_production> findByMonthlyReport(String employee_no,String date_1,String date_2) throws Exception;

}

