package com.tdk.txm_java.service;




import com.tdk.txm_java.domain.Epm_processing_item;

import java.util.List;

public interface IEpm_processing_itemService {
    List<Epm_processing_item> findAll() throws Exception;

    List<Epm_processing_item> findAllByDept(String department) throws Exception; //2021.01.27
    void save(Epm_processing_item epm_processing_item) throws Exception;
    void update(Epm_processing_item epm_processing_item) throws Exception;
    void delete(int id) throws Exception;
    Epm_processing_item findByItem_no(String item_no) throws Exception;
    Epm_processing_item findBydeptItem_no(String department,String item_no) throws Exception;
    Epm_processing_item findById(int id) throws Exception;
}
