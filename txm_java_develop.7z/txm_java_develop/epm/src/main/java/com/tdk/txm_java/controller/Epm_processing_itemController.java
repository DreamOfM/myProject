package com.tdk.txm_java.controller;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.tdk.txm_java.domain.Epm_processing_item;
import com.tdk.txm_java.domain.Epm_st_count;
import com.tdk.txm_java.domain.ResultInfo;
import com.tdk.txm_java.service.IEpm_processing_itemService;
import com.tdk.txm_java.service.IEpm_st_countService;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

@Controller
@RequestMapping("/epm_processing_item")
public class Epm_processing_itemController {
    @Autowired
    private IEpm_processing_itemService iEpm_processing_itemService;

    @Autowired
    private IEpm_st_countService iEpm_st_countService;


    /**
     * 修改
     *
     * @return
     * @throws Exception
     */

    //修改
    @RequestMapping("/update.do")
    public String update(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception {
        System.out.println("hhh");
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        String username = (String) httpSession.getAttribute("username");

        for (String name1 : set) {
            String[] vals = (String[]) map.get(name1);
            hashMap.put(name1, vals[0]);
        }
        System.out.println("aaaa");
        System.out.println(hashMap.get("id"));
        int id1 = Integer.parseInt(request.getParameter("id"));
        Epm_processing_item a = iEpm_processing_itemService.findById(id1);
        System.out.println("1212");
        System.out.println(a);
        try {
            //double传不成功
            BeanUtils.populate(a, hashMap);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

        a.setUpdate_oid(username);
        String update_program = "/epm_processing_item/update";
        a.setUpdate_program(update_program);
        iEpm_processing_itemService.update(a);

        return "redirect:findByitem_no.do";

    }

    /**
     * 根据品名代碼来查询
     *
     * @param item_no
     * @return
     * @throws Exception
     */
    @RequestMapping("/findByitem_no.do")
    public ModelAndView findByItem_no(String item_no) throws Exception {
        Epm_processing_item epm_processing_item = iEpm_processing_itemService.findByItem_no(item_no);
        ModelAndView mv = new ModelAndView();
//        if (processing_code != "" && epm_processing_item == null) {
//            mv.setViewName("epm-processing-add");
//        } else {
            mv.setViewName("epm-item-list");
            System.out.println(epm_processing_item);
//        }
            mv.addObject("epm_processing_item", epm_processing_item);
            return mv;

    }

    /**
     * 根据部门+品名代碼来查询2021.01.21
     * @param department
     * @param item_no
     * @return
     * @throws Exception
     *
     */

    @RequestMapping("/findBydeptitem_no.do")
    public ModelAndView findBydeptItem_no(String department,String item_no) throws Exception {
        Epm_processing_item epm_processing_item = iEpm_processing_itemService.findBydeptItem_no(department,item_no);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("epm-item-list");
        System.out.println(epm_processing_item);
//        }
        mv.addObject("department", department);
        mv.addObject("epm_processing_item", epm_processing_item);
        return mv;

    }


    /**
     * 新增
     */
    @RequestMapping("/save.do")
    public String save(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception {
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //测试前端数据是否传送过来？
        System.out.println(map.entrySet().toString() + "数据已传过来");
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();

        String username = (String) httpSession.getAttribute("username");
        Epm_processing_item epm_processing_item = new Epm_processing_item();

        for (String name1 : set) {
            String[] vals = (String[]) map.get(name1);
            int c = vals.length;
            hashMap.put(name1, vals[0]);
        }

        try {
            BeanUtils.populate(epm_processing_item, hashMap);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        epm_processing_item.setLogin_oid(username);
        epm_processing_item.setUpdate_oid(username);
        epm_processing_item.setUpdate_program("/epm_processing_item/save");
        iEpm_processing_itemService.save(epm_processing_item);

        return "redirect:findByitem_no.do";
    }

    /**
     * 删除
     */
    @RequestMapping("/delete.do")
    public String delete(int id) throws Exception {
        iEpm_processing_itemService.delete(id);
        return "redirect:findByitem_no.do";
    }

//ST表已存在，不可删除
    @RequestMapping("/check.do")
    public void check3(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        //1.获取信息
        String department = request.getParameter("department");  //2021.01.21追加
        String item_no = request.getParameter("item_no");

        System.out.println(item_no + "11111");
        //2.调用service层判断是否存在
       // List<Epm_st_count> mac = iEpm_st_countService.findByItem(item_no);
        List<Epm_st_count> mac = iEpm_st_countService.findBydeptItem(department,item_no);
        System.out.println(mac);
        if (!mac.isEmpty()) {
            info.setFlag(false);
            errorList.add("item_no");
        } else {
            info.setFlag(true);
        }
        info.setErrorList(errorList);
        // 响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(), info);

    }

    @RequestMapping("/check1.do")
    public void check1(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        //1.获取信息
        String item_no = request.getParameter("item_no");

        System.out.println(item_no + "11111");
        //2.调用service层判断是否存在
        Epm_processing_item mac = iEpm_processing_itemService.findByItem_no(item_no);
        System.out.println(mac);
        if (mac!=null) {
            info.setFlag(false);
            errorList.add("item_no");
        } else {
            info.setFlag(true);
        }
        info.setErrorList(errorList);
        // 响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(), info);

    }

    /**
     *@Description: 通过品名代码查找品名名称(json)
     *@Author: a135109
     *@time: 2020/5/25 8:53
     */
    @RequestMapping("/findItemSpec")
    public void findItemSpec(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String item_no = request.getParameter("item_no");
        Epm_processing_item epm_processing_item = iEpm_processing_itemService.findByItem_no(item_no);
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("text/html");
        mapper.writeValue(response.getOutputStream(),epm_processing_item);
    }

    /**
     *@Description: 通过品名代码查找品名名称(json)
     *@Author: a135109
     *@time: 2020/5/25 8:53
     */
    @RequestMapping("/findItemSpecDept")
    public void findItemSpecDept(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String department=request.getParameter("department");
        String item_no = request.getParameter("item_no");
        Epm_processing_item epm_processing_item = iEpm_processing_itemService.findBydeptItem_no(department,item_no);
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("text/html");
        mapper.writeValue(response.getOutputStream(),epm_processing_item);
    }


}
