package com.tdk.txm_java.service.impl;


import com.tdk.txm_java.dao.IEpm_employee_performanceDao;
import com.tdk.txm_java.domain.Epm_employee_performance;
import com.tdk.txm_java.service.IEpm_employee_performanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class Epm_employee_performanceServiceImpl implements IEpm_employee_performanceService {


    @Autowired
    private IEpm_employee_performanceDao iEpm_employee_performanceDao;

    @Override
    public List<Epm_employee_performance> findAll() throws Exception {
        return iEpm_employee_performanceDao.findAll();
    }
    @Override
    public Epm_employee_performance findByUkey(Epm_employee_performance epm_employee_performance) throws Exception{
        return  iEpm_employee_performanceDao.findByUkey(epm_employee_performance);
    }
    @Override
    public List<Epm_employee_performance> findByemployee_date(String employee_no,String date,String class_type) throws Exception {
        return iEpm_employee_performanceDao.findByemployee_date(employee_no,date,class_type);
    }

    @Override
    public void save(Epm_employee_performance epm_employee_performance) throws Exception {
        epm_employee_performance.setPerformance_code(epm_employee_performance.getPerformance_code().toUpperCase());
        iEpm_employee_performanceDao.save(epm_employee_performance);
    }

    @Override
    public void update(Epm_employee_performance epm_employee_performance) throws Exception {
        epm_employee_performance.setPerformance_code(epm_employee_performance.getPerformance_code().toUpperCase());
        iEpm_employee_performanceDao.update(epm_employee_performance);
    }

    @Override
    public void delete(int id) throws Exception {
        iEpm_employee_performanceDao.delete(id);
    }

    @Override
    public Epm_employee_performance findById(int id) throws Exception {
        return iEpm_employee_performanceDao.findById(id);
    }

    @Override
    public List<Epm_employee_performance> findByMonthlyReport(int employee_no, String date_1, String date_2) throws Exception {
        if (date_2==""){ date_2 = new String(date_1);}
        List<Epm_employee_performance> epm_employee_performances = iEpm_employee_performanceDao.findByMonthlyReport(employee_no,date_1,date_2);
        return epm_employee_performances;
    }

}
