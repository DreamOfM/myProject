package com.tdk.txm_java.domain;


import lombok.Data;

import java.util.Date;

@Data
public class Epm_daily_report {
    private Integer employee_no;//工号
    private String employee_no_s;
    private Date date;//日期
    private String dept_code;//股别
    private String class_type;//班组
    private String employee_name;//姓名
    private String item_no;//品名代码
    private String item_spec;//品名描述
    private String processing_code;//工程
    private String processing_name;//工程描述
    private Double input_quantity;//投入数量
    private int input_minutes;//当日投入分钟
    private Double efficiency;//效率
    private Double efficiency_t;//汇总效率
    private String performance_code;//考核代码
    private String item;//品质明细
    private Double score;//分数
    private String mark;//考核备注
    private Double st_value;//epm_st_count

}
