package com.tdk.txm_java.dao;


import com.tdk.txm_java.domain.Epm_processing_item;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IEpm_processing_itemDao {

    // 查询所有信息
    @Select("select * from epm_processing_item")
    public List<Epm_processing_item> findAll() throws Exception;

    // 按部门查询所有信息
    @Select("select * from epm_processing_item where department=#{department}")
    public List<Epm_processing_item> findAllByDept(String department) throws Exception;


    //追加保存部门add 2021.01.29
    @Insert("insert into epm_processing_item" +
            "(item_no,item_spec,login_time,login_oid,update_oid,update_program,department)" +
            "values(#{item_no},#{item_spec},now(),#{login_oid},#{update_oid},#{update_program},#{department})")
    void save(Epm_processing_item epm_processing_item);

    @Update("update epm_processing_item set  " +
            "item_no=#{item_no}, item_spec=#{item_spec}, login_time=#{login_time}, login_oid=#{login_oid},update_oid=#{update_oid}, update_program=#{update_program} " +
            "where id =#{id}  ")
    void update(Epm_processing_item epm_processing_item);

    @Delete("delete from epm_processing_item where id =#{id}  ")
    void delete(int id);

    @Select("select * from epm_processing_item where item_no=#{item_no}")
    public Epm_processing_item findByItem_no(String item_no);

    @Select("select * from epm_processing_item where department=#{department} and item_no=#{item_no}")
    public Epm_processing_item findBydeptItem_no(@Param("department") String department,@Param("item_no") String item_no);

    @Select("select * from epm_processing_item where id=#{id}")
    public Epm_processing_item findById(int id) throws Exception;

}
