package com.tdk.txm_java.service;




import com.tdk.txm_java.domain.Epm_processing_code;

import java.util.List;

public interface IEpm_processing_codeService {
    List<Epm_processing_code> findAll() throws Exception;
    //2021.01.27
    List<Epm_processing_code> findAllByDept(String department) throws Exception;
    public Epm_processing_code findByid(int id) throws Exception;
    public Epm_processing_code findByprocessing_code(String processing_code) throws Exception;
    public Epm_processing_code findByprocessing_deptcode(String department, String processing_code) throws Exception;
    void save(Epm_processing_code Epm_processing_code) throws Exception;
    void update(Epm_processing_code epm_processing_code) throws Exception;
    void delete(int id) throws Exception;

}
