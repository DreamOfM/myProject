package com.tdk.txm_java.service;

import com.tdk.txm_java.domain.Epm_daily_report;

import java.util.List;

public interface IEpm_daily_reportService {
    void save(Epm_daily_report epm_daily_report) throws Exception;

    void saveEhr(Epm_daily_report epm_daily_report) throws Exception;

    void deleteAll() throws Exception;

    void deleteStartDate(String date_from) throws Exception;

    void snedDataToEhr() throws Exception;
}
