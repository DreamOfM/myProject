package com.tdk.txm_java.service.impl;


import com.tdk.txm_java.dao.IEpm_monthly_reportDao;
import com.tdk.txm_java.dao3.ICom_ehr_pmonthkh_regDao;
import com.tdk.txm_java.dao3.IEpm_ehr_monthly_reportDao;
import com.tdk.txm_java.domain.*;
import com.tdk.txm_java.service.*;
import com.tdk.txm_java.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional
public class Epm_monthly_reportServiceImpl implements IEpm_monthly_reportService {


    @Autowired
    private IEpm_monthly_reportDao iEpm_monthly_reportDao;
    @Autowired
    private IEpm_ehr_monthly_reportDao iEpm_ehr_monthly_reportDao;
    @Autowired
    private ICom_ehr_pmonthkh_regDao iCom_ehr_pmonthkh_regDao;
    @Autowired
    private IEpm_dept_scoreService iEpm_dept_scoreService;
    @Autowired
    private ICom_employeeService iCom_employeeService;
    @Autowired
    private IEpm_employee_productionService iEpm_employee_productionService;
    @Autowired
    private IEpm_employee_performanceService iEpm_employee_performanceService;

    @Override
    public List<Epm_monthly_report> findAll() throws Exception {
        return iEpm_monthly_reportDao.findAll();
    }

    @Override
    public void save(Epm_monthly_report epm_monthly_report) throws Exception {
        iEpm_monthly_reportDao.save(epm_monthly_report);
    }

    @Override
    public void update(Epm_monthly_report epm_monthly_report) throws Exception {
        iEpm_monthly_reportDao.update(epm_monthly_report);
    }

    @Override
    public void delete(int id) throws Exception {
        iEpm_monthly_reportDao.delete(id);
    }

    @Override
    public void creatMonthData(String create_month) throws Exception {
        if(create_month==""){
            create_month= DateUtils.date2String(new Date(),"yyyyMM");
        }
        iEpm_monthly_reportDao.deleteByMonth(create_month);
        iEpm_ehr_monthly_reportDao.deleteByMonth(create_month);
        String last_month= DateUtils.MonthAddMonth(create_month,-1);
        String date_1=last_month+"21";
        String date_2=create_month+"20";
        List<Epm_dept_score> epm_dept_scores= iEpm_dept_scoreService.findAllGroupDept();
        for(Epm_dept_score epm_dept_score:epm_dept_scores){
            List<Epm_monthly_report> epm_monthly_reports=creatMonthDataByDept(epm_dept_score.getGroup_dept_code(),date_1,date_2);
            int num=1;
            for(Epm_monthly_report epm_monthly_report:epm_monthly_reports){
                epm_monthly_report.setCreate_month(create_month);
                epm_monthly_report.setRanking(num);
                epm_monthly_report.setDate_from(date_1);
                epm_monthly_report.setDate_to(date_2);
//                epm_monthly_report.setDept_code(epm_dept_score.getDept_code());
                epm_monthly_report.setUpdate_program("creatMonthData");
                // 0 代表前面补充0 7代表长度为 d 代表参数为正数型
                epm_monthly_report.setEmployee_no_s(String.format("%07d",epm_monthly_report.getEmployee_no()));
                save(epm_monthly_report);
                iEpm_ehr_monthly_reportDao.save(epm_monthly_report);
                num++;
            }
        }
        System.out.println("finish");


    }


    @Override
    public List<Epm_monthly_report> creatMonthDataByDept(String dept_code, String date_1, String date_2) throws Exception {

        //建立一个Epm_dept_score对象，查找股别对应的分数基准
        List<Epm_dept_score> epm_dept_scores = iEpm_dept_scoreService.findByGroupDept(dept_code);

        //建立一个空的list对象，存放对应人员的epm_employee_production对象
        List<Epm_employee_production> ls = new ArrayList<>();
        int score_b_t = 0; //B得分累加
        int score_c_t= 0; //C得分累加
        int score_d_t = 0; //d得分累加
            for(Epm_dept_score epm_dept_score:epm_dept_scores) {
               score_b_t = epm_dept_score.getScore_b(); //B得分累加
               score_c_t = epm_dept_score.getScore_c(); //C得分累加
               score_d_t = epm_dept_score.getScore_d(); //d得分累加
                //通过股别从人事主档查找对应的人员，将人存在cls里
                List<Com_employee> cls = iCom_employeeService.findByDept(epm_dept_score.getDept_code());
                //遍历人员列表
                for (Com_employee employee : cls) {
                    //获取个人工号
                    String employee_no = employee.getMmemno();
                    //获取该员工对应的epm_employee_production对象
                    List<Epm_employee_production> eps = iEpm_employee_productionService.findByMonthlyReport(employee_no, date_1, date_2);
                    if(eps.size()==0){
                        //获取该员工考核信息
                        List<Epm_employee_performance> epm_employee_performances=new ArrayList<>();
                        try {
                            epm_employee_performances = iEpm_employee_performanceService.findByMonthlyReport(Integer.parseInt(employee_no), date_1, date_2);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        if(epm_employee_performances.size()>0){
                            Epm_employee_production epm_employee_production=new Epm_employee_production();
                            epm_employee_production.setEmployee_no(epm_employee_performances.get(0).getEmployee_no());
                            epm_employee_production.setEmployee_name(epm_employee_performances.get(0).getEmployee_name());
                            epm_employee_production.setDept_code(epm_employee_performances.get(0).getDept_code());
                            epm_employee_production.setInput_minutes(0.0);
                            epm_employee_production.setInput_quantity(0.0);
                            ls.add(epm_employee_production);
                        }
                    }
                    //奖该员工的epm_employee_production放到ls
                    ls.addAll(eps);
                }
            }
            //建立一个空的list,存放Epm_monthly_report对象
            List<Epm_monthly_report> sortList = new ArrayList<>();

            //当epm_dept_score存在时
            if (epm_dept_scores.size()>0) {
                List<Epm_monthly_report> emrs = new ArrayList<>();  //月报表对象数组
                List<List<Epm_employee_production>> groupList = new ArrayList<>();
                List<List<Epm_employee_performance>> groupList2 = new ArrayList<>();
                //对Epm_employee_production进行分组，每个人为一组
                ls.stream().collect(Collectors.groupingBy(Epm_employee_production::getEmployee_no, Collectors.toList())).forEach((groupNo, gList) -> {
                    groupList.add(gList);  //分组数组
                });
                int finalScore_b_t = score_b_t;
                int finalScore_c_t = score_c_t;
                int finalScore_d_t = score_d_t;
                groupList.forEach((eList) -> {  //遍历每一个分组数组,每一个分组为一条数据
                    Epm_monthly_report emr = new Epm_monthly_report();
                    emr.setFlag("1"); //默认参加评比
                    Double st_value = 0.0;
                    Double input_minutes = 0.0;
                    Double input_quantity = 0.0;
                    Double sum_ps = 0.0;
                    Double sum_pm = 0.0;
                    String sum;
                    double score_a = 80.0; //A得分累加
                    final int[] score_b = {finalScore_b_t}; //B得分累加
                    final int[] score_c = {finalScore_c_t}; //C得分累加
                    final int[] score_d = {0}; //D得分累加
                    double score_sum = 0.0; //得分累加
                    List<Epm_employee_performance> ls2 = new ArrayList<>();
                    for (Epm_employee_production epm_employee_production : eList) {
                        if (epm_employee_production.getEpm_st_count() == null) {
                            st_value = 0.0;
                        } else {
                            st_value = epm_employee_production.getEpm_st_count().getSt_value();
                        }

                        input_minutes = epm_employee_production.getInput_minutes();
                        input_quantity = epm_employee_production.getInput_quantity();
                        sum_ps += st_value * input_quantity * 100;
                        sum_pm += input_minutes;

                        emr.setEmployee_name(epm_employee_production.getEmployee_name());
                        emr.setEmployee_no(epm_employee_production.getEmployee_no());
                        emr.setDept_code(epm_employee_production.getDept_code());

                    }
                    //保留三位小数
                    DecimalFormat df = new DecimalFormat("#0.000");
                    double ps_div_pm=0.0;
                    if(sum_pm!=0.0){
                        ps_div_pm=sum_ps / sum_pm;

                    }
                    sum = String.valueOf(df.format(ps_div_pm));
                    //计算效率的得分
                    Epm_performance_benchmark epm_performance_benchmark = new Epm_performance_benchmark();
                        score_a = score_a * (ps_div_pm / 100);
                        emr.setEfficiency(ps_div_pm / 100);
//                    emr.setEfficiency(Math.round(sum_ps / sum_pm * 10000) / 10000);
                    emr.setEfficiency100(sum + "%");
                    //效率分不能超过80分
                    if (score_a >= 80) {
                        score_a = 80;
                    }
                    emr.setEff_score(score_a);
                    //获取该员工考核信息
                    try {
                        ls2 = iEpm_employee_performanceService.findByMonthlyReport(emr.getEmployee_no(), date_1, date_2);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    //对Epm_employee_performance进行分组
                    ls2.stream().collect(Collectors.groupingBy(Epm_employee_performance::getPerformance_code, Collectors.toList())).forEach((groupNo, gList2) -> {
                        groupList2.add(gList2);  //分组数组
                    });
                    groupList2.forEach((eList2) -> {  //遍历每一个分组数组
                        for (Epm_employee_performance epm_employee_performance : eList2) {
                            //判断考核代码的类型，获取第一位
                            String performance_code_1=epm_employee_performance.getPerformance_code().substring(0, 1);
                            double score_count=epm_employee_performance.getScore() * epm_employee_performance.getNumber();
                            if (performance_code_1.equals("B")) {
                                score_b[0] += score_count;
                                if (score_b[0] <= 0) {
                                    score_b[0] = 0;
                                }
                            } else if (performance_code_1.equals("C")) {
                                score_c[0] += score_count;
                                if (score_c[0] <= 0) {
                                    score_c[0] = 0;
                                }
                                //判断是否取消考核，C1、C2取消考核
                                if (epm_employee_performance.getPerformance_code().equals("C1") || epm_employee_performance.getPerformance_code().equals("C2")) {
                                    emr.setFlag("0");
                                }
                            } else if (performance_code_1.equals("D")) {
                                score_d[0] += score_count;
                                //奖励不能超过D对应的分
                                if (score_d[0] >= finalScore_d_t) {
                                    score_d[0] = finalScore_d_t;
                                }
                            }

                        }
                    });
                    groupList2.clear();
                    score_sum = score_a + score_b[0] + score_c[0] + score_d[0];
                    if(emr.getFlag()=="0") score_sum=0;   //判断是否取消评比
                    emr.setB_score(score_b[0]);
                    emr.setC_score(score_c[0]);
                    emr.setD_score(score_d[0]);
                    emr.setSum_score(score_sum);
//                    //判断是否取消评比
//                    if (emr.isFlag()) {
                        emrs.add(emr);
//                    }
                });
                //对成绩进行排序
                sortList = emrs.stream().sorted(Comparator.comparing(Epm_monthly_report::getSum_score).thenComparing(Epm_monthly_report::getEfficiency).reversed()).collect(Collectors.toList());
            }
        List<Epm_monthly_report> sortList_t = new ArrayList<>();

        int num=1;

        for(Epm_monthly_report epm_monthly_report:sortList){
            epm_monthly_report.setRanking(num);
            epm_monthly_report.setGroup_dept_code(dept_code);
            String employee_s=String.format("%07d",epm_monthly_report.getEmployee_no());
            epm_monthly_report.setEmployee_no_s(employee_s);
//           20201123 guo 连接人事取请假时数，经常会有问题，暂时取消
//            Double leave_h=iCom_ehr_pmonthkh_regDao.findByNoMonth(employee_s,date_2);
//            if(null==leave_h){
//                epm_monthly_report.setLeave_h("");
//            }else {
//                epm_monthly_report.setLeave_h(String.valueOf(leave_h));
//            }
            sortList_t.add(epm_monthly_report);
            num++;
        }
        return  sortList_t;
    }

}
