package com.tdk.txm_java.dao2;

import com.tdk.txm_java.domain.Foc_release;
import org.apache.ibatis.annotations.Many;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IFoc_Release2Dao {

    @Select("select * from wavedbf.xwlhp ")
    Foc_release findAll();
    @Select(" select * from wavedbf.xwlhp where LHDCNO=#{release} ")
    @Results({
            @Result(property = "LHDCNO", column = "LHDCNO"),
            @Result(property = "LHCUN1", column = "LHCUN1"),
            @Result(property = "LHCUN2", column = "LHCUN2"),
            @Result(property = "LHADR1", column = "LHADR1"),
            @Result(property = "LHADR2", column = "LHADR2"),
            @Result(property = "LHADR3", column = "LHADR3"),
            @Result(property = "LHRECP", column = "LHRECP"),
            @Result(property = "LHCUTE", column = "LHCUTE"),
            @Result(property = "LHEMNO", column = "LHEMNO"),
            @Result(property = "LHSHIP", column = "LHSHIP"),
            @Result(property = "LHMEMO", column = "LHMEMO"),
            @Result(property = "foc_release_ds", column = "LHDCNO",javaType = List.class,many = @Many(select = "com.tdk.txm_java.dao2.IFoc_Release_d2Dao.findByRelease"))

    })
    Foc_release findByRelease(String release);
}
