package com.tdk.txm_java.service.impl;

import com.tdk.txm_java.dao.IFoc_dn_feeDao;
import com.tdk.txm_java.domain.Foc_dn_fee;
import com.tdk.txm_java.service.IFoc_dn_feeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class Foc_dn_feeServiceImpl implements IFoc_dn_feeService {
    @Autowired
    private IFoc_dn_feeDao iFoc_dn_feeDao;

    @Override
    public Foc_dn_fee findById(int id) throws Exception {
        return iFoc_dn_feeDao.findById(id);
    }

    @Override
    public List<Foc_dn_fee> findByFreight_com_code(String freight_com_code) throws Exception {
        return iFoc_dn_feeDao.findByFreight_com_code(freight_com_code);
    }
    @Override
    public List<Foc_dn_fee> findByAddress_en(String address_en) throws Exception {
        return iFoc_dn_feeDao.findByAddress_en(address_en);
    }

    @Override
    public List<String> findFreight_com_code() throws Exception {
        return iFoc_dn_feeDao.findFreight_com_code();
    }

    @Override
    public Double CountAmt(double wt3, String address, String freight_com_code) throws Exception {
        List<Foc_dn_fee> foc_dn_fees=iFoc_dn_feeDao.findByFreight_com_code(freight_com_code);
        double total_amt=0;
        // 取得相应重量价格
        for(Foc_dn_fee foc_dn_fee:foc_dn_fees){

            if(foc_dn_fee.getAddress_cn().equals(address.toUpperCase())||foc_dn_fee.getAddress_en().equals(address.toUpperCase())){
                double wt4=wt3;

                //临界重量的判断，小于临界重量，先算首重的钱，超出部分再按照价格区间计算
                //大于临界重量，全部重量按照价格区间计算
                if (wt3<foc_dn_fee.getWeight()){
                    wt4=wt4 - foc_dn_fee.getWeight1();
                    total_amt=foc_dn_fee.getPrice0();
                }
                //按照价格区间计算
                if(wt4>0){
                    if(wt3<=foc_dn_fee.getWeight1()){
                        total_amt += wt4/foc_dn_fee.getPer_weight1()*foc_dn_fee.getPrice1();
                    }else if(wt3<=foc_dn_fee.getWeight2()){
                        total_amt += wt4/foc_dn_fee.getPer_weight2()*foc_dn_fee.getPrice2();
                    }else if(wt3<=foc_dn_fee.getWeight3()){
                        total_amt += wt4/foc_dn_fee.getPer_weight3()*foc_dn_fee.getPrice3();
                    }else if(wt3<=foc_dn_fee.getWeight4()){
                        total_amt += wt4/foc_dn_fee.getPer_weight4()*foc_dn_fee.getPrice4();
                    }else if(wt3<=foc_dn_fee.getWeight5()){
                        total_amt += wt4/foc_dn_fee.getPer_weight5()*foc_dn_fee.getPrice5();
                    }else if(wt3<=foc_dn_fee.getWeight6()){
                        total_amt += wt4/foc_dn_fee.getPer_weight6()*foc_dn_fee.getPrice6();
                    }else if(wt3<=foc_dn_fee.getWeight7()){
                        total_amt += wt4/foc_dn_fee.getPer_weight7()*foc_dn_fee.getPrice7();
                    }else if(wt3<=foc_dn_fee.getWeight8()){
                        total_amt += wt4/foc_dn_fee.getPer_weight8()*foc_dn_fee.getPrice8();
                    }
                }
                break;
            }

        }
        return total_amt;
    }


    @Override
    public void save(Foc_dn_fee foc_dn_fee) throws Exception {

        iFoc_dn_feeDao.save(foc_dn_fee);

    }

    @Override
    public void update(Foc_dn_fee foc_dn_fee) {
        iFoc_dn_feeDao.update(foc_dn_fee);
    }

    @Override
    public void  delete(int  id) {
        iFoc_dn_feeDao.deleteById(id);

    }

}
