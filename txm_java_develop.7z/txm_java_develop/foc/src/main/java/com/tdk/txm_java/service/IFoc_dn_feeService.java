package com.tdk.txm_java.service;

import com.tdk.txm_java.domain.Foc_dn_fee;

import java.util.List;

public interface IFoc_dn_feeService {

    Foc_dn_fee findById(int id) throws Exception;
    List<Foc_dn_fee> findByFreight_com_code(String freight_com_code) throws Exception;
    List<Foc_dn_fee> findByAddress_en(String address_en) throws Exception;
    List<String> findFreight_com_code() throws Exception;
    Double CountAmt(double weight,String Address,String freight_com_code) throws Exception;

    void save(Foc_dn_fee foc_dn_fee) throws Exception;


    void update(Foc_dn_fee foc_dn_fee);

    void delete(int id);

   }
