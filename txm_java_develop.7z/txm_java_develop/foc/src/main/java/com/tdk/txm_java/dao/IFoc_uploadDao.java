package com.tdk.txm_java.dao;

import com.tdk.txm_java.domain.Foc_upload;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IFoc_uploadDao {

    
    /**
    *@Description: 查询所有信息
    *@Author: a135109
    *@time: 2019/11/6 10:27
    */
    @Select("select * from foc_upload ")
    public List<Foc_upload> findAll() throws Exception;

    /**
     *@Description: 通过express_no查找
     *@Author: a135109
     *@time: 2019/11/6 10:24
     */
    @Select("select * from foc_upload where  express_no = #{express_no}")
    public List<Foc_upload> findByExpress_no(String express_no);

    /**
     *@Description: /通过id查找
     *@Author: a135109
     *@time: 2019/11/6 10:29
     */
    @Select("select * from foc_upload where  id = #{id}")
    public Foc_upload findById_no(int id);

    /**
     *@Description: 校验
     *@Author: a135109
     *@time: 2019/11/6 10:29
     */
    @Select("select * from foc_upload where  express_no = #{express_no}")
    public Foc_upload queryByExpress_no(Foc_upload foc_upload);

    /**
    *@Description: 存入中间表
    *@Author: a135109
    *@time: 2019/11/6 10:26
    */
    @Insert("insert into foc_upload(id,express_no,actual_express_no,express_company) values(#{id},#{express_no},#{actual_express_no},#{express_company})")
    void save(Foc_upload foc_upload);

    /**
    *@Description: 删除
    *@Author: a135109
    *@time: 2019/11/6 10:25
    */
    @Delete("delete from foc_upload where id = #{id}")
    void delete(int id);

    /**
    *@Description: 改变中间表状态
    *@Author: a135109
    *@time: 2019/11/6 10:25
    */
    @Update("update foc_upload set state='不存在'  where express_no = #{express_no} ")
    void update(String express_no);
}
