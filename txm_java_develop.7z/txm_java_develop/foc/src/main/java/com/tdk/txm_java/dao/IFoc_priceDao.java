package com.tdk.txm_java.dao;


import com.tdk.txm_java.domain.Foc_price;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface IFoc_priceDao {

    // 查询所有信息
    @Select("select * from foc_price")
    public List<Foc_price> findAll() throws Exception;


    @Select("select * from foc_price where mrpcode=#{mrpcode} and type=#{type}")
    public List<Foc_price> findByMrpType(@Param("mrpcode") String mrpcode, @Param("type") String type) throws Exception;
    @Select("select * from foc_price where mrpcode=#{mrpcode} and type>#{type}")
    public List<Foc_price> findByMrpTypeGt(@Param("mrpcode") String mrpcode, @Param("type") String type) throws Exception;

    @Select("select * from foc_price where mrpcode=#{mrpcode} and type=#{type} and currency=#{currency} and expiration_flag='Y' ")
    public Foc_price findByMrpTypeCur(Foc_price foc_price) throws Exception;

    @Select("select * from foc_price where mrpcode=#{mrpcode} and type=#{type} and currency=#{currency} and expiration_flag='Y' ")
    public List<Foc_price> findByMrpTypeCur2(Foc_price foc_price) throws Exception;

    @Select("select * from foc_price where mrpcode=#{mrpcode} and expiration_flag!='N' ")
    public List<Foc_price> findByMrp(String mrpcode) throws Exception;

    @Select("select * from foc_price where id=#{id}")
    public Foc_price findById(int id) throws Exception;

    @Select("select * from foc_price where mrpcode=#{mrpcode} and type=#{type}")
    public int findTotalCount(@Param("mrpcode") String mrpcode, @Param("type") String type) throws Exception;

    @Insert("insert into foc_price(mrpcode,type,effective_date,expiration_date,price_1_upper,price_1_lower,products_type,currency,unit,item_descrip,item_descrip_en,expiration_flag,login_time,login_oid,update_oid,update_program) values(#{mrpcode},#{type},#{effective_date},#{expiration_date},#{price_1_upper},#{price_1_lower},#{products_type},#{currency},#{unit},#{item_descrip},#{item_descrip_en},'Y',now(),#{login_oid},#{update_oid},#{update_program})")
    void save(Foc_price foc_price);

    @Update("update foc_price set  mrpcode=#{mrpcode}, type=#{type}, effective_date=#{effective_date}, expiration_date=#{expiration_date}, products_type=#{products_type}, price_1_lower=#{price_1_lower}, price_1_upper=#{price_1_upper}, currency=#{currency}, unit=#{unit}, item_descrip=#{item_descrip}, item_descrip_en=#{item_descrip_en}, expiration_flag=#{expiration_flag}, update_oid=#{update_oid}, update_program=#{update_program}  where id =#{id}  ")
    void update(Foc_price foc_price);

    @Delete("delete from foc_price where id =#{id}  ")
    void delete(int id);

}
