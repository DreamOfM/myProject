package com.tdk.txm_java.service.impl;


import com.tdk.txm_java.dao.IFoc_general_tradeDao;
import com.tdk.txm_java.domain.Foc_general_trade;
import com.tdk.txm_java.service.IFoc_general_tradeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class Foc_general_tradeServiceImpl implements IFoc_general_tradeService {


    @Autowired
    private IFoc_general_tradeDao iFoc_general_tradeDao;

    @Override
    public List<Foc_general_trade> findAll() throws Exception {
        return iFoc_general_tradeDao.findAll();
    }

    @Override
    public List<Foc_general_trade> findByIv(String invoice_no) throws Exception {
        return iFoc_general_tradeDao.findByIv(invoice_no);
    }

    @Override
    public void save(Foc_general_trade foc_general_trade) throws Exception {
        iFoc_general_tradeDao.save(foc_general_trade);
    }

    @Override
    public void update(Foc_general_trade foc_general_trade) throws Exception {
        iFoc_general_tradeDao.update(foc_general_trade);
    }

    @Override
    public void delete(int id) throws Exception {
        iFoc_general_tradeDao.delete(id);
    }


}
