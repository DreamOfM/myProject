package com.tdk.txm_java.controller;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tdk.txm_java.domain.Com_userInfo;
import com.tdk.txm_java.domain.Foc_price;
import com.tdk.txm_java.domain.ResultInfo;
import com.tdk.txm_java.service.IFoc_priceService;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

@Controller
@RequestMapping("/foc_price")
public class Foc_priceController {


    @Autowired
    private IFoc_priceService foc_priceService;


    //查询
    @RequestMapping("/findByMrpType")
    public ModelAndView findByMrpType(@RequestParam(value="pn",defaultValue="1")Integer pn, @RequestParam(value = "PageSize", defaultValue = "5") Integer ps,String mrpcode, String type) throws Exception {
        //引入PageHelper分页插件
        //查询之前需要调用,,传入页码，以及每页的大小
        PageHelper.startPage(pn,ps);

        List<Foc_price> foc_price = foc_priceService.findByMrpType(mrpcode, type);
        //startPage后面紧跟的是这个查询就是一个分页查询
        //使用pageInfo包装查询后的结果，只需要将Pageinfo交给页面就行了
        //封装了详细的分页信息，包括我们查出来的数据,传入连续显示的数据
        PageInfo page = new PageInfo(foc_price,ps);
        ModelAndView mv = new ModelAndView();
        if(foc_price.size()==0) {
            mv.setViewName("foc-price-add");
            mv.addObject("type", type);
        }else{
            mv.setViewName("foc-price-list");
            mv.addObject("foc_price", foc_price);
            mv.addObject("pageInfo", page);
        };

        return mv;
    }
    //查询
    @RequestMapping("/findByMrpTypeGt")
    public ModelAndView findByMrpTypeGt(@RequestParam(value="pn",defaultValue="1")Integer pn, @RequestParam(value = "PageSize", defaultValue = "5") Integer ps,String mrpcode, String type) throws Exception {
        //引入PageHelper分页插件
        //查询之前需要调用,,传入页码，以及每页的大小
        PageHelper.startPage(pn,ps);

        List<Foc_price> foc_price = foc_priceService.findByMrpTypeGt(mrpcode, type);


        //startPage后面紧跟的是这个查询就是一个分页查询
        //使用pageInfo包装查询后的结果，只需要将Pageinfo交给页面就行了
        //封装了详细的分页信息，包括我们查出来的数据,传入连续显示的数据
        PageInfo page = new PageInfo(foc_price,ps);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("foc-price-query");
        mv.addObject("foc_price", foc_price);
        mv.addObject("pageInfo", page);
        return mv;
    }
    //查询
    @RequestMapping("/findByMrp")
    public ModelAndView findByMrp(HttpSession httpSession) throws Exception {
        Com_userInfo userInfo= (Com_userInfo) httpSession.getAttribute("userInfo");
        List<Foc_price> foc_price = foc_priceService.findByMrp(userInfo.getMrpcode());
        ModelAndView mv = new ModelAndView();
        mv.setViewName("foc-price-query");
        mv.addObject("foc_price", foc_price);
        return mv;
    }
    //查询
    @ResponseBody
    @RequestMapping("/findByMrpTypeCur")
    public ResultInfo findByMrpTypeCur(String mrpcode, String type,String currency) throws Exception {
        Foc_price foc_price=new Foc_price();
        foc_price.setMrpcode(mrpcode);
        foc_price.setType(type);
        foc_price.setCurrency(currency);
        Foc_price foc_price2=foc_priceService.findByMrpTypeCur(foc_price);
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据

        info.setData(foc_price2);
        System.out.println(info);
        return info;
    }

    //查询全部
    @RequestMapping("/findAll.do")
    public ModelAndView findAll() throws Exception {
        ModelAndView mv = new ModelAndView();
        List<Foc_price> ls = foc_priceService.findAll();
        mv.setViewName("foc-price-list");
        mv.addObject("foc_price", ls);
        return mv;
    }

    //保存
    @RequestMapping("/save.do")
    public String save(Foc_price foc_price) throws Exception {
        foc_price.setExpiration_flag("Y");
        foc_priceService.save(foc_price);
        return "redirect:findAll.do";
    }
    //保存
    @RequestMapping("/saveAll.do")
    public String saveAll(HttpServletRequest request, HttpServletResponse response,HttpSession httpSession ) throws Exception {
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        int b=0;
        int c=0;
        String username= (String) httpSession.getAttribute("username");
        String[] vals = (String[]) map.get("currency");
        c=vals.length;
        while (1==1){
            for(String name1 : set){
                vals = (String[]) map.get(name1);
                if(name1.equals("mrpcode")||name1.equals("type")||name1.equals("item_descrip")||name1.equals("item_descrip_en")||name1.equals("unit")){
                    hashMap.put(name1,vals[0]);
                }else{
                    hashMap.put(name1,vals[b]);

                }

            }

            Foc_price foc_price = new Foc_price();
            try {
                BeanUtils.populate(foc_price,hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //添加一个判断，如果为空值或者没有输入则不往数据库里插数据
            if (foc_price.getCurrency().equals(null) || foc_price.getCurrency().equals("")) {
                b++;
                if (b == c) break;
                continue;
            }
            foc_price.setExpiration_flag("Y");
            foc_price.setLogin_oid(username);
            foc_price.setUpdate_oid(username);
            foc_price.setUpdate_program("/foc_price/update");
            foc_priceService.save(foc_price);
            b++;
            if(b==c) break;
        }
        return "redirect:findAll.do";

    }
    //delete
    @RequestMapping("/delete.do")
    public String delete(int id) throws Exception {
        foc_priceService.detele(id);
        return "redirect:findAll.do";
    }


    //修改
    @RequestMapping("/update.do")
    public void update(HttpServletRequest request, HttpServletResponse response,HttpSession httpSession) throws Exception {
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        String username= (String) httpSession.getAttribute("username");
        int b=0;
        int c=0;
        while (1==1){
        for(String name1 : set){
            String[] vals = (String[]) map.get(name1);
            c=vals.length;
             hashMap.put(name1,vals[b]);
        }
        Foc_price foc_price=foc_priceService.findById(Integer.parseInt(hashMap.get("id")));
        try {
            BeanUtils.populate(foc_price,hashMap);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
            //添加一个判断，如果为空值或者没有输入则不往数据库里插数据
            if (foc_price.getCurrency().equals(null) || foc_price.getCurrency().equals("")) {
                b++;
                if (b == c) break;
                continue;
            }
            foc_price.setUpdate_oid(username);
            foc_price.setUpdate_program("/foc_price/update");
            foc_priceService.update(foc_price);
        b++;
        if(b==c) break;
        }


    }
    @RequestMapping("/checkAdd.do")
    public void checkAdd(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception, IOException, JsonGenerationException, JsonMappingException {
        ResultInfo info = new ResultInfo();
        List<Foc_price> foc_prices = new ArrayList<Foc_price>();
        info.setFlag(true);
        List<String> errorList=new ArrayList<String>();
//取出前端传回的所有数据
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        int b=0;
        int c=0;
        String[] vals = (String[]) map.get("currency");
        c=vals.length;
        while (1==1){
            for(String name1 : set){
                vals = (String[]) map.get(name1);
                if(name1.equals("mrpcode")||name1.equals("type")||name1.equals("item_descrip")||name1.equals("item_descrip_en")||name1.equals("unit")){
                    hashMap.put(name1,vals[0]);
                }else{
                    hashMap.put(name1,vals[b]);

                }
            }
            Foc_price foc_price = new Foc_price();
            try {
                BeanUtils.populate(foc_price,hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //添加一个判断，如果为空值或者没有输入则不往数据库里插数据
            if (foc_price.getCurrency().equals(null) || foc_price.getCurrency().equals("")) {
                b++;
                if (b == c) break;
                continue;
            }
            //检查价格分类对应的该币别是否存在有效记录
             foc_prices=foc_priceService.findByMrpTypeCur2(foc_price);
            //价格的判断
            if(foc_prices.size()>0){
                info.setErrorMsg("价格分类已存在");
                String errLine= String.valueOf(b);
                errorList.add("currency"+ errLine);
                info.setFlag(false);
                break;
            }
            b++;
            if (b == c) break;
        }

        info.setErrorList(errorList);
        info.setData(foc_prices);
        //响应数据
        ObjectMapper mapper = new ObjectMapper();

        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(),info);
    }

}


