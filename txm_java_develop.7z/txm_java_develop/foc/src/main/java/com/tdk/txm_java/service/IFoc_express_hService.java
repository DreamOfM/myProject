package com.tdk.txm_java.service;

import com.tdk.txm_java.domain.Foc_express_d;
import com.tdk.txm_java.domain.Foc_express_h;

import java.util.List;

public interface IFoc_express_hService {
    /**
     * 根据快递单号来查询
     * @param express_no
     * @return
     * @throws Exception
     */
    Foc_express_h findByExpress_no(String express_no) throws Exception;
    List<Foc_express_h> findBySql(String sql_val) throws Exception;

    /**
     *新增信息方法
     */
    void save(Foc_express_h foc_express_h) throws Exception;
    void saveNoHarrive_day(Foc_express_h foc_express_h) throws Exception;


    void update(Foc_express_h foc_express_h) throws Exception;
    void updateStatus(Foc_express_h foc_express_h) throws Exception;
    /*
     *2019.10.30  Haowen Tan
     *条件查找快运单表头
     */
    public List<Foc_express_h> findByNo(String express_no,String express_no_2,String scheduled_ship_date,String scheduled_ship_date_2,String freight_com_code,String print_sign) throws Exception;
 /**
     *
     * @param express_no
     * @return
     * @throws Exception
     */
    Foc_express_h findByExpress_no2(String express_no) throws Exception;

    /*
     *根据出货日期查找
     */
    public List<Foc_express_h> findByScheduled_ship_date(String scheduled_ship_date,String scheduled_ship_date_2,String dept) throws Exception;

    /**
     * 根据id来查询数据库的数据
     * @param id
     * @return
     * @throws Exception
     */
    Foc_express_h findById(int id) throws Exception;

    void update2(Foc_express_h foc_express_h) throws Exception;

    /**
     *@Description: 条件查找快运单（发票）
     *@Author: a135109
     *@time: 2020/3/11 14:21
     */
    public List<Foc_express_h> findByNo_iv(String express_no,String express_no_2,String scheduled_ship_date,String scheduled_ship_date_2,String freight_com_code,String overseas,String bonded_logo) throws Exception;

    public List<Foc_express_h> findByQuery(String scheduled_ship_date, String scheduled_ship_date_2,String freight_com_code,String dept,String handled_manual_id) throws Exception;

    List<Foc_express_h> findByship_date(String date_from, String date_to)  throws Exception;

    Foc_express_h findByReal_exp(String real_express)  throws Exception;
}
