package com.tdk.txm_java.controller;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tdk.txm_java.domain.*;
import com.tdk.txm_java.service.*;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

@Controller
@RequestMapping("/foc_release")
public class Foc_releaseController {
    @Autowired
    private IFoc_releaseService releaseService;


    @RequestMapping("/findByRelease.do")
    public void check(HttpServletResponse response,String release_slip) throws Exception, JsonGenerationException, JsonMappingException {
        ResultInfo info = new ResultInfo();

        Foc_release foc_release=releaseService.findByRelease(release_slip);
        if(foc_release!=null) {
            info.setData(foc_release);
            info.setFlag(true);
        }
        //响应数据
        ObjectMapper mapper = new ObjectMapper();

        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(),info);
    }
    }





