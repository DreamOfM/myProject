package com.tdk.txm_java.service.impl;

import com.tdk.txm_java.dao.ICom_commonDao;
import com.tdk.txm_java.dao.IFoc_express_hDao;
import com.tdk.txm_java.domain.Com_common;
import com.tdk.txm_java.domain.Foc_express_h;
import com.tdk.txm_java.service.IFoc_express_hService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class Foc_express_hServiceImpl implements IFoc_express_hService {
    @Autowired
    private IFoc_express_hDao iFoc_express_hDao;
    @Autowired
    private ICom_commonDao iCom_commonDao;
    /**
     * 根据快递单号来查询
     * @param express_no
     * @return  详细的信息
     * @throws Exception
     */
    @Override
    public Foc_express_h findByExpress_no(String express_no) throws Exception {
       return iFoc_express_hDao.findByExpress_no(express_no);
    }

    @Override
    public List<Foc_express_h> findBySql(String sql_val) throws Exception {
        return iFoc_express_hDao.findBySql(sql_val);
    }

    /**
     * 新增信息
     * @param foc_express_h
     * @throws Exception
     */
    @Override
    public void save(Foc_express_h foc_express_h) throws Exception {
        //记录相应的保费
        Com_common com_common=iCom_commonDao.findByKey1("premium");
        foc_express_h.setPremium(com_common.getChar1());
        foc_express_h.setFreight_com_code("");
        if(foc_express_h.getHarrive_day()==null||foc_express_h.getHarrive_day()==""){
            iFoc_express_hDao.saveNoHarrive_day(foc_express_h);
        }else {
            iFoc_express_hDao.save(foc_express_h);
        }
        System.out.println("h-OK");
    }
    @Override
    public void saveNoHarrive_day(Foc_express_h foc_express_h) throws Exception {
        //记录相应的保费
        Com_common com_common=iCom_commonDao.findByKey1("premium");
        foc_express_h.setPremium(com_common.getChar1());
        iFoc_express_hDao.saveNoHarrive_day(foc_express_h);
        System.out.println("h-OK");
    }

    /**
     * 修改信息
     *
     * @param foc_express_h
     */
    public void update(Foc_express_h foc_express_h) {
        if(foc_express_h.getHarrive_day()==null||foc_express_h.getHarrive_day()==""){
            iFoc_express_hDao.updateNoHarrive_day(foc_express_h);
        }else {
            iFoc_express_hDao.update(foc_express_h);
        }
    }

    @Override
    public void updateStatus(Foc_express_h foc_express_h) throws Exception {
        iFoc_express_hDao.updateStatus(foc_express_h);
    }

    @Override
    public List<Foc_express_h> findByNo(String express_no, String express_no_2, String scheduled_ship_date, String scheduled_ship_date_2, String freight_com_code,String print_sign) throws Exception {
        if (express_no_2==""){ express_no_2 = new String(express_no); }
        if (scheduled_ship_date_2==""){ scheduled_ship_date_2 = new String(scheduled_ship_date);}
        if (express_no.equals("")){express_no = new String("0"); express_no_2 = new String("ZZZZZ");}
        if (scheduled_ship_date.equals("")){scheduled_ship_date = new String("0"); scheduled_ship_date_2 = new String("9999-12-31");}
        List<Foc_express_h> foc_express_h = iFoc_express_hDao.findByNo(express_no,express_no_2,scheduled_ship_date,scheduled_ship_date_2,freight_com_code);
        List<Foc_express_h> foc_express_hs = new ArrayList<>();
        //通过打印标志筛选
        for (Foc_express_h f1:foc_express_h) {
            if (print_sign.equals("Y")&&f1.getPrint_sign().equals("Y")){
                foc_express_hs.add(f1);
            } else if(print_sign.equals("N")&&f1.getPrint_sign().equals("N")){
                foc_express_hs.add(f1);
            } else if (print_sign.equals("")){
                foc_express_hs.add(f1);
            }
        }
        return foc_express_hs;
    }

 /**
     *
     * @param express_no
     * @return
     * @throws Exception
     */
    @Override
    public Foc_express_h findByExpress_no2(String express_no) throws Exception {
        return iFoc_express_hDao.findByExpress_no2(express_no);
    }

    @Override
    public List<Foc_express_h> findByScheduled_ship_date(String scheduled_ship_date,String scheduled_ship_date_2,String dept) throws Exception {

        return iFoc_express_hDao.findByScheduled_ship_date(scheduled_ship_date,scheduled_ship_date_2,dept);
    }
    @Override
    public Foc_express_h findById(int id) throws Exception {
        return iFoc_express_hDao.findById(id);
    }

    @Override
    public void update2(Foc_express_h foc_express_h) {
        iFoc_express_hDao.update2(foc_express_h);
    }

    /**
     *@Description: iv条件查找
     *@Author: a135109
     *@time: 2020/3/11 14:25
     */
    @Override
    public List<Foc_express_h> findByNo_iv(String express_no, String express_no_2, String scheduled_ship_date, String scheduled_ship_date_2,String freight_com_code,String overseas,String bonded_logo) throws Exception {
        if (express_no_2==""){ express_no_2 = new String(express_no); }
        if (scheduled_ship_date_2==""){ scheduled_ship_date_2 = new String(scheduled_ship_date);}
        List<Foc_express_h> foc_express_h = iFoc_express_hDao.findByNo_iv(express_no,express_no_2,scheduled_ship_date,scheduled_ship_date_2,freight_com_code,overseas,bonded_logo);
        return foc_express_h;
    }

    @Override
    public List<Foc_express_h> findByQuery(String scheduled_ship_date,String scheduled_ship_date_2,String freight_com_code,String dept,String handled_manual_id) throws Exception {
        if (scheduled_ship_date_2==""){ scheduled_ship_date_2 = new String(scheduled_ship_date);}
        List<Foc_express_h> foc_express_h = iFoc_express_hDao.findByQuery(scheduled_ship_date,scheduled_ship_date_2,freight_com_code,dept,handled_manual_id);
        return foc_express_h;
    }

    @Override
    public List<Foc_express_h> findByship_date(String date_from,String date_to)  throws Exception {
        return iFoc_express_hDao.findByship_date(date_from,date_to) ;
    }

    @Override
    public Foc_express_h findByReal_exp(String real_express)  throws Exception {
        return iFoc_express_hDao.findByReal_exp(real_express) ;
    }
}
