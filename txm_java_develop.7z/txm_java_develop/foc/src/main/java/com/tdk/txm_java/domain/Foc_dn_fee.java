package com.tdk.txm_java.domain;

import java.sql.Time;
import java.util.Date;

/**
 * 彔入表体
 */
public class Foc_dn_fee {
    private int id;
    private String express_no;
    private String freight_com_code;
    private String freight_com_name;
    private String address_cn;
    private String address_en;
    private Double weight;
    private Double weight0;
    private Double price0;
    private Double weight1;
    private Double price1;
    private Double per_weight1;
    private Double weight2;
    private Double price2;
    private Double per_weight2;
    private Double weight3;
    private Double price3;
    private Double per_weight3;
    private Double weight4;
    private Double price4;
    private Double per_weight4;
    private Double weight5;
    private Double price5;
    private Double per_weight5;
    private Double weight6;
    private Double price6;
    private Double per_weight6;
    private Double weight7;
    private Double price7;
    private Double per_weight7;
    private Double weight8;
    private Double price8;
    private Double per_weight8;
    private String alternate_field;
    private Time login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getExpress_no() {
        return express_no;
    }

    public void setExpress_no(String express_no) {
        this.express_no = express_no;
    }

    public String getFreight_com_code() {
        return freight_com_code;
    }

    public void setFreight_com_code(String freight_com_code) {
        this.freight_com_code = freight_com_code;
    }

    public String getFreight_com_name() {
        return freight_com_name;
    }

    public void setFreight_com_name(String freight_com_name) {
        this.freight_com_name = freight_com_name;
    }

    public String getAddress_cn() {
        return address_cn;
    }

    public void setAddress_cn(String address_cn) {
        this.address_cn = address_cn;
    }

    public String getAddress_en() {
        return address_en;
    }

    public void setAddress_en(String address_en) {
        this.address_en = address_en;
    }

    public Double getWeight() {
        return weight;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    public Double getWeight0() {
        return weight0;
    }

    public void setWeight0(Double weight0) {
        this.weight0 = weight0;
    }

    public Double getPrice0() {
        return price0;
    }

    public void setPrice0(Double price0) {
        this.price0 = price0;
    }

    public Double getWeight1() {
        return weight1;
    }

    public void setWeight1(Double weight1) {
        this.weight1 = weight1;
    }

    public Double getPrice1() {
        return price1;
    }

    public void setPrice1(Double price1) {
        this.price1 = price1;
    }

    public Double getPer_weight1() {
        return per_weight1;
    }

    public void setPer_weight1(Double per_weight1) {
        this.per_weight1 = per_weight1;
    }

    public Double getWeight2() {
        return weight2;
    }

    public void setWeight2(Double weight2) {
        this.weight2 = weight2;
    }

    public Double getPrice2() {
        return price2;
    }

    public void setPrice2(Double price2) {
        this.price2 = price2;
    }

    public Double getPer_weight2() {
        return per_weight2;
    }

    public void setPer_weight2(Double per_weight2) {
        this.per_weight2 = per_weight2;
    }

    public Double getWeight3() {
        return weight3;
    }

    public void setWeight3(Double weight3) {
        this.weight3 = weight3;
    }

    public Double getPrice3() {
        return price3;
    }

    public void setPrice3(Double price3) {
        this.price3 = price3;
    }

    public Double getPer_weight3() {
        return per_weight3;
    }

    public void setPer_weight3(Double per_weight3) {
        this.per_weight3 = per_weight3;
    }

    public Double getWeight4() {
        return weight4;
    }

    public void setWeight4(Double weight4) {
        this.weight4 = weight4;
    }

    public Double getPrice4() {
        return price4;
    }

    public void setPrice4(Double price4) {
        this.price4 = price4;
    }

    public Double getPer_weight4() {
        return per_weight4;
    }

    public void setPer_weight4(Double per_weight4) {
        this.per_weight4 = per_weight4;
    }

    public Double getWeight5() {
        return weight5;
    }

    public void setWeight5(Double weight5) {
        this.weight5 = weight5;
    }

    public Double getPrice5() {
        return price5;
    }

    public void setPrice5(Double price5) {
        this.price5 = price5;
    }

    public Double getPer_weight5() {
        return per_weight5;
    }

    public void setPer_weight5(Double per_weight5) {
        this.per_weight5 = per_weight5;
    }

    public Double getWeight6() {
        return weight6;
    }

    public void setWeight6(Double weight6) {
        this.weight6 = weight6;
    }

    public Double getPrice6() {
        return price6;
    }

    public void setPrice6(Double price6) {
        this.price6 = price6;
    }

    public Double getPer_weight6() {
        return per_weight6;
    }

    public void setPer_weight6(Double per_weight6) {
        this.per_weight6 = per_weight6;
    }

    public Double getWeight7() {
        return weight7;
    }

    public void setWeight7(Double weight7) {
        this.weight7 = weight7;
    }

    public Double getPrice7() {
        return price7;
    }

    public void setPrice7(Double price7) {
        this.price7 = price7;
    }

    public Double getPer_weight7() {
        return per_weight7;
    }

    public void setPer_weight7(Double per_weight7) {
        this.per_weight7 = per_weight7;
    }

    public Double getWeight8() {
        return weight8;
    }

    public void setWeight8(Double weight8) {
        this.weight8 = weight8;
    }

    public Double getPrice8() {
        return price8;
    }

    public void setPrice8(Double price8) {
        this.price8 = price8;
    }

    public Double getPer_weight8() {
        return per_weight8;
    }

    public void setPer_weight8(Double per_weight8) {
        this.per_weight8 = per_weight8;
    }

    public String getAlternate_field() {
        return alternate_field;
    }

    public void setAlternate_field(String alternate_field) {
        this.alternate_field = alternate_field;
    }

    public Time getLogin_time() {
        return login_time;
    }

    public void setLogin_time(Time login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public Time getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(Time update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    @Override
    public String toString() {
        return "Foc_dn_fee{" +
                "id=" + id +
                ", express_no='" + express_no + '\'' +
                ", freight_com_code='" + freight_com_code + '\'' +
                ", freight_com_name='" + freight_com_name + '\'' +
                ", address_cn='" + address_cn + '\'' +
                ", address_en='" + address_en + '\'' +
                ", weight=" + weight +
                ", weight0=" + weight0 +
                ", price0=" + price0 +
                ", weight1=" + weight1 +
                ", price1=" + price1 +
                ", per_weight1=" + per_weight1 +
                ", weight2=" + weight2 +
                ", price2=" + price2 +
                ", per_weight2=" + per_weight2 +
                ", weight3=" + weight3 +
                ", price3=" + price3 +
                ", per_weight3=" + per_weight3 +
                ", weight4=" + weight4 +
                ", price4=" + price4 +
                ", per_weight4=" + per_weight4 +
                ", weight5=" + weight5 +
                ", price5=" + price5 +
                ", per_weight5=" + per_weight5 +
                ", weight6=" + weight6 +
                ", price6=" + price6 +
                ", per_weight6=" + per_weight6 +
                ", weight7=" + weight7 +
                ", price7=" + price7 +
                ", per_weight7=" + per_weight7 +
                ", weight8=" + weight8 +
                ", price8=" + price8 +
                ", per_weight8=" + per_weight8 +
                ", alternate_field='" + alternate_field + '\'' +
                ", login_time=" + login_time +
                ", login_oid='" + login_oid + '\'' +
                ", update_time=" + update_time +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                '}';
    }
}

