package com.tdk.txm_java.service;

import com.tdk.txm_java.domain.Foc_express_d;
import com.tdk.txm_java.domain.Foc_express_h;

import java.util.List;

public interface IFoc_express_dService {
    /**
     * 根据id来查询数据库的数据
     * @param id
     * @return
     * @throws Exception
     */
    Foc_express_d findById(int id) throws Exception;
    /**
     *新增信息方法
     */
    void save(Foc_express_d foc_express_d) throws Exception;

    /**
     * 根据快递单号来查询
     * @param express_no
     * @return
     * @throws Exception
     */
    List<Foc_express_d> findByExpress_no(String express_no) throws Exception;

    /**
     * 修改信息
     * @param foc_express_d
     */
    void update(Foc_express_d foc_express_d);

    /**
     * 根据ID删除数据
     * @param id
     */
    void deleteById(int id);

    /*
     *2019.10.30  Haowen Tan
     *条件查找快运单表底
     */
    List<Foc_express_d> findByNo(String express_no) throws Exception;
/**
     *
     * @param express_no
     * @return
     * @throws Exception
     */
    List<Foc_express_d> findByExpress_no2(String express_no) throws Exception;

    /**
     *
     * @param foc_express_d
     */
    void update2(Foc_express_d foc_express_d);
    void updateByExpress_no(Foc_express_d foc_express_d);

    Foc_express_d findByIv(String express_no) throws Exception;


    /**
     *
     *
     */
//    float calculateqty(String express_no) throws Exception;
//    Foc_express_d calculateamount(String express_no) throws Exception;
//    Foc_express_d calculategross_weight(String express_no) throws Exception;
}
