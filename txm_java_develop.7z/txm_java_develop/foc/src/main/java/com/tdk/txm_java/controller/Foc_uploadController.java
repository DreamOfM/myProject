package com.tdk.txm_java.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tdk.txm_java.domain.Foc_express_h;
import com.tdk.txm_java.domain.Foc_upload;
import com.tdk.txm_java.service.IFoc_express_hService;
import com.tdk.txm_java.service.IFoc_uploadService;
import com.tdk.txm_java.utils.ExcelUtils;
import com.tdk.txm_java.utils.UploadUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.*;
import static com.tdk.txm_java.utils.ExcelUtils.*;

/**
 *@Description: 上载中间表Controller层
 *@Author: a135109
 *@time: 2019/11/6 10:16
 */

@Controller
@RequestMapping("/foc_upload")
public class Foc_uploadController {

    @Autowired
    private IFoc_uploadService iFoc_uploadService;
    @Autowired
    private IFoc_express_hService iFoc_express_hService;

    /**
     *@Description: 查询中间表
     *@Author: a135109
     *@time: 2019/11/6 10:15
     */
    @RequestMapping("/findAll.do")
    public ModelAndView find(String express_no) throws Exception{
        List<Foc_upload> list = new ArrayList<>();
        //获取中间表信息,若未输入信息，则会遍历所有数据
        if(express_no==""||express_no==null){
            list = iFoc_uploadService.findAll();
        }
        else{
            list = iFoc_uploadService.findByExpress_no(express_no);
        }
        ModelAndView mv = new ModelAndView();
        mv.setViewName("foc-upload");
        mv.addObject("foc_upload",list);
        return mv;
    }

    /**
     *@Description: 上载数据
     *@Author: a135109
     *@time: 2019/11/6 10:17
     */
    @RequestMapping("/upload.do")
    public String upload(MultipartFile imgFile, HttpServletRequest request) throws Exception{
        UploadUtils uploadUtils = new UploadUtils();
        String filePath = uploadUtils.upload(imgFile,request);
        //导入LoadExcle方法
        String columns[] = {"express_no","actual_express_no","express_company"};
        //创建对象
        Foc_upload foc_upload_1 = new Foc_upload();
        //从Excel获取数据列表
        List<Map<String, Object>> list =  ExcelUtils.LoadExcle(filePath,columns);
        //创建新的对象列表
        List<Foc_upload> ls = new ArrayList<>();
        //将map转为foc_upload对象，并存到对象list
        for (Map ma: list) {
            foc_upload_1 = ExcelUtils.mapToBean(ma, Foc_upload.class);
            ls.add(foc_upload_1);
        }
        //将获取的数据上载到中间表
        for (Foc_upload foc_upload:ls) {
            //判断express_no是否存在
            Foc_upload f = iFoc_uploadService.queryByExpress_no(foc_upload);
            if (f==null){
                //不存在新增
                iFoc_uploadService.save(foc_upload);
                System.out.println("---"+foc_upload);
            }else {
                System.out.println("存在");
            }
        }
        ModelAndView mv = new ModelAndView();
        mv.setViewName("foc-upload");
        mv.addObject("foc_upload1",ls);
        return "redirect:findAll.do";
    }

    /**
     *@Description: 确认
     *@Author: a135109
     *@time: 2019/11/6 10:17
     */
    @RequestMapping("/confirm.do")
    public String update(int ids[]) throws Exception{
        String express_no = null;
        if(ids != null && ids.length > 0){
            //1.遍历数组
            for (int id : ids) {
                //2.通过id找到express_no
                Foc_upload foc_upload =  iFoc_uploadService.findById(id);
                express_no = foc_upload.getExpress_no();
                //通过express_no获取中间表对象
                System.out.println(express_no);
                //通过中间表，查找对应表头
                Foc_express_h foc_express_h = iFoc_express_hService.findByExpress_no(foc_upload.getExpress_no());
                //更新中间表状态，若未找到表头，显示不存在
                if (foc_express_h==null){
                    iFoc_uploadService.update(express_no);
                }else {
                    //实际快运单
                    String reo = foc_upload.getActual_express_no();
                    //快递公司
                    String ec = foc_upload.getExpress_company();
                    foc_express_h.setReal_express(reo);
                    foc_express_h.setExpress_company(ec);
                    //更新表头
                    iFoc_express_hService.update2(foc_express_h);
                    //自动删除确认数据
                    iFoc_uploadService.delete(foc_upload.getId());
                }
            }
        }
        return "redirect:findAll.do";
    }

    /**
     *@Description: 删除数据
     *@Author: a135109
     *@time: 2019/11/6 10:18
     */
    @RequestMapping("/delete.do")
    public String delete(int ids[]) throws Exception{
        System.out.println(ids);
        if(ids != null && ids.length > 0){
            //1.遍历数组
            for (int id : ids) {
                //2.单条删除
                iFoc_uploadService.delete(id);
            }
        }
        return "redirect:findAll.do";
    }
}
