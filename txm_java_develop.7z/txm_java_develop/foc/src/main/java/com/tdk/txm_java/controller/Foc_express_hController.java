package com.tdk.txm_java.controller;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tdk.txm_java.domain.*;
//import com.tdk.txm_java.domain.ResultInfo;
import com.tdk.txm_java.service.*;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@Controller
@RequestMapping("/foc_express_h")
@SessionAttributes(value = {"t_express_no"})
public class Foc_express_hController {
    @Autowired
    private IFoc_express_hService iFoc_express_hService;
    @Autowired
    private IFoc_express_dService iFoc_express_dService;
    @Autowired
    private IFoc_general_tradeService iFoc_general_tradeService;
    @Autowired
    private ICom_serialnumService iCom_serialnumService;
    @Autowired
    private IFoc_dn_feeService iFoc_dn_feeService;
    @Autowired
    private ICom_rateService iCom_rateService;
    @Autowired
    private ICom_companyService iCom_companyService;

    /**
     *
     * @Description 前端页面发送过来的数据类型和数据库中接收的类型不符。
     *
     **/
    @InitBinder
    public void init(WebDataBinder binder) {
        CustomDateEditor editor = new CustomDateEditor(new SimpleDateFormat("yyyy-MM-dd"),true);
        binder.registerCustomEditor(Date.class, editor);
    }

    /**
     * 根据快递单号来查询
     * @param express_no
     * @return
     * @throws Exception
     */
    @RequestMapping("/findByExpress_no")
    public ModelAndView findByExpress_no(String express_no) throws Exception {
        List<Foc_express_d> foc_express_dList = iFoc_express_dService.findByExpress_no(express_no);
        Foc_express_h foc_express_h = iFoc_express_hService.findByExpress_no(express_no);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("foc-express-list");
        mv.addObject("foc_express_dList", foc_express_dList);
        mv.addObject("foc_express_h", foc_express_h);
        return mv;
    }
    @RequestMapping("/updateStatus.do")
    public void updateStatus(String express_no,String express_status,HttpSession httpSession) throws Exception {
        Foc_express_h foc_express_h = new Foc_express_h();
        String username= (String) httpSession.getAttribute("username");
        foc_express_h.setUpdate_oid(username);
        foc_express_h.setExpress_no(express_no);
        foc_express_h.setExpress_status(express_status);
        foc_express_h.setUpdate_program("foc_express_h/updateStatus.do");
        iFoc_express_hService.updateStatus(foc_express_h);
    }


    /**
     * 新增
     * @param foc_express_h
     * @return
     * @throws Exception
     */
    //没用
    @RequestMapping("/save.do")
    public String save(Foc_express_h foc_express_h, HttpSession httpSession) throws Exception {
        Com_serialnum com_serialnum=new Com_serialnum();
        com_serialnum.setType("foc");
        com_serialnum.setKey01(foc_express_h.getDept());
        com_serialnum.setKey02(foc_express_h.getDept());
        Com_serialnum foc_serialnum=iCom_serialnumService.find(com_serialnum);
        System.out.println(foc_serialnum.getSerialnum());
        // 0 代表前面补充0
        // 6代表长度为6
        // d 代表参数为正数型
        String t_express_no = foc_express_h.getDept()+String.format("%06d", foc_serialnum.getSerialnum());

        httpSession.setAttribute("t_express_no",t_express_no);

        iCom_serialnumService.update(com_serialnum);
        foc_express_h.setExpress_no(t_express_no);
        foc_express_h.setSample_invoice(t_express_no);
        String username= (String) httpSession.getAttribute("username");
        foc_express_h.setUpdate_oid(username);
        foc_express_h.setUpdate_terminal_id("/foc_express_d/save");
// ****       状态 价格的判断来决定状态 需要审核15，正常为20
        iFoc_express_hService.save(foc_express_h);
        return "redirect:findByExpress_no";
    }
    /**
     *@Description: 条件查找快运单表头
     *@Author: a135109
     *@time: 2020/1/4 17:46
     */
    @RequestMapping("/findByNo.do")
    public ModelAndView findByNo(String express_no, String express_no_2, String scheduled_ship_date, String scheduled_ship_date_2, String freight_com_code,String print_sign) throws Exception {
        List<Foc_express_h> foc_express_h = iFoc_express_hService.findByNo(express_no,express_no_2,scheduled_ship_date,scheduled_ship_date_2,freight_com_code,print_sign);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("foc-print");
        mv.addObject("foc_express_h", foc_express_h);
        mv.addObject("express_no", express_no);
        mv.addObject("express_no_2", express_no_2);
        mv.addObject("scheduled_ship_date", scheduled_ship_date);
        mv.addObject("scheduled_ship_date_2", scheduled_ship_date_2);
        mv.addObject("freight_com_code", freight_com_code);
        mv.addObject("print_sign", print_sign);
        return mv;
    }

    /**
     *@Description: 检查
     *@Author: a135109
     *@time: 2019/12/27 9:54
     */ @RequestMapping("/check.do" )
    public void check(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception, IOException, JsonGenerationException, JsonMappingException {
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        //1.获取信息
        String express_no = request.getParameter("express_no");
        String express_no_2 = request.getParameter("express_no_2");
        String scheduled_ship_date = request.getParameter("scheduled_ship_date");
        String scheduled_ship_date_2 = request.getParameter("scheduled_ship_date_2");
        String freight_com_code = request.getParameter("freight_com_code");
        String print_sign = request.getParameter("print_sign");
        //2.调用service层判断是否存在
        List<Foc_express_h> foc_express_h = iFoc_express_hService.findByNo(express_no,express_no_2,scheduled_ship_date,scheduled_ship_date_2,freight_com_code,print_sign);
        if (foc_express_h.isEmpty()) {
            info.setFlag(false);
        }else {
            info.setFlag(true);
        }
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(),info);
    }

    /**
     *@Description: 打印
     *@Author: a135109
     *@time: 2020/1/7 9:32
     */
    @RequestMapping("/print.do" )
    public ModelAndView print(int ids[]) throws Exception {
        List<Foc_express_h> foc_express_hs = new ArrayList<>();
        if(ids != null && ids.length > 0){
            //遍历数组
            for (int id : ids) {
                //单条获取表头
                Foc_express_h foc_express_h = iFoc_express_hService.findById(id);
                //设置打印标志
                foc_express_h.setPrint_sign("Y");
                //打印日期添加(从系统获取时间)
                SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
                foc_express_h.setPrint_time(df.format(new Date()));
                //更新表头信息
                iFoc_express_hService.update(foc_express_h);
                //查找表头对应的表底
                List<Foc_express_d> foc_express_d = iFoc_express_dService.findByNo(foc_express_h.getExpress_no());
                foc_express_h.setFoc_express_ds(foc_express_d);
                foc_express_hs.add(foc_express_h);
            }
        }
        ModelAndView mv = new ModelAndView();
        mv.setViewName("foc-print-detial");
        mv.addObject("foc_express_hs", foc_express_hs);
        return mv;
    }

    @RequestMapping("/findByScheduled_ship_date")
    public ModelAndView findByScheduled_ship_date(String scheduled_ship_date, String scheduled_ship_date_2,String dept,String flag_arr,String express_no) throws Exception {
//        dept=dept+ "*";
        List<Foc_express_h> foc_forwarder_arr2 = new ArrayList<Foc_express_h>();
        List<Com_company> com_companies= iCom_companyService.findByType("01");
        if(express_no!=""){
            Foc_express_h foc_express_h=iFoc_express_hService.findByExpress_no(express_no);
            if(foc_express_h.getExpress_status().compareTo("20")>=0) {
                foc_forwarder_arr2.add(foc_express_h);
            }
        }else {
            List<Foc_express_h> foc_forwarder_arr = iFoc_express_hService.findByScheduled_ship_date(scheduled_ship_date, scheduled_ship_date_2, dept);
            for (Foc_express_h va01 : foc_forwarder_arr) {
                if (dept != null && dept != ""&&!dept.equals(va01.getDept())) continue;;
                if (flag_arr.equals("Y") && (va01.getFreight_com_code()==(null)||va01.getFreight_com_code().equals(""))) continue;
                if (flag_arr.equals("N") && va01.getFreight_com_code() != (null)&& !va01.getFreight_com_code().equals("")) continue;
                foc_forwarder_arr2.add(va01);
//                    if (dept != null && dept != "") {
//                    if (dept.equals(va01.getDept())) {
//                        if (flag_arr.equals("n") && va01.getFreight_com_code()==(null)) {
//                            foc_forwarder_arr2.add(va01);
//                        }
//                        if (flag_arr.equals("y") && va01.getFreight_com_code() != (null)) {
//                            foc_forwarder_arr2.add(va01);
//                        }
//                        if (flag_arr.equals("all")) {
//                            foc_forwarder_arr2.add(va01);
//                        }
//                    }
//                } else {
//                    if (flag_arr.equals("n") && va01.getFreight_com_code()==(null)) {
//                        foc_forwarder_arr2.add(va01);
//                    }
//                    if (flag_arr.equals("y") && va01.getFreight_com_code() != (null)) {
//                        foc_forwarder_arr2.add(va01);
//                    }
//                    if (flag_arr.equals("all")) {
//                        foc_forwarder_arr2.add(va01);
//                    }else{
//
//                    }
//                }
            }
        }
        ModelAndView mv = new ModelAndView();
        mv.setViewName("foc-forwarder-arr");
        mv.addObject("foc_forwarder_arr", foc_forwarder_arr2);
        mv.addObject("com_companies", com_companies);
        mv.addObject("scheduled_ship_date", scheduled_ship_date);
        mv.addObject("scheduled_ship_date_2", scheduled_ship_date_2);
        mv.addObject("dept", dept);
        mv.addObject("flag_arr", flag_arr);
        mv.addObject("express_no", express_no);

//        mv.addObject("foc_price_acklist", foc_price_acklist);
        System.out.println("oooooooo");
        return mv;
    }

    @RequestMapping("/update.do")
    public String update(HttpServletRequest request, HttpServletResponse response) throws Exception {
        //取出前端传回的所有数据
        int rate=iCom_rateService.findByTable();
        Map map = request.getParameterMap();
        Map<String, String> map2 = new HashMap<>();
        Set<String> set = map.keySet();
        int b=0;
        int c=0;
        while (1==1){
            for(String name1 : set){

                String[] vals = (String[]) map.get(name1);
                System.out.println(vals);
                c=vals.length;
                map2.put(name1,vals[b]);

            }
            Foc_express_h a = new Foc_express_h();

            String express_no = map2.get("express_no");

            a= iFoc_express_hService.findByExpress_no(express_no);
            try {
                BeanUtils.populate(a,map2);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            iFoc_express_hService.update(a);
            b++;
            if(b==c) break;
        }
        return "redirect:findByExpress_no";
    }

    @RequestMapping("/updateArr.do")
    public String updateArr(HttpServletRequest request, HttpServletResponse response,HttpSession httpSession) throws Exception {
        //取出前端传回的所有数据

        Map map = request.getParameterMap();
        Map<String, String> map2 = new HashMap<>();
        Set<String> set = map.keySet();
        int b=0;
        int c=0;
        String username= (String) httpSession.getAttribute("username");

        while (1==1){
            for(String name1 : set){

                String[] vals = (String[]) map.get(name1);
                System.out.println(vals);
                c=vals.length;
                map2.put(name1,vals[b]);

            }
            Foc_express_h iFoc_express_h = new Foc_express_h();

            int id1 = Integer.parseInt(map2.get("id"));

            iFoc_express_h= iFoc_express_hService.findById(id1);
            try {
                BeanUtils.populate(iFoc_express_h,map2);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //计算运费
            double total_amt=0;
            //1 计算重量
            DecimalFormat df   = new DecimalFormat("######0.0");
            double wt1 = Double.parseDouble((map2.get("gross_weightz")));
            double wt2= Double.parseDouble(iFoc_express_h.getPacking_volume())*167;
            double wt3= Double.parseDouble(df.format(wt1>wt2?wt1:wt2));
            //2 计算金额
            String country=iFoc_express_h.getCountry();
            total_amt=iFoc_dn_feeService.CountAmt(wt3,country,iFoc_express_h.getFreight_com_code());
            //3 取得汇率
            String currency=iFoc_express_h.getCurrency().toUpperCase();;
            if(!currency.equals("RMB")) {
                Com_rate com_rate = new Com_rate();
                SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
                Date today = new Date();
                int date7 = Integer.parseInt(format.format(today)) - 19000000;
                com_rate.setCurrency(currency);
                com_rate.setRate_date(date7);
                com_rate.setType("D");
                Double xx=iCom_rateService.findByCurDateType(com_rate);
                iFoc_express_h.setRate(xx);
                total_amt = total_amt /iCom_rateService.findByCurDateType(com_rate);
            }
            iFoc_express_h.setShip_cost(total_amt);
            //更新状态
            if(iFoc_express_h.getFreight_com_code().equals("")||iFoc_express_h.getFreight_com_code()==null){
                iFoc_express_h.setExpress_status("20");}
            else{
                iFoc_express_h.setExpress_status("50");
            }
            iFoc_express_h.setUpdate_oid(username);
            iFoc_express_h.setUpdate_program("/foc_express_h/updateArr");
            iFoc_express_hService.update(iFoc_express_h);
            b++;
            if(b==c) break;
        }
        return"foc-forwarder-arr";
    }

    /**
     *@Description: 检查
     *@Author: a135109
     *@time: 2019/12/27 9:54
     */
    @RequestMapping("/check_iv.do" )
    public void check_iv(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception, IOException, JsonGenerationException, JsonMappingException {
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        //1.获取信息
        String express_no = request.getParameter("express_no");
        String express_no_2 = request.getParameter("express_no_2");
        String scheduled_ship_date = request.getParameter("scheduled_ship_date");
        String scheduled_ship_date_2 = request.getParameter("scheduled_ship_date_2");
        String freight_com_code = request.getParameter("freight_com_code");
        String overseas = request.getParameter("overseas");
        String bonded_logo = request.getParameter("bonded_logo");
        //2.调用service层判断是否存在
        List<Foc_express_h> foc_express_h = iFoc_express_hService.findByNo_iv(express_no,express_no_2,scheduled_ship_date,scheduled_ship_date_2,freight_com_code,overseas,bonded_logo);
        if (foc_express_h.isEmpty()) {
            info.setFlag(false);
        }else {
            info.setFlag(true);
        }
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(),info);
    }

    /**
     *@Description: 发票打印
     *@Author: a135109
     *@time: 2020/3/11 13:17
     */
    @RequestMapping("/print_iv")
    public ModelAndView print_iv (int ids[],String iv_type) throws Exception {
        List<Foc_express_h> foc_express_hs = new ArrayList<>();
        if(ids != null && ids.length > 0){
            //遍历数组
            for (int id : ids) {
                //单条获取表头
                Foc_express_h foc_express_h = iFoc_express_hService.findById(id);
                //查找表头对应的表底
                List<Foc_express_d> foc_express_d = iFoc_express_dService.findByNo(foc_express_h.getExpress_no());
                foc_express_h.setFoc_express_ds(foc_express_d);
                foc_express_hs.add(foc_express_h);
            }
        }
        ModelAndView mv = new ModelAndView();
        // 响应数据
        mv.setViewName("foc-invoice");
        mv.addObject("foc_express_hs", foc_express_hs);
        if (iv_type.equals("物流用 INVOICE & PACKING LIST")){
            iv_type = new String("1");
        }else if(iv_type.equals("技术用 INVOICE & PACKING LIST")){
            iv_type = new String("2");
        }else if(iv_type.equals("INVOICE")){
            iv_type = new String("3");
        } else {
            iv_type = new String("4");
        }
        mv.addObject("iv_type", iv_type);
        return mv;
    }

    /**
     *@Description: 查找快运单发票
     *@Author: a135109
     *@time: 2020/3/11 13:23
     */
    @RequestMapping("/findByNo_iv.do")
    public ModelAndView findByNo_iv(@RequestParam(value="pn",defaultValue="1")Integer pn, @RequestParam(value = "PageSize", defaultValue = "30") Integer ps,String express_no, String express_no_2, String scheduled_ship_date, String scheduled_ship_date_2,String iv_type,String freight_com_code,String overseas,String bonded_logo) throws Exception {
        PageHelper.startPage(pn,ps);
        List<Foc_express_h> foc_express_h = iFoc_express_hService.findByNo_iv(express_no,express_no_2,scheduled_ship_date,scheduled_ship_date_2,freight_com_code,overseas,bonded_logo);
        PageInfo page = new PageInfo(foc_express_h,ps);
        System.out.println(page);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("foc-invoice-list");
        mv.addObject("pageInfo", page);
        mv.addObject("foc_express_h", foc_express_h);
        mv.addObject("express_no", express_no);
        mv.addObject("express_no_2", express_no_2);
        mv.addObject("scheduled_ship_date", scheduled_ship_date);
        mv.addObject("scheduled_ship_date_2", scheduled_ship_date_2);
        mv.addObject("freight_com_code", freight_com_code);
        mv.addObject("overseas", overseas);
        mv.addObject("bonded_logo", bonded_logo);
        mv.addObject("iv_type", iv_type);
        return mv;
    }

    @RequestMapping("/check_query.do" )
    public void check_query(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception, IOException, JsonGenerationException, JsonMappingException {
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        //1.获取信息
        String scheduled_ship_date = request.getParameter("scheduled_ship_date");
        String scheduled_ship_date_2 = request.getParameter("scheduled_ship_date_2");
        String freight_com_code = request.getParameter("freight_com_code");
        String dept = request.getParameter("dept");
        String handled_manual_id = request.getParameter("handled_manual_id");
        //2.调用service层判断是否存在
        List<Foc_express_h> foc_express_h = iFoc_express_hService.findByQuery(scheduled_ship_date,scheduled_ship_date_2,freight_com_code,dept,handled_manual_id);
        if (foc_express_h.isEmpty()) {
            info.setFlag(false);
        }else {
            info.setFlag(true);
        }
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(),info);
    }

    /**
    *@Description: 无偿查询使用表
    *@Author: a135109
    *@time: 2020/5/6 10:35
    */
    @RequestMapping("/findByQuery.do")
    public ModelAndView findByQuery(String scheduled_ship_date, String scheduled_ship_date_2,String freight_com_code,String dept,String handled_manual_id) throws Exception {
        List<Foc_express_h> foc_express_hs = iFoc_express_hService.findByQuery(scheduled_ship_date,scheduled_ship_date_2,freight_com_code,dept,handled_manual_id);
        List<Foc_express_h> ls = new ArrayList<>();
        Double total_net_weight = 0.0;   //总净重
        Double total_volume = 0.0;   //总体积
        for (Foc_express_h foc_express_h:foc_express_hs) {
            //查找表头对应的表底
            List<Foc_express_d> foc_express_ds = iFoc_express_dService.findByNo(foc_express_h.getExpress_no());
            List<Foc_express_d> ls2 = new ArrayList<>();
            for (int i = 0 ; i < foc_express_ds.size();i++){
                if(foc_express_ds.get(i).getMaterial_descriable()==null||foc_express_ds.get(i).getNet_weigh()==null){
                    foc_express_ds.get(i).setMaterial_descriable("");
                    foc_express_ds.get(i).setNet_weigh(0.0);
                }else{
                    if (i > 0 && foc_express_ds.get(i).getMaterial_descriable().equals(foc_express_ds.get(i - 1).getMaterial_descriable())) {
                    } else {
                        ls2.add(foc_express_ds.get(i));
                    }
                }
                System.out.println(total_net_weight+"-------"+foc_express_ds.get(i).getNet_weigh());
                total_net_weight=total_net_weight+foc_express_ds.get(i).getNet_weigh();
                System.out.println(total_net_weight);

            }
            foc_express_h.setFoc_express_ds(ls2);
            ls.add(foc_express_h);
            total_volume= total_volume+Double.valueOf(foc_express_h.getPacking_volume());
        }
        ModelAndView mv = new ModelAndView();
        mv.setViewName("foc-query-list");
        mv.addObject("foc_express_h", ls);
        mv.addObject("scheduled_ship_date", scheduled_ship_date);
        mv.addObject("scheduled_ship_date_2", scheduled_ship_date_2);
        mv.addObject("freight_com_code", freight_com_code);
        mv.addObject("dept", dept);
        mv.addObject("handled_manual_id", handled_manual_id);
        mv.addObject("total_net_weight", total_net_weight);
        mv.addObject("total_volume", total_volume);
        return mv;
    }

    /**
     *@Description: 一般贸易查询
     *@Author: a135109
     *@time: 2020/5/14 9:37
     */
    @RequestMapping("/findByGt")
    public ModelAndView findByGt(String express_no, String express_no_2, String scheduled_ship_date, String scheduled_ship_date_2,String freight_com_code,String overseas,String bonded_logo,String flag) throws Exception{
        List<Foc_express_h> foc_express_hs = iFoc_express_hService.findByNo_iv(express_no,express_no_2,scheduled_ship_date,scheduled_ship_date_2,freight_com_code,overseas,bonded_logo);
        List<Foc_express_h> ls = new ArrayList<>();
        //查找对应的一般贸易条件
        for (Foc_express_h foc_express_h:foc_express_hs) {
            Foc_general_trade foc_general_trade = new Foc_general_trade();
            List<Foc_general_trade> foc_general_trades = iFoc_general_tradeService.findByIv(foc_express_h.getExpress_no());
            if (flag.equals("Y")){
                if (foc_general_trades.isEmpty()){
                    System.out.println("no  foc_express_h");
                }else {
                    foc_express_h.setFoc_general_trade(foc_general_trades);
                    ls.add(foc_express_h);
                }
            } else if (flag.equals("N")){
                if (foc_general_trades.isEmpty()){
                    foc_express_h.setFoc_general_trade(foc_general_trades);
                    foc_general_trades.add(foc_general_trade);
                    ls.add(foc_express_h);
                }else {
                    System.out.println("no  foc_express_h");
                }
            }else {
                if (foc_general_trades.isEmpty()){
                    foc_general_trades.add(foc_general_trade);
                    System.out.println(foc_general_trades);
                }
                foc_express_h.setFoc_general_trade(foc_general_trades);
                ls.add(foc_express_h);
            }
        }
        ModelAndView mv = new ModelAndView();
        mv.setViewName("foc-general-trade");
        mv.addObject("foc_express_h", ls);
        mv.addObject("express_no", express_no);
        mv.addObject("express_no_2", express_no_2);
        mv.addObject("scheduled_ship_date", scheduled_ship_date);
        mv.addObject("scheduled_ship_date_2", scheduled_ship_date_2);
        mv.addObject("freight_com_code", freight_com_code);
        mv.addObject("overseas", overseas);
        mv.addObject("bonded_logo", bonded_logo);
        mv.addObject("flag", flag);
        return mv;
    }
}
