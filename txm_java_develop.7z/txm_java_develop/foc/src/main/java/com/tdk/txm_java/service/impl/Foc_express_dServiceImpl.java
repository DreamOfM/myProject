package com.tdk.txm_java.service.impl;

import com.tdk.txm_java.dao.IFoc_express_dDao;
import com.tdk.txm_java.domain.Foc_express_d;
import com.tdk.txm_java.service.IFoc_express_dService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class Foc_express_dServiceImpl implements IFoc_express_dService {
    @Autowired
    private IFoc_express_dDao iFoc_express_dDao;

    @Override
    public Foc_express_d findById(int id) throws Exception {
        return iFoc_express_dDao.findById(id);
    }

    /**
     * 新增信息的方法
     * @param foc_express_d
     * @throws Exception
     */
    @Override
    public void save(Foc_express_d foc_express_d) throws Exception {

        iFoc_express_dDao.save(foc_express_d);

    }

    /**
     * 根据快递单号查询信息
     * @param express_no
     * @return
     * @throws Exception
     */
    @Override
    public List<Foc_express_d> findByExpress_no(String express_no) throws Exception {
        return iFoc_express_dDao.findByExpress_no(express_no);
    }

    /**
     * 修改信息
     * @param foc_express_d
     */
    @Override
    public void update(Foc_express_d foc_express_d) {
        System.out.println("d-service");
        iFoc_express_dDao.update(foc_express_d);
    }

    /**
     * 根据id删除数据
     * @param id
     */
    @Override
    public void  deleteById(int  id) {
        System.out.println("d-service");
        iFoc_express_dDao.deleteById(id);

    }
    /*
     *2019.10.30  Haowen Tan
     *条件查找快运单表底
     */
    @Override
    public List<Foc_express_d> findByNo(String express_no) throws Exception {
        return iFoc_express_dDao.findByNo(express_no);
    }

    /**

     * @param express_no
     * @return
     * @throws Exception
     */
    @Override
    public List<Foc_express_d> findByExpress_no2(String express_no) throws Exception {
        return iFoc_express_dDao.findByExpress_no2(express_no);
    }

    /**
     *更新打印标识
     * @param foc_express_d
     */
    @Override
    public void update2(Foc_express_d foc_express_d) {
        iFoc_express_dDao.update2(foc_express_d);
    }

    @Override
    public void updateByExpress_no(Foc_express_d foc_express_d) {
        iFoc_express_dDao.updatebyExpress_no(foc_express_d);
    }

    @Override
    public Foc_express_d findByIv(String express_no) throws Exception {
        return iFoc_express_dDao.findByIv(express_no);
    }

}
