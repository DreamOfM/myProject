package com.tdk.txm_java.dao;


import com.tdk.txm_java.domain.Foc_general_trade;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IFoc_general_tradeDao {

    // 查询所有信息
    @Select("select * from foc_general_trade")
    public List<Foc_general_trade> findAll() throws Exception;

    @Select("select * from foc_general_trade where invoice_no =#{invoice_no}")
    public List<Foc_general_trade> findByIv(String invoice_no) throws Exception;

    @Insert("insert into foc_general_trade" +
            "(declare_date,declaration_no,declare_port,list_no,invoice_no,terms_trade,login_time,login_oid,update_time,update_oid,update_program )" +
            "values(#{declare_date},#{declaration_no},#{declare_port},#{list_no},#{invoice_no},#{terms_trade},now(),#{login_oid},now(),#{update_oid},#{update_program})")
    void save(Foc_general_trade foc_general_trade);

    @Update("update foc_general_trade set  declare_date=#{declare_date}, declaration_no=#{declaration_no}, declare_port=#{declare_port}, list_no=#{list_no}, invoice_no=#{invoice_no}, terms_trade=#{terms_trade}, login_time=#{login_time}, login_oid=#{login_oid}, now(), update_oid=#{update_oid}, update_program=#{update_program}" +
            "where id =#{id}  ")
    void update(Foc_general_trade foc_general_trade);

    @Delete("delete from foc_general_trade where id =#{id} ")
    void delete(int id);

}
