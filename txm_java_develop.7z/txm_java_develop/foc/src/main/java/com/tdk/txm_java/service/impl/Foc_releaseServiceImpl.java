package com.tdk.txm_java.service.impl;

import com.tdk.txm_java.dao.IFoc_ReleaseDao;
import com.tdk.txm_java.dao2.IFoc_Release2Dao;
import com.tdk.txm_java.domain.Foc_release;
import com.tdk.txm_java.service.IFoc_releaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class Foc_releaseServiceImpl implements IFoc_releaseService {
    @Autowired
    private IFoc_ReleaseDao iFoc_releaseDao;
    @Autowired
    private IFoc_Release2Dao iFoc_release2Dao;

    @Override
    public Foc_release findByRelease(String release) throws Exception {
        Foc_release foc_release=new Foc_release();

        foc_release=iFoc_releaseDao.findByRelease(release);
        if(foc_release==null){
            foc_release=iFoc_release2Dao.findByRelease(release);
        }
        return foc_release;
    }
}
