package com.tdk.txm_java.controller;

import com.tdk.txm_java.domain.Foc_express_d;
import com.tdk.txm_java.domain.Foc_express_h;
import com.tdk.txm_java.service.IFoc_express_dService;
import com.tdk.txm_java.service.IFoc_express_hService;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.varia.StringMatchFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

@Controller
@RequestMapping("/foc_forwarder_arr")
public class Foc_forwarder_arrController {
    @Autowired
    private IFoc_express_hService iFoc_express_hService;
//    @Autowired
//    private IFoc_express_dService iFoc_express_dService;

    @RequestMapping("/findByScheduled_ship_date")
    public ModelAndView findByScheduled_ship_date(String scheduled_ship_date, String scheduled_ship_date_2,String dept) throws Exception {

        List<Foc_express_h> foc_forwarder_arr = iFoc_express_hService.findByScheduled_ship_date(scheduled_ship_date,scheduled_ship_date_2,dept);
        System.out.println("hhhhhhh");
        System.out.println(scheduled_ship_date);
        System.out.println(scheduled_ship_date_2);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("foc-forwarder-arr");
        mv.addObject("foc_forwarder_arr", foc_forwarder_arr);
        System.out.println(foc_forwarder_arr);

//        mv.addObject("foc_price_acklist", foc_price_acklist);
        System.out.println("oooooooo");
        return mv;
    }

    /**
     * 修改
     * @return
     * @throws Exception
     */
    @RequestMapping("/update.do")
        public String update(HttpServletRequest request, HttpServletResponse response) throws Exception {
            //取出前端传回的所有数据
        Map map = request.getParameterMap();
        Map<String, String> map2 = new HashMap<>();
        Set<String> set = map.keySet();
        System.out.println("eeeeeeeee");
        System.out.println(request);
        System.out.println(response);

        int b=0;
        int c=0;
        while (1==1){
            for(String name1 : set){

                String[] vals = (String[]) map.get(name1);
                System.out.println(vals);
                c=vals.length;
                map2.put(name1,vals[b]);

            }
            Foc_express_h a = new Foc_express_h();

            int id1 = Integer.parseInt(map2.get("id"));

            System.out.println(id1);
            a= iFoc_express_hService.findById(id1);
            try {
                BeanUtils.populate(a,map2);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            System.out.println(a.toString());
            //更新状态
            if(a.getFreight_com_code().equals("")||a.getFreight_com_code()==null){
                a.setExpress_status("20");}
                else{
                a.setExpress_status("50");
            }
            iFoc_express_hService.update(a);
            b++;
            if(b==c) break;
        }
            return"foc-forwarder-arr";
        }

    }

