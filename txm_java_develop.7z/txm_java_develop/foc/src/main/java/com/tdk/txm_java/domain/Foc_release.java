package com.tdk.txm_java.domain;

import java.sql.Time;
import java.util.List;

/**
 * 彔入表体
 */
public class Foc_release {
    private int id;
    private String LHDCNO;
    private String LHCUN1;
    private String LHCUN2;
    private String LHADR1;
    private String LHADR2;
    private String LHADR3;
    private String LHRECP;
    private String LHCUTE;
    private String LHEMNO;
    private String LHSHIP;
    private String LHMEMO;
    private List<Foc_release_d> foc_release_ds;

    @Override
    public String toString() {
        return "Foc_release{" +
                "id=" + id +
                ", LHDCNO='" + LHDCNO + '\'' +
                ", LHCUN1='" + LHCUN1 + '\'' +
                ", LHCUN2='" + LHCUN2 + '\'' +
                ", LHADR1='" + LHADR1 + '\'' +
                ", LHADR2='" + LHADR2 + '\'' +
                ", LHADR3='" + LHADR3 + '\'' +
                ", LHRECP='" + LHRECP + '\'' +
                ", LHCUTE='" + LHCUTE + '\'' +
                ", LHEMNO='" + LHEMNO + '\'' +
                ", LHSHIP=" + LHSHIP +
                ", LHMEMO='" + LHMEMO + '\'' +
                ", foc_release_ds=" + foc_release_ds +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLHDCNO() {
        return LHDCNO;
    }

    public void setLHDCNO(String LHDCNO) {
        this.LHDCNO = LHDCNO;
    }

    public String getLHCUN1() {
        return LHCUN1;
    }

    public void setLHCUN1(String LHCUN1) {
        this.LHCUN1 = LHCUN1;
    }

    public String getLHCUN2() {
        return LHCUN2;
    }

    public void setLHCUN2(String LHCUN2) {
        this.LHCUN2 = LHCUN2;
    }

    public String getLHADR1() {
        return LHADR1;
    }

    public void setLHADR1(String LHADR1) {
        this.LHADR1 = LHADR1;
    }

    public String getLHADR2() {
        return LHADR2;
    }

    public void setLHADR2(String LHADR2) {
        this.LHADR2 = LHADR2;
    }

    public String getLHADR3() {
        return LHADR3;
    }

    public void setLHADR3(String LHADR3) {
        this.LHADR3 = LHADR3;
    }

    public String getLHRECP() {
        return LHRECP;
    }

    public void setLHRECP(String LHRECP) {
        this.LHRECP = LHRECP;
    }

    public String getLHCUTE() {
        return LHCUTE;
    }

    public void setLHCUTE(String LHCUTE) {
        this.LHCUTE = LHCUTE;
    }

    public String getLHEMNO() {
        return LHEMNO;
    }

    public void setLHEMNO(String LHEMNO) {
        this.LHEMNO = LHEMNO;
    }

    public String getLHSHIP() {
        return LHSHIP;
    }

    public void setLHSHIP(String LHSHIP) {
        this.LHSHIP = LHSHIP;
    }

    public String getLHMEMO() {
        return LHMEMO;
    }

    public void setLHMEMO(String LHMEMO) {
        this.LHMEMO = LHMEMO;
    }

    public List<Foc_release_d> getFoc_release_ds() {
        return foc_release_ds;
    }

    public void setFoc_release_ds(List<Foc_release_d> foc_release_ds) {
        this.foc_release_ds = foc_release_ds;
    }
}


