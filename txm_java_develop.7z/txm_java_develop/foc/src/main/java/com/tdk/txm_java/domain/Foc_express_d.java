package com.tdk.txm_java.domain;

import java.math.BigDecimal;
import java.sql.Time;
import java.util.Date;

/**
 * 彔入表体
 */
public class Foc_express_d {
    private int id;
    private String express_no;//快遞單號碼
    private int express_id;//快遞号序號
    private String sample_invoice;//送樣發票
    private String material_descriable;//品名描述
    private String material_specif;//品名規格
    private String material_e_descriable;//品名英文描述
    private String unit;//單位
    private String sips_no;//SIPS NO
    private String price_type;//價格分類
    private String confirm_no;//承認者工號
    private String confirm_id;//承認這 ID
    private String confirm_name;//承認這姓名
    private String price_modi_conf;//價格修改承認標誌
    private Double qty;//送樣數量
    private Double price;//單價
    private Double amount;//金额
    private Double price_lower;//價格下限
    private Double price_upper;//價格上限
    private Double net_weigh;//净重
    private Double gross_weight;//毛重
    private int box_from;//箱號 FROM
    private int box_to;//箱號 TO
    private Time confirm_time;//承認时间
    private Date login_time;//登陸时间
    private String login_oid;//更新操作员代码
    private Date update_time;//更新時間
    private String update_terminal_id;//更新操作员代码
    private String update_oid;//更新操作员代码
    private String update_program;//更新程式名稱
    private Foc_express_h foc_express_h;//表头


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getExpress_no() {
        return express_no;
    }

    public void setExpress_no(String express_no) {
        this.express_no = express_no;
    }

    public int getExpress_id() {
        return express_id;
    }

    public void setExpress_id(int express_id) {
        this.express_id = express_id;
    }

    public String getSample_invoice() {
        return sample_invoice;
    }

    public void setSample_invoice(String sample_invoice) {
        this.sample_invoice = sample_invoice;
    }

    public String getMaterial_descriable() {
        return material_descriable;
    }

    public void setMaterial_descriable(String material_descriable) {
        this.material_descriable = material_descriable;
    }

    public String getMaterial_specif() {
        return material_specif;
    }

    public void setMaterial_specif(String material_specif) {
        this.material_specif = material_specif;
    }

    public String getMaterial_e_descriable() {
        return material_e_descriable;
    }

    public void setMaterial_e_descriable(String material_e_descriable) {
        this.material_e_descriable = material_e_descriable;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getSips_no() {
        return sips_no;
    }

    public void setSips_no(String sips_no) {
        this.sips_no = sips_no;
    }

    public String getPrice_type() {
        return price_type;
    }

    public void setPrice_type(String price_type) {
        this.price_type = price_type;
    }

    public String getConfirm_no() {
        return confirm_no;
    }

    public void setConfirm_no(String confirm_no) {
        this.confirm_no = confirm_no;
    }

    public String getConfirm_id() {
        return confirm_id;
    }

    public void setConfirm_id(String confirm_id) {
        this.confirm_id = confirm_id;
    }

    public String getConfirm_name() {
        return confirm_name;
    }

    public void setConfirm_name(String confirm_name) {
        this.confirm_name = confirm_name;
    }

    public String getPrice_modi_conf() {
        return price_modi_conf;
    }

    public void setPrice_modi_conf(String price_modi_conf) {
        this.price_modi_conf = price_modi_conf;
    }

    public Double getQty() {
        return qty;
    }

    public void setQty(Double qty) {
        this.qty = qty;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public Double getPrice_lower() {
        return price_lower;
    }

    public void setPrice_lower(Double price_lower) {
        this.price_lower = price_lower;
    }

    public Double getPrice_upper() {
        return price_upper;
    }

    public void setPrice_upper(Double price_upper) {
        this.price_upper = price_upper;
    }

    public Double getNet_weigh() {
        return net_weigh;
    }

    public void setNet_weigh(Double net_weigh) {
        this.net_weigh = net_weigh;
    }

    public Double getGross_weight() {
        return gross_weight;
    }

    public void setGross_weight(Double gross_weight) {
        this.gross_weight = gross_weight;
    }

    public int getBox_from() {
        return box_from;
    }

    public void setBox_from(int box_from) {
        this.box_from = box_from;
    }

    public int getBox_to() {
        return box_to;
    }

    public void setBox_to(int box_to) {
        this.box_to = box_to;
    }

    public Time getConfirm_time() {
        return confirm_time;
    }

    public void setConfirm_time(Time confirm_time) {
        this.confirm_time = confirm_time;
    }

    public Date getLogin_time() {
        return login_time;
    }

    public void setLogin_time(Date login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public Date getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(Date update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_terminal_id() {
        return update_terminal_id;
    }

    public void setUpdate_terminal_id(String update_terminal_id) {
        this.update_terminal_id = update_terminal_id;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    public Foc_express_h getFoc_express_h() {
        return foc_express_h;
    }

    public void setFoc_express_h(Foc_express_h foc_express_h) {
        this.foc_express_h = foc_express_h;
    }

    @Override
    public String toString() {
        return "Foc_express_d{" +
                "id=" + id +
                ", express_no='" + express_no + '\'' +
                ", express_id=" + express_id +
                ", sample_invoice='" + sample_invoice + '\'' +
                ", material_descriable='" + material_descriable + '\'' +
                ", material_specif='" + material_specif + '\'' +
                ", material_e_descriable='" + material_e_descriable + '\'' +
                ", unit='" + unit + '\'' +
                ", sips_no='" + sips_no + '\'' +
                ", price_type='" + price_type + '\'' +
                ", confirm_no='" + confirm_no + '\'' +
                ", confirm_id='" + confirm_id + '\'' +
                ", confirm_name='" + confirm_name + '\'' +
                ", price_modi_conf='" + price_modi_conf + '\'' +
                ", qty=" + qty +
                ", price=" + price +
                ", amount=" + amount +
                ", price_lower=" + price_lower +
                ", price_upper=" + price_upper +
                ", net_weigh=" + net_weigh +
                ", gross_weight=" + gross_weight +
                ", box_from=" + box_from +
                ", box_to=" + box_to +
                ", confirm_time=" + confirm_time +
                ", login_time=" + login_time +
                ", login_oid='" + login_oid + '\'' +
                ", update_time=" + update_time +
                ", update_terminal_id='" + update_terminal_id + '\'' +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                ", foc_express_h=" + foc_express_h +
                '}';
    }
}

