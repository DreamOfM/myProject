package com.tdk.txm_java.controller;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tdk.txm_java.domain.*;
import com.tdk.txm_java.service.*;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@Controller
@RequestMapping("/foc_express_d")
public class Foc_express_dController {
    @Autowired
    private IFoc_express_dService iFoc_express_dService;
    @Autowired
    private IFoc_express_hService iFoc_express_hService;
    @Autowired
    private ICom_serialnumService iCom_serialnumService;
    @Autowired
    private IFoc_priceService iFoc_priceService;
    @Autowired
    private IFoc_dn_feeService iFoc_dn_feeService;
    @Autowired
    private ICom_employeeService iCom_employeeService;

    /**
     * 根据ID查找
     *
     * @param id
     * @return
     * @throws Exception
     */
    @RequestMapping("/findById.do")
    public ModelAndView findById(String id) throws Exception {
        ModelAndView mv = new ModelAndView();
        System.out.println(id);
        mv.setViewName("foc-express-list");
        return mv;
    }
    @RequestMapping("/findByExpress_no2")
    public ModelAndView findByExpress_no2(String express_no) throws Exception {
        System.out.println(express_no);
        List<Foc_express_d> foc_price_acklist = iFoc_express_dService.findByExpress_no(express_no);
        Foc_express_h foc_price_ack = iFoc_express_hService.findByExpress_no(express_no);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("foc-price-ack");
        mv.addObject("foc_price_ack", foc_price_ack);
        mv.addObject("foc_price_acklist", foc_price_acklist);
        return mv;
    }
    /**
     * 删除
     *
     * @param
     * @return
     * @throws Exception
     */
    @RequestMapping("/delete.do")
    public String delete(int id) throws Exception {
        System.out.println(id + "delete's id has send");
        iFoc_express_dService.deleteById(id);
        System.out.println("foc_express_d's values");
        return "redirect:findById.do";
    }
    @RequestMapping("/updateByExpress_no.do")
    public String updateByExpress_no(String express_no,HttpSession httpSession) throws Exception {
        Foc_express_d foc_express_d = new Foc_express_d();
        String username= (String) httpSession.getAttribute("username");
        foc_express_d.setUpdate_oid(username);
        foc_express_d.setExpress_no(express_no);
        foc_express_d.setUpdate_program("updatebyExpress_no.do");
        iFoc_express_dService.updateByExpress_no(foc_express_d);
        return "redirect:findById.do";
    }


    /**
     * 新增
     *
     * @param
     * @return
     * @throws Exception
     */
    @RequestMapping("/save.do")
    public String save(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception {
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //测试前端数据是否传送过来？
        System.out.println(map.entrySet().toString() + "数据已传过来");
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;

        String t_express_no= (String) httpSession.getAttribute("t_express_no");
        String username= (String) httpSession.getAttribute("username");
        Foc_express_d foc_express_d = new Foc_express_d();

        while (1 == 1) {
            for (String name1 : set) {
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                hashMap.put(name1, vals[b]);
            }

            try {
                BeanUtils.populate(foc_express_d, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //添加一个判断，如果为空值或者没有输入则不往数据库里插数据
            if (foc_express_d.getPrice_type().equals(null) || foc_express_d.getPrice_type().equals("")) {
                b++;
                if (b == c) break;
                continue;
            }
            foc_express_d.setExpress_no(t_express_no);
            foc_express_d.setSample_invoice(t_express_no);
            foc_express_d.setUpdate_oid(username);
//            foc_express_d.setUpdate_terminal_id("/foc_express_d/save");
            iFoc_express_dService.save(foc_express_d);
            b++;
            if (b == c) break;
        }
        return "redirect:findById.do";
    }

    //修改
    @RequestMapping("/update.do")
    public String update(HttpServletRequest request,
                         HttpServletResponse response)
            throws Exception {
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();

        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //将每一个key值对应的一组值放到数组里去
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                hashMap.put(name1, vals[b]);
            }
            Foc_express_d foc_express_d = new Foc_express_d();
            //根据key值找到集合中对应的id
            int id1 = Integer.parseInt(hashMap.get("id"));
            //找到这个id对应数据库里的数据，并取出
            foc_express_d = iFoc_express_dService.findById(id1);
            try {

                BeanUtils.populate(foc_express_d, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //调用业务层的update()方法
            iFoc_express_dService.update(foc_express_d);
            b++;
            if (b == c) break;
        }
        return "redirect:findById.do";
    }
    @RequestMapping("/update2.do")
    public String update2(HttpServletRequest request, HttpServletResponse response) throws Exception {
        Map map = request.getParameterMap();
        Map<String, String> map2 = new HashMap<>();
        Set<String> set = map.keySet();

        int b=0;
        int c=0;
        while (1==1){
            for(String name1 : set){
                String[] vals = (String[]) map.get(name1);
                c=vals.length;
                map2.put(name1,vals[b]);

            }
            Foc_express_d a = new Foc_express_d();
            try {
                BeanUtils.populate(a,map2);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            System.out.println(a.toString());
            iFoc_express_dService.update2(a);
            b++;
            if(b==c) break;
        }
        return "redirect:findByExpress_no2.do";
    }
    @RequestMapping("/saveAll.do")
    public String saveAll(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception {
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();

        //head
        for (String name1 : set) {
            String[] vals = (String[]) map.get(name1);
            hashMap.put(name1, vals[0]);
        }
        Foc_express_h foc_express_h = new Foc_express_h();
        try {
            BeanUtils.populate(foc_express_h, hashMap);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        Com_serialnum com_serialnum=new Com_serialnum();
        com_serialnum.setType("foc");
        com_serialnum.setKey01(foc_express_h.getDept());
        com_serialnum.setKey02(foc_express_h.getDept());
        Com_serialnum foc_serialnum=iCom_serialnumService.find(com_serialnum);
        iCom_serialnumService.update(com_serialnum);
        System.out.println(foc_serialnum.getSerialnum());
        // 0 代表前面补充0 6代表长度为6 d 代表参数为正数型
        String t_express_no = foc_express_h.getDept()+String.format("%06d", foc_serialnum.getSerialnum());
        String username= (String) httpSession.getAttribute("username");
        String terminal_id="/foc_express_d/save";
        String dept=foc_express_h.getDept();
        String currency=foc_express_h.getCurrency();

        // update body
        int b = 0;
        int c = 0;

        Foc_express_d foc_express_d = new Foc_express_d();

        while (true) {
            for (String name1 : set) {
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                if(c>b) hashMap.put(name1, vals[b]);
            }

            try {
                BeanUtils.populate(foc_express_d, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //添加一个判断，如果为空值或者没有输入则不往数据库里插数据
            if (foc_express_d.getPrice_type().equals(null) || foc_express_d.getPrice_type().equals("")) {
                b++;
                if (b == c) break;
                continue;
            }

            // ****       状态 价格的判断来决定状态 需要审核15，正常为20
            Foc_price foc_price=new Foc_price();
            foc_price.setMrpcode(dept);
            foc_price.setType(foc_express_d.getPrice_type());
            foc_price.setCurrency(currency);
            Foc_price foc_price2=iFoc_priceService.findByMrpTypeCur(foc_price);
            foc_express_h.setExpress_status("15");
            if(foc_express_d.getPrice()>= foc_price2.getPrice_1_lower() && foc_express_d.getPrice()<foc_price2.getPrice_1_upper()){
                foc_express_h.setExpress_status("20");
            }

            foc_express_d.setExpress_no(t_express_no);
            foc_express_d.setSample_invoice(t_express_no);
            foc_express_d.setExpress_id(b+1);
            foc_express_d.setUpdate_oid(username);
//            foc_express_d.setUpdate_terminal_id(terminal_id);
            iFoc_express_dService.save(foc_express_d);
            b++;
            if (b == c) break;
        }
//        update head

        foc_express_h.setExpress_no(t_express_no);
        foc_express_h.setSample_invoice(t_express_no);
        foc_express_h.setUpdate_oid(username);
//        foc_express_h.setUpdate_terminal_id(terminal_id);

        //保存表头
        iFoc_express_hService.save(foc_express_h);
        return "redirect:findById.do";
    }

    @RequestMapping("/updateAll.do")
    public String updateAll(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception {
        //取出前端传回的所有数据
        Map map = request.getParameterMap();

        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();

        //head
        for (String name1 : set) {
            String[] vals = (String[]) map.get(name1);
            hashMap.put(name1, vals[0]);
        }
        Foc_express_h foc_express_h = new Foc_express_h();
        foc_express_h = iFoc_express_hService.findByExpress_no(hashMap.get("express_no"));
        try {
            BeanUtils.populate(foc_express_h, hashMap);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        String username= (String) httpSession.getAttribute("username");
        String terminal_id="/foc_express_d/save";

        // update body
        int b = 0;   //第几笔记录
        int c = 0;   //total

        while (true) {
            for (String name1 : set) {
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                if(c>b)  hashMap.put(name1, vals[b]);
            }
            Foc_express_d foc_express_d = new Foc_express_d();
            foc_express_d = iFoc_express_dService.findById(Integer.parseInt(hashMap.get("id")));

            try {
                BeanUtils.populate(foc_express_d, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //添加一个判断，如果为空值或者没有输入则不往数据库里插数据
            if (foc_express_d.getPrice_type().equals(null) || foc_express_d.getPrice_type().equals("")) {
                b++;
                if (b == c) break;
                continue;
            }
            //价格的判断

            foc_express_d.setUpdate_oid(username);
//            foc_express_d.setUpdate_terminal_id(terminal_id);
            iFoc_express_dService.update(foc_express_d);
            b++;
            if (b == c) break;
        }
//        update head
        foc_express_h.setUpdate_oid(username);
//        foc_express_h.setUpdate_terminal_id(terminal_id);
// ****       状态 价格的判断来决定状态 需要审核15，正常为20
        iFoc_express_hService.update(foc_express_h);
        return "redirect:findById.do";
    }
    @RequestMapping("/check.do")
    public void check(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception, IOException, JsonGenerationException, JsonMappingException {
        ResultInfo info = new ResultInfo();
        List<Foc_express_d> foc_express_ds = new ArrayList<Foc_express_d>();
        info.setFlag(true);
        List<String> errorList=new ArrayList<String>();
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();

        List<Integer> box_list_f = new ArrayList<>(); //记录有毛重的箱号
        List<Integer> box_list = new ArrayList<>(); //记录有毛重的箱号
        Set<String> set = map.keySet();

        //check head
        for (String name1 : set) {
            String[] vals = (String[]) map.get(name1);
            hashMap.put(name1, vals[0]);
        }
        Foc_express_h foc_express_h = new Foc_express_h();
        if(hashMap.containsKey("express_no")) {
            foc_express_h = iFoc_express_hService.findByExpress_no(hashMap.get("express_no"));
            if(foc_express_h.getExpress_no().equals("50")){
                info.setErrorMsg("物流已排载，如需要修改请联络物流");
                info.setFlag(false);
            }
        }
        try {
            BeanUtils.populate(foc_express_h, hashMap);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        //判断工号
        if(iCom_employeeService.findByEmployee_id(foc_express_h.getHandled_manual_id())==null){
            info.setErrorMsg("请输入7位的工号");
            errorList.add("handled_manual_id");
            info.setFlag(false);
        }
        //保税海外地区要有相应的货代

        if(foc_express_h.getBonded_logo().equals("Y") && foc_express_h.getOverseas().equals("1")){
//         List<Foc_dn_fee> foc_dn_fee=iFoc_dn_feeService.findByFreight_com_code(foc_express_h.getCountry());
            List<Foc_dn_fee> foc_dn_fee=iFoc_dn_feeService.findByAddress_en(foc_express_h.getCountry().trim().trim());
            if(foc_dn_fee.size()==0){
                info.setErrorMsg("保税海外地区要有相应的货代");
                errorList.add("country");
                info.setFlag(false);
            }
        }
        String dept=foc_express_h.getDept();
        String currency=foc_express_h.getCurrency();
        // check body
        int b = 0;   //第几笔记录
        int c = 0;   //total
        Double amt_total=0.00;  //发票总金额

        while (true) {
            hashMap.clear();
            for (String name1 : set) {
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                if(c>b)  hashMap.put(name1, vals[b]);
            }
            Foc_express_d foc_express_d = new Foc_express_d();
            if(hashMap.containsKey("id")) {
                foc_express_d = iFoc_express_dService.findById(Integer.parseInt(hashMap.get("id")));
            }
            try {
                BeanUtils.populate(foc_express_d, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //添加一个判断，如果为空值或者没有输入则不往数据库里插数据
            if (foc_express_d.getPrice_type().equals(null) || foc_express_d.getPrice_type().equals("")|| foc_express_d.getPrice_type()==null) {
                b++;
                if (b == c) break;
                continue;
            }
            String errLine= String.valueOf(b); //记录当前记录行
            //判断箱号合理性
            Integer box_from=foc_express_d.getBox_from();
            Integer box_to=foc_express_d.getBox_to();
            if(box_from>box_to){
                info.setErrorMsg("箱号输入有误");
                errorList.add("box_from"+ errLine);
                info.setFlag(false);
            }
            //from箱号与上一行to箱号比较，是否跳号
            if(box_list_f.size()>0) {
                Integer box_from_last=box_list_f.get(box_list_f.size() - 1);
                Integer box_to_last=box_list.get(box_list.size() - 1);
                if(box_from>box_to_last+1){
                    info.setErrorMsg("请输入连续的号码");
                    errorList.add("box_from"+ errLine);
                    info.setFlag(false);
                }else if(box_to_last>box_from_last && box_from==box_to_last){
                    info.setErrorMsg("输入的号码有误");
                    errorList.add("box_from"+ errLine);
                    info.setFlag(false);
                }
                else if(box_to>box_from && box_from==box_to_last){
                    info.setErrorMsg("输入的号码有误");
                    errorList.add("box_to"+ errLine);
                    info.setFlag(false);
                }
            }else if(box_from!=1){
                info.setErrorMsg("第一笔必须输入1");
                errorList.add("box_from"+ errLine);
                info.setFlag(false);
            }
            //记录最后一箱,并判断每一箱的第一行毛重有没有值
            if(!box_list.contains(box_to)){
                //判断每一箱是否都有毛重
                if(foc_express_d.getGross_weight()<=0){
                    info.setErrorMsg("请输入毛重");
                    errorList.add("gross_weight"+ errLine);
                    info.setFlag(false);
                }
                box_list_f.add(box_from);
                box_list.add(box_to);
            }

            //检查净重要大于等于0.001
            if(foc_express_d.getNet_weigh()<0.001){
                info.setErrorMsg("净重不能小于0.001");
                errorList.add("net_weigh"+ errLine);
                info.setFlag(false);
            }

            //检查价格分类是否存在
            Foc_price foc_price=new Foc_price();

            foc_price.setMrpcode(dept);
            foc_price.setType(foc_express_d.getPrice_type());
            foc_price.setCurrency(currency);

//            Foc_price foc_price2=iFoc_priceService.findByMrpTypeCur(foc_price);
            List<Foc_price> foc_prices=iFoc_priceService.findByMrpTypeCur2(foc_price);

            //价格的判断
            if(foc_prices.size()==0){
                info.setErrorMsg("价格分类不存在");
                errorList.add("price_type"+ errLine);
                info.setFlag(false);

            }else if(foc_prices.size()>1){
                info.setErrorMsg("存在重复的价格分类，请检查");
                errorList.add("price_type"+ errLine);
                info.setFlag(false);

            }
            else {
                String unit_db= foc_prices.get(0).getUnit();
                String unit_jsp= foc_express_d.getUnit().trim().trim();
                foc_express_d.setUnit(unit_jsp);
                if(!unit_db.equals("")){
                    if(unit_jsp.equals("")){
                        foc_express_d.setUnit(unit_db);
                    }else if(!unit_db.equals(unit_jsp)){
                        info.setErrorMsg("单位与主档不符，请修改");
                        errorList.add("unit"+ errLine);
                        info.setFlag(false);
                    }

                }else if(unit_jsp.equals("")){
                    info.setErrorMsg("单位不能为空，请输入");
                    errorList.add("unit"+ errLine);
                    info.setFlag(false);
                }

            }
//            //价格的判断
//            if(foc_price2==null){
//                info.setErrorMsg("价格分类不存在");
//                errorList.add("price_type"+ errLine);
//                info.setFlag(false);
//
//            }else {
//                foc_express_d.setUnit(foc_price2.getUnit());
//            }
//            计算金额
            DecimalFormat df = new DecimalFormat("#.00");
            Double amt=foc_express_d.getPrice()*foc_express_d.getQty();
            if(foc_express_h.getCurrency().equals("USD")) {
                amt_total += amt;
                if(amt_total>600){
                    info.setErrorMsg("总金额不能超出600美金");
                    errorList.add("amount"+ errLine);
                    info.setFlag(false);
                }
            }
            foc_express_d.setAmount(Double.valueOf(df.format(foc_express_d.getPrice()*foc_express_d.getQty())));
            foc_express_ds.add(foc_express_d);
            b++;
            if (b == c) break;
        }

        info.setErrorList(errorList);
        info.setData(foc_express_ds);
        //响应数据
        ObjectMapper mapper = new ObjectMapper();

        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(),info);
    }
    @RequestMapping("/updateOrSave.do")
    public void updateOrSave(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession,String updateType) throws Exception {
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();

        //get head data
        for (String name1 : set) {
            String[] vals = (String[]) map.get(name1);
            hashMap.put(name1, vals[0]);
        }
        Foc_express_h foc_express_h = new Foc_express_h();
        if(hashMap.containsKey("express_no")) {
            foc_express_h = iFoc_express_hService.findByExpress_no(hashMap.get("express_no"));
        }
        try {
            BeanUtils.populate(foc_express_h, hashMap);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        //处理工号 转为姓名
        Com_employee com_employee=iCom_employeeService.findByEmployee_id(foc_express_h.getHandled_manual_id());
        foc_express_h.setHandled_manual_name(com_employee.getMmdnam());
        String t_express_no="";
        if(updateType.equals("save")) {
//        取得流水号
            Com_serialnum com_serialnum = new Com_serialnum();
            com_serialnum.setType("foc");
            com_serialnum.setKey01(foc_express_h.getDept());
            com_serialnum.setKey02(foc_express_h.getDept());
            Com_serialnum foc_serialnum = iCom_serialnumService.find(com_serialnum);
            iCom_serialnumService.update(com_serialnum);
            System.out.println(foc_serialnum.getSerialnum());
            // 0 代表前面补充0 6代表长度为6 d 代表参数为正数型
            t_express_no = foc_express_h.getDept() + String.format("%06d", foc_serialnum.getSerialnum());
        }else {
            t_express_no=foc_express_h.getExpress_no();
        }

//
        String username= (String) httpSession.getAttribute("username");
        String dept=foc_express_h.getDept();
        String currency=foc_express_h.getCurrency();
        foc_express_h.setExpress_status("15");

        // update body
        int b = 0;   //当前是第几笔
        int c = 0;  //一共有多少笔记录
        int totalbox=0;

        while (true) {
            //按顺序取得一笔记录
            hashMap.clear();
            for (String name1 : set) {
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                if(c>b) hashMap.put(name1, vals[b]);
            }
            Foc_express_d foc_express_d = new Foc_express_d();
            //取得数据库中数据
            if(hashMap.containsKey("id")) {
                foc_express_d = iFoc_express_dService.findById(Integer.parseInt(hashMap.get("id")));
            }
            //将画面的值更新到对象
            try {
                BeanUtils.populate(foc_express_d, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //添加一个判断，如果为空值或者没有输入则不往数据库里插数据
            if (foc_express_d.getPrice_type().equals(null) || foc_express_d.getPrice_type().equals("")) {
                b++;
                if (b == c) break;
                continue;
            }

            // ****       状态 价格的判断来决定状态 需要审核15，正常为20
            Foc_price foc_price=new Foc_price();
            foc_price.setMrpcode(dept);
            foc_price.setType(foc_express_d.getPrice_type());
            foc_price.setCurrency(currency);
            Foc_price foc_price2=iFoc_priceService.findByMrpTypeCur(foc_price);


//            foc_express_d.setUnit(foc_price2.getUnit());
            if(foc_express_d.getPrice()>= foc_price2.getPrice_1_lower() && foc_express_d.getPrice()<=foc_price2.getPrice_1_upper()){
                foc_express_h.setExpress_status("20");
            }
            foc_express_d.setPrice_lower(foc_price2.getPrice_1_lower());
            foc_express_d.setPrice_upper(foc_price2.getPrice_1_upper());
//计算总件数
            if(totalbox<foc_express_d.getBox_to()) totalbox=foc_express_d.getBox_to();
//            计算金额
            DecimalFormat df = new DecimalFormat("#.00");
            foc_express_d.setAmount(Double.valueOf(df.format(foc_express_d.getPrice()*foc_express_d.getQty())));
//            调用更新程序
            foc_express_d.setUpdate_oid(username);
            foc_express_d.setUpdate_program("foc_express_d/updateOrSave");
//            if(updateType.equals("save")){
            if( foc_express_d.getId()==0){
                foc_express_d.setMaterial_descriable(foc_price2.getItem_descrip());
                foc_express_d.setMaterial_e_descriable(foc_price2.getItem_descrip_en());
                foc_express_d.setExpress_no(t_express_no);
                foc_express_d.setSample_invoice(t_express_no);
                foc_express_d.setExpress_id(b+1);
                foc_express_d.setLogin_oid(username);

                iFoc_express_dService.save(foc_express_d);
            }else{
                iFoc_express_dService.update(foc_express_d);
            };
//            读取下一笔
            b++;
            if (b == c) break;
        }
//        update head
        //保存表头
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String currentTime = sdf.format(new Date());
        foc_express_h.setUpdate_oid(username);
        foc_express_h.setUpdate_program("foc_express_d/updateOrSave");
        foc_express_h.setNumber(totalbox);
        foc_express_h.setCountry(foc_express_h.getCountry().trim().trim());

//        if(updateType.equals("save")){
        if(updateType.equals("save")){
            foc_express_h.setExpress_no(t_express_no);
            foc_express_h.setSample_invoice(t_express_no);
            foc_express_h.setLogin_oid(username);
            iFoc_express_hService.save(foc_express_h);
        }else{
            iFoc_express_hService.update(foc_express_h);
        }
        ResultInfo info = new ResultInfo();
        info.setData(t_express_no);
        //响应数据
        ObjectMapper mapper = new ObjectMapper();

        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(),info);

    }

    /**
     *@Description: 修改表体
     *@Author: a135109
     *@time: 2020/4/9 16:59
     */
    @RequestMapping("/update_invoice.do")
    public String update(HttpServletRequest request, HttpServletResponse response,HttpSession httpSession) throws Exception {
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        int b=0;
        int c=0;
        while (1==1){
            for(String name1 : set){
                String[] vals = (String[]) map.get(name1);
                c=vals.length;
                hashMap.put(name1,vals[b]);
            }
            Foc_express_d d = new Foc_express_d();
            System.out.println(hashMap.get("id"));
            int id1 = Integer.parseInt(hashMap.get("id"));
            d=iFoc_express_dService.findById(id1);
            try {
                BeanUtils.populate(d,hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            System.out.println(d.toString());
            String username= (String) httpSession.getAttribute("username");
            d.setUpdate_oid(username);
            d.setUpdate_program("/foc_express_d/update_iv");
            iFoc_express_dService.update(d);
            b++;
            if(b==c) break;
        }
        return "redirect:findByName.do";
    }

    /**
     *@Description: 通过快递单号查询表体
     *@Author: a135109
     *@time: 2020/4/23 16:27
     */
    @RequestMapping("/find_iv.do")
    public ModelAndView shutdown(String express_no) throws Exception{
        //通过no找到表体
        System.out.println(express_no+"-----------------------");
        List<Foc_express_d> ls = iFoc_express_dService.findByExpress_no(express_no);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("foc-invoice-body-list");
        mv.addObject("foc_express_d",ls);
        return mv;
    }

}






