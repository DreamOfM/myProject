package com.tdk.txm_java.domain;

import java.util.Date;
import java.util.List;


/**
 * 录入表头
 */

public class Foc_express_h {
    private int id;
    private String express_no;//快递单号码
    private String sample_invoice;//送样发票
    private String customer_name1;//客户名称1
    private String customer_name2;//客户名称2
    private String ship_address1;//送达地址 1
    private String ship_address2 ;//送达地址 2
    private String ship_address3;//送达地址 3
    private String zip_code;//邮政编码
    private String customer_phone;//客户电话
    private String recipient;//接受人
    private String country;//国家地区
    private String harrive_day;//希望抵达日
    private String name_operator;//经办人姓名
    private String dept;//部门
    private String packing_volume;//包装体积
    private int number;//件数
    private String currency;//币別
    private String shipping_signs;//出货标志
    private String note;//备注
    private String salesman_code;//营业员代码
    private String alternate_field;//备用栏位
    private String handled_manual_id;//经办人工号
    private String handled_manual_name;
    private String major_sip_no;//主要
    private String scheduled_ship_date;//计划出货日期;
    private String freight_com_code;//貨運公司代碼
    private String release_slip;//出场放行单
    private String express_status;//该快递单的状态
    private String document_last_time;
    private String free_logo;//无偿标志
    private String reason_code;//原因代码
    private String pack_material;//包装材质
    private String real_express;//实际快递单号
    private String express_company;//快递公司
    private String bonded_logo;//保税标志
    private String overseas;//海外
    private String premium;//保費
    private Double ship_cost;//运费
    private Double rate;//汇率
    private String terms_trade ;//贸易条件
    private String origin_country ;//原产国
    private String trading_country;//贸易国
    private String update_terminal_id;//更新终端机名称
    private String print_sign;//打印标志
    private String print_time;//打印时间
    private Date login_time;//登录时间
    private String login_oid;//登陆操作员代码
    private Date update_time;//更新时间
    private String update_oid;//更新操作员代码
    private String update_program;//更新程式名称
    private List<Foc_express_d> foc_express_ds;//标底信息
    private List<Foc_general_trade> foc_general_trade;//一般贸易信息
    private float qtyz;
    private float amountz;
    private float gross_weightz;

    public String getHandled_manual_name() {
        return handled_manual_name;
    }

    public void setHandled_manual_name(String handled_manual_name) {
        this.handled_manual_name = handled_manual_name;
    }

    public String getPrint_sign() {
        return print_sign;
    }

    public void setPrint_sign(String print_sign) {
        this.print_sign = print_sign;
    }

    public String getPrint_time() {
        return print_time;
    }

    public void setPrint_time(String print_time) {
        this.print_time = print_time;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getExpress_no() {
        return express_no;
    }

    public void setExpress_no(String express_no) {
        this.express_no = express_no;
    }

    public String getSample_invoice() {
        return sample_invoice;
    }

    public void setSample_invoice(String sample_invoice) {
        this.sample_invoice = sample_invoice;
    }

    public String getCustomer_name1() {
        return customer_name1;
    }

    public void setCustomer_name1(String customer_name1) {
        this.customer_name1 = customer_name1;
    }

    public String getCustomer_name2() {
        return customer_name2;
    }

    public void setCustomer_name2(String customer_name2) {
        this.customer_name2 = customer_name2;
    }

    public String getShip_address1() {
        return ship_address1;
    }

    public void setShip_address1(String ship_address1) {
        this.ship_address1 = ship_address1;
    }

    public String getShip_address2() {
        return ship_address2;
    }

    public void setShip_address2(String ship_address2) {
        this.ship_address2 = ship_address2;
    }

    public String getShip_address3() {
        return ship_address3;
    }

    public void setShip_address3(String ship_address3) {
        this.ship_address3 = ship_address3;
    }

    public String getZip_code() {
        return zip_code;
    }

    public void setZip_code(String zip_code) {
        this.zip_code = zip_code;
    }

    public String getCustomer_phone() {
        return customer_phone;
    }

    public void setCustomer_phone(String customer_phone) {
        this.customer_phone = customer_phone;
    }

    public String getRecipient() {
        return recipient;
    }

    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getHarrive_day() {
        return harrive_day;
    }

    public void setHarrive_day(String harrive_day) {
        this.harrive_day = harrive_day;
    }

    public String getName_operator() {
        return name_operator;
    }

    public void setName_operator(String name_operator) {
        this.name_operator = name_operator;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public String getPacking_volume() {
        return packing_volume;
    }

    public void setPacking_volume(String packing_volume) {
        this.packing_volume = packing_volume;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getShipping_signs() {
        return shipping_signs;
    }

    public void setShipping_signs(String shipping_signs) {
        this.shipping_signs = shipping_signs;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getSalesman_code() {
        return salesman_code;
    }

    public void setSalesman_code(String salesman_code) {
        this.salesman_code = salesman_code;
    }

    public String getAlternate_field() {
        return alternate_field;
    }

    public void setAlternate_field(String alternate_field) {
        this.alternate_field = alternate_field;
    }

    public String getHandled_manual_id() {
        return handled_manual_id;
    }

    public void setHandled_manual_id(String handled_manual_id) {
        this.handled_manual_id = handled_manual_id;
    }

    public String getMajor_sip_no() {
        return major_sip_no;
    }

    public void setMajor_sip_no(String major_sip_no) {
        this.major_sip_no = major_sip_no;
    }

    public String getScheduled_ship_date() {
        return scheduled_ship_date;
    }

    public void setScheduled_ship_date(String scheduled_ship_date) {
        this.scheduled_ship_date = scheduled_ship_date;
    }

    public String getFreight_com_code() {
        return freight_com_code;
    }

    public void setFreight_com_code(String freight_com_code) {
        this.freight_com_code = freight_com_code;
    }

    public String getRelease_slip() {
        return release_slip;
    }

    public void setRelease_slip(String release_slip) {
        this.release_slip = release_slip;
    }

    public String getExpress_status() {
        return express_status;
    }

    public void setExpress_status(String express_status) {
        this.express_status = express_status;
    }

    public String getFree_logo() {
        return free_logo;
    }

    public void setFree_logo(String free_logo) {
        this.free_logo = free_logo;
    }

    public String getReason_code() {
        return reason_code;
    }

    public void setReason_code(String reason_code) {
        this.reason_code = reason_code;
    }

    public String getPack_material() {
        return pack_material;
    }

    public void setPack_material(String pack_material) {
        this.pack_material = pack_material;
    }

    public String getReal_express() {
        return real_express;
    }

    public void setReal_express(String real_express) {
        this.real_express = real_express;
    }

    public String getExpress_company() {
        return express_company;
    }

    public void setExpress_company(String express_company) {
        this.express_company = express_company;
    }

    public String getBonded_logo() {
        return bonded_logo;
    }

    public void setBonded_logo(String bonded_logo) {
        this.bonded_logo = bonded_logo;
    }

    public String getOverseas() {
        return overseas;
    }

    public void setOverseas(String overseas) {
        this.overseas = overseas;
    }

    public String getPremium() {
        return premium;
    }

    public void setPremium(String premium) {
        this.premium = premium;
    }

    public Double getShip_cost() {
        return ship_cost;
    }

    public void setShip_cost(Double ship_cost) {
        this.ship_cost = ship_cost;
    }

    public Double getRate() {
        return rate;
    }

    public void setRate(Double rate) {
        this.rate = rate;
    }

    public String getTerms_trade() {
        return terms_trade;
    }

    public void setTerms_trade(String terms_trade) {
        this.terms_trade = terms_trade;
    }

    public String getOrigin_country() {
        return origin_country;
    }

    public void setOrigin_country(String origin_country) {
        this.origin_country = origin_country;
    }

    public String getTrading_country() {
        return trading_country;
    }

    public void setTrading_country(String trading_country) {
        this.trading_country = trading_country;
    }

    public String getUpdate_terminal_id() {
        return update_terminal_id;
    }

    public void setUpdate_terminal_id(String update_terminal_id) {
        this.update_terminal_id = update_terminal_id;
    }

    public Date getLogin_time() {
        return login_time;
    }

    public void setLogin_time(Date login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public Date getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(Date update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    public List<Foc_express_d> getFoc_express_ds() {
        return foc_express_ds;
    }

    public void setFoc_express_ds(List<Foc_express_d> foc_express_ds) {
        this.foc_express_ds = foc_express_ds;
    }

    public float getQtyz() {
        return qtyz;
    }

    public void setQtyz(float qtyz) {
        this.qtyz = qtyz;
    }

    public float getAmountz() {
        return amountz;
    }

    public void setAmountz(float amountz) {
        this.amountz = amountz;
    }

    public float getGross_weightz() {
        return gross_weightz;
    }

    public void setGross_weightz(float gross_weightz) {
        this.gross_weightz = gross_weightz;
    }

    public String getDocument_last_time() {
        return document_last_time;
    }

    public void setDocument_last_time(String document_last_time) {
        this.document_last_time = document_last_time;
    }

    public List<Foc_general_trade> getFoc_general_trade() {
        return foc_general_trade;
    }

    public void setFoc_general_trade(List<Foc_general_trade> foc_general_trade) {
        this.foc_general_trade = foc_general_trade;
    }

    @Override
    public String toString() {
        return "Foc_express_h{" +
                "id=" + id +
                ", express_no='" + express_no + '\'' +
                ", sample_invoice='" + sample_invoice + '\'' +
                ", customer_name1='" + customer_name1 + '\'' +
                ", customer_name2='" + customer_name2 + '\'' +
                ", ship_address1='" + ship_address1 + '\'' +
                ", ship_address2='" + ship_address2 + '\'' +
                ", ship_address3='" + ship_address3 + '\'' +
                ", zip_code='" + zip_code + '\'' +
                ", customer_phone='" + customer_phone + '\'' +
                ", recipient='" + recipient + '\'' +
                ", country='" + country + '\'' +
                ", harrive_day='" + harrive_day + '\'' +
                ", name_operator='" + name_operator + '\'' +
                ", dept='" + dept + '\'' +
                ", packing_volume='" + packing_volume + '\'' +
                ", number=" + number +
                ", currency='" + currency + '\'' +
                ", shipping_signs='" + shipping_signs + '\'' +
                ", note='" + note + '\'' +
                ", salesman_code='" + salesman_code + '\'' +
                ", alternate_field='" + alternate_field + '\'' +
                ", handled_manual_id='" + handled_manual_id + '\'' +
                ", major_sip_no='" + major_sip_no + '\'' +
                ", scheduled_ship_date='" + scheduled_ship_date + '\'' +
                ", freight_com_code='" + freight_com_code + '\'' +
                ", release_slip='" + release_slip + '\'' +
                ", express_status='" + express_status + '\'' +
                ", document_last_time='" + document_last_time + '\'' +
                ", free_logo='" + free_logo + '\'' +
                ", reason_code='" + reason_code + '\'' +
                ", pack_material='" + pack_material + '\'' +
                ", real_express='" + real_express + '\'' +
                ", express_company='" + express_company + '\'' +
                ", bonded_logo='" + bonded_logo + '\'' +
                ", overseas='" + overseas + '\'' +
                ", premium='" + premium + '\'' +
                ", ship_cost=" + ship_cost +
                ", rate=" + rate +
                ", terms_trade='" + terms_trade + '\'' +
                ", origin_country='" + origin_country + '\'' +
                ", trading_country='" + trading_country + '\'' +
                ", update_terminal_id='" + update_terminal_id + '\'' +
                ", print_sign='" + print_sign + '\'' +
                ", print_time='" + print_time + '\'' +
                ", login_time=" + login_time +
                ", login_oid='" + login_oid + '\'' +
                ", update_time=" + update_time +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                ", foc_express_ds=" + foc_express_ds +
                ", foc_general_trade=" + foc_general_trade +
                ", qtyz=" + qtyz +
                ", amountz=" + amountz +
                ", gross_weightz=" + gross_weightz +
                '}';
    }
}
