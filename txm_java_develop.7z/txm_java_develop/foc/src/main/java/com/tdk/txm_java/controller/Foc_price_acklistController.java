package com.tdk.txm_java.controller;

import com.tdk.txm_java.domain.Foc_express_d;
import com.tdk.txm_java.service.IFoc_express_dService;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Controller
@RequestMapping("/foc_price_acklist")
public class Foc_price_acklistController {
    @Autowired
    private IFoc_express_dService iFoc_express_dService;



    @RequestMapping("/findByExpress_no2")
    public ModelAndView findByExpress_no2(String express_no) throws Exception {
        System.out.println("555555");
        List<Foc_express_d>foc_price_acklist= iFoc_express_dService.findByExpress_no2(express_no);
        System.out.println(foc_price_acklist);
        ModelAndView mv=new ModelAndView();
        mv.setViewName("foc-price-ack");
        mv.addObject("foc_price_acklist",foc_price_acklist);
        return mv;
    }

    @RequestMapping("/save.do")
    public String save(Foc_express_d foc_express_d) throws Exception {
        iFoc_express_dService.save(foc_express_d);
        return "redirect:findByExpress_no.do";
    }
    @RequestMapping("/update2.do")
    public String update2(HttpServletRequest request, HttpServletResponse response) throws Exception {
        Map map = request.getParameterMap();
        Map<String, String> map2 = new HashMap<>();
        Set<String> set = map.keySet();
            System.out.println("eeeeeeeee");
            System.out.println(request);
            System.out.println(response);

        int b=0;
        int c=0;
        while (1==1){
            for(String name1 : set){
                String[] vals = (String[]) map.get(name1);
                c=vals.length;
                map2.put(name1,vals[b]);

            }
            Foc_express_d a = new Foc_express_d();
            try {
                BeanUtils.populate(a,map2);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            System.out.println(a.toString());
            iFoc_express_dService.update2(a);
            b++;
            if(b==c) break;
        }
        return "redirect:findByExpress_no2.do";
    }

}
