package com.tdk.txm_java.service;




import com.tdk.txm_java.domain.Foc_general_trade;

import java.util.List;

public interface IFoc_general_tradeService {
    List<Foc_general_trade> findAll() throws Exception;
    List<Foc_general_trade> findByIv(String invoice_no) throws Exception;
    void save(Foc_general_trade foc_general_trade) throws Exception;
    void update(Foc_general_trade foc_general_trade) throws Exception;
    void delete(int id) throws Exception;
}
