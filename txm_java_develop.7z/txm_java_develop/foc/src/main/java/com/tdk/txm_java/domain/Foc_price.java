package com.tdk.txm_java.domain;

public class Foc_price {
    private int id;
    private String mrpcode;
    private String type;
    private String effective_date;
    private String expiration_date;
    private String products_type;
    private double price_1_lower;
    private double price_1_upper;
    private String currency;
    private String unit;
    private String item_descrip;
    private String item_descrip_en;
    private String expiration_flag;
    private String login_time;
    private String login_oid;//登陆操作员代码
    private String update_time;
    private String update_oid;
    private String update_program;


      public Foc_price() {
    }

    public String getMrpcode() {
        return mrpcode;
    }

    public void setMrpcode(String mrpcode) {
        this.mrpcode = mrpcode;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getEffective_date() {
        return effective_date;
    }

    public void setEffective_date(String effective_date) {
        this.effective_date = effective_date;
    }

    public String getExpiration_date() {
        return expiration_date;
    }

    public void setExpiration_date(String expiration_date) {
        this.expiration_date = expiration_date;
    }

    public String getProducts_type() {
        return products_type;
    }

    public void setProducts_type(String products_type) {
        this.products_type = products_type;
    }

    public double getPrice_1_lower() {
        return price_1_lower;
    }

    public void setPrice_1_lower(double price_1_lower) {
        this.price_1_lower = price_1_lower;
    }

    public double getPrice_1_upper() {
        return price_1_upper;
    }

    public void setPrice_1_upper(double price_1_upper) {
        this.price_1_upper = price_1_upper;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getItem_descrip() {
        return item_descrip;
    }

    public void setItem_descrip(String item_descrip) {
        this.item_descrip = item_descrip;
    }

    public String getItem_descrip_en() {
        return item_descrip_en;
    }

    public void setItem_descrip_en(String item_descrip_en) {
        this.item_descrip_en = item_descrip_en;
    }

    public String getExpiration_flag() {
        return expiration_flag;
    }

    public void setExpiration_flag(String expiration_flag) {
        this.expiration_flag = expiration_flag;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Foc_price{" +
                "id=" + id +
                ", mrpcode='" + mrpcode + '\'' +
                ", type='" + type + '\'' +
                ", effective_date='" + effective_date + '\'' +
                ", expiration_date='" + expiration_date + '\'' +
                ", products_type='" + products_type + '\'' +
                ", price_1_lower=" + price_1_lower +
                ", price_1_upper=" + price_1_upper +
                ", currency='" + currency + '\'' +
                ", unit='" + unit + '\'' +
                ", item_descrip='" + item_descrip + '\'' +
                ", item_descrip_en='" + item_descrip_en + '\'' +
                ", expiration_flag='" + expiration_flag + '\'' +
                ", login_time='" + login_time + '\'' +
                ", login_oid='" + login_oid + '\'' +
                ", update_time='" + update_time + '\'' +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                '}';
    }
}

