package com.tdk.txm_java.dao;


import com.tdk.txm_java.domain.Foc_express_h;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IFoc_express_hDao {
    /**
     * 根据快递单号查询信息
     * @return
     * @throws Exception
     */
    @Select("select * from foc_express_h where express_no=#{express_no}")
    Foc_express_h findByExpress_no(String express_no) throws Exception;

    /**
     * 新增信息
     * @param foc_express_h
     * @throws Exception
     */
    @Insert("insert into  foc_express_h(express_no, sample_invoice, customer_name1,customer_name2 ," +
            "ship_address1 ,ship_address2 ,ship_address3 ,zip_code ,customer_phone ,recipient ,country ," +
            "harrive_day ,name_operator ,dept ,packing_volume ,number ,currency ,shipping_signs ,note ," +
            "salesman_code ,alternate_field ,handled_manual_id,handled_manual_name,major_sip_no,scheduled_ship_date,freight_com_code," +
            "release_slip,express_status,free_logo," +
            "reason_code ,pack_material ,real_express ,express_company ,bonded_logo ,overseas ,premium ,ship_cost," +
            "rate,terms_trade,origin_country,trading_country,login_time,login_oid,update_program) values(#{express_no}," +
            "#{sample_invoice},#{customer_name1},#{customer_name2}, #{ship_address1}, " +
            "#{ship_address2},#{ship_address3},#{zip_code},  " +
            "#{customer_phone},#{recipient},#{country},#{harrive_day},#{name_operator},  " +
            "#{dept},#{packing_volume},#{number},#{currency},  " +
            "#{shipping_signs},#{note},#{salesman_code},  " +
            "#{alternate_field},#{handled_manual_id},#{handled_manual_name},#{major_sip_no},  " +
            "#{scheduled_ship_date},#{freight_com_code},  " +
            "#{release_slip},#{express_status},#{free_logo},  " +
            "#{reason_code},#{pack_material},  " +
            "#{real_express},#{express_company},#{bonded_logo},  " +
            "#{overseas},#{premium},#{ship_cost},#{rate},  " +
            "#{terms_trade},#{origin_country},  " +
            "#{trading_country},now(),#{login_oid},#{update_program} )")
    void save(Foc_express_h foc_express_h) throws Exception;

    @Insert("insert into  foc_express_h(express_no, sample_invoice, customer_name1,customer_name2 ," +
            "ship_address1 ,ship_address2 ,ship_address3 ,zip_code ,customer_phone ,recipient ,country ," +
            " name_operator ,dept ,packing_volume ,number ,currency ,shipping_signs ,note ," +
            "salesman_code ,alternate_field ,handled_manual_id,handled_manual_name,major_sip_no,scheduled_ship_date,freight_com_code," +
            "release_slip,express_status,free_logo," +
            "reason_code ,pack_material ,real_express ,express_company ,bonded_logo ,overseas ,premium ,ship_cost," +
            "rate,terms_trade,origin_country,trading_country,login_time,login_oid) values(#{express_no}," +
            "#{sample_invoice},#{customer_name1},#{customer_name2}, #{ship_address1}, " +
            "#{ship_address2},#{ship_address3},#{zip_code},  " +
            "#{customer_phone},#{recipient},#{country},#{name_operator},  " +
            "#{dept},#{packing_volume},#{number},#{currency},  " +
            "#{shipping_signs},#{note},#{salesman_code},  " +
            "#{alternate_field},#{handled_manual_id},#{handled_manual_name},#{major_sip_no},  " +
            "#{scheduled_ship_date},#{freight_com_code},  " +
            "#{release_slip},#{express_status},#{free_logo},  " +
            "#{reason_code},#{pack_material},  " +
            "#{real_express},#{express_company},#{bonded_logo},  " +
            "#{overseas},#{premium},#{ship_cost},#{rate},  " +
            "#{terms_trade},#{origin_country},  " +
            "#{trading_country},now(),#{login_oid})")
    void saveNoHarrive_day(Foc_express_h foc_express_h) throws Exception;
    /**
     * 修改信息
     * @param foc_express_h
     */
    @Update("update foc_express_h set   express_no=#{express_no}, sample_invoice=#{sample_invoice}, customer_name1=#{customer_name1}, customer_name2=#{customer_name2}, ship_address1=#{ship_address1}, ship_address2=#{ship_address2}, ship_address3=#{ship_address3}, zip_code=#{zip_code}, customer_phone=#{customer_phone}, recipient=#{recipient}, country=#{country}, harrive_day=#{harrive_day}, name_operator=#{name_operator}, dept=#{dept}, packing_volume=#{packing_volume}, number=#{number}, currency=#{currency}, shipping_signs=#{shipping_signs}, note=#{note}, salesman_code=#{salesman_code}, alternate_field=#{alternate_field}, handled_manual_id=#{handled_manual_id}, major_sip_no=#{major_sip_no}, scheduled_ship_date=#{scheduled_ship_date}, freight_com_code=#{freight_com_code}, release_slip=#{release_slip}, express_status=#{express_status}, free_logo=#{free_logo}, reason_code=#{reason_code}, pack_material=#{pack_material}, real_express=#{real_express}, express_company=#{express_company}, bonded_logo=#{bonded_logo}, overseas=#{overseas}, premium=#{premium}, ship_cost=#{ship_cost}, rate=#{rate}, terms_trade=#{terms_trade}, origin_country=#{origin_country}, trading_country=#{trading_country},   update_oid=#{update_oid}, update_program=#{update_program},print_sign=#{print_sign},print_time=#{print_time} " +
            "  where express_no =#{express_no}")
    void update(Foc_express_h foc_express_h);

    @Update("update foc_express_h set   express_no=#{express_no}, sample_invoice=#{sample_invoice}, customer_name1=#{customer_name1}, customer_name2=#{customer_name2}, ship_address1=#{ship_address1}, ship_address2=#{ship_address2}, ship_address3=#{ship_address3}, zip_code=#{zip_code}, customer_phone=#{customer_phone}, recipient=#{recipient}, country=#{country}, name_operator=#{name_operator}, dept=#{dept}, packing_volume=#{packing_volume}, number=#{number}, currency=#{currency}, shipping_signs=#{shipping_signs}, note=#{note}, salesman_code=#{salesman_code}, alternate_field=#{alternate_field}, handled_manual_id=#{handled_manual_id}, handled_manual_name=#{handled_manual_name}, major_sip_no=#{major_sip_no}, scheduled_ship_date=#{scheduled_ship_date}, freight_com_code=#{freight_com_code}, release_slip=#{release_slip}, express_status=#{express_status}, free_logo=#{free_logo}, reason_code=#{reason_code}, pack_material=#{pack_material}, real_express=#{real_express}, express_company=#{express_company}, bonded_logo=#{bonded_logo}, overseas=#{overseas}, premium=#{premium}, ship_cost=#{ship_cost}, rate=#{rate}, terms_trade=#{terms_trade}, origin_country=#{origin_country}, trading_country=#{trading_country},   update_oid=#{update_oid}, update_program=#{update_program} " +
            " where express_no =#{express_no}")
    void updateNoHarrive_day(Foc_express_h foc_express_h);
    /*
     *2019.10.30  Haowen Tan
     *条件查找快运单表头
     * 多表操作
     */
    @Select("select * from foc_express_h where " +
            " (express_no between #{express_no} and #{express_no_2}) " +
            " and (scheduled_ship_date between #{scheduled_ship_date} and #{scheduled_ship_date_2}) " +
            " and freight_com_code=#{freight_com_code}" +
            "order by express_no asc")
    @Results({
            @Result(id = true, property = "express_no", column = "express_no"),
            @Result(property = "recipient", column = "recipient"), //接收人
            @Result(property = "zip_code", column = "zip_code"), //邮政编码
            @Result(property = "customer_phone", column = "customer_phone"),//客户电话
            @Result(property = "customer_name1", column = "customer_name1"),//顾客名
            @Result(property = "foc_express_ds",column = "foc_express_ds",javaType = List.class,many = @Many(select = "com.tdk.txm_java.dao.IFoc_express_dDao.findByExpress_no"))
    })
    public List<Foc_express_h> findByNo(@Param("express_no") String express_no, @Param("express_no_2") String express_no_2, @Param("scheduled_ship_date") String scheduled_ship_date, @Param("scheduled_ship_date_2") String scheduled_ship_date_2, @Param("freight_com_code") String freight_com_code) throws Exception;


    @Select("select * from foc_express_h where express_no=#{express_no}  and express_status='15'")
    Foc_express_h findByExpress_no2(String express_no) throws Exception;


    /*
     *按出货日期查找
     * 多表操作
     */
//    @Select("select * from foc_express_h where scheduled_ship_date>=#{scheduled_ship_date} and scheduled_ship_date<=#{scheduled_ship_date_2} and dept like #{dept}")
    @Select("select * from foc_express_h where scheduled_ship_date>=#{scheduled_ship_date} and scheduled_ship_date<=#{scheduled_ship_date_2} and express_status>'15' order by dept,scheduled_ship_date ")

    @Results({
            @Result(id = true,property = "express_no", column = "express_no"), //发票号
            @Result(property = "scheduled_ship_date", column = "scheduled_ship_date"),
            @Result(property = "freight_com_code", column = "freight_com_code"), //货运公司代码
            @Result(property = "customer_name1", column = "customer_name1"),//顾客名
            @Result(property = "ship_address1", column = "ship_address1"),//送货地址
            @Result(property = "packing_volumn", column = "packing_volumn"),//体积
            @Result(property = "country", column = "country"),//国家
            @Result(property = "currency", column = "currency"),//币别
            @Result(property = "qtyz",column = "express_no",javaType =Float.class,one =@One(select = "com.tdk.txm_java.dao.IFoc_express_dDao.calculateqty")),
            @Result(property = "amountz",column = "express_no",javaType =Float.class,one = @One(select = "com.tdk.txm_java.dao.IFoc_express_dDao.calculateamount")),
            @Result(property = "gross_weightz",column = "express_no",javaType =Float.class,one = @One(select = "com.tdk.txm_java.dao.IFoc_express_dDao.calculategross_weight"))
    })

    public List<Foc_express_h> findByScheduled_ship_date(@Param("scheduled_ship_date") String scheduled_ship_date, @Param("scheduled_ship_date_2") String scheduled_ship_date_2, @Param("dept") String dept) throws Exception;

    @Select("select * from foc_express_h where id=#{id}")
    public Foc_express_h findById(int id) throws Exception;
	
	
    /**
     * Haowen Tan
     * 更新真实快递信息
     */
    @Update("update foc_express_h set real_express=#{real_express},express_company=#{express_company}, update_oid=#{update_oid},update_program=#{update_program} where express_no in (select express_no from foc_upload where express_no=#{express_no}) ")
    void update2(Foc_express_h foc_express_h);

    @Update("update foc_express_h set express_status=#{express_status}, update_oid=#{update_oid},update_program=#{update_program} where express_no =#{express_no} ")
    void updateStatus(Foc_express_h foc_express_h);

    @Select("select * from foc_express_h where #{sql_val}")

    @Results({
            @Result(id = true,property = "express_no", column = "express_no"), //发票号
            @Result(property = "scheduled_ship_date", column = "scheduled_ship_date"),
            @Result(property = "freight_com_code", column = "freight_com_code"), //货运公司代码
            @Result(property = "customer_name1", column = "customer_name1"),//顾客名
            @Result(property = "ship_address1", column = "ship_address1"),//送货地址
            @Result(property = "packing_volumn", column = "packing_volumn"),//体积
            @Result(property = "country", column = "country"),//国家
            @Result(property = "currency", column = "currency"),//币别
            @Result(property = "qtyz",column = "express_no",javaType =Float.class,one =@One(select = "com.tdk.txm_java.dao.IFoc_express_dDao.calculateqty")),
            @Result(property = "amountz",column = "express_no",javaType =Float.class,one = @One(select = "com.tdk.txm_java.dao.IFoc_express_dDao.calculateamount")),
            @Result(property = "gross_weightz",column = "express_no",javaType =Float.class,one = @One(select = "com.tdk.txm_java.dao.IFoc_express_dDao.calculategross_weight")),
            @Result(property = "foc_express_ds",column = "foc_express_ds",javaType = List.class,many = @Many(select = "com.tdk.txm_java.dao.IFoc_express_dDao.findByExpress_no"))
    })
    public List<Foc_express_h> findBySql(String sql_val)throws Exception;


    @Select("select * from foc_express_h where " +
            " express_no between (case #{express_no} when '' then express_no else #{express_no} end) and (case #{express_no_2} when '' then express_no else #{express_no_2} end) " +
            " and scheduled_ship_date between (case #{scheduled_ship_date} when '' then scheduled_ship_date else #{scheduled_ship_date} end) and (case #{scheduled_ship_date_2} when '' then scheduled_ship_date else #{scheduled_ship_date_2} end) " +
            " and freight_com_code = (case #{freight_com_code} when '' then freight_com_code else #{freight_com_code} end) " +
            " and overseas = (case #{overseas} when '' then overseas else #{overseas} end) " +
            " and bonded_logo = (case #{bonded_logo} when '' then bonded_logo else #{bonded_logo} end )" +
            "and express_status>'10'"+
            "order by express_no asc")
    public List<Foc_express_h> findByNo_iv(@Param("express_no") String express_no, @Param("express_no_2") String express_no_2, @Param("scheduled_ship_date") String scheduled_ship_date, @Param("scheduled_ship_date_2") String scheduled_ship_date_2, @Param("freight_com_code") String freight_com_code, @Param("overseas") String overseas, @Param("bonded_logo") String bonded_logo) throws Exception;

    @Select("select * from foc_express_h where " +
            "scheduled_ship_date between (case #{scheduled_ship_date} when '' then scheduled_ship_date else #{scheduled_ship_date} end) and (case #{scheduled_ship_date_2} when '' then scheduled_ship_date else #{scheduled_ship_date_2} end) " +
            " and freight_com_code = (case #{freight_com_code} when '' then freight_com_code else #{freight_com_code} end) " +
            " and dept = (case #{dept} when '' then dept else #{dept} end) " +
            " and handled_manual_id = (case #{handled_manual_id} when '' then handled_manual_id else #{handled_manual_id} end )" +
            "and express_status>'10'"+
            "order by express_no asc")
    public List<Foc_express_h> findByQuery(@Param("scheduled_ship_date") String scheduled_ship_date, @Param("scheduled_ship_date_2") String scheduled_ship_date_2, @Param("freight_com_code") String freight_com_code, @Param("dept") String dept, @Param("handled_manual_id") String handled_manual_id) throws Exception;


    @Select("select * from foc_express_h where scheduled_ship_date>=#{date_from} and scheduled_ship_date<=#{date_to} and overseas='1' and bonded_logo='Y' ")
    List<Foc_express_h> findByship_date(@Param("date_from") String date_from,@Param("date_to") String date_to) throws Exception;

    @Select("select real_express,sum(number) number from foc_express_h where real_expres#{real_express} group by real_express ")
    public Foc_express_h findByReal_exp(String real_express) throws Exception;

}





