package com.tdk.txm_java.service.impl;


import com.tdk.txm_java.dao.IFoc_priceDao;
import com.tdk.txm_java.domain.Foc_price;

import com.tdk.txm_java.service.IFoc_priceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class Foc_priceServiceImpl implements IFoc_priceService {

    @Autowired
    private IFoc_priceDao foc_priceDao;


    public List<Foc_price> findByMrpType(String mrpcode,String type) throws Exception {
        return foc_priceDao.findByMrpType(mrpcode, type);
    }

    public List<Foc_price> findByMrpTypeGt(String mrpcode,String type) throws Exception {
        return foc_priceDao.findByMrpTypeGt(mrpcode, type);
    }
    public List<Foc_price> findByMrp(String mrpcode) throws Exception {
        return foc_priceDao.findByMrp(mrpcode);
    }


    @Override
    public List<Foc_price> findAll() throws Exception {
        return foc_priceDao.findAll();
    }

    @Override
    public Foc_price findByMrpTypeCur(Foc_price foc_price) throws Exception {
        return foc_priceDao.findByMrpTypeCur(foc_price);
    }
    @Override
    public List<Foc_price> findByMrpTypeCur2(Foc_price foc_price) throws Exception {
        return foc_priceDao.findByMrpTypeCur2(foc_price);
    }

    @Override
    public Foc_price findById(int id) throws Exception {
        return foc_priceDao.findById(id);
    }

    @Override
    public void save(Foc_price foc_price) throws Exception {

        List<Foc_price> foc_prices=foc_priceDao.findByMrpType(foc_price.getMrpcode(),foc_price.getType());
        if(foc_prices.size()>0){
            foc_price.setUnit(foc_prices.get(0).getUnit());
            foc_price.setItem_descrip(foc_prices.get(0).getItem_descrip());
            foc_price.setItem_descrip_en(foc_prices.get(0).getItem_descrip_en());
        }
        foc_priceDao.save(foc_price);
    }

    @Override
    public void update(Foc_price foc_price) throws Exception {
        foc_priceDao.update(foc_price);
    }

    @Override
    public void detele(int id) throws Exception {
        foc_priceDao.delete(id);
    }


}
