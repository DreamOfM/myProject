package com.tdk.txm_java.dao;


import com.tdk.txm_java.domain.Foc_dn_fee;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface IFoc_dn_feeDao {

    @Select("select * from foc_dn_fee where id=#{id}")
    public Foc_dn_fee findById(int id) throws Exception;


    @Select("select freight_com_code from foc_dn_fee group by freight_com_code")
    public List<String> findFreight_com_code() throws Exception;

    @Select("select * from foc_dn_fee where address_en=#{address_en}")
    public List<Foc_dn_fee> findByAddress_en(String address_en) throws Exception;

    /**
     * 新增信息
     *
     * @param foc_dn_fee
     * @throws Exception
     */
    @Insert({"insert into foc_dn_fee(freight_com_code,freight_com_name,address_cn,address_en,weight,weight0,price0,weight1,price1,per_weight1,weight2,price2,per_weight2,weight3,price3,per_weight3,weight4,price4,per_weight4,weight5,price5,per_weight5,weight6,price6,per_weight6,weight7,price7,per_weight7,weight8,price8,per_weight8,alternate_field,login_time,login_oid,update_oid,update_program" +
            " values (#{freight_com_code},#{freight_com_name},#{address_cn},#{address_en},#{weight},#{weight0},#{price0},#{weight1},#{price1},#{per_weight1},#{weight2},#{price2},#{per_weight2},#{weight3},#{price3},#{per_weight3},#{weight4},#{price4},#{per_weight4},#{weight5},#{price5},#{per_weight5},#{weight6},#{price6},#{per_weight6},#{weight7},#{price7},#{per_weight7},#{weight8},#{price8},#{per_weight8},#{alternate_field},#{login_time},#{login_oid},#{update_oid},#{update_program}" +
            " now(),#{update_oid},now(),#{update_oid},#{update_program})"})
    void save(Foc_dn_fee foc_dn_fee) throws Exception;

    /**
     * 根据快递单号查询信息
     *
     * @return
     * @throws Exception
     */
    @Select("select * from foc_dn_fee where freight_com_code=#{freight_com_code}")
    public List<Foc_dn_fee> findByFreight_com_code(String freight_com_code) throws Exception;

    /**
     * 修改信息
     *
     * @param foc_dn_fee
     */
    @Update("update foc_dn_fee set " +
            "id=#{id}, freight_com_code=#{freight_com_code}, freight_com_name=#{freight_com_name}, address_cn=#{address_cn}, address_en=#{address_en}, weight=#{weight}, weight0=#{weight0}, price0=#{price0}, weight1=#{weight1}, price1=#{price1}, per_weight1=#{per_weight1}, weight2=#{weight2}, price2=#{price2}, per_weight2=#{per_weight2}, weight3=#{weight3}, price3=#{price3}, per_weight3=#{per_weight3}, weight4=#{weight4}, price4=#{price4}, per_weight4=#{per_weight4}, weight5=#{weight5}, price5=#{price5}, per_weight5=#{per_weight5}, weight6=#{weight6}, price6=#{price6}, per_weight6=#{per_weight6}, weight7=#{weight7}, price7=#{price7}, per_weight7=#{per_weight7}, weight8=#{weight8}, price8=#{price8}, per_weight8=#{per_weight8}, alternate_field=#{alternate_field}, " +
            " update_oid=#{update_oid},update_program=#{update_program}  where id=#{id}")
    void update(Foc_dn_fee foc_dn_fee);

    /**
     * 删除信息
     *
     * @param id
     */
    @Delete("delete from foc_dn_fee where id=#{id}")
    void deleteById(int id);


}
