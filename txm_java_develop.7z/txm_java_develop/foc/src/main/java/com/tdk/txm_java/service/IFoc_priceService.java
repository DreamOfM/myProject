package com.tdk.txm_java.service;

import com.tdk.txm_java.domain.Foc_price;

import java.util.List;
import java.util.Map;

public interface IFoc_priceService {
    public List<Foc_price> findByMrpType(String mrpcode, String type) throws Exception;
    public List<Foc_price> findByMrpTypeGt(String mrpcode, String type) throws Exception;
    public List<Foc_price> findByMrp(String mrpcode) throws Exception;

    public List<Foc_price> findAll() throws Exception;

    public Foc_price findByMrpTypeCur(Foc_price foc_price) throws Exception;
    public List<Foc_price> findByMrpTypeCur2(Foc_price foc_price) throws Exception;

    public Foc_price findById(int id) throws Exception;

    void save(Foc_price foc_price) throws Exception;


    void update(Foc_price foc_price) throws Exception;

    void detele(int id) throws Exception;


}
