package com.tdk.txm_java.dao2;

import com.tdk.txm_java.domain.Foc_release_d;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IFoc_Release_d2Dao {

    @Select("select * from wavedbf.xwldp ")
    List<Foc_release_d> findAll();
    @Select(" select * from wavedbf.xwldp where LDDCNO=#{LDDCNO} ")
    List<Foc_release_d> findByRelease(String LDDCNO);
}
