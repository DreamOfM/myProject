package com.tdk.txm_java.service;

import com.tdk.txm_java.domain.Foc_release;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public interface IFoc_releaseService {


    Foc_release findByRelease(String release) throws Exception;

   }
