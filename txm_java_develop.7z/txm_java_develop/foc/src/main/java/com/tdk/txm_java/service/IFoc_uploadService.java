package com.tdk.txm_java.service;

import com.tdk.txm_java.domain.Foc_upload;

import java.util.List;

public interface IFoc_uploadService {

    /**
    *@Description: 查询全部
    *@Author: a135109
    *@time: 2019/11/6 10:32
    */
    public List<Foc_upload> findAll() throws Exception;

    /**
    *@Description: 通过express_no查询
    *@Author: a135109
    *@time: 2019/11/6 10:32
    */
    public List<Foc_upload> findByExpress_no(String express_no) throws Exception;

    /**
     *@Description: 通过id查询
     *@Author: a135109
     *@time: 2019/11/6 10:33
     */
    Foc_upload findById(int id);

    /**
     *@Description: 查找快递单号
     *@Author: a135109
     *@time: 2019/11/6 10:33
     */
    Foc_upload queryByExpress_no(Foc_upload foc_upload);

    /**
     *@Description: 上载数据
     *@Author: a135109
     *@time: 2019/11/6 10:32
     */
    void save(Foc_upload foc_upload) throws Exception;

    /**
    *@Description: 删除
    *@Author: a135109
    *@time: 2019/11/6 10:32
    */
    void delete(int id) throws Exception;

    /**
    *@Description: 确认
    *@Author: a135109
    *@time: 2019/11/6 10:32
    */
    void update(String express_no) throws Exception;
}
