package com.tdk.txm_java.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tdk.txm_java.domain.Foc_general_trade;
import com.tdk.txm_java.domain.ResultInfo;
import com.tdk.txm_java.service.IFoc_general_tradeService;
import com.tdk.txm_java.utils.ExcelUtils;
import com.tdk.txm_java.utils.UploadUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

/**
*@Description: 一般贸易条件
*@Author: a135109
*@time: 2020/5/13 11:54
*/

@Controller
@RequestMapping("/foc_general_trade")
public class Foc_general_tradeController {

    @Autowired
    private IFoc_general_tradeService foc_general_tradeService;

    /**
    *@Description: 上载数据
    *@Author: a135109
    *@time: 2020/5/13 11:57
    */
    @RequestMapping("/upload.do")
    public ModelAndView upload(MultipartFile imgFile, HttpServletRequest request) throws Exception{
        UploadUtils uploadUtils = new UploadUtils();
        String filePath = uploadUtils.upload(imgFile,request);
        //导入LoadExcle方法
        String columns[] = {"declare_date","declaration_no","declare_port","list_no","invoice_no","terms_trade"};
        //创建对象
        Foc_general_trade foc_general_trade = new Foc_general_trade();
        //从Excel获取数据列表
        List<Map<String, Object>> list =  ExcelUtils.LoadExcle(filePath,columns);
        //创建新的对象列表
        List<Foc_general_trade> ls = new ArrayList<>();
        //将map转为对象，并存到对象list
        for (Map ma: list) {
            foc_general_trade = ExcelUtils.mapToBean(ma, Foc_general_trade.class);
            //判断行是否为空
            if (!foc_general_trade.getInvoice_no().equals("")){
                String[] iv = foc_general_trade.getInvoice_no().split(",");
                for (int i = 0;i<iv.length;i++){
                    //分割后新建的对象
                    Foc_general_trade fs = new Foc_general_trade();
                    //对象复制
                    BeanUtils.copyProperties(fs,foc_general_trade);
                    fs.setInvoice_no(iv[i]);
                    ls.add(fs);
                }
            }
        }
        ModelAndView mv = new ModelAndView();
        mv.setViewName("foc-general-trade-upload");
        mv.addObject("foc_general_trade",ls);
        return mv;
    }

    /**
    *@Description: 检查上载的数据
    *@Author: a135109
    *@time: 2020/5/19 10:29
    */
    @RequestMapping("/check.do")
    public void check(HttpServletRequest request,HttpServletResponse response) throws Exception{
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        info.setFlag(true);
        List<String> errorList=new ArrayList<String>();
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        Foc_general_trade foc_general_trade = new Foc_general_trade();
        while (1 == 1) {
            for (String name : set) {
                String[] vals = (String[]) map.get(name);
                c = vals.length;
                hashMap.put(name, vals[b]);
            }
            try {
                BeanUtils.populate(foc_general_trade, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            String invoice_no = foc_general_trade.getInvoice_no();
            List<Foc_general_trade> fg = foc_general_tradeService.findByIv(invoice_no);
            if (!fg.isEmpty()) {
                info.setFlag(false);
                String errLine = String.valueOf(b);
                errorList.add("invoice_no" + errLine);
                info.setErrorMsg("发票存在");
            }
            b++;
            if (b == c) break;
        }
        info.setErrorList(errorList);
        info.getErrorMsg();
        // 响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(),info);
    }

    /**
    *@Description: 保存上载数据
    *@Author: a135109
    *@time: 2020/5/14 13:20
    */
    @RequestMapping("/save.do")
    public void save(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception {
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        List<String> errorList=new ArrayList<String>();
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        Foc_general_trade foc_general_trade = new Foc_general_trade();
        while (1 == 1) {
            for (String name : set) {
                String[] vals = (String[]) map.get(name);
                c = vals.length;
                hashMap.put(name, vals[b]);
            }
            try {
                BeanUtils.populate(foc_general_trade, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //添加一个判断，如果为空值或者没有输入则不往数据库里插数据
            if (foc_general_trade.getDeclaration_no().equals(null) || foc_general_trade.getDeclaration_no().equals("")) {
                b++;
                if (b == c) break;
                continue;
            }
            String username= (String) httpSession.getAttribute("username");
            foc_general_trade.setUpdate_oid(username);
            foc_general_trade.setUpdate_program("/foc_general_trade/save.do");
            foc_general_trade.setLogin_oid(username);
            foc_general_tradeService.save(foc_general_trade);
            b++;
            if (b == c) break;
        }
    }
}
