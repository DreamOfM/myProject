package com.tdk.txm_java.dao;


import com.tdk.txm_java.domain.Foc_express_d;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface IFoc_express_dDao {

    @Select("select * from foc_express_d where id=#{id}")
    public Foc_express_d findById(int id) throws Exception;

    @Select("select  max(express_id)   from foc_express_d where express_no=#{express_no} ")
    public int findMaxId(String express_no) throws Exception;

    /**
     * 新增信息
     *
     * @param foc_express_d
     * @throws Exception
     */
    @Insert({"insert into foc_express_d(express_no,express_id,sample_invoice,material_descriable," +
            "material_specif,material_e_descriable," +
            "unit,sips_no,price_type,confirm_no,confirm_id," +
            "confirm_name,price_modi_conf,qty,price,amount," +
            "price_lower,price_upper,net_weigh,gross_weight," +
            "box_from,box_to,login_time,login_oid,update_program)" +
            " values (#{express_no},#{express_id},#{sample_invoice}," +
            "#{material_descriable}, #{material_specif}," +
            "#{material_e_descriable}," +
            "#{unit}, #{sips_no}, #{price_type}," +
            "#{confirm_no}, #{confirm_id}, #{confirm_name}," +
            "'',#{qty},#{price}," +
            "#{amount},#{price_lower}," +
            "#{price_upper},#{net_weigh}, " +
            "#{gross_weight},#{box_from},#{box_to}, now()," +
            "#{login_oid},#{update_program})"})
    void save(Foc_express_d foc_express_d) throws Exception;

    /**
     * 根据快递单号查询信息
     *
     * @return
     * @throws Exception
     */
    @Select("select * from foc_express_d where express_no=#{express_no}")
    public List<Foc_express_d> findByExpress_no(String express_no) throws Exception;

    /**
     * 修改信息
     *
     * @param foc_express_d
     */
    @Update("update foc_express_d set " +
            "express_no=#{express_no},express_id=#{express_id}," +
            "sample_invoice=#{sample_invoice}," +
            "material_descriable=#{material_descriable}," +
            "material_specif=#{material_specif}," +
            "material_e_descriable=#{material_e_descriable}," +
            "unit=#{unit}," +
            "sips_no=#{sips_no}," +
            "price_type=#{price_type}," +
            "confirm_no=#{confirm_no}," +
            "confirm_id=#{confirm_id}," +
            "confirm_name=#{confirm_name}," +
            "price_modi_conf=#{price_modi_conf}," +
            "qty=#{qty}," +
            "price=#{price}," +
            "amount=#{amount}," +
            "price_lower=#{price_lower}," +
            "price_upper=#{price_upper}," +
            "net_weigh=#{net_weigh}," +
            "gross_weight=#{gross_weight}," +
            "box_from=#{box_from}," +
            "box_to=#{box_to}," +
            "confirm_time=#{confirm_time},update_oid=#{update_oid},update_program=#{update_program}  where id=#{id}")
    void update(Foc_express_d foc_express_d);

    /**
     * 删除信息
     *
     * @param id
     */
    @Delete("delete from foc_express_d where id=#{id}")
    void deleteById(int id);

    /*
     *2019.10.30  Haowen Tan
     *条件查找快运单表底
     */
    @Select("select * from foc_express_d where express_no in (select express_no from foc_express_h where express_no=#{express_no}) order by express_no asc , material_descriable asc ")
    public List<Foc_express_d> findByNo(String express_no) throws Exception;

    /**
     * @return
     * @throws Exception
     */
    @Select("select * from foc_express_d where express_no=#{express_no} " +
            "and price_modi_conf<>'Y' and express_no in(select express_no from foc_express_h where express_status='15')")
    public List<Foc_express_d> findByExpress_no2(String express_no) throws Exception;


    /**
     *
     * @param foc_express_d
     */
    @Update("update foc_express_d  set  price_modi_conf='Y',update_oid=#{update_oid},update_program=#{update_program}  where  id=#{id} ")
    void update2(Foc_express_d foc_express_d);


    @Update("update foc_express_d  set  confirm_id=#{update_oid},price_modi_conf='Y',confirm_time=now(),update_oid=#{update_oid},update_program=#{update_program} where  express_no=#{express_no} ")
    void updatebyExpress_no(Foc_express_d foc_express_d);

    /*
     *汇总数量
     */
    @Select("select sum(qty) qtyz from foc_express_d where express_no=#{express_no}")
    public float calculateqty(String express_no) throws Exception;


    /*
     *汇总金额
     */
    @Select("select sum(amount) amountz from foc_express_d where express_no in (select express_no from foc_express_h where express_no=#{express_no}) ")
    public float calculateamount(String express_no) throws Exception;

    /*
     *汇总重量
     */
    @Select("select sum(gross_weight) gross_weightz from foc_express_d where express_no in (select express_no from foc_express_h where express_no=#{express_no}) ")
    public float calculategross_weight(String express_no) throws Exception;

//    @Select("select sum(gross_weight) gross_weightz, sum(amount) amountz,sum(qty) qtyz from foc_express_d where express_no in (select express_no from foc_express_h where express_no=#{express_no}) ")
//    public float calculate(String express_no) throws Exception;

    @Select("select express_no,sum(qty) qty,sum(amount) amount,sum(net_weigh) net_weigh,sum(gross_weight) gross_weight from foc_express_d where express_no=#{express_no} group by express_no ")
    public Foc_express_d findByIv(String express_no) throws Exception;

}
