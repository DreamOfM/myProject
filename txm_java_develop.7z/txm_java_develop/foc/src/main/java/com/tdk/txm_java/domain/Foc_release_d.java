package com.tdk.txm_java.domain;

/**
 * 彔入表体
 */
public class Foc_release_d {
    private String LDDCNO;
    private Double LDSEQN;
    private String LDSPEC;
    private String LDSIPS;
    private String LDSAUM;
    private Double LDSYQT;

    @Override
    public String toString() {
        return "Foc_release_d{" +
                "LDDCNO='" + LDDCNO + '\'' +
                ", LDSEQN=" + LDSEQN +
                ", LDSPEC='" + LDSPEC + '\'' +
                ", LDSIPS='" + LDSIPS + '\'' +
                ", LDSAUM='" + LDSAUM + '\'' +
                ", LDSYQT=" + LDSYQT +
                '}';
    }

    public String getLDDCNO() {
        return LDDCNO;
    }

    public void setLDDCNO(String LDDCNO) {
        this.LDDCNO = LDDCNO;
    }

    public Double getLDSEQN() {
        return LDSEQN;
    }

    public void setLDSEQN(Double LDSEQN) {
        this.LDSEQN = LDSEQN;
    }

    public String getLDSPEC() {
        return LDSPEC;
    }

    public void setLDSPEC(String LDSPEC) {
        this.LDSPEC = LDSPEC;
    }

    public String getLDSIPS() {
        return LDSIPS;
    }

    public void setLDSIPS(String LDSIPS) {
        this.LDSIPS = LDSIPS;
    }

    public String getLDSAUM() {
        return LDSAUM;
    }

    public void setLDSAUM(String LDSAUM) {
        this.LDSAUM = LDSAUM;
    }

    public Double getLDSYQT() {
        return LDSYQT;
    }

    public void setLDSYQT(Double LDSYQT) {
        this.LDSYQT = LDSYQT;
    }
}


