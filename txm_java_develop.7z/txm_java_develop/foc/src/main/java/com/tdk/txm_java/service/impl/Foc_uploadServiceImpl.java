package com.tdk.txm_java.service.impl;

import com.tdk.txm_java.dao.IFoc_uploadDao;
import com.tdk.txm_java.domain.Foc_upload;
import com.tdk.txm_java.service.IFoc_uploadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class Foc_uploadServiceImpl implements IFoc_uploadService {

    @Autowired
    private IFoc_uploadDao foc_uploadDao;

    /**
    *@Description: 查询所有数据
    *@Author: a135109
    *@time: 2019/11/6 10:35
    */
    @Override
    public List<Foc_upload> findAll() throws Exception {
        return foc_uploadDao.findAll();
    }

    /**
    *@Description: 上载
    *@Author: a135109
    *@time: 2019/11/6 10:35
    */
    @Override
    public void save(Foc_upload foc_upload) throws Exception {
        foc_uploadDao.save(foc_upload);
    }

    /**
    *@Description: 通过快递单号查找对象
    *@Author: a135109
    *@time: 2019/11/6 10:35
    */
    @Override
    public List<Foc_upload> findByExpress_no(String express_no) {
        return foc_uploadDao.findByExpress_no(express_no);
    }

    /**
    *@Description: 删除
    *@Author: a135109
    *@time: 2019/11/6 10:35
    */
    @Override
    public void delete(int id) throws Exception {
        foc_uploadDao.delete(id);
    }

    /**
    *@Description: 更新数据
    *@Author: a135109
    *@time: 2019/11/6 10:35
    */
    @Override
    public void update(String express_no) throws Exception {
        foc_uploadDao.update(express_no);
    }

    /**
    *@Description: 通过id查找对象
    *@Author: a135109
    *@time: 2019/11/6 10:36
    */
    @Override
    public Foc_upload findById(int id) {
        return foc_uploadDao.findById_no(id);
    }

    /**
    *@Description: 确认
    *@Author: a135109
    *@time: 2019/11/6 10:37
    */
    @Override
    public Foc_upload queryByExpress_no(Foc_upload foc_upload) {
        return foc_uploadDao.queryByExpress_no(foc_upload);
    }

}
