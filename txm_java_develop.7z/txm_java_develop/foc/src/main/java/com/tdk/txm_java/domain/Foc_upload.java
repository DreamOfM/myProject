package com.tdk.txm_java.domain;

public class Foc_upload {
    private int id;
    private String express_no;
    private String actual_express_no;
    private String express_company;
    private String state;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getExpress_no() {
        return express_no;
    }

    public void setExpress_no(String express_no) {
        this.express_no = express_no;
    }

    public String getActual_express_no() {
        return actual_express_no;
    }

    public void setActual_express_no(String actual_express_no) {
        this.actual_express_no = actual_express_no;
    }

    public String getExpress_company() {
        return express_company;
    }

    public void setExpress_company(String express_company) {
        this.express_company = express_company;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Foc_upload() {
    }

    public Foc_upload(int id, String express_no, String actual_express_no, String express_company, String state) {
        this.id = id;
        this.express_no = express_no;
        this.actual_express_no = actual_express_no;
        this.express_company = express_company;
        this.state = state;
    }

    @Override
    public String toString() {
        return "Foc_upload{" +
                "id=" + id +
                ", express_no='" + express_no + '\'' +
                ", actual_express_no='" + actual_express_no + '\'' +
                ", express_company='" + express_company + '\'' +
                ", state='" + state + '\'' +
                '}';
    }
}
