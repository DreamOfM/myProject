package com.tdk.txm_java.domain;

import java.sql.Time;
import java.util.Date;

public class Foc_general_trade {
    private int id;
    private String declare_date;
    private String declaration_no;
    private String declare_port;
    private String list_no;
    private String invoice_no;
    private String terms_trade;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDeclare_date() {
        return declare_date;
    }

    public void setDeclare_date(String declare_date) {
        this.declare_date = declare_date;
    }

    public String getDeclaration_no() {
        return declaration_no;
    }

    public void setDeclaration_no(String declaration_no) {
        this.declaration_no = declaration_no;
    }

    public String getDeclare_port() {
        return declare_port;
    }

    public void setDeclare_port(String declare_port) {
        this.declare_port = declare_port;
    }

    public String getList_no() {
        return list_no;
    }

    public void setList_no(String list_no) {
        this.list_no = list_no;
    }

    public String getInvoice_no() {
        return invoice_no;
    }

    public void setInvoice_no(String invoice_no) {
        this.invoice_no = invoice_no;
    }

    public String getTerms_trade() {
        return terms_trade;
    }

    public void setTerms_trade(String terms_trade) {
        this.terms_trade = terms_trade;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    @Override
    public String toString() {
        return "Foc_general_trade{" +
                "id=" + id +
                ", declare_date=" + declare_date +
                ", declaration_no='" + declaration_no + '\'' +
                ", declare_port='" + declare_port + '\'' +
                ", list_no='" + list_no + '\'' +
                ", invoice_no='" + invoice_no + '\'' +
                ", terms_trade='" + terms_trade + '\'' +
                ", login_time=" + login_time +
                ", login_oid='" + login_oid + '\'' +
                ", update_time=" + update_time +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                '}';
    }

}
