package com.tdk.txm_java.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tdk.txm_java.domain.*;
import com.tdk.txm_java.service.*;
import com.tdk.txm_java.utils.DateUtils;
import com.tdk.txm_java.utils.MathUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

@Controller

@RequestMapping("/bnd_master_item_mail")
public class Bnd_master_item_mailController {
    @Autowired
    IBnd_master_item_mailService iBnd_master_item_mailService;
    @Autowired
    IBnd_master_itemService iBnd_master_itemService;

    @RequestMapping("/findByState")
    public ModelAndView  findByState() throws Exception {
        ModelAndView mv = new ModelAndView();
        List<Bnd_master_item_mail> bnd_master_item_mails=iBnd_master_item_mailService.findByState("0");
        mv.setViewName("bnd-master-item-audit");
        mv.addObject("bnd_master_item_mails", bnd_master_item_mails);
        return mv;
    }
    @RequestMapping("/findByMrp")
    public ModelAndView  findByMrp(String mrpcode) throws Exception {
        ModelAndView mv = new ModelAndView();
        List<Bnd_master_item_mail> bnd_master_item_mails=new ArrayList<>();
        if(null==mrpcode||mrpcode.equals(" ")||mrpcode.equals("all")) {
            bnd_master_item_mails=iBnd_master_item_mailService.findByState("0");
        }else{
            bnd_master_item_mails = iBnd_master_item_mailService.findByMrp(mrpcode);

        }
        mv.setViewName("bnd-master-item-audit");
        mv.addObject("bnd_master_item_mails", bnd_master_item_mails);
        return mv;
    }

    @RequestMapping("/save")
    public void save(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        String username = (String) session.getAttribute("username");
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();

        if(map.size()>0) {
            int b = 0;
            int c = 0;
            while (1 == 1) {
                for (String name1 : set) {
                    //取出这个属性对应的值
                    String[] vals = (String[]) map.get(name1);
                    //计算该数组的长度
                    c = vals.length;
                    //判断这个key值是否是实体类里的属性
                    hashMap.put(name1, vals[b]);
                }
                Bnd_master_item_mail bnd_master_item_mail = iBnd_master_item_mailService.findById(Integer.parseInt(hashMap.get("id")));
                try {
                    BeanUtils.populate(bnd_master_item_mail, hashMap);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    e.printStackTrace();
                }

                if (bnd_master_item_mail.getState() .equals( "1" )|| bnd_master_item_mail.getState() .equals("2")) {
                    bnd_master_item_mail.setUpdate_program("bnd_master_mail/save");
                    bnd_master_item_mail.setUpdate_oid(username);
                    //更新品名档bnd_master_item及bnd_master_item_mail
                    iBnd_master_item_mailService.updateStateById(bnd_master_item_mail);

                }

                b++;
                if (b == c) {
                    break;
                }
            }
        }

            // 响应数据
//        info.setData(bndmasterInvtList);
            ObjectMapper mapper = new ObjectMapper();
            response.setContentType("application/json;charset=utf-8");
            mapper.writeValue(response.getOutputStream(), info);
        }


    }

