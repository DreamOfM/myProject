package com.tdk.txm_java.controller;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tdk.txm_java.domain.Bnd_master_item;
import com.tdk.txm_java.domain.Bnd_master_maximun_loss;
import com.tdk.txm_java.domain.ResultInfo;
import com.tdk.txm_java.service.IBnd_master_itemService;
import com.tdk.txm_java.service.IBnd_master_maximun_lossService;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

@Controller
@RequestMapping("/bnd_master_maximun_loss")

public class Bnd_master_maximun_lossController {

    @Autowired
    private IBnd_master_maximun_lossService bnd_master_maximun_lossService;

    @Autowired
    private IBnd_master_itemService bnd_master_itemService;

    /**
     * @Description: 查询所有设备信息
     * @Author: a135109
     * @time: 2019/12/4 11:58
     */
    @RequestMapping("/findAll.do")
    public ModelAndView findAll(@RequestParam(value = "pn", defaultValue = "1") Integer pn, @RequestParam(value = "PageSize", defaultValue = "10") Integer ps) throws Exception {
        PageHelper.startPage(pn, ps);
        ModelAndView mv = new ModelAndView();
        List<Bnd_master_maximun_loss> ls = bnd_master_maximun_lossService.findAll();
        PageInfo page = new PageInfo(ls, ps);
        mv.setViewName("bnd-master-maximun-loss");
        mv.addObject("maximun_lossAll", ls);
        mv.addObject("pageInfo", page);
        return mv;
    }

    /**
     * @Description: 通过输入设备工程名查询
     * @Author: a135109
     * @time: 2019/12/4 14:41
     */
    @RequestMapping("/findByName")
    public ModelAndView findByName(String material_item_no) throws Exception {
        Bnd_master_maximun_loss bnd_master_maximun_loss = bnd_master_maximun_lossService.findByKey(material_item_no);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("bnd-master-maximun-loss");
        mv.addObject("maximun_loss", bnd_master_maximun_loss);
        return mv;
    }
    /**
     * @Description: 新增设备信息
     * @Author: a135109
     * @time: 2019/12/4 11:57
     */
    @RequestMapping("/save.do")
    public void save(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception {
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //测试前端数据是否传送过来？
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        Bnd_master_maximun_loss bnd_master_maximun_loss = new Bnd_master_maximun_loss();
        while (1 == 1) {
            for (String name1 : set) {
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                hashMap.put(name1, vals[b]);
            }
            try {
                BeanUtils.populate(bnd_master_maximun_loss, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //添加一个判断，如果为空值或者没有输入则不往数据库里插数据
            if (bnd_master_maximun_loss.getMaterial_item_no().equals(null) || bnd_master_maximun_loss.getMaterial_item_no().equals("")) {
                b++;
                if (b == c) break;
                continue;
            }
            String username = (String) httpSession.getAttribute("username");
            bnd_master_maximun_loss.setUpdate_oid(username);
            bnd_master_maximun_loss.setUpdate_program("/bnd_master_max_loss/save");
            bnd_master_maximun_loss.setLogin_oid(username);
            bnd_master_maximun_lossService.save(bnd_master_maximun_loss);
            b++;
            if (b == c) break;
        }
    }

    /**
     * @Description: 删除设备信息
     * @Author: a135109
     * @time: 2019/12/4 11:58
     */
    @RequestMapping("/delete.do")
    public String delete(int id) throws Exception {
        bnd_master_maximun_lossService.delete(id);
        return "redirect:findByName.do";
    }

    /**
     * @Description: 修改设备信息
     * @Author: a135109
     * @time: 2019/12/5 9:00
     */
    @RequestMapping("/update.do")
    public void update(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception {
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        //1.获取信息
        int id = Integer.parseInt(request.getParameter("id"));
        Double max_pm_orderqty_io = Double.parseDouble(request.getParameter("max_pm_orderqty_io"));
        //2.调用service层判断是否存在
        Bnd_master_maximun_loss bnd_master_maximun_loss = bnd_master_maximun_lossService.findById(id);
        bnd_master_maximun_loss.setMax_pm_orderqty_io(max_pm_orderqty_io);
        String username = (String) httpSession.getAttribute("username");
        bnd_master_maximun_loss.setUpdate_oid(username);
        bnd_master_maximun_loss.setUpdate_program("/bnd_master_max_loss/update");
        bnd_master_maximun_lossService.update(bnd_master_maximun_loss);
        // 响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        info.setFlag(true);
        mapper.writeValue(response.getOutputStream(), info);
    }

    /**
     * @Description: ajax验证
     * @Author: a135109
     * @time: 2019/12/16 11:54
     */
    @RequestMapping("/check.do")
    public void check(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception, IOException, JsonGenerationException, JsonMappingException {
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        Bnd_master_maximun_loss bnd_master_maximun_loss = new Bnd_master_maximun_loss();
        int b = 0;   //第几笔记录
        int c = 0;   //total

        List<String> item_list = new ArrayList<>();//增加一个list去放置form中获取的值

        while (true) {
            //一条数据
            for (String name : set) {
                String[] vals = (String[]) map.get(name);
                c = vals.length;
                hashMap.put(name, vals[b]);
            }
            //hashmap找到对应的对象
            try {
                BeanUtils.populate(bnd_master_maximun_loss, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            String material_item_no = bnd_master_maximun_loss.getMaterial_item_no();
            if (!(material_item_no == "" || "".equals(material_item_no))) {
                if (item_list.contains(bnd_master_maximun_loss.getMaterial_item_no())) {
                    info.setFlag(false);
                    info.setData(-3);
                    String errLine = String.valueOf(b);
                    errorList.add("material_item_no" + errLine);
                } else {
                    item_list.add(bnd_master_maximun_loss.getMaterial_item_no());
                }
                //查找是否存在材料
                Bnd_master_item master_item = bnd_master_itemService.findByitem_no(material_item_no);
                if (master_item == null) {
                    info.setFlag(false);
                    info.setData(-1);
                    String errLine = String.valueOf(b);
                    errorList.add("material_item_no" + errLine);
                } else {
                    //查找存在的对象
                    Bnd_master_maximun_loss bnd_master_maximun_loss2 = bnd_master_maximun_lossService.findByKey(material_item_no);
                    if (bnd_master_maximun_loss2 != null) {
                        info.setFlag(false);
                        info.setData(-2);
                        String errLine = String.valueOf(b);
                        errorList.add("material_item_no" + errLine);
                    }

                }
            }
            b++;
            if (b == c) break;
        }
        info.setErrorList(errorList);
        // 响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(), info);
    }
}
