package com.tdk.txm_java.domain;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class Bnd_invoice_h implements Serializable {
    private String internal_number;
    private String amt_t;
    private String amt_t_cn;
    private String invoices;
    private String gross_wet_t;
    private String net_wet_t;
    private String qty_t;
    private String ctn_t;
    private List bnd_invoices;

}
