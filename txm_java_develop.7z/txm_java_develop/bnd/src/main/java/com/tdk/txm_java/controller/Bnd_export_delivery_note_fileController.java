package com.tdk.txm_java.controller;


import com.tdk.txm_java.dao.IBnd_export_delivery_note_fileDao;
import com.tdk.txm_java.domain.*;
import com.tdk.txm_java.service.*;
import com.tdk.txm_java.utils.JsonUtil;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.*;

import static java.util.stream.Collectors.groupingBy;
import static java.util.stream.Collectors.summingDouble;

@Controller
@RequestMapping("/bnd_export_delivery_note_file")
public class Bnd_export_delivery_note_fileController {
    @Autowired
    private IBnd_export_delivery_note_fileService iBnd_export_delivery_note_fileService;
    @Autowired
    private IBnd_export_delivery_note_fileDao iBnd_export_delivery_note_fileDao;
    @Autowired
    private IBnd_export_invoice_dService iBnd_export_invoice_dService;
    @Autowired
    private IBnd_export_invoice_hService iBnd_export_invoice_hService;
    @Autowired
    private IBnd_master_itemService iBnd_master_itemService;
    @Autowired
    private IBnd_master_customerService iBnd_master_customerService;
    @Autowired
    private IBnd_master_unit_measure_codeService iBnd_master_unit_measure_codeService;


    @RequestMapping("/check2Confirm")
    public void check2Confirm(HttpServletRequest request, HttpServletResponse response) throws IOException {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            for (String name1 : set) {
                    String[] vals = (String[]) map.get(name1);
                    c = vals.length;
                    hashMap.put(name1, vals[b]);
            }
            //记录当前记录行
            String shipped_date_from = hashMap.get("shipped_date_from");
            String shipped_date_to = hashMap.get("shipped_date_to");
            if(shipped_date_from.compareTo(shipped_date_to)>0){
                info.setFlag(false);
                info.setErrorMsg("日期不合规，请重新确认");
            }

            b++;
            if (b == c) {
                break;
            }
        }
        //响应数据
        JsonUtil.writeValue(info,response);
    }

//
//    @RequestMapping("/checke2Save")
//    public void checke2Save(String[] ids, HttpServletRequest request, HttpServletResponse response) throws IOException {
//        ResultInfo info = new ResultInfo ();
//        info.setFlag (true);
//        List<String> errorList = new ArrayList<String> ();
//        Map map = request.getParameterMap ();
//        Map<String, String> hashMap = new HashMap<> ();
//        Set<String> set = map.keySet ();
//        int b = 0;
//        int c = 0;
//        while (1 == 1) {
//            for(String name1 : set){
//                String[] vals = (String[]) map.get(name1);
//                c=vals.length;
//                hashMap.put(name1,vals[b]);
//            }
//            Bnd_export_delivery_note_file bnd_export_delivery_note_file=new Bnd_export_delivery_note_file ();
//            try {
//                BeanUtils.populate(bnd_export_delivery_note_file,hashMap);
//            } catch (IllegalAccessException e) {
//                e.printStackTrace();
//            } catch (InvocationTargetException e) {
//                e.printStackTrace();
//            }
//            //记录当前记录行
//            String errLine = String.valueOf (b);
//            String flag1 = hashMap.get ("flag1");
//                    if (flag1 != null && !"".equals (flag1)) {
//                        if (!"Y".equals (flag1) || !"N".equals (flag1)) {
//                            info.setFlag (false);
//                            info.setErrorMsg ("只能输入'Y'或'N'，请重新确认");
//                            errorList.add ("pass_date" + errLine);
//                    }
//                }
//                b++;
//                if (b == c) {
//                    break;
//                }
//            }
//            info.setErrorList (errorList);
//            //响应数据
//            ObjectMapper mapper = new ObjectMapper ();
//            response.setContentType ("application/json;charset=utf-8");
//            mapper.writeValue (response.getOutputStream (), info);
//
//    }
//




    //确认保存---物流确认
    @RequestMapping("/update2Confirm.do")
    public String update2Confirm(String[] ids, HttpServletRequest request, HttpServletResponse response, HttpSession httpSession, RedirectAttributes attr) throws Exception {
        String username = (String) httpSession.getAttribute("username");
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<> ();
        Set<String> set = map.keySet ();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            for (String name1 : set) {
                if(!name1.equals("ids")){
                    String[] vals = (String[]) map.get(name1);
                    c = vals.length;
                    hashMap.put(name1, vals[b]);
                }
            }
            //取出id
            String id = hashMap.get("id");
            //判断这个id是否被选中？
            String flag1="";
            boolean isContains = Arrays.asList(ids).contains(id);
            if(isContains) {
                flag1 = "Y";
            }

                String invoice_no = hashMap.get ("invoice_no");

                Bnd_export_delivery_note_file bnd_export_delivery_note_file = iBnd_export_delivery_note_fileService.findByInvoice (invoice_no);
                if (bnd_export_delivery_note_file != null && !"".equals (bnd_export_delivery_note_file)) {
                    bnd_export_delivery_note_file.setFlag1 (flag1);
                    bnd_export_delivery_note_file.setUpdate_oid (username);
                    bnd_export_delivery_note_file.setUpdate_program ("update2Confirm.do");
                    //调用service层的方法处理
                    iBnd_export_delivery_note_fileService.update (bnd_export_delivery_note_file);
                } else {
                    bnd_export_delivery_note_file = new Bnd_export_delivery_note_file ();
//                    DateUtils.convert2Date ();
                    BeanUtils.copyProperties (bnd_export_delivery_note_file,hashMap);
                    bnd_export_delivery_note_file.setFlag1 (flag1);
                    bnd_export_delivery_note_file.setLogin_oid (username);
                    bnd_export_delivery_note_file.setUpdate_program ("update2Confirm.do");
                    iBnd_export_delivery_note_fileService.save (bnd_export_delivery_note_file);
                }
            b++;
            if (b == c) {
                break;
            }
        }
        return "bnd-export-delivery-note-file";
    }

    //确认保存----仓库确认
    @RequestMapping("/updateWHConfirm.do")
    public String updateWHConfirm(String[] ids, HttpServletRequest request, HttpServletResponse response, HttpSession httpSession, RedirectAttributes attr) throws Exception {
        String username = (String) httpSession.getAttribute("username");
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<> ();
        Set<String> set = map.keySet ();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            for (String name1 : set) {
                if(!name1.equals("ids")){
                    String[] vals = (String[]) map.get(name1);
                    c = vals.length;
                    hashMap.put(name1, vals[b]);
                }
            }
            //取出id
            String id = hashMap.get("id");
            //判断这个id是否被选中？
            String flag2="";
            boolean isContains = Arrays.asList(ids).contains(id);
            if(isContains) {
                flag2 = "Y";
            }

            String invoice_no = hashMap.get ("invoice_no");

            Bnd_export_delivery_note_file bnd_export_delivery_note_file = iBnd_export_delivery_note_fileService.findByInvoice (invoice_no);
            if (bnd_export_delivery_note_file != null && !"".equals (bnd_export_delivery_note_file)) {
                bnd_export_delivery_note_file.setFlag2 (flag2);
                bnd_export_delivery_note_file.setUpdate_oid (username);
                bnd_export_delivery_note_file.setUpdate_program ("updateWHConfirm.do");
                //调用service层的方法处理
                iBnd_export_delivery_note_fileService.update (bnd_export_delivery_note_file);
            }
            b++;
            if (b == c) {
                break;
            }
        }
        return "bnd-export-delivery-note-warehouse";
    }



    //物流确认查询
    @RequestMapping("/confirmQuery.do")
    public ModelAndView confirmQuery(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String message=null;
        ModelAndView modelAndView = new ModelAndView();
        String shipped_date_from = request.getParameter("shipped_date_from");
        String shipped_date_to = request.getParameter("shipped_date_to");
        String flag = request.getParameter("flag");
        String forwarder_code1 = request.getParameter("forwarder_code1");
        String forwarder_code2 = request.getParameter("forwarder_code2");
        String forwarder_code3 = request.getParameter("forwarder_code3");
        String forwarder_code4 = request.getParameter("forwarder_code4");
        List<Bnd_export_delivery_note_file> bnd_export_delivery_note_file=new ArrayList<> ();
        if(flag!=null || !"".equals (flag)) {
            bnd_export_delivery_note_file = iBnd_export_delivery_note_fileService.confirmQueryN (shipped_date_from, shipped_date_to, flag, forwarder_code1, forwarder_code2, forwarder_code3, forwarder_code4);

            if (bnd_export_delivery_note_file.size () > 0) {
                modelAndView.addObject ("bnd_export_delivery_note_file", bnd_export_delivery_note_file);

            } else {
                message = "未查询到任何结果";
                modelAndView.addObject ("message", message);
            }
        }
        modelAndView.addObject ("shipped_date_from", shipped_date_from);
        modelAndView.addObject ("shipped_date_to", shipped_date_to);
        modelAndView.addObject ("flag", flag);
        modelAndView.addObject ("forwarder_code1", forwarder_code1);
        modelAndView.addObject ("forwarder_code2", forwarder_code2);
        modelAndView.addObject ("forwarder_code3", forwarder_code3);
        modelAndView.addObject ("forwarder_code4", forwarder_code4);
        modelAndView.setViewName ("bnd-export-delivery-note-file");
        return modelAndView;
    }


    //仓库确认查询
    @RequestMapping("/confirmQueryWH.do")
    public ModelAndView confirmQueryWH(HttpServletRequest request, HttpServletResponse response) throws Exception {
        String message=null;
        ModelAndView modelAndView = new ModelAndView();
        String shipped_date_from = request.getParameter("shipped_date_from");
        String shipped_date_to = request.getParameter("shipped_date_to");
        String flag = request.getParameter("flag");

        List<Bnd_export_delivery_note_file> bnd_export_delivery_note_file=new ArrayList<> ();
        if(flag!=null || !"".equals (flag)) {
            bnd_export_delivery_note_file = iBnd_export_delivery_note_fileService.confirmQueryWH(shipped_date_from, shipped_date_to, flag);

            if (bnd_export_delivery_note_file.size () > 0) {
                modelAndView.addObject ("bnd_export_delivery_note_file", bnd_export_delivery_note_file);

            } else {
                message = "未查询到任何结果";
                modelAndView.addObject ("message", message);
            }
        }
        modelAndView.addObject ("shipped_date_from", shipped_date_from);
        modelAndView.addObject ("shipped_date_to", shipped_date_to);
        modelAndView.addObject ("flag", flag);
//        modelAndView.addObject("bnd_export_delivery_note_file",  bnd_export_delivery_note_file);
//        modelAndView.addObject("bnd_export_delivery_note_file",  bnd_export_delivery_note_file);
        modelAndView.setViewName ("bnd-export-delivery-note-warehouse");

        return modelAndView;
    }
    //物流确认取消
    @RequestMapping("/update2ConCanl.do")
    public String update2ConCanl(int[] ids,HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception {
        for(int id: ids){
            iBnd_export_delivery_note_fileDao.update2ConCanl(id);
        }
        return "bnd-export-delivery-note-file";
    }

    //仓库确认取消
    @RequestMapping("/updateWHConCanl.do")
    public String updateWHConCanl(int[] ids,HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception {
        for(int id: ids){
            iBnd_export_delivery_note_fileDao.updateWHConCanl(id);
        }
        return "bnd-export-delivery-note-warehouse";
    }

    //打印
    @RequestMapping("/printedToWm.do")
    public ModelAndView printedToWm(String invoice_no,String delivery_note_name,String shipped_date_from,String shipped_date_to,String flag) throws Exception {
        //根据invoice_no 查询bnd_export_invoice_d数据
        List<Bnd_export_invoice_d>  bnd_export_invoice_dList = iBnd_export_invoice_dService.findByInvoice_no(invoice_no);
        ModelAndView mv = new ModelAndView();
        if (bnd_export_invoice_dList.size()>0){
            for (Bnd_export_invoice_d bnd_export_invoice_d : bnd_export_invoice_dList){
                Map<String, Double> collects = bnd_export_invoice_dList.stream().collect(groupingBy(Bnd_export_invoice_d::getDn_no,summingDouble(Bnd_export_invoice_d::getPacking_qty)));
                //根据key(dn_no) 查询value(此处的packing_qty=dn_qty=相同DN的packing_qty之和)
                String dn_no = bnd_export_invoice_d.getDn_no();
                Double dn_qty = collects.get(dn_no);
                bnd_export_invoice_d.setDn_qty(dn_qty);
                //1.根据invoice 去bnd_export_invoice_h 查询数据
                Bnd_export_invoice_h bnd_export_invoice_h = iBnd_export_invoice_hService.findByInvoice_no(invoice_no);
                if(bnd_export_invoice_h!=null&&!"".equals(bnd_export_invoice_h)){
                    /**
                     * 拆分年月日，变成三个字段来显示
                     */
                    String shipping_date = bnd_export_invoice_h.getShipped_date();
                    String shipping_year = shipping_date.substring(0,4);
                    String shipping_month = shipping_date.substring(5,7);
                    String shipping_day = shipping_date.substring(8,10);
                    bnd_export_invoice_h.setShipping_year(shipping_year);
                    bnd_export_invoice_h.setShipping_month(shipping_month);
                    bnd_export_invoice_h.setShipping_day(shipping_day);
                    bnd_export_invoice_d.setBnd_export_invoice_h(bnd_export_invoice_h);
                }
                //2.根据item_no去bnd_master_item查询
                String item_no = bnd_export_invoice_d.getItem_no();
                Bnd_master_item bnd_master_item = iBnd_master_itemService.findByitem_no(item_no);
                if(bnd_master_item!=null&&!"".equals(bnd_master_item)){
                    String um_incoming_outgoing = bnd_master_item.getUm_incoming_outgoing();
                    if(um_incoming_outgoing!=null&&!"".equals(um_incoming_outgoing)){
                        //2.1 um_incoming_outgoing在txqpp(bnd_master_unit_measure_code)中转换unit_code_alternative，找不到存入bnd_master_item .um_incoming_outgoing
                        Bnd_master_unit_measure_code bnd_master_unit_measure_code = iBnd_master_unit_measure_codeService.findByunit_code(um_incoming_outgoing);
                        if(bnd_master_unit_measure_code!=null&&!"".equals(bnd_master_unit_measure_code)){
                            bnd_master_item.setUm_incoming_outgoing(bnd_master_unit_measure_code.getUnit_code_alternative());
                        }
                    }
                    bnd_export_invoice_d.setBnd_master_item(bnd_master_item);
                }
                //3.根据customer_no 去bnd_master_customer查询数据
                String customer_no = bnd_export_invoice_d.getCustomer_no();
                Bnd_master_customer bnd_master_customer = iBnd_master_customerService.findByCustomer_no(customer_no);
                if(bnd_master_customer!=null&&!"".equals(bnd_master_customer)){
                    bnd_export_invoice_d.setBnd_master_customer(bnd_master_customer);
                }

                //4.货品=item_description_dbcs+customer_item_code
                String item_description_dbcs = bnd_master_item.getItem_description_dbcs();
                String customer_item_code = bnd_export_invoice_d.getCustomer_item_code();
                bnd_export_invoice_d.setGoods(item_description_dbcs+customer_item_code);

            }
            mv.addObject ("shipped_date_from", shipped_date_from);
            mv.addObject ("shipped_date_to", shipped_date_to);
            mv.addObject ("flag", flag);
            mv.addObject ("bnd_export_invoice_dList", bnd_export_invoice_dList);
        }
        mv.setViewName (delivery_note_name);
        return mv;
    }


}
