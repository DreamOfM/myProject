package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_master_bom_weed {
    private String item_no;
    private String material_item_no;
    private String char1;
    private Integer int1;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;
}
