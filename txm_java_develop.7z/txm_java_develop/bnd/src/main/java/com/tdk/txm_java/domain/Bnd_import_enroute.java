package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_import_enroute {
    private int id;
    private String po_no;//购买订单号码
    private Double po_no_line;//购买订单行号
    private String request_no;//请求号
    private String invoice_no;//发票号码
    private Integer invoice_no_line;//发票行号
    private String web_status;// WEB状态
    private String vendor_no;//供货商代码
    private String purchaser;//购买者
    private String puchase_pic;//资材担当
    private String terms_trade;//贸易条件
    private String mrpcode;// MRP代码
    private String item_no;//品名代码
    private String item_description_dbcs;//品名（中文）
    private String item_spec;//品名规格
    private String vendor_item_no;//供货商品名代码
    private String um_purchase;//计量单位（购买）
    private Double cf_purchase ;//购买换算系数
    private Double bording_price;//载运单价
    private Double purchase_qty;//购买订单数量
    private Double consignment_qty;//交货数量
    private Double po_boarding_amt;//交货金额
    private String note;//备注
    private String consignment_date;//发货日期
    private String apply_date;//申请日期
    private String apply_time;//申请时间
    private String plan_receive_date;//预计到货日
    private String plant_place;//工发地
    private String trans_mode;//运输方式
    private String plant_code;//板代码
    private Integer plant_1;//栈板1
    private Integer plant_2;//栈板2
    private Integer pad_qty;//总板数
    private String packing_code;//包装代码
    private Integer box_1;//箱数1
    private Integer box_2;//箱数2
    private Integer box_qty;//总箱数
    private String ori_country;//源产国
    private Double gross_weight;//毛重
    private String lot_no;//批号
    private String manufacture_date;//生产日期
    private String unit;//计量单位
    private Double net_weight;//凈重
    private Double totoal_net_weight;//总凈重
    private Double pieces;//件数
    private String confirm_date;//确认日期
    private String confirm_time;//确认时间
    private String confirm_ws_id;//确认终端机名称
    private String confirm_operator_id;//确认操作员代码
    private Double large_packing_qty;//大包装数
    private Double middle_packing_qty;//中包装数
    private Double small_packing_qty;//小包装数量
    private Double expiration_date;
    private String customs_cover;
    private Integer customs_cover_no;
    private String inner_no;
    private String customs_declaration_mark ;
    private Double supervision_quantity ;
    private Double legal_quantity;
    private String currency ;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;
    private String ccc_code;
    private String item_spec2;//申报要素
    private String regulatory_credentials_code;
    private String bonded_logo;
}
