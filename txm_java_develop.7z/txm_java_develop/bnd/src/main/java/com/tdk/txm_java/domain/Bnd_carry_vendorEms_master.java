package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Time;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_develop</h3>
 * @ClassName<h4>结转发单控制</h4>
 * @ToDo<p></p>
 * @date : 2020-05-23 15:07
 * @version:1.0
 **/
@Data
public class Bnd_carry_vendorEms_master {
    private int id;
    //供應商代碼
    private String vendor_no;
    //供應商賬冊
    private String vendor_ems;
    //生效日期
    private String effective_date;
    //失效日期
    private String expiration_date;
    private Time login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;




}
