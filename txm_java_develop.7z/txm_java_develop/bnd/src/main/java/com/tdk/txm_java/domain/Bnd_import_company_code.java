package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Time;

@Data
public class Bnd_import_company_code {
    private int id;
    private String company_code;//公司代码
    private String company_type;//公司型态
    private String company_name;//公司型态
    private String express_company;//快递公司
    private String address1_dbcs;//住址１（中文）
    private String address2_dbcs;//住址２（中文）
    private String address3_dbcs;//住址３（中文）
    private String company_name_2;//公司名 2
    private String company_offical_code;//公司正式代码

    private Time login_time;//登陆时间login_time
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;



}
