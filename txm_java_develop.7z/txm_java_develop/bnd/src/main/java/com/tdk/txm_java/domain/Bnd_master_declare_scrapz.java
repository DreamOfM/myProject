package com.tdk.txm_java.domain;

public class Bnd_master_declare_scrapz {
    private int id;
    private String item_no;
    private Double img_no;
    private String bonded_logo;
    private String ccc_code;
    private String item_description_dbcs;
    private String item_description_dbcs1;
    private String item_description_dbcs2;
    private String brand_type;
    private String export_discount;
    private String um_physical_inventory;
    private Double net_weigh;
    private String lawf_unitcd;
    private Double lawf_unitcd_cf;
    private String secd_lawf_unitcd;
    private Double secd_lawf_unitcd_cf;
    private Double unit_price;
    private String content;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getItem_no() {
        return item_no;
    }

    public void setItem_no(String item_no) {
        this.item_no = item_no;
    }

    public Double getImg_no() {
        return img_no;
    }

    public void setImg_no(Double img_no) {
        this.img_no = img_no;
    }

    public String getBonded_logo() {
        return bonded_logo;
    }

    public void setBonded_logo(String bonded_logo) {
        this.bonded_logo = bonded_logo;
    }

    public String getCcc_code() {
        return ccc_code;
    }

    public void setCcc_code(String ccc_code) {
        this.ccc_code = ccc_code;
    }

    public String getItem_description_dbcs() {
        return item_description_dbcs;
    }

    public void setItem_description_dbcs(String item_description_dbcs) {
        this.item_description_dbcs = item_description_dbcs;
    }

    public String getItem_description_dbcs1() {
        return item_description_dbcs1;
    }

    public void setItem_description_dbcs1(String item_description_dbcs1) {
        this.item_description_dbcs1 = item_description_dbcs1;
    }

    public String getBrand_type() {
        return brand_type;
    }

    public void setBrand_type(String brand_type) {
        this.brand_type = brand_type;
    }

    public String getExport_discount() {
        return export_discount;
    }

    public void setExport_discount(String export_discount) {
        this.export_discount = export_discount;
    }

    public String getUm_physical_inventory() {
        return um_physical_inventory;
    }

    public void setUm_physical_inventory(String um_physical_inventory) {
        this.um_physical_inventory = um_physical_inventory;
    }

    public Double getNet_weigh() {
        return net_weigh;
    }

    public void setNet_weigh(Double net_weigh) {
        this.net_weigh = net_weigh;
    }

    public String getLawf_unitcd() {
        return lawf_unitcd;
    }

    public void setLawf_unitcd(String lawf_unitcd) {
        this.lawf_unitcd = lawf_unitcd;
    }

    public Double getLawf_unitcd_cf() {
        return lawf_unitcd_cf;
    }

    public void setLawf_unitcd_cf(Double lawf_unitcd_cf) {
        this.lawf_unitcd_cf = lawf_unitcd_cf;
    }

    public String getSecd_lawf_unitcd() {
        return secd_lawf_unitcd;
    }

    public void setSecd_lawf_unitcd(String secd_lawf_unitcd) {
        this.secd_lawf_unitcd = secd_lawf_unitcd;
    }

    public Double getSecd_lawf_unitcd_cf() {
        return secd_lawf_unitcd_cf;
    }

    public void setSecd_lawf_unitcd_cf(Double secd_lawf_unitcd_cf) {
        this.secd_lawf_unitcd_cf = secd_lawf_unitcd_cf;
    }

    public Double getUnit_price() {
        return unit_price;
    }

    public void setUnit_price(Double unit_price) {
        this.unit_price = unit_price;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    public String getItem_description_dbcs2() {
        return item_description_dbcs2;
    }

    public void setItem_description_dbcs2(String item_description_dbcs2) {
        this.item_description_dbcs2 = item_description_dbcs2;
    }

    @Override
    public String toString() {
        return "Bnd_master_declare_scrapz{" +
                "id=" + id +
                ", item_no='" + item_no + '\'' +
                ", img_no=" + img_no +
                ", bonded_logo='" + bonded_logo + '\'' +
                ", ccc_code='" + ccc_code + '\'' +
                ", item_description_dbcs='" + item_description_dbcs + '\'' +
                ", item_description_dbcs1='" + item_description_dbcs1 + '\'' +
                ", item_description_dbcs2='" + item_description_dbcs2 + '\'' +
                ", brand_type='" + brand_type + '\'' +
                ", export_discount='" + export_discount + '\'' +
                ", um_physical_inventory='" + um_physical_inventory + '\'' +
                ", net_weigh=" + net_weigh +
                ", lawf_unitcd='" + lawf_unitcd + '\'' +
                ", lawf_unitcd_cf=" + lawf_unitcd_cf +
                ", secd_lawf_unitcd='" + secd_lawf_unitcd + '\'' +
                ", secd_lawf_unitcd_cf=" + secd_lawf_unitcd_cf +
                ", unit_price=" + unit_price +
                ", content='" + content + '\'' +
                ", login_time='" + login_time + '\'' +
                ", login_oid='" + login_oid + '\'' +
                ", update_time='" + update_time + '\'' +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                '}';
    }
}
