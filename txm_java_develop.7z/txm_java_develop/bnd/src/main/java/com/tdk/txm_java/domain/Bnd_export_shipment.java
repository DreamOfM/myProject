package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Time;
import java.util.Date;

@Data
public class Bnd_export_shipment {
    private int id;
    private String invoice_no;
    private String customer_so;
    private String invoice_type;
    private String transaction_code;
    private String mrpcode;
    private String warehouse_code;
    private String invoice_date;
    private String customer_no;
    private String item_no;
    private String statement_customer_no;
    private Double sold_qty;
    private Double amt_cny;
    private Double amt_foreign;
    private Double selling_price;
    private String currency;
    private Double rate;
    private String shipped_date;
    private String shutdown_reason_code;
    private String transaction_date;
    private String customer_item_code;
    private String paytax_declaration_no2;
    private Double paytax_qty2;
    private String paytax_declaration_no3;
    private Double paytax_qty3;
    private String paytax_declaration_no4;
    private Double paytax_qty4;
    private String paytax_declaration_no5;
    private Double paytax_qty5;
    private String country_code;
    private String remark_1;
    private String remark_2;


    private Time login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;

}
