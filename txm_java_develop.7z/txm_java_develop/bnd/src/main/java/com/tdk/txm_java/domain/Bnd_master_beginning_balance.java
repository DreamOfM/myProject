package com.tdk.txm_java.domain;

public class Bnd_master_beginning_balance {
    private int id;
    private String data_state;
    private String item_no;
    private Double img_no;
    private Double beginning_balance;
    private Double base_date;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getData_state() {
        return data_state;
    }

    public void setData_state(String data_state) {
        this.data_state = data_state;
    }

    public String getItem_no() {
        return item_no;
    }

    public void setItem_no(String item_no) {
        this.item_no = item_no;
    }

    public Double getImg_no() {
        return img_no;
    }

    public void setImg_no(Double img_no) {
        this.img_no = img_no;
    }

    public Double getBeginning_balance() {
        return beginning_balance;
    }

    public void setBeginning_balance(Double beginning_balance) {
        this.beginning_balance = beginning_balance;
    }

    public Double getBase_date() {
        return base_date;
    }

    public void setBase_date(Double base_date) {
        this.base_date = base_date;
    }

    @Override
    public String toString() {
        return "Bnd_master_beginning_balance{" +
                "id=" + id +
                ", data_state='" + data_state + '\'' +
                ", item_no='" + item_no + '\'' +
                ", img_no=" + img_no +
                ", beginning_balance=" + beginning_balance +
                ", base_date=" + base_date +
                '}';
    }
}
