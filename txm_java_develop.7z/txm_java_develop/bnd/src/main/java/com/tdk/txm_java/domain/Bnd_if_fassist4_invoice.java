package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Time;

@Data
public class Bnd_if_fassist4_invoice {
    private int id;
    private String akivnr;
    private String akdnno;
    private String aksono;
    private String akivtp;
    private String akcunr;
    private String akstmt;
    private String akcurr;
    private String akshpd;
    private String akdpdt;
    private String akbill;
    private Double akplqt;
    private Double akctqt;
    private String aktrmc;
    private String akshpc;
    private String akport;
    private String akitnr;
    private Double aksapr;
    private String akltno;
    private Double aktrqt;
    private Double aktpkq;
    private Double akcawt;
    private Double akntwt;
    private String akbont;
    private String akoivn;
    private Double akpkam;
    private String aksntp;
    private String akcupo;
    private String akpono;
    private Double akctnf;
    private Double akctnt;
    private Double akctnq;
    private Double akpltq;
    private String akfrgc;
    private String akstat;
    private String akcpnr;
    private String akupdt;
    private String akcpdd;
    private Double akbasq;

    private Time login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;

}
