package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_if_fmts_mo_d {
    private int id;
    private String odcoce;//部門代碼
    private String odmonr;//SAP MO號碼
    private String odrtnr;//ROUING GROUP+COUNT
    private Double odopsq;//作業順序號碼
    private String odwoce;//工作站
    private String odctky;//CONTROL KEY
    private String odrseq;//SEQNO.
    private String odspsa;//線邊倉
    private String odflag;//標示
    private String odstat;//狀態
    private String odupsr;//更新操作員代碼
    private String odupdt;//更新時間


    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;


}
