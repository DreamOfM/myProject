package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Time;

@Data
public class Bnd_domestic_plan_ship {
    private int id;
    private String yyyymm;
    private String item_no;
    private Double ucns_verno;
    private Double plan_qty;
    private Double actual_qty;

    private Time login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;

}
