package com.tdk.txm_java.domain;

public class Ttajp {
    private String ajrlst;
    private String ajstmt;
    private String ajshpd;
    private String ajivnr;
    private String ajshpc;
    private Integer ajsnd1;
    private String ajtrmc;
    private Double ajcurr;
    private Double ajexrs;
    private String ajexrp;
    private String ajpkqt;
    private String ajpkad;
    private String ajpkaf;
    private String ajtctn;
    private Integer ajtnwt;
    private String ajtawt;
    private Integer ajivtp;
    private String ajdpdt;
    private Double ajbill;
    private Double ajport;
    private Double ajfrgc;
    private Double akplqt;

    public String getAjrlst() {
        return ajrlst;
    }

    public void setAjrlst(String ajrlst) {
        this.ajrlst = ajrlst;
    }

    public String getAjstmt() {
        return ajstmt;
    }

    public void setAjstmt(String ajstmt) {
        this.ajstmt = ajstmt;
    }

    public String getAjshpd() {
        return ajshpd;
    }

    public void setAjshpd(String ajshpd) {
        this.ajshpd = ajshpd;
    }

    public String getAjivnr() {
        return ajivnr;
    }

    public void setAjivnr(String ajivnr) {
        this.ajivnr = ajivnr;
    }

    public String getAjshpc() {
        return ajshpc;
    }

    public void setAjshpc(String ajshpc) {
        this.ajshpc = ajshpc;
    }

    public Integer getAjsnd1() {
        return ajsnd1;
    }

    public void setAjsnd1(Integer ajsnd1) {
        this.ajsnd1 = ajsnd1;
    }

    public String getAjtrmc() {
        return ajtrmc;
    }

    public void setAjtrmc(String ajtrmc) {
        this.ajtrmc = ajtrmc;
    }

    public Double getAjcurr() {
        return ajcurr;
    }

    public void setAjcurr(Double ajcurr) {
        this.ajcurr = ajcurr;
    }

    public Double getAjexrs() {
        return ajexrs;
    }

    public void setAjexrs(Double ajexrs) {
        this.ajexrs = ajexrs;
    }

    public String getAjexrp() {
        return ajexrp;
    }

    public void setAjexrp(String ajexrp) {
        this.ajexrp = ajexrp;
    }

    public String getAjpkqt() {
        return ajpkqt;
    }

    public void setAjpkqt(String ajpkqt) {
        this.ajpkqt = ajpkqt;
    }

    public String getAjpkad() {
        return ajpkad;
    }

    public void setAjpkad(String ajpkad) {
        this.ajpkad = ajpkad;
    }

    public String getAjpkaf() {
        return ajpkaf;
    }

    public void setAjpkaf(String ajpkaf) {
        this.ajpkaf = ajpkaf;
    }

    public String getAjtctn() {
        return ajtctn;
    }

    public void setAjtctn(String ajtctn) {
        this.ajtctn = ajtctn;
    }

    public Integer getAjtnwt() {
        return ajtnwt;
    }

    public void setAjtnwt(Integer ajtnwt) {
        this.ajtnwt = ajtnwt;
    }

    public String getAjtawt() {
        return ajtawt;
    }

    public void setAjtawt(String ajtawt) {
        this.ajtawt = ajtawt;
    }

    public Integer getAjivtp() {
        return ajivtp;
    }

    public void setAjivtp(Integer ajivtp) {
        this.ajivtp = ajivtp;
    }

    public String getAjdpdt() {
        return ajdpdt;
    }

    public void setAjdpdt(String ajdpdt) {
        this.ajdpdt = ajdpdt;
    }

    public Double getAjbill() {
        return ajbill;
    }

    public void setAjbill(Double ajbill) {
        this.ajbill = ajbill;
    }

    public Double getAjport() {
        return ajport;
    }

    public void setAjport(Double ajport) {
        this.ajport = ajport;
    }

    public Double getAjfrgc() {
        return ajfrgc;
    }

    public void setAjfrgc(Double ajfrgc) {
        this.ajfrgc = ajfrgc;
    }

    public Double getAkplqt() {
        return akplqt;
    }

    public void setAkplqt(Double akplqt) {
        this.akplqt = akplqt;
    }

    @Override
    public String toString() {
        return "Ttajp{" +
                "ajrlst='" + ajrlst + '\'' +
                ", ajstmt='" + ajstmt + '\'' +
                ", ajshpd='" + ajshpd + '\'' +
                ", ajivnr='" + ajivnr + '\'' +
                ", ajshpc='" + ajshpc + '\'' +
                ", ajsnd1=" + ajsnd1 +
                ", ajtrmc='" + ajtrmc + '\'' +
                ", ajcurr=" + ajcurr +
                ", ajexrs=" + ajexrs +
                ", ajexrp='" + ajexrp + '\'' +
                ", ajpkqt='" + ajpkqt + '\'' +
                ", ajpkad='" + ajpkad + '\'' +
                ", ajpkaf='" + ajpkaf + '\'' +
                ", ajtctn='" + ajtctn + '\'' +
                ", ajtnwt=" + ajtnwt +
                ", ajtawt='" + ajtawt + '\'' +
                ", ajivtp=" + ajivtp +
                ", ajdpdt='" + ajdpdt + '\'' +
                ", ajbill=" + ajbill +
                ", ajport=" + ajport +
                ", ajfrgc=" + ajfrgc +
                ", akplqt=" + akplqt +
                '}';
    }
}
