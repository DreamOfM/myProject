package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_if_fsap_routing {
    private int id;
    private String rdgrpn;//GROUP NO.
    private String rdgrpc;//GROUP COUNTER
    private String rdortn;//OLD TASK LIST
    private String rditnr;//ITEM NO.
    private String rdopsq;//OPERATION SEQUENCE NO
    private String rdopdc;//OPERATION DESC.
    private String rdwknr;//WORK CENTER NO.
    private String rdctrk;//CONTROL KEY
    private String rdstdt;//EFFECTIVE DATE
    private String rdltdt;//EXPIRY DATE
    private String rdnbom;//NO-BOM FLAG
    private String rddltf;//DELETE FALG
    private String rdtopd;//OPERATION DESC.
    private String rdstat;//0-SEND 1-COMPLETED
    private Double rdupdt;//UPDATE TEIME

    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

}
