package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_export_proforma_invoice {
    private String internal_number;
    private String declare_date;
    private Double pieces;
    private String premium;
    private Double total_packing_qty;
    private Double total_amt_foreign;
    private String currency;
    private String port_name;
    private String freight;
    private String invoice_no;
    private Double invoice_pieces;
    private String gds_nm;
    private Double packing_qty;
    private String unit;
    private Double price;
    private Double amt_foreign;

}
