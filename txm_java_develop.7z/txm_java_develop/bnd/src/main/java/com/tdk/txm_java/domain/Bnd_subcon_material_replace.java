package com.tdk.txm_java.domain;

import lombok.Data;

import java.util.Date;


@Data
public class Bnd_subcon_material_replace {
    private  int id;
    private String operation_no;//委外流水号
    private String vendor_code;//協力廠代碼
    private String psa_code;//PSA
    private String operation_type;//委外類型
    private String item_no;//製品品名
    private String material_no;//材料品名
    private String material_replace;//替代料品名
    private Double standard_cost;//單價
    private String um_incoming_outgoing;//在庫單位
    private String item_description_dbcs;//中文品名
    private String apply_date;//申請日期
    private String date_from;//申請開始日期
    private String date_to;//申請結束日期



    private Date login_time;
    private String login_oid;
    private Date update_time;
    private String update_oid;
    private String update_program;

}
