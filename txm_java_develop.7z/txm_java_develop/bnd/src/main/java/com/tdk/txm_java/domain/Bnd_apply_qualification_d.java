package com.tdk.txm_java.domain;

public class Bnd_apply_qualification_d {
    private int id;
    private String file_no;
    private String data_state;
    private String seq_no;
    private String expiration_flag;
    private Double g_no;
    private String mtno;
    private Double chg_tms_cnt;
    private String gdecd;
    private String gds_nm;
    private String modf_markcd;
    private String rmk;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFile_no() {
        return file_no;
    }

    public void setFile_no(String file_no) {
        this.file_no = file_no;
    }

    public String getData_state() {
        return data_state;
    }

    public void setData_state(String data_state) {
        this.data_state = data_state;
    }

    public String getSeq_no() {
        return seq_no;
    }

    public void setSeq_no(String seq_no) {
        this.seq_no = seq_no;
    }

    public String getExpiration_flag() {
        return expiration_flag;
    }

    public void setExpiration_flag(String expiration_flag) {
        this.expiration_flag = expiration_flag;
    }

    public Double getG_no() {
        return g_no;
    }

    public void setG_no(Double g_no) {
        this.g_no = g_no;
    }

    public String getMtno() {
        return mtno;
    }

    public void setMtno(String mtno) {
        this.mtno = mtno;
    }

    public Double getChg_tms_cnt() {
        return chg_tms_cnt;
    }

    public void setChg_tms_cnt(Double chg_tms_cnt) {
        this.chg_tms_cnt = chg_tms_cnt;
    }

    public String getGdecd() {
        return gdecd;
    }

    public void setGdecd(String gdecd) {
        this.gdecd = gdecd;
    }

    public String getGds_nm() {
        return gds_nm;
    }

    public void setGds_nm(String gds_nm) {
        this.gds_nm = gds_nm;
    }

    public String getModf_markcd() {
        return modf_markcd;
    }

    public void setModf_markcd(String modf_markcd) {
        this.modf_markcd = modf_markcd;
    }

    public String getRmk() {
        return rmk;
    }

    public void setRmk(String rmk) {
        this.rmk = rmk;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    @Override
    public String toString() {
        return "Bnd_apply_qualification_d{" +
                "id=" + id +
                ", file_no='" + file_no + '\'' +
                ", data_state='" + data_state + '\'' +
                ", seq_no='" + seq_no + '\'' +
                ", expiration_flag='" + expiration_flag + '\'' +
                ", g_no=" + g_no +
                ", mtno='" + mtno + '\'' +
                ", chg_tms_cnt=" + chg_tms_cnt +
                ", gdecd='" + gdecd + '\'' +
                ", gds_nm='" + gds_nm + '\'' +
                ", modf_markcd='" + modf_markcd + '\'' +
                ", rmk='" + rmk + '\'' +
                ", login_time='" + login_time + '\'' +
                ", login_oid='" + login_oid + '\'' +
                ", update_time='" + update_time + '\'' +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                '}';
    }
}
