package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_import_custom_regulatory {
    private int id;
    private String ccc_code;//商編
    /**
     * wangfengcai
     * 因为上载时出现，这个字段的值全部变成0.0,所以改成字符型
     */
    private String regulatory_credentials_code;//監管證件號碼
    private String login_time;//登陆时间login_time
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;
    
}
