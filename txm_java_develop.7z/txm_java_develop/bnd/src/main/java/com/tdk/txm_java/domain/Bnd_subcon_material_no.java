package com.tdk.txm_java.domain;

import lombok.Data;

import java.util.Date;


@Data
public class Bnd_subcon_material_no {
    private  int id;
    private String operation_no;//委外流水号
    private String mrp_code;//ＭＲＰ基準代
    private String psa_code;//PSA
    private String vendor_code;//供應商代碼
    private String operation_type;//委外类型
    private String item_no;//品名代碼
    private Double operation_quantity ;//委外數量
    private Double operation_sequence_no;//作業順序號碼
    private String material_no;//材料品名
    private Double material_quantity;//材料用量
    private Double standard_cost;//材料单价
    private String material_type;//材料類型
    private String apply_date;//申請日期
    private String date_from;//開始日期
    private String date_to;//結束日期


    private Date login_time;
    private String login_oid;
    private Date update_time;
    private String update_oid;
    private String update_program;

}
