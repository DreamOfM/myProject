package com.tdk.txm_java.domain;

import java.sql.Time;

public class Bnd_domestic_controller {
    private int id;
    private String type;
    private String month;


    private Time login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public Time getLogin_time() {
        return login_time;
    }

    public void setLogin_time(Time login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public Time getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(Time update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    @Override
    public String toString() {
        return "Bnd_domestic_controller{" +
                "id=" + id +
                ", type='" + type + '\'' +
                ", month='" + month + '\'' +
                ", login_time=" + login_time +
                ", login_oid='" + login_oid + '\'' +
                ", update_time=" + update_time +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                '}';
    }
}
