package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_export_audit_ok {
    private int id;
    private String premium;
    private String shipped_date;
    private String invoice_no;
    private String transport_code;
    private String shipping_condition_code;
    private String forwarder_code;
    private String goods_type;
    private String invoice_type;
    private String tax_code2;
    private String audit;
    private String audit_supervisor;
    private String master_airway_bill;
    private String special_relationship;
    private String price_effect;
    private String royalties;
    private String internal_number;
    private String audit_comfirm;
    private String country_code;
    private String terms_trade;
    private String destination_country;
    private String ship_to_name1_dbcs;
    private Double packing_qty;
    private String unit;
    private Double total_netwet;
    private Double gross_weight;
    private Double amt_foreign;
    private String currency;
    private String packing_volume;
    private Double pieces;
    private Double invoice_pieces;
    private String packing_code;
    private String so_no;
    private String bond_type;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;
    private String declare_date;
    private Double total_packing_qty;
    private Double total_amt_foreign;
    private String port_name;
    private String freight;
    private String gds_nm;
    private Double price;
}
