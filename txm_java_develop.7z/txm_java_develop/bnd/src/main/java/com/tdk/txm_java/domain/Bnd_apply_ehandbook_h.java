package com.tdk.txm_java.domain;

import lombok.Data;

import java.util.Date;


public class Bnd_apply_ehandbook_h {
    private int id;
    private String file_no ;
    private String data_state ;
    private String seq_no ;
    private String ems_no ;
    private Double chg_tms_cnt ;
    private String etps_preent_no ;
    private String bizop_etps_sccd ;
    private String bizop_etpsno ;
    private String bizop_etps_nm ;
    private String prcs_etps_sccd ;
    private String prcs_etpsno ;
    private String prcs_etps_nm ;
    private String dec_dm ;
    private String dcl_etpsno;
    private String dcl_etps_nm;
    private String dcl_etps_typecd ;
    private String input_code;
    private String input_credit_code;
    private String input_name;
    private String ems_type;
    private Date finish_valid_time ;
    private String dcl_typecd;
    private Double actl_imp_total_amt;
    private Double actl_exp_total_amt;
    private String apcret_not;
    private String netwk_etps_arcrp_no;
    private Double max_tovr_amt;
    private Date dcl_time;
    private Date rcnt_vclr_time;
    private Date input_date ;
    private String ucns_dcl_segcd;
    private Double vclr_prid_val;
    private String ucns_verno_cntr_fla;
    private Double material_count;
    private Double endprd_item_cnt;
    private String rmk ;
    private String master_cuscd;
    private Double imp_max_account;
    private String vclr_typecd;
    private String usagetypecd;
    private String putrec_appr_time ;
    private String cash_payment_date;
    private String exe_markcd  ;
    private String ehvtyp;
    private Date login_time;
    private String login_oid;
    private Date update_time;
    private String update_oid;
    private String update_program;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFile_no() {
        return file_no;
    }

    public void setFile_no(String file_no) {
        this.file_no = file_no;
    }

    public String getData_state() {
        return data_state;
    }

    public void setData_state(String data_state) {
        this.data_state = data_state;
    }

    public String getSeq_no() {
        return seq_no;
    }

    public void setSeq_no(String seq_no) {
        this.seq_no = seq_no;
    }

    public String getEms_no() {
        return ems_no;
    }

    public void setEms_no(String ems_no) {
        this.ems_no = ems_no;
    }

    public Double getChg_tms_cnt() {
        return chg_tms_cnt;
    }

    public void setChg_tms_cnt(Double chg_tms_cnt) {
        this.chg_tms_cnt = chg_tms_cnt;
    }

    public String getEtps_preent_no() {
        return etps_preent_no;
    }

    public void setEtps_preent_no(String etps_preent_no) {
        this.etps_preent_no = etps_preent_no;
    }

    public String getBizop_etps_sccd() {
        return bizop_etps_sccd;
    }

    public void setBizop_etps_sccd(String bizop_etps_sccd) {
        this.bizop_etps_sccd = bizop_etps_sccd;
    }

    public String getBizop_etpsno() {
        return bizop_etpsno;
    }

    public void setBizop_etpsno(String bizop_etpsno) {
        this.bizop_etpsno = bizop_etpsno;
    }

    public String getBizop_etps_nm() {
        return bizop_etps_nm;
    }

    public void setBizop_etps_nm(String bizop_etps_nm) {
        this.bizop_etps_nm = bizop_etps_nm;
    }

    public String getPrcs_etps_sccd() {
        return prcs_etps_sccd;
    }

    public void setPrcs_etps_sccd(String prcs_etps_sccd) {
        this.prcs_etps_sccd = prcs_etps_sccd;
    }

    public String getPrcs_etpsno() {
        return prcs_etpsno;
    }

    public void setPrcs_etpsno(String prcs_etpsno) {
        this.prcs_etpsno = prcs_etpsno;
    }

    public String getPrcs_etps_nm() {
        return prcs_etps_nm;
    }

    public void setPrcs_etps_nm(String prcs_etps_nm) {
        this.prcs_etps_nm = prcs_etps_nm;
    }

    public String getDec_dm() {
        return dec_dm;
    }

    public void setDec_dm(String dec_dm) {
        this.dec_dm = dec_dm;
    }

    public String getDcl_etpsno() {
        return dcl_etpsno;
    }

    public void setDcl_etpsno(String dcl_etpsno) {
        this.dcl_etpsno = dcl_etpsno;
    }

    public String getDcl_etps_nm() {
        return dcl_etps_nm;
    }

    public void setDcl_etps_nm(String dcl_etps_nm) {
        this.dcl_etps_nm = dcl_etps_nm;
    }

    public String getDcl_etps_typecd() {
        return dcl_etps_typecd;
    }

    public void setDcl_etps_typecd(String dcl_etps_typecd) {
        this.dcl_etps_typecd = dcl_etps_typecd;
    }

    public String getInput_code() {
        return input_code;
    }

    public void setInput_code(String input_code) {
        this.input_code = input_code;
    }

    public String getInput_credit_code() {
        return input_credit_code;
    }

    public void setInput_credit_code(String input_credit_code) {
        this.input_credit_code = input_credit_code;
    }

    public String getInput_name() {
        return input_name;
    }

    public void setInput_name(String input_name) {
        this.input_name = input_name;
    }

    public String getEms_type() {
        return ems_type;
    }

    public void setEms_type(String ems_type) {
        this.ems_type = ems_type;
    }

    public Date getFinish_valid_time() {
        return finish_valid_time;
    }

    public void setFinish_valid_time(Date finish_valid_time) {
        this.finish_valid_time = finish_valid_time;
    }

    public String getDcl_typecd() {
        return dcl_typecd;
    }

    public void setDcl_typecd(String dcl_typecd) {
        this.dcl_typecd = dcl_typecd;
    }

    public Double getActl_imp_total_amt() {
        return actl_imp_total_amt;
    }

    public void setActl_imp_total_amt(Double actl_imp_total_amt) {
        this.actl_imp_total_amt = actl_imp_total_amt;
    }

    public Double getActl_exp_total_amt() {
        return actl_exp_total_amt;
    }

    public void setActl_exp_total_amt(Double actl_exp_total_amt) {
        this.actl_exp_total_amt = actl_exp_total_amt;
    }

    public String getApcret_not() {
        return apcret_not;
    }

    public void setApcret_not(String apcret_not) {
        this.apcret_not = apcret_not;
    }

    public String getNetwk_etps_arcrp_no() {
        return netwk_etps_arcrp_no;
    }

    public void setNetwk_etps_arcrp_no(String netwk_etps_arcrp_no) {
        this.netwk_etps_arcrp_no = netwk_etps_arcrp_no;
    }

    public Double getMax_tovr_amt() {
        return max_tovr_amt;
    }

    public void setMax_tovr_amt(Double max_tovr_amt) {
        this.max_tovr_amt = max_tovr_amt;
    }

    public Date getDcl_time() {
        return dcl_time;
    }

    public void setDcl_time(Date dcl_time) {
        this.dcl_time = dcl_time;
    }

    public Date getRcnt_vclr_time() {
        return rcnt_vclr_time;
    }

    public void setRcnt_vclr_time(Date rcnt_vclr_time) {
        this.rcnt_vclr_time = rcnt_vclr_time;
    }

    public Date getInput_date() {
        return input_date;
    }

    public void setInput_date(Date input_date) {
        this.input_date = input_date;
    }

    public String getUcns_dcl_segcd() {
        return ucns_dcl_segcd;
    }

    public void setUcns_dcl_segcd(String ucns_dcl_segcd) {
        this.ucns_dcl_segcd = ucns_dcl_segcd;
    }

    public Double getVclr_prid_val() {
        return vclr_prid_val;
    }

    public void setVclr_prid_val(Double vclr_prid_val) {
        this.vclr_prid_val = vclr_prid_val;
    }

    public String getUcns_verno_cntr_fla() {
        return ucns_verno_cntr_fla;
    }

    public void setUcns_verno_cntr_fla(String ucns_verno_cntr_fla) {
        this.ucns_verno_cntr_fla = ucns_verno_cntr_fla;
    }

    public Double getMaterial_count() {
        return material_count;
    }

    public void setMaterial_count(Double material_count) {
        this.material_count = material_count;
    }

    public Double getEndprd_item_cnt() {
        return endprd_item_cnt;
    }

    public void setEndprd_item_cnt(Double endprd_item_cnt) {
        this.endprd_item_cnt = endprd_item_cnt;
    }

    public String getRmk() {
        return rmk;
    }

    public void setRmk(String rmk) {
        this.rmk = rmk;
    }

    public String getMaster_cuscd() {
        return master_cuscd;
    }

    public void setMaster_cuscd(String master_cuscd) {
        this.master_cuscd = master_cuscd;
    }

    public Double getImp_max_account() {
        return imp_max_account;
    }

    public void setImp_max_account(Double imp_max_account) {
        this.imp_max_account = imp_max_account;
    }

    public String getVclr_typecd() {
        return vclr_typecd;
    }

    public void setVclr_typecd(String vclr_typecd) {
        this.vclr_typecd = vclr_typecd;
    }

    public String getUsagetypecd() {
        return usagetypecd;
    }

    public void setUsagetypecd(String usagetypecd) {
        this.usagetypecd = usagetypecd;
    }

    public String getPutrec_appr_time() {
        return putrec_appr_time;
    }

    public void setPutrec_appr_time(String putrec_appr_time) {
        this.putrec_appr_time = putrec_appr_time;
    }

    public String getCash_payment_date() {
        return cash_payment_date;
    }

    public void setCash_payment_date(String cash_payment_date) {
        this.cash_payment_date = cash_payment_date;
    }

    public String getExe_markcd() {
        return exe_markcd;
    }

    public void setExe_markcd(String exe_markcd) {
        this.exe_markcd = exe_markcd;
    }

    public String getEhvtyp() {
        return ehvtyp;
    }

    public void setEhvtyp(String ehvtyp) {
        this.ehvtyp = ehvtyp;
    }

    public Date getLogin_time() {
        return login_time;
    }

    public void setLogin_time(Date login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public Date getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(Date update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    @Override
    public String toString() {
        return "Bnd_apply_ehandbook_h{" +
                "id=" + id +
                ", file_no='" + file_no + '\'' +
                ", data_state='" + data_state + '\'' +
                ", seq_no='" + seq_no + '\'' +
                ", ems_no='" + ems_no + '\'' +
                ", chg_tms_cnt=" + chg_tms_cnt +
                ", etps_preent_no='" + etps_preent_no + '\'' +
                ", bizop_etps_sccd='" + bizop_etps_sccd + '\'' +
                ", bizop_etpsno='" + bizop_etpsno + '\'' +
                ", bizop_etps_nm='" + bizop_etps_nm + '\'' +
                ", prcs_etps_sccd='" + prcs_etps_sccd + '\'' +
                ", prcs_etpsno='" + prcs_etpsno + '\'' +
                ", prcs_etps_nm='" + prcs_etps_nm + '\'' +
                ", dec_dm='" + dec_dm + '\'' +
                ", dcl_etpsno='" + dcl_etpsno + '\'' +
                ", dcl_etps_nm='" + dcl_etps_nm + '\'' +
                ", dcl_etps_typecd='" + dcl_etps_typecd + '\'' +
                ", input_code='" + input_code + '\'' +
                ", input_credit_code='" + input_credit_code + '\'' +
                ", input_name='" + input_name + '\'' +
                ", ems_type='" + ems_type + '\'' +
                ", finish_valid_time=" + finish_valid_time +
                ", dcl_typecd='" + dcl_typecd + '\'' +
                ", actl_imp_total_amt=" + actl_imp_total_amt +
                ", actl_exp_total_amt=" + actl_exp_total_amt +
                ", apcret_not='" + apcret_not + '\'' +
                ", netwk_etps_arcrp_no='" + netwk_etps_arcrp_no + '\'' +
                ", max_tovr_amt=" + max_tovr_amt +
                ", dcl_time=" + dcl_time +
                ", rcnt_vclr_time=" + rcnt_vclr_time +
                ", input_date=" + input_date +
                ", ucns_dcl_segcd='" + ucns_dcl_segcd + '\'' +
                ", vclr_prid_val=" + vclr_prid_val +
                ", ucns_verno_cntr_fla='" + ucns_verno_cntr_fla + '\'' +
                ", material_count=" + material_count +
                ", endprd_item_cnt=" + endprd_item_cnt +
                ", rmk='" + rmk + '\'' +
                ", master_cuscd='" + master_cuscd + '\'' +
                ", imp_max_account=" + imp_max_account +
                ", vclr_typecd='" + vclr_typecd + '\'' +
                ", usagetypecd='" + usagetypecd + '\'' +
                ", putrec_appr_time='" + putrec_appr_time + '\'' +
                ", cash_payment_date='" + cash_payment_date + '\'' +
                ", exe_markcd='" + exe_markcd + '\'' +
                ", ehvtyp='" + ehvtyp + '\'' +
                ", login_time=" + login_time +
                ", login_oid='" + login_oid + '\'' +
                ", update_time=" + update_time +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                '}';
    }
}
