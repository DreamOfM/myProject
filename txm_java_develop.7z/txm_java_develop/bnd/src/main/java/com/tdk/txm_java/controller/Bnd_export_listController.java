package com.tdk.txm_java.controller;


import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tdk.txm_java.dao.IBnd_export_invoice_dDao;
import com.tdk.txm_java.domain.*;
import com.tdk.txm_java.service.*;
import com.tdk.txm_java.utils.DateUtils;
import com.tdk.txm_java.utils.MathUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.DecimalFormat;
import java.util.*;

@Controller
@RequestMapping("/bnd_export_list")
public class Bnd_export_listController {
    @Autowired
    private IBnd_export_invoice_dDao iBnd_export_invoice_dDao;
    @Autowired
    private IBnd_export_invoice_hService iBnd_export_invoice_hService;
    @Autowired
    private IBnd_export_invoice_batchService iBnd_export_invoice_batchService;
    @Autowired
    private IBnd_master_customerService iBnd_master_customerService;
    @Autowired
    private IBnd_master_invt_dService iBnd_master_invt_dService;
    @Autowired
    private IBnd_master_trade_transactionService iBnd_master_trade_transactionService;
    @Autowired
    private IBnd_master_ehandbook_dService iBnd_master_ehandbook_dService;
    @Autowired
    private IBnd_master_mo_versionService iBnd_master_mo_versionService;
    @Autowired
    private IBnd_export_list_convertService iBnd_export_list_convertService;
    @Autowired
    private IBnd_master_itemService iBnd_master_itemService;
    @Autowired
    private ICom_serialnumService iCom_serialnumService;
    @Autowired
    IBnd_master_ehandbook_hService iBnd_master_ehandbook_hService;
    @Autowired
    IBnd_master_invt_hService iBnd_master_invt_hService;
    @Autowired
    IBnd_export_return_replacementService iBnd_export_return_replacementService;
    @Autowired
    IBnd_master_country_codeService iBnd_master_country_codeService;
    @Autowired
    IBnd_master_currency_codeService iBnd_master_currency_codeService;
    @Autowired
    IBnd_master_unit_codeService iBnd_master_unit_codeService;
    @Autowired
    IBnd_master_declare_companyService iBnd_master_declare_companyService;

//    @RequestMapping("/save")
//    public void save(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception {
//        //取出前端传回的所有数据
//        Map map = request.getParameterMap();
//        //测试前端数据是否传送过来
//        System.out.println(map.entrySet().toString() + "数据已传过来");
//        Map<String, String> hashMap = new HashMap<>();
//        Set<String> set = map.keySet();
//
//        String[] vals1 = (String[]) map.get("mdfm");
//        String[] vals2 = (String[]) map.get("endprd_gds_mtno");
//        String[] vals3 = (String[]) map.get("ucns_verno");
//
//        if (vals1[0].equals("修改")) {
//            iBnd_master_bomService.deleteByitem_ver(vals2[0], Double.parseDouble(vals3[0]));
//        }
//
//        int b = 0;
//        int c = 0;
//        Bnd_master_bom bnd_master_bom = new Bnd_master_bom();
//        while (1 == 1) {
//            for (String name1 : set) {
//                String[] vals = (String[]) map.get(name1);
//                c = vals.length;
//                hashMap.put(name1, vals[b]);
//            }
//
//            try {
//                BeanUtils.populate(bnd_master_bom, hashMap);
//            } catch (IllegalAccessException e) {
//                e.printStackTrace();
//            } catch (InvocationTargetException e) {
//                e.printStackTrace();
//            }
//            //添加一个判断，如果为空值或者没有输入则不往数据库里插数据
//            if (bnd_master_bom.getMtpck_gds_mtno().equals(null) || bnd_master_bom.getMtpck_gds_mtno().equals("")) {
//                b++;
//                if (b == c) break;
//                continue;
//            }
//            String username = (String) httpSession.getAttribute("username");
//            bnd_master_bom.setUpdate_oid(username);
//            bnd_master_bom.setLogin_oid(username);
//            bnd_master_bom.setUpdate_program("/bnd_export_list/save.do");
//            bnd_master_bom.setData_state("1");
//            bnd_master_bom.setUcns_dcl_stucd("2");
//            bnd_master_bom.setModf_markcd("3");
//            bnd_master_bom.setBond_mtpck_prpr(100.0);
//
//            iBnd_master_bomService.save(bnd_master_bom);
//            b++;
//            if (b == c) break;
//        }
//    }

    //    检查发票
    @RequestMapping("/check.do")
    public void check(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception, IOException, JsonGenerationException, JsonMappingException {
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();

        // check body
        int b = 0;   //第几笔记录
        int c = 0;   //total
        List<String> invoice_list = new ArrayList<>();
        String trade_code = "";
        String currency_code = "";

        while (true) {
            for (String name1 : set) {
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                hashMap.put(name1, vals[b]);
            }

            Bnd_export_invoice_h bnd_export_invoice_h = new Bnd_export_invoice_h();

            try {
                BeanUtils.populate(bnd_export_invoice_h, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }


            if (!"".equals(bnd_export_invoice_h.getInvoice_no())) {
//            检查发票号码是否正确
                List<Bnd_export_invoice_d> invoice_d = iBnd_export_invoice_dDao.findByInvoice_no(bnd_export_invoice_h.getInvoice_no());
                List<Bnd_export_invoice_batch> invoice_batch = iBnd_export_invoice_batchService.findByInvoice_no(bnd_export_invoice_h.getInvoice_no());
                Bnd_export_invoice_h invoice_h = iBnd_export_invoice_hService.findByInvoice_no(bnd_export_invoice_h.getInvoice_no());
                List<Bnd_master_invt_d> invt_d = iBnd_master_invt_dService.findByInvoice_no(bnd_export_invoice_h.getInvoice_no());
                if (invoice_d.size() == 0) {
                    info.setErrorMsg("发票号码错误");
                    String errLine = String.valueOf(b);
                    errorList.add("invoice_no" + errLine);
                    info.setFlag(false);
                } else {
                    Bnd_master_customer customer_k = iBnd_master_customerService.findByCustomer_no(invoice_d.get(0).getCustomer_no());
                    if (customer_k != null) {
                        if ("D".equals(customer_k.getInvoice_type())) {
                            info.setErrorMsg("不能为内销顾客");
                            String errLine = String.valueOf(b);
                            errorList.add("invoice_no" + errLine);
                            info.setFlag(false);
                        }
                    }

                    for (Bnd_export_invoice_d invoice_d1 : invoice_d) {
                        Bnd_master_ehandbook_d ehandbook_d = iBnd_master_ehandbook_dService.findByItem_no(invoice_d1.getItem_no());
                        if (ehandbook_d == null) {
                            info.setErrorMsg(invoice_d1.getItem_no()+"品名未备案");
                            String errLine = String.valueOf(b);
                            errorList.add("invoice_no" + errLine);
                            info.setFlag(false);
                        }
                    }
                }

                if (invoice_batch.size() > 0) {
                    if (!"01".equals(invoice_batch.get(0).getBond_type())) {
                        info.setErrorMsg("非保税");
                        String errLine = String.valueOf(b);
                        errorList.add("invoice_no" + errLine);
                        info.setFlag(false);
                    }

                    for (Bnd_export_invoice_batch invoice_batch1 : invoice_batch) {
                        Bnd_master_mo_version mo_version = iBnd_master_mo_versionService.findByMo_item(invoice_batch1.getLot_no(), invoice_batch1.getItem_no());
                        if (mo_version == null) {
                            info.setErrorMsg(invoice_batch1.getLot_no()+"无版本");
                            String errLine = String.valueOf(b);
                            errorList.add("invoice_no" + errLine);
                            info.setFlag(false);
                        } else if (mo_version.equals(0.0)) {
                            info.setErrorMsg(invoice_batch1.getLot_no()+"无版本");
                            String errLine = String.valueOf(b);
                            errorList.add("invoice_no" + errLine);
                            info.setFlag(false);
                        }
                    }
                }

                if (invoice_h != null) {
                    Bnd_master_customer customer_j = iBnd_master_customerService.findByCustomer_no(invoice_h.getStatement_customer_no());
                    if (customer_j != null) {
                        if ("E".equals(customer_j.getInvoice_type()) && "B".equals(customer_j.getTax_code2())) {
                            info.setErrorMsg("不能为结转顾客");
                            String errLine = String.valueOf(b);
                            errorList.add("invoice_no" + errLine);
                            info.setFlag(false);
                        }
                    }
                    Bnd_master_trade_transaction trade_transaction = iBnd_master_trade_transactionService.findByTermsTrade(invoice_h.getTerms_trade());
                    String customs_import_code = "";
                    if (trade_transaction == null) {
                        customs_import_code = "XXX";
                    } else {
                        customs_import_code = trade_transaction.getCustoms_import_code();
                        if (!"".equals(trade_code) && !customs_import_code.equals(trade_code)) {
                            info.setErrorMsg("成交方式不一致");
                            String errLine = String.valueOf(b);
                            errorList.add("invoice_no" + errLine);
                            info.setFlag(false);
                        }
                    }

//                    if (!"".equals(currency_code) && !invoice_h.getCurrency().equals(currency_code)) {
//                        info.setErrorMsg("币别不一致");
//                        String errLine = String.valueOf(b);
//                        errorList.add("invoice_no" + errLine);
//                        info.setFlag(false);
//                    }

                    trade_code = customs_import_code;
//                    currency_code = invoice_h.getCurrency();
                }

                if (invt_d.size() > 0) {
                    info.setErrorMsg("发票号码已生成清单");
                    String errLine = String.valueOf(b);
                    errorList.add("invoice_no" + errLine);
                    info.setFlag(false);
                }

//            检查发票号码是否重复
                if (invoice_list.contains(bnd_export_invoice_h.getInvoice_no())) {
                    info.setErrorMsg("发票号码重复");
                    String errLine = String.valueOf(b);
                    errorList.add("invoice_no" + errLine);
                    info.setFlag(false);
                } else {
                    invoice_list.add(bnd_export_invoice_h.getInvoice_no());
                }

            }

            b++;
            if (b == c) break;
        }

        info.setErrorList(errorList);
        //响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(), info);
    }


    @RequestMapping("/findinvoice_d")
    public ModelAndView create(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception {
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //测试前端数据是否传送过来
        System.out.println(map.entrySet().toString() + "数据已传过来");
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        iBnd_export_list_convertService.deleteAll();
        ModelAndView modelAndView = new ModelAndView();

        int b = 0;   //第几笔记录
        int c = 0;   //total

        while (true) {
            for (String name1 : set) {
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                hashMap.put(name1, vals[b]);
            }

            Bnd_export_invoice_h bnd_export_invoice_h = new Bnd_export_invoice_h();

            try {
                BeanUtils.populate(bnd_export_invoice_h, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }


            if (!"".equals(bnd_export_invoice_h.getInvoice_no())) {
                String invoive = bnd_export_invoice_h.getInvoice_no().substring(0, 3);
                List<Bnd_export_invoice_d> invoice_d = iBnd_export_invoice_dDao.findByInvoice_no(bnd_export_invoice_h.getInvoice_no());
//                Bnd_export_invoice_h invoice_h = iBnd_export_invoice_hService.findByInvoice_no(bnd_export_invoice_h.getInvoice_no());
//                List<Bnd_master_invt_d> invt_d = iBnd_master_invt_dService.findByInvoice_no(bnd_export_invoice_h.getInvoice_no());

                DecimalFormat dfn1 = new DecimalFormat("0.0");
                DecimalFormat dfn2 = new DecimalFormat("0.00");
                DecimalFormat dfn3 = new DecimalFormat("0.000");

                DecimalFormat dfn5 = new DecimalFormat("0.00000");
                DecimalFormat dfn6 = new DecimalFormat("0.000000");


//                    System.out.println(dfn.format(11356.970800000));
                if (!"RTX".equals(invoive)) {
                    for (Bnd_export_invoice_d invoice_d1 : invoice_d) {
                        Double pkqt = invoice_d1.getPacking_qty();
                        Double ntwt = invoice_d1.getNet_weigh();
                        Double ntwt1;
                        Double cawt;
                        Double qtyn;
                        cawt = invoice_d1.getCaton_weight();

                        int packing_serial = invoice_d1.getPacking_serial();
                        List<Bnd_export_invoice_batch> invoice_batch = iBnd_export_invoice_batchService.findByInv_seri(invoice_d1.getInvoice_no(), packing_serial);
                        if (invoice_batch.size() > 0) {
                            for (Bnd_export_invoice_batch invoice_batch1 : invoice_batch) {
                                Bnd_master_mo_version mo_version = iBnd_master_mo_versionService.findByMo_item(invoice_batch1.getLot_no(), invoice_batch1.getItem_no());
                                double ver = 0.0;
                                if (mo_version != null) {
                                    ver = mo_version.getUcns_verno();
                                }
                                pkqt = pkqt - invoice_batch1.getTransaction_qty();
                                if (pkqt.equals(0.0)) {
                                    ntwt1 = ntwt;
                                } else {
                                    ntwt1 = invoice_d1.getNet_weigh() * invoice_batch1.getTransaction_qty() / invoice_d1.getPacking_qty();
                                }
                                ntwt = ntwt - ntwt1;
                                cawt = cawt + ntwt1;
                                Bnd_export_list_convert list_convert1 = iBnd_export_list_convertService.findByInv_item_ver(invoice_d1.getInvoice_no(), invoice_d1.getItem_no(), ver);
//                               写进中间档
                                if (list_convert1 == null) {
                                    Bnd_export_list_convert list_convert = new Bnd_export_list_convert();
                                    list_convert.setUcns_verno(ver);
                                    list_convert.setInvoice_no(invoice_d1.getInvoice_no());
                                    list_convert.setItem_no(invoice_d1.getItem_no());
                                    list_convert.setEnterprise_declared_total_price(invoice_batch1.getTransaction_amt());
                                    list_convert.setNet_weigh(ntwt1);
                                    list_convert.setWeight(cawt);
                                    list_convert.setGross_weight(cawt - ntwt1);
                                    list_convert.setPacking_qty(invoice_batch1.getTransaction_qty());
                                    iBnd_export_list_convertService.save(list_convert);
                                } else {
                                    list_convert1.setEnterprise_declared_total_price(list_convert1.getEnterprise_declared_total_price() + invoice_batch1.getTransaction_amt());
                                    list_convert1.setNet_weigh(list_convert1.getNet_weigh() + ntwt1);
                                    list_convert1.setWeight(list_convert1.getWeight() + cawt);
                                    list_convert1.setGross_weight(list_convert1.getGross_weight() + cawt - ntwt1);
                                    list_convert1.setPacking_qty(list_convert1.getPacking_qty() + invoice_batch1.getTransaction_qty());
                                    iBnd_export_list_convertService.update(list_convert1);
                                }

                                Bnd_export_list_convert list_convert2 = iBnd_export_list_convertService.findByInv_item_ver(invoice_d1.getInvoice_no(), invoice_d1.getItem_no(), ver);
                                if (list_convert2 != null) {
                                    Bnd_master_item master_item = iBnd_master_itemService.findByitem_no(invoice_d1.getItem_no());
                                    if (master_item != null) {
//                                    计算监管数量
                                        if (!"KG".equals(master_item.getUm_incoming_outgoing()) && "KG".equals(master_item.getUm_physical_inventory())) {
                                            qtyn = list_convert2.getNet_weigh();
                                        } else if (master_item.getCf_physical_inventory().equals(0.0)) {
                                            qtyn = list_convert2.getPacking_qty() * 1;
                                        } else {
                                            qtyn = list_convert2.getPacking_qty() * master_item.getCf_physical_inventory();
                                        }
                                        list_convert2.setDeclare_qty(qtyn);
//                                        计算法定数量
                                        Bnd_master_ehandbook_d ehandbook_d = iBnd_master_ehandbook_dService.findByitem(invoice_d1.getItem_no());
                                        if (ehandbook_d != null) {
                                            if ("035".equals(ehandbook_d.getLawf_unitcd())) {
                                                list_convert2.setLegal_qty(list_convert2.getNet_weigh());
                                            } else {
                                                list_convert2.setLegal_qty(list_convert2.getDeclare_qty() * ehandbook_d.getLawf_unitcd_cf());
                                            }
                                            if (!ehandbook_d.getSecd_lawf_unitcd_cf().equals(0.0)) {
                                                if ("035".equals(ehandbook_d.getSecd_lawf_unitcd())) {
                                                    list_convert2.setSec_legal_qty(list_convert2.getNet_weigh());
                                                } else {
                                                    list_convert2.setSec_legal_qty(list_convert2.getDeclare_qty() * ehandbook_d.getSecd_lawf_unitcd_cf());
                                                }
                                            }
                                        } else {
                                            list_convert2.setLegal_qty(0.0);
                                            list_convert2.setSec_legal_qty(0.0);
                                        }
//                                        计算单价
                                        list_convert2.setUnit_price(list_convert2.getEnterprise_declared_total_price() / list_convert2.getDeclare_qty());
                                        iBnd_export_list_convertService.update(list_convert2);
                                        ntwt1 = 0.0;
                                        cawt = 0.0;
                                        qtyn = 0.0;
                                    }
                                }
                            }
                        }
                    }
                }
//                退货
                else {
                    double dcpa2 = 0.0;
                    double pkqt2 = 0.0;
                    double ntwt2 = 0.0;
                    double cawt2 = 0.0;
                    String item = "";
                    String invoice_no = "";
//                    dfn.format(11356.970800000)
                    for (Bnd_export_invoice_d invoice_d1 : invoice_d) {
                        double pkqt1 = 0.0;
                        double ntwt1 = 0.0;
                        double cawt1 = 0.0;
                        double dcpa1 = 0.0;

                        if (!item.equals("") && !invoice_d1.getItem_no().equals(item)) {
                            pkqt2 = 0.0;
                            ntwt2 = 0.0;
                            cawt2 = 0.0;
                            dcpa2 = 0.0;
                        }

                        dcpa1 = Double.parseDouble(dfn2.format(invoice_d1.getPacking_qty() * invoice_d1.getSampling_principle()));
                        dcpa2 = Double.parseDouble(dfn2.format(dcpa2 + dcpa1));
                        ntwt1 = Double.parseDouble(dfn3.format(invoice_d1.getNet_weigh()));
                        ntwt2 = Double.parseDouble(dfn3.format(ntwt2 + ntwt1));
                        cawt1 = Double.parseDouble(dfn3.format(invoice_d1.getCaton_weight()));
                        cawt2 = Double.parseDouble(dfn3.format(cawt2 + cawt1));
                        pkqt1 = Double.parseDouble(dfn5.format(invoice_d1.getPacking_qty()));
                        pkqt2 = Double.parseDouble(dfn5.format(pkqt2 + pkqt1));
                        //这个判断有问题，对于发票或者品番有变更才需要做
//                        if ((!invoice_d1.getItem_no().equals(item) || !invoice_d1.getInvoice_no().equals(invoice_no))) {
                        double qtyn2;
                        Bnd_master_item master_item = iBnd_master_itemService.findByitem_no(invoice_d1.getItem_no());
                        if (master_item != null) {
//                                计算监管数量
                            if (!"KG".equals(master_item.getUm_incoming_outgoing()) && "KG".equals(master_item.getUm_physical_inventory())) {
                                qtyn2 = ntwt2;
                            } else if (master_item.getCf_physical_inventory().equals(0.0)) {
                                qtyn2 = pkqt2 * 1;
                            } else {
                                qtyn2 = pkqt2 * master_item.getCf_physical_inventory();
                            }
                            Bnd_export_list_convert list_convert1 = iBnd_export_list_convertService.findByInv_item_ver(invoice_d1.getInvoice_no(), invoice_d1.getItem_no(), 0.0);
//                               写进中间档
                            if (list_convert1 == null) {
                                Bnd_export_list_convert list_convert = new Bnd_export_list_convert();
                                list_convert.setUcns_verno(0.0);
                                list_convert.setInvoice_no(invoice_d1.getInvoice_no());
                                list_convert.setItem_no(invoice_d1.getItem_no());
                                fuzhi(dcpa2, pkqt2, ntwt2, cawt2, invoice_d1, qtyn2, list_convert);
                                iBnd_export_list_convertService.save(list_convert);

                            } else {
                                fuzhi(dcpa2, pkqt2, ntwt2, cawt2, invoice_d1, qtyn2, list_convert1);
                                iBnd_export_list_convertService.update(list_convert1);
                            }
                        }
                        item = invoice_d1.getItem_no();
                    }
                }
            }
            b++;
            if (b == c) break;
        }

//        产生表头表体
        String internal_number = "";
        List<Bnd_export_list_convert> list = iBnd_export_list_convertService.findAll();
        String flag = "";
        DecimalFormat dfn0 = new DecimalFormat("0");
        if (list.size() > 0) {
            List<Bnd_export_invoice_d> ind = iBnd_export_invoice_dDao.findByInvoice_no(list.get(0).getInvoice_no());
            Bnd_master_item item = iBnd_master_itemService.findByitem_no(list.get(0).getItem_no());
            if (!"".equals(ind.get(0).getOriginal_invoice().trim()) && ind.get(0).getOriginal_invoice() != null) {
                flag = "N";
            }
            if ("4".equals(item.getItem_type())) {
                flag = "Y";
            }
        }
        internal_number = iCom_serialnumService.findAndUpdate("bnd", "export", "list", 5);
        Bnd_master_ehandbook_h bndMasterEhandbookH = iBnd_master_ehandbook_hService.findOne();
        String ems_no = bndMasterEhandbookH.getEms_no();
        //调用业务层方法去H2LHP(bnd_master_invt_h)查询
        Bnd_master_invt_h bndMasterInvtH1 = iBnd_master_invt_hService.findByInternalNumberAndEmsNo(internal_number, ems_no);
        List<Bnd_master_invt_d> bndMasterInvtDs = new ArrayList<>();
        Bnd_master_invt_h bndMasterInvtH = new Bnd_master_invt_h();

        if (bndMasterInvtH1 == null || "".equals(bndMasterInvtH1)) {

            bndMasterInvtH.setInternal_number(internal_number);
            bndMasterInvtH.setEms_no(ems_no);
            //核注单位
            bndMasterInvtH.setBizop_etpsno(bndMasterEhandbookH.getBizop_etpsno());
            bndMasterInvtH.setBizop_etps_nm(bndMasterEhandbookH.getBizop_etps_nm());
            bndMasterInvtH.setReceive_enterprise_no(bndMasterEhandbookH.getBizop_etpsno());
            bndMasterInvtH.setInput_code(bndMasterEhandbookH.getBizop_etpsno());
            bndMasterInvtH.setDcl_etpsno(bndMasterEhandbookH.getBizop_etpsno());

//            String internal_number_3 = internal_number.substring(0, 3);
            String date = DateUtils.date2String(new Date(), "yyyyMMdd");
//         料件成品标志&监管方式
            if ("".equals(flag)) {
                bndMasterInvtH.setPart_sign_code("E");
                bndMasterInvtH.setSupervision_mode_code("0715");
            } else if (flag.equals("Y")) {
                bndMasterInvtH.setPart_sign_code("I");
                bndMasterInvtH.setSupervision_mode_code("0664");
            } else {
                bndMasterInvtH.setPart_sign_code("E");
                bndMasterInvtH.setSupervision_mode_code("4600");
            }
            System.out.println("qoqo" + date);
            bndMasterInvtH.setDeclare_date(date);//当前日期
            bndMasterInvtH.setTransport_code("5");//运输方式
            bndMasterInvtH.setDeclare_port("3715");//申報海关
            bndMasterInvtH.setImport_export_gate("3715");//进出口岸
            bndMasterInvtH.setOrigin_destination_country("");//起运国
            bndMasterInvtH.setTrade_country("");//贸易国
            bndMasterInvtH.setCorresponding_customs_unit_code("");//报关单位
//                bndMasterInvtH.set(bndMasterEhandbookH.getDcl_etps_nm());//核关单位名

            for (Bnd_export_list_convert list1 : list) {
                Bnd_master_invt_d bnd_master_invt_d = new Bnd_master_invt_d();

                Bnd_master_item bnd_master_item = iBnd_master_itemService.findByitem_no(list1.getItem_no());
                Bnd_master_ehandbook_d bnd_master_ehandbook_d = iBnd_master_ehandbook_dService.findByitem(list1.getItem_no());
                bnd_master_invt_d.setCf_physical_inventory(bnd_master_item.getCf_physical_inventory());//监管换算系數  品名主档
                bnd_master_invt_d.setUm_incoming_outgoing(bnd_master_item.getUm_incoming_outgoing());//品名主档 在库单位
                bnd_master_invt_d.setUm_physical_inventory(bnd_master_item.getUm_physical_inventory());//监管单位
                bnd_master_invt_d.setItem_description_dbcs(bnd_master_item.getItem_description_dbcs()); //品名,品名主档

                bnd_master_invt_d.setUse_code("05");//用途代码
                bnd_master_invt_d.setExempting_method("3");//征免方式
                if (bnd_master_ehandbook_d != null) {
//                成品版本
                    if ("1".equals(bnd_master_ehandbook_d.getItem_type())) {
                        if ("N".equals(flag)) {
                            List<Bnd_export_return_replacement> bnd_export_return_replacement = iBnd_export_return_replacementService.findByfindByshiv_item(list1.getInvoice_no(), list1.getItem_no());
                            if (bnd_export_return_replacement.size() > 0) {
                                List<Bnd_master_invt_d> invt_d = iBnd_master_invt_dService.findByInvoice_item(bnd_export_return_replacement.get(0).getInvoice_no(), list1.getItem_no());
                                if (invt_d.size() > 0) {
                                    bnd_master_invt_d.setUcns_verno(invt_d.get(0).getUcns_verno());
                                }
                            }
                        } else {
                            bnd_master_invt_d.setUcns_verno(list1.getUcns_verno());
                        }
                    } else {
                        bnd_master_invt_d.setUcns_verno(0.0);
                    }
                    Bnd_export_invoice_h bnd_export_invoice_h = iBnd_export_invoice_hService.findByInvoice_no(list1.getInvoice_no());
//                   币别
                    if (bnd_export_invoice_h != null) {
                        if (!"".equals(bnd_export_invoice_h.getCurrency())) {
                            bnd_master_invt_d.setCurrency(bnd_export_invoice_h.getCurrency());
                        } else {
                            bnd_master_invt_d.setCurrency("RMB");
                        }
//                   国家代码
//                        复运出口
                        if ("Y".equals(flag)) {
                            List<Bnd_master_country_code> bnd_master_country_code = iBnd_master_country_codeService.findBycountry_code_2a(bnd_export_invoice_h.getProduct_country_code());
                            bnd_master_invt_d.setCountry_code(bnd_master_country_code.get(0).getCountry_code_5a());
                        } else {
                            bnd_master_invt_d.setCountry_code("142");
                        }
                    }
                    bnd_master_invt_d.setItem_spec(bnd_master_item.getItem_spec());//品名规格
                    bnd_master_invt_d.setDeclare_qty(list1.getDeclare_qty()); //申报数量
                    bnd_master_invt_d.setGood_code(bnd_master_ehandbook_d.getCcc_code());//商编
                    bnd_master_invt_d.setGross_weight(list1.getGross_weight());//毛重
                    bnd_master_invt_d.setInvoice_no(list1.getInvoice_no());//发票号码
                    bnd_master_invt_d.setItem_no(list1.getItem_no());//品番
                    bnd_master_invt_d.setNet_weight(list1.getNet_weigh());//净重
                    bnd_master_invt_d.setPacking_qty(list1.getPacking_qty());// 包装数量
                    bnd_master_invt_d.setEnterprise_declared_total_price(list1.getEnterprise_declared_total_price());//总金额
                    bnd_master_invt_d.setUnit_price(list1.getUnit_price());//HTOCP单价
                    bndMasterInvtDs.add(bnd_master_invt_d);
                }
            }

        } else {
            bndMasterInvtH = bndMasterInvtH1;
            //存在，H2LDP（bnd_master_invt_d）根据手册号和清单查询明细并带出
            bndMasterInvtDs = iBnd_master_invt_dService.findByInternalNumberAndEmsNo(internal_number, ems_no);
            if (bndMasterInvtDs != null && !"".equals(bndMasterInvtDs)) {
                for (Bnd_master_invt_d bndMasterInvtD : bndMasterInvtDs) {
                    //处理单价，小数位保留5位
                    String unitPrice = MathUtils.formatDouble(bndMasterInvtD.getUnit_price(), 5);
                    bndMasterInvtD.setUnit_price(Double.valueOf(unitPrice));
                    //根据品番去品名主档中带出规格
                    String itemNo = bndMasterInvtD.getItem_no();
                    Bnd_master_item bndMasterItem = iBnd_master_itemService.findByitem_no(itemNo);
                    bndMasterInvtD.setItem_spec(bndMasterItem.getItem_spec());
                    bndMasterInvtD.setBndMasterItem(bndMasterItem);
//                    币别转换
                    Bnd_master_currency_code currency_code = iBnd_master_currency_codeService.findByCurrency(bndMasterInvtD.getCurrency());
                    if (currency_code != null) {
                        bndMasterInvtD.setCurrency(currency_code.getCurrency());
                    }
//                    单位转换
                    List<Bnd_master_unit_code> bnd_master_unit_codei = iBnd_master_unit_codeService.findBycustoms_unit_code(bndMasterInvtD.getUm_incoming_outgoing());
                    if (bnd_master_unit_codei.size() > 0) {
                        bndMasterInvtD.setUm_incoming_outgoing(bnd_master_unit_codei.get(0).getUnit_code());
                    }
                    List<Bnd_master_unit_code> bnd_master_unit_codep = iBnd_master_unit_codeService.findBycustoms_unit_code(bndMasterInvtD.getUm_physical_inventory());
                    if (bnd_master_unit_codep.size() > 0) {
                        bndMasterInvtD.setUm_physical_inventory(bnd_master_unit_codep.get(0).getUnit_code());
                    }
                }
            }
        }
        Bnd_master_declare_company bndMasterDeclareCompany = iBnd_master_declare_companyService.findByDecEtpsNm(bndMasterInvtH.getDcl_etpsno());
        bndMasterInvtH.setDcl_etpsno_nm(bndMasterDeclareCompany.getDcl_etps_nm());//核注单位
        //报关单位
        if ("".equals(bndMasterInvtH.getCorresponding_customs_unit_code())) {
            List<Bnd_master_declare_company> bndMasterDeclareCompany1 = iBnd_master_declare_companyService.findBytype_dept("E", bndMasterInvtH.getDeclare_port());
            bndMasterInvtH.setCorresponding_customs_unit_code(bndMasterDeclareCompany1.get(0).getDcl_etpsno());
            Bnd_master_declare_company bndMasterDeclareCompany2 = iBnd_master_declare_companyService.findByDecEtpsNm(bndMasterInvtH.getCorresponding_customs_unit_code());
            bndMasterInvtH.setCorresponding_customs_unit_nm(bndMasterDeclareCompany2.getDcl_etps_nm());
        }

        modelAndView.addObject("bndMasterInvtH", bndMasterInvtH);
        System.out.println("aaa" + bndMasterInvtH);
        System.out.println("bbb" + bndMasterInvtDs);
        modelAndView.addObject("bndMasterInvtDs", bndMasterInvtDs);
        modelAndView.setViewName("bnd-master-invt-dcl");

        return modelAndView;
    }

    private void fuzhi(double dcpa2, double pkqt2, double ntwt2, double cawt2, Bnd_export_invoice_d invoice_d1, double qtyn2, Bnd_export_list_convert list_convert) throws Exception {
        list_convert.setEnterprise_declared_total_price(dcpa2);
        list_convert.setNet_weigh(ntwt2);
        list_convert.setWeight(cawt2);
        list_convert.setGross_weight(cawt2);
        list_convert.setPacking_qty(pkqt2);
        list_convert.setDeclare_qty(qtyn2);

        DecimalFormat dfn4 = new DecimalFormat("0.0000");

//                                计算法定数量
        Bnd_master_ehandbook_d ehandbook_d = iBnd_master_ehandbook_dService.findByitem(invoice_d1.getItem_no());
        if (ehandbook_d != null) {
            if ("035".equals(ehandbook_d.getLawf_unitcd())) {
                list_convert.setLegal_qty(ntwt2);
            } else {
                list_convert.setLegal_qty(qtyn2 * ehandbook_d.getLawf_unitcd_cf());
            }

            if ("035".equals(ehandbook_d.getSecd_lawf_unitcd())) {
                list_convert.setSec_legal_qty(ntwt2);
            } else {
                list_convert.setSec_legal_qty(qtyn2 * ehandbook_d.getSecd_lawf_unitcd_cf());
            }
        } else {
            list_convert.setLegal_qty(0.0);
            list_convert.setSec_legal_qty(0.0);
        }
//                                    计算单价
        list_convert.setUnit_price(Double.parseDouble(dfn4.format(dcpa2 / qtyn2)));
    }

}
