package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_if_fsap_vendor {
    private int id;
    private String vendor_no;//
    private String vendor_name1_dbcs;//
    private String vendor_name1;//
    private String vendor_name_abbr_dbcs;//
    private String vendor_name_abbr;//
    private String address1_dbcs;//
    private String address1;//
    private String vmi_or_jit;//
    private String custom_approved_no;//
    private String currency;//
    private String country_code;//
    private String state;//

    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

}
