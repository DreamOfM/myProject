package com.tdk.txm_java.domain;

public class Bnd_import_declaration {
    private int id;
    private String invoice_no;
    private String declare_no;
    private Double declare_amt;
    private String currency;
    private String declaration_date;
    private String text_contents1;
    private String text_contents2;
    private String text_contents3;
    private String text_contents4;
    private Double invoice_amt;
    private String submit_date;
    private String tax_no;
    private String ie_flag;
    private String list_no;
    private String import_export_gate;
    private String vendor_no;
    private String custom_approved_no;
    private String supervision_mode_code ;
    private String import_export_date;
    private String return_so1;
    private String return_so2;
    private String return_so3;
    private String return_so4;
    private String return_so5;
    private String return_so6;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;
    private double iv_amount;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getInvoice_no() {
        return invoice_no;
    }

    public void setInvoice_no(String invoice_no) {
        this.invoice_no = invoice_no;
    }

    public String getDeclare_no() {
        return declare_no;
    }

    public void setDeclare_no(String declare_no) {
        this.declare_no = declare_no;
    }

    public Double getDeclare_amt() {
        return declare_amt;
    }

    public void setDeclare_amt(Double declare_amt) {
        this.declare_amt = declare_amt;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getDeclaration_date() {
        return declaration_date;
    }

    public void setDeclaration_date(String declaration_date) {
        this.declaration_date = declaration_date;
    }

    public String getText_contents1() {
        return text_contents1;
    }

    public void setText_contents1(String text_contents1) {
        this.text_contents1 = text_contents1;
    }

    public String getText_contents2() {
        return text_contents2;
    }

    public void setText_contents2(String text_contents2) {
        this.text_contents2 = text_contents2;
    }

    public String getText_contents3() {
        return text_contents3;
    }

    public void setText_contents3(String text_contents3) {
        this.text_contents3 = text_contents3;
    }

    public String getText_contents4() {
        return text_contents4;
    }

    public void setText_contents4(String text_contents4) {
        this.text_contents4 = text_contents4;
    }

    public Double getInvoice_amt() {
        return invoice_amt;
    }

    public void setInvoice_amt(Double invoice_amt) {
        this.invoice_amt = invoice_amt;
    }

    public String getSubmit_date() {
        return submit_date;
    }

    public void setSubmit_date(String submit_date) {
        this.submit_date = submit_date;
    }

    public String getTax_no() {
        return tax_no;
    }

    public void setTax_no(String tax_no) {
        this.tax_no = tax_no;
    }

    public String getIe_flag() {
        return ie_flag;
    }

    public void setIe_flag(String ie_flag) {
        this.ie_flag = ie_flag;
    }

    public String getList_no() {
        return list_no;
    }

    public void setList_no(String list_no) {
        this.list_no = list_no;
    }

    public String getImport_export_gate() {
        return import_export_gate;
    }

    public void setImport_export_gate(String import_export_gate) {
        this.import_export_gate = import_export_gate;
    }

    public String getVendor_no() {
        return vendor_no;
    }

    public void setVendor_no(String vendor_no) {
        this.vendor_no = vendor_no;
    }

    public String getCustom_approved_no() {
        return custom_approved_no;
    }

    public void setCustom_approved_no(String custom_approved_no) {
        this.custom_approved_no = custom_approved_no;
    }

    public String getSupervision_mode_code() {
        return supervision_mode_code;
    }

    public void setSupervision_mode_code(String supervision_mode_code) {
        this.supervision_mode_code = supervision_mode_code;
    }

    public String getImport_export_date() {
        return import_export_date;
    }

    public void setImport_export_date(String import_export_date) {
        this.import_export_date = import_export_date;
    }

    public String getReturn_so1() {
        return return_so1;
    }

    public void setReturn_so1(String return_so1) {
        this.return_so1 = return_so1;
    }

    public String getReturn_so2() {
        return return_so2;
    }

    public void setReturn_so2(String return_so2) {
        this.return_so2 = return_so2;
    }

    public String getReturn_so3() {
        return return_so3;
    }

    public void setReturn_so3(String return_so3) {
        this.return_so3 = return_so3;
    }

    public String getReturn_so4() {
        return return_so4;
    }

    public void setReturn_so4(String return_so4) {
        this.return_so4 = return_so4;
    }

    public String getReturn_so5() {
        return return_so5;
    }

    public void setReturn_so5(String return_so5) {
        this.return_so5 = return_so5;
    }

    public String getReturn_so6() {
        return return_so6;
    }

    public void setReturn_so6(String return_so6) {
        this.return_so6 = return_so6;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    public double getIv_amount() {
        return iv_amount;
    }

    public void setIv_amount(double iv_amount) {
        this.iv_amount = iv_amount;
    }

    @Override
    public String toString() {
        return "Bnd_import_declaration{" +
                "id=" + id +
                ", invoice_no='" + invoice_no + '\'' +
                ", declare_no='" + declare_no + '\'' +
                ", declare_amt=" + declare_amt +
                ", currency='" + currency + '\'' +
                ", declaration_date='" + declaration_date + '\'' +
                ", text_contents1='" + text_contents1 + '\'' +
                ", text_contents2='" + text_contents2 + '\'' +
                ", text_contents3='" + text_contents3 + '\'' +
                ", text_contents4='" + text_contents4 + '\'' +
                ", invoice_amt=" + invoice_amt +
                ", submit_date='" + submit_date + '\'' +
                ", tax_no='" + tax_no + '\'' +
                ", ie_flag='" + ie_flag + '\'' +
                ", list_no='" + list_no + '\'' +
                ", import_export_gate='" + import_export_gate + '\'' +
                ", vendor_no='" + vendor_no + '\'' +
                ", custom_approved_no='" + custom_approved_no + '\'' +
                ", supervision_mode_code='" + supervision_mode_code + '\'' +
                ", import_export_date='" + import_export_date + '\'' +
                ", return_so1='" + return_so1 + '\'' +
                ", return_so2='" + return_so2 + '\'' +
                ", return_so3='" + return_so3 + '\'' +
                ", return_so4='" + return_so4 + '\'' +
                ", return_so5='" + return_so5 + '\'' +
                ", return_so6='" + return_so6 + '\'' +
                ", login_time='" + login_time + '\'' +
                ", login_oid='" + login_oid + '\'' +
                ", update_time='" + update_time + '\'' +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                ", iv_amount='" + iv_amount + '\'' +
                '}';
    }
}
