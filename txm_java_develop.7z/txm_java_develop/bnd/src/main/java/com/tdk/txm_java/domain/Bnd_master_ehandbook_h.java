package com.tdk.txm_java.domain;

import lombok.Data;

import java.util.Date;

@Data
public class Bnd_master_ehandbook_h {
    private int id;
    private String seq_no ;
    private String ems_no;
    private Double chg_tms_cnt ;
    private String etps_preent_no ;
    private String bizop_etps_sccd ;
    private String bizop_etpsno ;
    private String bizop_etps_nm ;
    private String prcs_etps_sccd ;
    private String prcs_etpsno ;
    private String prcs_etps_nm ;
    private String dec_dm ;
    private String dcl_etpsno;
    private String dcl_etps_nm;
    private String dcl_etps_typecd ;
    private String input_code ;
    private String input_credit_code;
    private String input_name ;
    private String ems_type ;

    private Date finish_valid_time ;
    private String finish_valid_time2 ;

    private String dcl_typecd;
    private Double actl_imp_total_amt;
    private Double actl_exp_total_amt;
    private String apcret_not;
    private String netwk_etps_arcrp_no;
    private Double max_tovr_amt;

    private Date dcl_time;
    private String dcl_time2;
    private Date rcnt_vclr_time;
    private String rcnt_vclr_time2;
    private Date input_date ;
    private String input_date2 ;

    private String ucns_dcl_segcd;
    private Double vclr_prid_val;
    private String ucns_verno_cntr_fla;
    private Double material_count;
    private Double endprd_item_cnt;
    private String rmk ;
    private String master_cuscd  ;
    private Double imp_max_account;
    private String vclr_typecd;
    private String usagetypecd;

    private Date putrec_appr_time ;
    private String putrec_appr_time2 ;
    private Date cash_payment_date;
    private String cash_payment_date2;

    private String exe_markcd  ;
    private String ehvtyp;
    private Bnd_master_declare_company bnd_master_declare_company;
    private Date login_time;
    private String login_oid;
    private Date update_time;
    private String update_oid;
    private String update_program;


}
