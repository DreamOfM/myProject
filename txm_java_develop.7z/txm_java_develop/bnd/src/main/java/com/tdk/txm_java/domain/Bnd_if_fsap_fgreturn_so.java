package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_if_fsap_fgreturn_so {
    private int id;
    private String sosono;
    private String sodfno;
    private String sooivn;
    private String socunr;
    private String sostmt;
    private String sopshd;
    private String soitnr;
    private Double sosoqt;
    private Double sopric;
    private String socurr;
    private String sorttp;
    private String sobdfg;
    private String sodelf;
    private String sostat;
    private String soupdt;

}
