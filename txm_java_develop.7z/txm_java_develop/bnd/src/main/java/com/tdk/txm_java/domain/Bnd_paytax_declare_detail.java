package com.tdk.txm_java.domain;


import lombok.Data;

import java.util.Date;

@Data
public class Bnd_paytax_declare_detail {
    private int id;
    private String data_state;
    private String yyyymm;
    private String paytax_type;
    private String declaration_no_b;
    private String internal_number;
    private String list_no;
    private Date apply_date;
    private Date paytax_date;
    private String ems_no;
    private String item_class_code;
    private String item_no;
    private Double img_no;
    private String country_code;
    private String ccc_code;
    private Double tax_rate;
    private Double paytax_qty_total;
    private Double used_qty;
    private Double used_amt;
    private Double used_wet;
    private String um_physical_inventory;
    private Double purchase_price;
    private String currency;
    private String paytax_declaration_no;
    private Double paytax_qty;
    private Double paytax_amt;
    private Double paytax_wet;
    private String remark_1;
    private String remark_2;

    private Double net_weigh;
    private String bond_type;// bond,nonbond,upload
    private String type;// bnd_domestic_special_item.type

    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

    }
