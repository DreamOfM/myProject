package com.tdk.txm_java.domain;

import lombok.Data;

import java.util.Date;

//CIF单价

@Data
public class Bnd_carry_cif_price {
    private int id;
    private String declaration_no;//報關單號
    private String item_no;//ITEM
    private Double fee_amount;//運費額
    private Double fee_rate;//運費率
    private Double insur_amount;//保費額
    private Double insur_rate;//保費率
    private Double other_amount;//雜費
    private String transaction_code;//成交方式代碼
    private String terms_trade;//成交方式
    private String fee_curr;//運費幣別
    private String insur_curr;//保費幣別
    private String other_curr;//雜費幣別
    private Double cif_price;//CIF單價
    private Double declaration_price;//申報總價
    private Double declare_qty;//數量
    private Double enterprise_declared_total_price;//金額
    private Double decalre_rate;//報關清單匯率
    private Double fee_exchange_rate;//運費匯率
    private Double insur_exchange_rate;//保費匯率
    private Double other_exchange_rate;//雜費匯率
    private Date login_time;
    private String login_oid;
    private Date update_time;
    private String update_oid;
    private String update_program;


}
