package com.tdk.txm_java.domain;

public class Bnd_master_vendor {
    private int id;
    private String vendor_no;
    private String vendor_name1_dbcs;
    private String vendor_name1;
    private String vendor_name_abbr_dbcs;
    private String vendor_name_abbr;
    private String address1_dbcs;
    private String address1;
    private String vmi_or_jit;
    private String custom_approved_no;
    private String currency;
    private String country_code;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getVendor_no() {
        return vendor_no;
    }

    public void setVendor_no(String vendor_no) {
        this.vendor_no = vendor_no;
    }

    public String getVendor_name1_dbcs() {
        return vendor_name1_dbcs;
    }

    public void setVendor_name1_dbcs(String vendor_name1_dbcs) {
        this.vendor_name1_dbcs = vendor_name1_dbcs;
    }

    public String getVendor_name1() {
        return vendor_name1;
    }

    public void setVendor_name1(String vendor_name1) {
        this.vendor_name1 = vendor_name1;
    }

    public String getVendor_name_abbr_dbcs() {
        return vendor_name_abbr_dbcs;
    }

    public void setVendor_name_abbr_dbcs(String vendor_name_abbr_dbcs) {
        this.vendor_name_abbr_dbcs = vendor_name_abbr_dbcs;
    }

    public String getVendor_name_abbr() {
        return vendor_name_abbr;
    }

    public void setVendor_name_abbr(String vendor_name_abbr) {
        this.vendor_name_abbr = vendor_name_abbr;
    }

    public String getaddress1_dbcs() {
        return address1_dbcs;
    }

    public void setaddress1_dbcs(String address1_dbcs) {
        this.address1_dbcs = address1_dbcs;
    }

    public String getaddress1() {
        return address1;
    }

    public void setaddress1(String address1) {
        this.address1 = address1;
    }

    public String getVmi_or_jit() {
        return vmi_or_jit;
    }

    public void setVmi_or_jit(String vmi_or_jit) {
        this.vmi_or_jit = vmi_or_jit;
    }

    public String getCustom_approved_no() {
        return custom_approved_no;
    }

    public void setCustom_approved_no(String custom_approved_no) {
        this.custom_approved_no = custom_approved_no;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getCountry_code() {
        return country_code;
    }

    public void setCountry_code(String country_code) {
        this.country_code = country_code;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    @Override
    public String toString() {
        return "Bnd_master_vendor{" +
                "id=" + id +
                ", vendor_no='" + vendor_no + '\'' +
                ", vendor_name1_dbcs='" + vendor_name1_dbcs + '\'' +
                ", vendor_name1='" + vendor_name1 + '\'' +
                ", vendor_name_abbr_dbcs='" + vendor_name_abbr_dbcs + '\'' +
                ", vendor_name_abbr='" + vendor_name_abbr + '\'' +
                ", address1_dbcs='" + address1_dbcs + '\'' +
                ", address1='" + address1 + '\'' +
                ", vmi_or_jit='" + vmi_or_jit + '\'' +
                ", custom_approved_no='" + custom_approved_no + '\'' +
                ", currency='" + currency + '\'' +
                ", country_code='" + country_code + '\'' +
                ", login_time='" + login_time + '\'' +
                ", login_oid='" + login_oid + '\'' +
                ", update_time='" + update_time + '\'' +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                '}';
    }
}
