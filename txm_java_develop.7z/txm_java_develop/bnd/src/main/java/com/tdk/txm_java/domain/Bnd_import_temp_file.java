package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Time;

@Data
public class Bnd_import_temp_file {
    private int id;
    private String invoice_no;//發票號碼
    private String item_no;//品名代码
    private String country_code;//国家代码
    private String currency;//币别
    private String um_purchase;//购买单位
    private Double cf_purchase;//购买单位换算系数
    private Double unit_price;//監管單價
    private Double enterprise_declared_total_price;//企业申报总价
    private Double declare_qty;//報關單數量
    private Double net_weigh;//净重
    private Double gross_weight;//毛重
    private Double po_boarding_qty;//载途数量
    private Time login_time;//登陆时间login_time
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;

}
