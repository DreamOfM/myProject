package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_import_return_po {
    private int id;
    private String po_no ;//購買訂單號碼
    private Double po_no_line;//購買訂單行號
    private String po_type;//po_type
    private String plan_return_date;//plan_return_date
    private String vendor_no;//供货商代码
    private String vendor_type;//供货商型态
    private String currency;//幣別
    private String item_no;//品名代码
    private Double price0;//价格
    private Double po_qty;//po_qty
    private Double net_weigh;//净重
    private String um_purchase;//购买单位
    private Double cf_purchase;//购买单位换算系数
    private String original_invoice;//退货原发票
    private Double actual_return_qty;//actual_return_qty
    private String actual_return_date;//actual_return_date
    private String return_invoice;//退貨發票
    private Double actual_replace_qty;//actual_replace_qty
    private String actual_replace_date;//actual_replace_date
    private String replace_invoice;//replace_invoice
    private String batch_no;//BATCH NO.
    private Double batch_quantity;//batch_quantity
    private Double batch_price;//batch_price
    private String invoice_no;//發票號碼
    private Double invoice_no_line;//發票行號
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;
}
