package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Date;

@Data
public class Bnd_master_mbom {
    private int id;
    private String item_no;//品名代码
    private String bom_number;//ISBOMN
    private String alternative_bom;//ISALTB
    private Double circuit_no;//電路板號碼
    private String bom_item_node_number;//ISBINN
    private String component_item_no;//材料品名代碼
    private String ait_item_group;//ISAIGR
    private String ait_ranking_order;//ait_ranking_order
    private String ait_item_strategy;//ait_item_strategy
    private Double ait_item_usage_prob;//ait_item_usage_prob
    private Double base_qty;//base_qty
    private Double component_qtyparent_qty;//製品用量
    private Double loss_qty;//損耗數
    private String effective_datemfg_lot;//EFFECTIVE           DATE/MFG LOT
    private String expiry_datemfg_lot;//EXPIRY              DATE/MFG LOT
    private String routing_no;//制造途程代码
    private String equipment_name;//工程设备名
    private Double seq_no;//流水号


    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

}
