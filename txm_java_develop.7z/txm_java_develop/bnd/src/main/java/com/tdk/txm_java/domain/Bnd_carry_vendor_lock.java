package com.tdk.txm_java.domain;

import java.util.Date;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_develop</h3>
 * @ClassName<h4>结转发单控制</h4>
 * @ToDo<p></p>
 * @date : 2020-05-23 15:07
 * @version:1.0
 **/

public class Bnd_carry_vendor_lock {
    private  int id;
    private  String  vendor_no;
    private Date login_time;
    private String login_oid;
    private Date update_time;
    private String update_oid;
    private String update_program;

    public Bnd_carry_vendor_lock() {
    }

    public Bnd_carry_vendor_lock(String vendor_no) {
        this.vendor_no = vendor_no;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getVendor_no() {
        return vendor_no;
    }

    public void setVendor_no(String vendor_no) {
        this.vendor_no = vendor_no;
    }

    public Date getLogin_time() {
        return login_time;
    }

    public void setLogin_time(Date login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public Date getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(Date update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    @Override
    public String toString() {
        return "Bnd_carry_vendor_lock{" +
                "id=" + id +
                ", vendor_no='" + vendor_no + '\'' +
                ", login_time=" + login_time +
                ", login_oid='" + login_oid + '\'' +
                ", update_time=" + update_time +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                '}';
    }
}
