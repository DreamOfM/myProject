package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_import_fee {
    private int id;
    private String invoice_no;//发票号
    private String vendor_no;//供货商代码
    private String vendor_name1_dbcs;//供货商中文名称
    private Double charged_weight;//计费重量
    private String entry_clearance_no ;//入境通关单号
    private Double quarantine_fee ;//检疫费
    private String currency_1;//币别1
    private Double sanitation_treatment_fee;//卫生处理费
    private String currency_2;//币别2
    private Double quarantine_value;//检疫货值
    private String currency_3;//币别3
    private Double publish_freight;//公布运费
    private String currency_4;//币别4
    private Double freight;//运费
    private String currency_5;//币别5
    private Double fuel_cost;//燃油费
    private String currency_6;//币别6
    private Double premium_rate;//保险费率
    private Double port_of_discharge_fee;//启运港费用
    private String currency_7;//币别7
    private Double exchange_fee;//换单费
    private String currency_8;//币别8
    private Double other_fee;//其他费用
    private String currency_9;//币别9
    private String note;//备注
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;
}
