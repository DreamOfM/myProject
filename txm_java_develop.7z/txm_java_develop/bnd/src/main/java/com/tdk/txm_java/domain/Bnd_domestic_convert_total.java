package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Time;
import java.util.List;

@Data
public class Bnd_domestic_convert_total {
    private int id;
    private String yyyymm;
    private String item_no;
    private Double img_no;
    private String type;
    private Double domestic_qty;
    private Double domestic_wet;
    private Double domestic_amt;
    private Double domestic_qty_paytax;
    private Double domestic_wet_paytax;
    private Double domestic_amt_paytax;
    private Double nonbond_qty;
    private Double nonbond_wet;
    private Double nonbond_amt;
    private Double nonbond_qty_paytax;
    private Double nonbond_wet_paytax;
    private Double nonbond_amt_paytax;
    private Double upload_qty;
    private Double upload_qty_paytax;
    private List<Bnd_paytax_declare_deduct> in1year_declare_deducts;
    private List<Bnd_paytax_declare_deduct> gt1year_declare_deducts;
    private Bnd_master_item bnd_master_item;
    private String ems_no;

    private Time login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;
}
