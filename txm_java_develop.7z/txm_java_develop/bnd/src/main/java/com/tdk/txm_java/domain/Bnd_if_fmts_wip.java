package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_if_fmts_wip {
    private int id;
    private String wicoce;//CO_CODE
    private String wiyymm;//STAKE_MONTH
    private String wisapm;//SAP_MO
    private String wimonr;//MTS_LOT
    private String wiwknr;//WIP_PROC_ID
    private String wiitnr;//ITEM NO.
    private String wilots;//LOT_STATUS
    private Double wiopsq;//OPERATION SEQUENCE NO.
    private Double wiinqt;//IN_QTY
    private Double wiwipq;//WIP-QTY
    private Double wioutq;//OUT_QTY
    private Double wingqt;//NG_QTY
    private String wiindt;//START_DATE
    private String wiflag;//FLAG
    private String wistat;//0-SEND 1-COMPLETED
    private String wiupdt;//UPDATE TIME






    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;


}
