package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_if_fsap_sample_consume {
    private int id;
    private String ccmrpc;//MRP基准代码
    private String ccmdoc;//MD号
    private String ccdoci;//MD序号
    private String ccdoch;//MD表头
    private String ccdocn;//关联文档
    private Double ccpsdt;//异动日期
    private Double ccdocd;//文档日期
    private Double ccdoct;//文档时间
    private String ccitnr;//品名代码
    private Double cctrqt;//TRANSACTION QTY
    private String ccumcd;//单位
    private String ccltno;//批號
    private String cccoct;//成本 中心
    private String ccpsac;//PSA
    private String ccmvtp;//异动类型
    private String ccusid;//用户ID
    private String ccstat;//状态
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

}
