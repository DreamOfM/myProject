package com.tdk.txm_java.domain;

import lombok.Data;

import java.util.Date;

@Data

public class Bnd_export_airway_list {
    private int id;
    private String invoice_no;//發票號碼
    private String flight_no;//班機或航次 1
    private String master_airway_bill;//主提單號碼
    private String house_airway_bill;//分提單號碼
    private String error_reason;//分提單號碼
    private Date login_time;//登陆时间login_time
    private String login_oid;//登陆人员login_oid
    private Date update_time;//更新时间update_time
    private String update_oid;//更新人员update_oid
    private String update_program;//更新程序update_program

}
