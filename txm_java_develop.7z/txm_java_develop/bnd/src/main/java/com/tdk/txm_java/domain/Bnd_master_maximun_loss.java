package com.tdk.txm_java.domain;

public class Bnd_master_maximun_loss {
    private int id;
    private String material_item_no;
    private Double max_pm_orderqty_io;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMaterial_item_no() {
        return material_item_no;
    }

    public void setMaterial_item_no(String material_item_no) {
        this.material_item_no = material_item_no;
    }

    public Double getMax_pm_orderqty_io() {
        return max_pm_orderqty_io;
    }

    public void setMax_pm_orderqty_io(Double max_pm_orderqty_io) {
        this.max_pm_orderqty_io = max_pm_orderqty_io;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    @Override
    public String toString() {
        return "Bnd_master_maximun_loss{" +
                "id=" + id +
                ", material_item_no='" + material_item_no + '\'' +
                ", max_pm_orderqty_io=" + max_pm_orderqty_io +
                ", login_time='" + login_time + '\'' +
                ", login_oid='" + login_oid + '\'' +
                ", update_time='" + update_time + '\'' +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                '}';
    }
}
