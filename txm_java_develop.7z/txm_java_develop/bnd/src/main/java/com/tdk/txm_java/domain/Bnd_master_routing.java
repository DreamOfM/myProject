package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_master_routing {
    private int id;
    private String routing_no;
    private Double operation_sequence_no;
    private String operation_desc_dbcs;
    private String section_code;
    private String um_load;
    private String um_operation_register;
    private String equipment_type;
    private String jig_tool_no;
    private String equipment_name;
    private Double yield;
    private String standard_flag;
    private String load_calculation_flag;
    private String labor_machine_code;
    private String standard_operation_flag;
    private String operation_sequence_group;
    private String operation_instruction_flg;
    private String operation_register_flag;
    private String additional_inspection_flg;
    private Double effect_engineer_chglvl;
    private Double expiry_engineer_chglvl;
    private Double moving_lt;
    private Double queuing_lt;
    private Double operation_lt;
    private Double urgent_moving_lt;
    private Double urgent_queuing_lt;
    private Double urgent_operation_lt;
    private String setup_flag;
    private String setup_code;
    private Double setup_crew_size;
    private Double setup_load;
    private Double standard_value;
    private Double basic_unit_qty;
    private Double opertime_basic_unit_qty;
    private String standard_time_code;
    private String operation_standard_no;
    private Double take_up_qty;
    private Double noof_jig_tool;
    private Double uprice_evaluate_unfinish;
    private Double subcontract_unit_price;
    private Double inprocess_matrialucost;
    private Double inprocess_mfg_unit_cost;
    private String alternate_equipment_type;
    private String alternate_work_center_no;
    private Double alternate_jig_tool_qty;
    private String effective_date;
    private String expiration_date;
    private String old_routing_no;
    private String item_no;
    private String control_key;
    private String WADLTF;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

}
