package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Time;
@Data

public class Bnd_master_unit_measure_code {
    private int id;
    private String unit_code;//
    private String unit_code_nm;//
    private String unit_code_dbcs;//
    private String unit_code_alternative;//
    private Time login_time;//登陆时间login_time
    private String login_oid;//登陆人员login_oid
    private Time update_time;//更新时间update_time
    private String update_oid;//更新人员update_oid
    private String update_program;//更新程序update_program

}
