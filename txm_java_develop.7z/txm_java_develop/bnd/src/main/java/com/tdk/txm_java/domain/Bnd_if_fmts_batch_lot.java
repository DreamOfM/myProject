package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_if_fmts_batch_lot {
    private int id;
    private String blcoce;//CO_CODE
    private String blpkno;//PACK_NO
    private String blpkdt;//PACK DATE
    private String blitnr;//PROD_PN.
    private String blbach;//BATCH NO.
    private Double blbexg;//BATCH BOM_VER.
    private String blsapm;//SAP MO
    private String blmonr;//LOT NO.
    private Double bllexg;//LOT NO BOM_VER
    private Double bllotq;//PACK_QTY
    private String blrcdt;//RECORD TYPE
    private String blstat;//0-SEND 1-COMPLETED
    private String blupdt;//UPDATE TIME


    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;


}
