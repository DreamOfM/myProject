package com.tdk.txm_java.domain;

import lombok.Data;

import java.util.Date;


/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_develop</h3>
 * @ClassName<h4>结转发单控制</h4>
 * @ToDo<p></p>
 * @date : 2020-05-23 15:07
 * @version:1.0
 **/
@Data
public class Bnd_carry_vendor_detailed {
    private int id;
    private String vendor_no;
    private String type;
    private String ten_digit_code;
    private String organization_code;
    private String transfer_out_code;
    private String customs_name;
    private String ems_no;
    private String manual_expiry_date;
    private String manual_effective_date;
    private String vendor_img_no;
    private String vendor_item_no;
    private String item_description_dbcs;
    private String ccc_code;
    private String item_spec;
    private String lawf_unitcd;
    private String secd_lawf_unitcd;
    private String cf_physical_inventory;
    private String img_no;
    private String item_no;
    private String supervsion_unit;
    private String supervsion_unit_code;
    private String legal_unit;
    private String legal_unit_code;
    private Double lawf_unitcd_cf;
    private String um_purchase;
    private Double cf_purchase;
    private Date login_time;
    private String login_oid;
    private Date update_time;
    private String update_oid;
    private String update_program;
    /**
     * @Author Wang FengCai
     * @Description 用于存放供应商主档中带出的供应商中文名称
     * @Date  2020/8/18
     * @Time  下午 02:16
     **/
    private String vendor_name1_dbcs;




}
