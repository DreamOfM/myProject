package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_if_fmts_split_merge {
    private int id;
    private String smcoce;//CO_CODE
    private String smyymm;//STAKE_MONTH
    private String smactn;//S-SPLIT M-MERGE C.TRANSFER
    private String smosap;//ORIGINAL SAP_MO
    private String smomon;//ORIGINAL MTS LOT NO.
    private String smtsap;//TARGET SAP_MO
    private String smtmon;//TARGET MTS LOT NO.
    private String smwknr;//WORK CENTER NO.
    private Double smoqty;//FROM QTY
    private Double smtqty;//TO QTY
    private Double smpqty;//PROCESS QTY
    private String smstat;//0-SEND 1-COMPLETED
    private String smupdt;//UPDATE TIME




    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;


}
