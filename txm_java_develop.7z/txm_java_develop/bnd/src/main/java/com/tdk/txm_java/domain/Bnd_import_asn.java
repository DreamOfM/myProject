package com.tdk.txm_java.domain;


import lombok.Data;

import java.sql.Time;
import java.util.List;

@Data
public class Bnd_import_asn {
    private int id;
    private String po_no ;//購買訂單號碼
    private Double po_no_line;//購買訂單行號
    private String invoice_no;//發票號碼
    private Double invoice_no_line;//發票行號
    private String state;//状态
    private String vendor_no;//供货商代码
    private String terms_trade;//贸易条件
    private String mrpcode;//mrp
    private String item_no;//品名代码
    private String vendor_item_no;//BPVINR
    private String um_purchase;//购买单位
    private Double cf_purchase;//购买单位换算系数
    private Double purchase_price;//购买单价（在库单位
    private Double purchase_qty;//購買訂單數量
    private Double po_boarding_qty;//载途数量
    private Double po_boarding_amt;//交貨金額
    private String note;//备注
    private String consignment_date;//發貨日期
    private String plant_place;//工發地
    private String trans_mode;//運輸方式
    private String pallet_code;//板代碼
    private Double pad_qty;//總板數
    private String packing_code;//包裝代碼
    private Double box_qty;//總箱數
    private String original_producing_area;//源產國
    private Double gross_weight;//毛重
    private Double totoal_net_weight;//總凈重
//    private String confirm_date;//確認日期
    private String custom_approved_no;//结转标识
    private String currency;
    private Time login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;
    private String ccc_code;
    private String item_spec2;//申报要素
    private String regulatory_credentials_code;
    private String bonded_logo;
    private String item_description_dbcs;
    private String item_spec;
    private Double pieces;
    private String declaration_no;//报关单号
    private List<Bnd_import_asn> bndImportAsns;


}
