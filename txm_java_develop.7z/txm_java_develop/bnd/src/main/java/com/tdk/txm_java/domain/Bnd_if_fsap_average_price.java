package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Date;
import java.sql.Time;

@Data
public class Bnd_if_fsap_average_price {
    private int id;
    private String m2itnr;//
    private Double m2avgp;//
    private Double m2avgn;//
    private Double m2stat;//

    private Time login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;





}
