package com.tdk.txm_java.domain;



import lombok.Data;

import java.sql.Time;

@Data
public class Bnd_master_invt_type {
    private int id;
    private String invt_type;//
    private String import_export_mark_code;//
    private String circulation_type;//
    private String customs_declaration_type_code;//
    private String customs_declaration_type;//
    private String list_type;//
    private String declaration_state;//
    private String dcl_etps_typecd;//
    private String supervision_mode_code;//
    private String part_sign_code;//
    private String declare_port;//
    private String import_export_gate;//
    private String country_code;//
    private String transport_code;//
    private String trade_country;//
    private Double ucns_verno;
    private String use_code;
    private String exempting_method;
    private String return_url;


}
