package com.tdk.txm_java.controller;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.tdk.txm_java.dao.IBnd_stock_wip_uploadDao;
import com.tdk.txm_java.domain.*;
import com.tdk.txm_java.service.*;
import com.tdk.txm_java.utils.ExcelUtils;
import com.tdk.txm_java.utils.UploadUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

@Controller
@RequestMapping("/bnd_stock_wip_upload")

public class Bnd_stock_wip_uploadController {
    @Autowired
    private IBnd_stock_wip_uploadService iBnd_stock_wip_uploadService;
    @Autowired
    private IBnd_stock_wip_uploadDao iBnd_stock_wip_uploadDao;
    @Autowired
    private IBnd_master_psa_mrpService iBnd_master_psa_mrpService;
    @Autowired
    private ICom_commonService iCom_commonService;
    @Autowired
    private IBnd_master_itemService iBnd_master_itemService;
    @Autowired
    private IBnd_master_batch_lotService iBnd_master_batch_lotService;
    @Autowired
    private IBnd_stock_location_floorService iBnd_stock_location_floorService;
    @Autowired
    private IBnd_stock_annual_inventoryService iBnd_stock_annual_inventoryService;
    @Autowired
    private IBnd_master_ehandbook_dService iBnd_master_ehandbook_dService;
    @Autowired
    private IBnd_stock_wip_psaService iBnd_stock_wip_psaService;
    @Autowired
    private IBnd_master_moService iBnd_master_moService;

    @RequestMapping("/findBypsa.do")
    public ModelAndView findBypsa(String psa_code) throws Exception {
        String message = null;
        Bnd_master_psa_mrp psa_mrp = iBnd_master_psa_mrpService.findBypsa(psa_code);
        Com_common com_common = new Com_common();
        List<Bnd_stock_wip_upload> ls = new ArrayList<Bnd_stock_wip_upload>();
        int count = 0;
        if (psa_mrp != null) {
            com_common = iCom_commonService.findByKeys("WIP", psa_mrp.getMrp_code());
        }
        if (com_common != null) {
            if ("Y".equals(com_common.getChar1())) {
                message = "该PSA已经盘点完成，如需修改请联络EDP";
            } else {
                ls = iBnd_stock_wip_uploadService.findBypsa(psa_code);
                if (ls.size() > 0) {
                    for (Bnd_stock_wip_upload psa_upload : ls) {
                        Bnd_master_item item = iBnd_master_itemService.findByitem_no(psa_upload.getItem_no());
                        if (item != null) {
                            if ("".equals(psa_upload.getUm_incoming_outgoing().trim())) {
                                psa_upload.setUm_incoming_outgoing(item.getUm_incoming_outgoing());
                            }
                        }
                    }
                    Bnd_stock_wip_upload stock = iBnd_stock_wip_uploadService.findcont(psa_code);
                    count = stock.getCount();
                } else {
                    if (psa_code != null && !psa_code.equals("")) {
                        message = "无数据";
                    }
                }
            }
        }
        ModelAndView mv = new ModelAndView();
        mv.setViewName("bnd-stock-wip-list");
        mv.addObject("bnd_stock_wip_upload", ls);
        mv.addObject("psa", psa_code);
        mv.addObject("psa_mrp", psa_mrp);
        mv.addObject("message", message);
        mv.addObject("count", count);
        return mv;
    }

    @RequestMapping("/save.do")
    public String save(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception {
        //取出前端传回的所有数据
        String username = (String) httpSession.getAttribute("username");
        String psa = request.getParameter("psa");
        String mrp = request.getParameter("mrp");
        iBnd_stock_annual_inventoryService.deleteBymrp_type(mrp, psa);
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        Bnd_stock_annual_inventory annual_inventory = new Bnd_stock_annual_inventory();
        while (1 == 1) {
            for (String name : set) {
                String[] vals = (String[]) map.get(name);
                c = vals.length;
                if (!name.equals("psa_code") && !name.equals("mrp")) {
                    hashMap.put(name, vals[b]);
                }
            }
            try {
                BeanUtils.populate(annual_inventory, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //添加一个判断，如果为空值或者没有输入则不往数据库里插数据
            if (annual_inventory.getMrp_code().equals(null) || annual_inventory.getMrp_code().equals("")) {
                b++;
                if (b == c) break;
                continue;
            }

            Bnd_master_item item = iBnd_master_itemService.findByitem_no(annual_inventory.getItem_no());
            if (item != null) {
                if ("Y".equals(item.getBonded_logo())) {
                    annual_inventory.setBond_flag("X");
                } else {
                    annual_inventory.setBond_flag(" ");
                }
            }

            annual_inventory.setStock_location(annual_inventory.getCustom_bin().substring(0, 6));
            annual_inventory.setStock_location_detail(annual_inventory.getCustom_bin().substring(6, 9));
            annual_inventory.setStorage_type("WIP");
            Bnd_stock_annual_inventory inventory = iBnd_stock_annual_inventoryService.findByall2(annual_inventory.getMrp_code(), annual_inventory.getStorage_type(), annual_inventory.getStock_location(), annual_inventory.getStock_location_detail(), annual_inventory.getItem_no(), annual_inventory.getBond_flag(), annual_inventory.getLot_no(), annual_inventory.getSeq_no(), annual_inventory.getPsa());
            if (inventory != null) {
                inventory.setOn_hand_qty(inventory.getOn_hand_qty() + annual_inventory.getOn_hand_qty());
                inventory.setUpdate_program("/stock_wip_upload/update.do");
                inventory.setUpdate_oid(username);
                iBnd_stock_annual_inventoryService.update(inventory);
            } else {
                annual_inventory.setStock_type("5");
                annual_inventory.setPrice(item.getStandard_cost());
                annual_inventory.setLogin_oid(username);
                annual_inventory.setUpdate_program("/stock_wip_upload/save.do");
                annual_inventory.setUpdate_oid(username);
                iBnd_stock_annual_inventoryService.save(annual_inventory);
            }
            b++;
            if (b == c) break;
        }
        iBnd_stock_wip_uploadService.deleteBypsa(psa);
        return "redirect:findBypsa.do";
    }

    @RequestMapping("/upload.do")
    public String upload(MultipartFile imgFile, HttpServletRequest request, HttpSession httpSession) throws Exception {
        String username = (String) httpSession.getAttribute("username");
        System.out.println("20210206" + username);
        UploadUtils uploadUtils = new UploadUtils();
        String filePath = uploadUtils.upload(imgFile, request);
        //导入LoadExcle方法
        String columns[] = {"mrp_code", "psa_code", "item_no", "lot_no", "seq_no", "equipment_name", "on_hand_qty", "um_incoming_outgoing", "custom_bin"};
        //创建对象
        Bnd_stock_wip_upload bnd_stock_wip_upload = new Bnd_stock_wip_upload();
        //从Excel获取数据列表
        List<Map<String, Object>> list = ExcelUtils.LoadExcle(filePath, columns);
        //将map转为对象，并存到对象list
        for (Map ma : list) {
            bnd_stock_wip_upload = ExcelUtils.mapToBean(ma, Bnd_stock_wip_upload.class);
            if (!bnd_stock_wip_upload.getMrp_code().equals("")) {
                bnd_stock_wip_upload.setMrp_code(bnd_stock_wip_upload.getMrp_code().substring(0, 1));
                bnd_stock_wip_upload.setLogin_oid(username);
                bnd_stock_wip_upload.setUpdate_program("/bnd_stock_psa/upload.do");
                iBnd_stock_wip_uploadDao.save(bnd_stock_wip_upload);
            }
        }
        return "redirect:findBypsa.do";
    }

    @RequestMapping("/check.do")
    public void check(HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        Bnd_stock_annual_inventory annual_inventory = new Bnd_stock_annual_inventory();
        List<String> bin_list = new ArrayList<>();
        List<String> iw_list = new ArrayList<>();
        while (1 == 1) {
            info.setFlag(true);
            for (String name : set) {
                String[] vals = (String[]) map.get(name);
                c = vals.length;
                hashMap.put(name, vals[b]);
            }
            try {
                BeanUtils.populate(annual_inventory, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }

            //判断
            do {
                String errLine = String.valueOf(b);
//                Bnd_master_psa_mrp psa_mrp = iBnd_master_psa_mrpService.findBypsa(annual_inventory.getStorage_type());
//                if (psa_mrp == null) {
//                    info.setErrorMsg("PSA不存在");
//                    errorList.add("storage_type" + errLine);
//                    info.setFlag(false);
//                    break;
//                }
//
                Bnd_master_item item = iBnd_master_itemService.findByitem_no(annual_inventory.getItem_no());
                if (item == null) {
                    info.setErrorMsg("品番在品名主档中不存在");
                    errorList.add("item_no" + errLine);
                    info.setFlag(false);
                    break;
                } else {
                    if (!annual_inventory.getUm_incoming_outgoing().equals(item.getUm_incoming_outgoing())) {
                        info.setErrorMsg("单位与品名主档在库单位不一致");
                        errorList.add("um_incoming_outgoing" + errLine);
                        info.setFlag(false);
                        break;
                    }
                }
                Bnd_stock_location_floor location_floor = iBnd_stock_location_floorService.findBystock_loc(annual_inventory.getCustom_bin().substring(0, 6));
                if (location_floor == null) {
                    info.setErrorMsg("存置地点未维护对楼层");
                    errorList.add("custom_bin" + errLine);
                    info.setFlag(false);
                    break;
                }

                if (annual_inventory.getOn_hand_qty().equals(0.0) || "".equals(annual_inventory.getOn_hand_qty()) || annual_inventory.getOn_hand_qty() == null) {
                    info.setErrorMsg("数量必须大于0");
                    errorList.add("on_hand_qty" + errLine);
                    info.setFlag(false);
                    break;
                }

                if (annual_inventory.getSeq_no().equals(0.0) || "".equals(annual_inventory.getSeq_no()) || annual_inventory.getSeq_no() == null) {
                    info.setErrorMsg("工序必须大于0");
                    errorList.add("seq_no" + errLine);
                    info.setFlag(false);
                    break;
                }

                String bin = annual_inventory.getCustom_bin().substring(2, 3);
                if (!"5".equals(bin) && !"0".equals(bin)) {
                    info.setErrorMsg("存置地点第三位维护错误");
                    errorList.add("custom_bin" + errLine);
                    info.setFlag(false);
                    break;
                }

                if (bin_list.contains(annual_inventory.getCustom_bin())) {
                    int position = bin_list.indexOf(annual_inventory.getCustom_bin());
                    String item_wknr = annual_inventory.getItem_no() + annual_inventory.getEquipment_name();
                    if (!iw_list.get(position).equals(item_wknr)) {
                        info.setErrorMsg("同一存置地点只能存放一个品番+工作中心");
                        errorList.add("item_no" + errLine);
                        info.setFlag(false);
                        break;
                    }
                } else {
                    bin_list.add(annual_inventory.getCustom_bin());
                    iw_list.add(annual_inventory.getItem_no() + annual_inventory.getEquipment_name());
                }
                Bnd_master_mo master_mo = iBnd_master_moService.findByMo(annual_inventory.getLot_no());
                if (master_mo != null) {
                    if (!master_mo.getItem_no().trim().equals(annual_inventory.getItem_no().trim())) {
                        info.setErrorMsg("批号错误");
                        errorList.add("lot_no" + errLine);
                        info.setFlag(false);
                        break;
                    }
                }
                break;
            } while (true);
            b++;
            if (b == c) break;
        }
        info.setErrorList(errorList);
        // 响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(), info);
    }


    @RequestMapping("/delete.do")
    public String delete(String psa) throws Exception {
        iBnd_stock_wip_uploadService.deleteBypsa(psa);
        return "redirect:findBypsa.do";

    }


}


