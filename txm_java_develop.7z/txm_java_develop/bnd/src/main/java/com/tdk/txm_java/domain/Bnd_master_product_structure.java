package com.tdk.txm_java.domain;

public class Bnd_master_product_structure {
    private int id;
    private String item_no;
    private Double revision_no;
    private String circuit_code;
    private Double circuit_no;
    private String effective_date_mfg_lot;
    private String expiry_date_mfg_lot;
    private String alternative_item_no;
    private Double alternative_revision_no;
    private String component_item_no;
    private Double component_revision_no;
    private Double operation_sequence_no;
    private String individual_require_flag;
    private Double componentparent_itemc;
    private Double component_qtyparent_qty;
    private Double spare_partsstd_lot_s;
    private Double spare_partsstd_lot;
    private String service_parts_flag;
    private String automatic_insertion_code;
    private Double option_planning_factor;
    private String adjust_lt_code;
    private Double adjust_lt;
    private Double yield;
    private Double setup_yield;
    private String safety_standard_code1;
    private String safety_standard_code2;
    private String ait_item_group;
    private String routing_no;
    private String bom_number;
    private String alternative_bom;
    private String bom_item_node_number;
    private String equipment_name;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getItem_no() {
        return item_no;
    }

    public void setItem_no(String item_no) {
        this.item_no = item_no;
    }

    public Double getRevision_no() {
        return revision_no;
    }

    public void setRevision_no(Double revision_no) {
        this.revision_no = revision_no;
    }

    public String getCircuit_code() {
        return circuit_code;
    }

    public void setCircuit_code(String circuit_code) {
        this.circuit_code = circuit_code;
    }

    public Double getCircuit_no() {
        return circuit_no;
    }

    public void setCircuit_no(Double circuit_no) {
        this.circuit_no = circuit_no;
    }

    public String getEffective_date_mfg_lot() {
        return effective_date_mfg_lot;
    }

    public void setEffective_date_mfg_lot(String effective_date_mfg_lot) {
        this.effective_date_mfg_lot = effective_date_mfg_lot;
    }

    public String getExpiry_date_mfg_lot() {
        return expiry_date_mfg_lot;
    }

    public void setExpiry_date_mfg_lot(String expiry_date_mfg_lot) {
        this.expiry_date_mfg_lot = expiry_date_mfg_lot;
    }

    public String getAlternative_item_no() {
        return alternative_item_no;
    }

    public void setAlternative_item_no(String alternative_item_no) {
        this.alternative_item_no = alternative_item_no;
    }

    public Double getAlternative_revision_no() {
        return alternative_revision_no;
    }

    public void setAlternative_revision_no(Double alternative_revision_no) {
        this.alternative_revision_no = alternative_revision_no;
    }

    public String getComponent_item_no() {
        return component_item_no;
    }

    public void setComponent_item_no(String component_item_no) {
        this.component_item_no = component_item_no;
    }

    public Double getComponent_revision_no() {
        return component_revision_no;
    }

    public void setComponent_revision_no(Double component_revision_no) {
        this.component_revision_no = component_revision_no;
    }

    public Double getOperation_sequence_no() {
        return operation_sequence_no;
    }

    public void setOperation_sequence_no(Double operation_sequence_no) {
        this.operation_sequence_no = operation_sequence_no;
    }

    public String getIndividual_require_flag() {
        return individual_require_flag;
    }

    public void setIndividual_require_flag(String individual_require_flag) {
        this.individual_require_flag = individual_require_flag;
    }

    public Double getComponentparent_itemc() {
        return componentparent_itemc;
    }

    public void setComponentparent_itemc(Double componentparent_itemc) {
        this.componentparent_itemc = componentparent_itemc;
    }

    public Double getComponent_qtyparent_qty() {
        return component_qtyparent_qty;
    }

    public void setComponent_qtyparent_qty(Double component_qtyparent_qty) {
        this.component_qtyparent_qty = component_qtyparent_qty;
    }

    public Double getSpare_partsstd_lot_s() {
        return spare_partsstd_lot_s;
    }

    public void setSpare_partsstd_lot_s(Double spare_partsstd_lot_s) {
        this.spare_partsstd_lot_s = spare_partsstd_lot_s;
    }

    public Double getSpare_partsstd_lot() {
        return spare_partsstd_lot;
    }

    public void setSpare_partsstd_lot(Double spare_partsstd_lot) {
        this.spare_partsstd_lot = spare_partsstd_lot;
    }

    public String getService_parts_flag() {
        return service_parts_flag;
    }

    public void setService_parts_flag(String service_parts_flag) {
        this.service_parts_flag = service_parts_flag;
    }

    public String getAutomatic_insertion_code() {
        return automatic_insertion_code;
    }

    public void setAutomatic_insertion_code(String automatic_insertion_code) {
        this.automatic_insertion_code = automatic_insertion_code;
    }

    public Double getOption_planning_factor() {
        return option_planning_factor;
    }

    public void setOption_planning_factor(Double option_planning_factor) {
        this.option_planning_factor = option_planning_factor;
    }

    public String getAdjust_lt_code() {
        return adjust_lt_code;
    }

    public void setAdjust_lt_code(String adjust_lt_code) {
        this.adjust_lt_code = adjust_lt_code;
    }

    public Double getAdjust_lt() {
        return adjust_lt;
    }

    public void setAdjust_lt(Double adjust_lt) {
        this.adjust_lt = adjust_lt;
    }

    public Double getYield() {
        return yield;
    }

    public void setYield(Double yield) {
        this.yield = yield;
    }

    public Double getSetup_yield() {
        return setup_yield;
    }

    public void setSetup_yield(Double setup_yield) {
        this.setup_yield = setup_yield;
    }

    public String getSafety_standard_code1() {
        return safety_standard_code1;
    }

    public void setSafety_standard_code1(String safety_standard_code1) {
        this.safety_standard_code1 = safety_standard_code1;
    }

    public String getSafety_standard_code2() {
        return safety_standard_code2;
    }

    public void setSafety_standard_code2(String safety_standard_code2) {
        this.safety_standard_code2 = safety_standard_code2;
    }

    public String getAit_item_group() {
        return ait_item_group;
    }

    public void setAit_item_group(String ait_item_group) {
        this.ait_item_group = ait_item_group;
    }

    public String getRouting_no() {
        return routing_no;
    }

    public void setRouting_no(String routing_no) {
        this.routing_no = routing_no;
    }

    public String getBom_number() {
        return bom_number;
    }

    public void setBom_number(String bom_number) {
        this.bom_number = bom_number;
    }

    public String getAlternative_bom() {
        return alternative_bom;
    }

    public void setAlternative_bom(String alternative_bom) {
        this.alternative_bom = alternative_bom;
    }

    public String getBom_item_node_number() {
        return bom_item_node_number;
    }

    public void setBom_item_node_number(String bom_item_node_number) {
        this.bom_item_node_number = bom_item_node_number;
    }

    public String getEquipment_name() {
        return equipment_name;
    }

    public void setEquipment_name(String equipment_name) {
        this.equipment_name = equipment_name;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    @Override
    public String toString() {
        return "Bnd_master_product_structure{" +
                "id=" + id +
                ", item_no='" + item_no + '\'' +
                ", revision_no=" + revision_no +
                ", circuit_code='" + circuit_code + '\'' +
                ", circuit_no=" + circuit_no +
                ", effective_date_mfg_lot='" + effective_date_mfg_lot + '\'' +
                ", expiry_date_mfg_lot='" + expiry_date_mfg_lot + '\'' +
                ", alternative_item_no='" + alternative_item_no + '\'' +
                ", alternative_revision_no=" + alternative_revision_no +
                ", component_item_no='" + component_item_no + '\'' +
                ", component_revision_no=" + component_revision_no +
                ", operation_sequence_no=" + operation_sequence_no +
                ", individual_require_flag='" + individual_require_flag + '\'' +
                ", componentparent_itemc=" + componentparent_itemc +
                ", component_qtyparent_qty=" + component_qtyparent_qty +
                ", spare_partsstd_lot_s=" + spare_partsstd_lot_s +
                ", spare_partsstd_lot=" + spare_partsstd_lot +
                ", service_parts_flag='" + service_parts_flag + '\'' +
                ", automatic_insertion_code='" + automatic_insertion_code + '\'' +
                ", option_planning_factor=" + option_planning_factor +
                ", adjust_lt_code='" + adjust_lt_code + '\'' +
                ", adjust_lt=" + adjust_lt +
                ", yield=" + yield +
                ", setup_yield=" + setup_yield +
                ", safety_standard_code1='" + safety_standard_code1 + '\'' +
                ", safety_standard_code2='" + safety_standard_code2 + '\'' +
                ", ait_item_group='" + ait_item_group + '\'' +
                ", routing_no='" + routing_no + '\'' +
                ", bom_number='" + bom_number + '\'' +
                ", alternative_bom='" + alternative_bom + '\'' +
                ", bom_item_node_number='" + bom_item_node_number + '\'' +
                ", equipment_name='" + equipment_name + '\'' +
                ", login_time='" + login_time + '\'' +
                ", login_oid='" + login_oid + '\'' +
                ", update_time='" + update_time + '\'' +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                '}';
    }
}
