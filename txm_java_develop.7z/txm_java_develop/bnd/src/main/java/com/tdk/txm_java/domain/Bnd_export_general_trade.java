package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_export_general_trade {
    private int id;
    private String state;
    private String declare_date;
    private String declaration_no;
    private double declaration_amt;
    private String declare_port;
    private String list_no;
    private String invoice_no;
    private String terms_trade;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;
    private String mrp;
    private String currency;
    private double invoice_amt;
    private String errmsg;

}
