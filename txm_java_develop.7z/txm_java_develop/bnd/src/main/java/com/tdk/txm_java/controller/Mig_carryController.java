package com.tdk.txm_java.controller;

import com.tdk.txm_java.dao.*;
import com.tdk.txm_java.dao2.*;
import com.tdk.txm_java.domain.*;
import com.tdk.txm_java.service.IBnd_mig_listService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;

@Component
@Controller
@RequestMapping("/mig_carry")
public class Mig_carryController {
    @Autowired
    private IH2z1pDao iH2z1pDao;
    @Autowired
    private IBnd_carry_vendor_basicDao iBnd_carry_vendor_basicDao;

    @Autowired
    private IH2z2pDao iH2z2pDao;
    @Autowired
    private IBnd_carry_vendor_detailedDao iBnd_carry_vendor_detailedDao;

    @Autowired
    private IH2jkpDao iH2jkpDao;
    @Autowired
    private IBnd_carry_po_controllerDao iBnd_carry_po_controllerDao;
    @Autowired
    private IBnd_mig_listService iBnd_mig_listService;

    @Autowired
    private IHmzbpDao iHmzbpDao;
    @Autowired
    private IBnd_carry_vendorEms_masterDao iBnd_carry_vendorEms_masterDao;
    @Autowired
    private IHmzapDao iHmzapDao;
    @Autowired
    private IBnd_carry_vendor_arrivalDao iBnd_carry_vendor_arrivalDao;
    @Autowired
    private IHmzcpDao iHmzcpDao;
    @Autowired
    private IBnd_carry_invt_listDao iBnd_carry_invt_listDao;
    @Autowired
    private IXtfmpDao iXtfmpDao;
    @Autowired
    private IBnd_carry_invoice_fileDao iBnd_carry_invoice_fileDao;
    @Autowired
    private IHtocpDao iHtocpDao;
    @Autowired
    private IBnd_carry_cif_priceDao iBnd_carry_cif_priceDao;
    @Autowired
    private IXtaapDao iXtaapDao;
    @Autowired
    private IBnd_export_return_replacementDao iBnd_export_return_replacementDao;

    @Autowired
    private IXwz1pDao iXwz1pDao;

    @Autowired
    private IXwz5pDao iXwz5pDao;

    @Autowired
    private IBnd_import_operationDao iBnd_import_operationDao;
    @Autowired
    private IBnd_import_feeDao iBnd_import_feeDao;

    @Autowired
    private ITxqkpDao iTxqkpDao;
    @Autowired
    private IBnd_master_trade_codeDao iBnd_master_trade_codeDao;
    @Autowired
    private ITxqopDao iTxqopDao;
    @Autowired
    private IBnd_master_company_codeDao iBnd_master_company_codeDao;
    @Autowired
    private IXtz3pDao iXtz3pDao;
    @Autowired
    private IBnd_import_declarationDao iBnd_import_declarationDao;
    @Autowired
    private IXtfipDao iXtfipDao;
    @Autowired
    private IBnd_export_airway_listDao iBnd_export_airway_listDao;



    @RequestMapping("/mig_vendor_basic.do")
    public ModelAndView mig_vendor_basic() throws Exception {
        // mig h2z1p
        ModelAndView mv = new ModelAndView ();
        List<Bnd_carry_vendor_basic> ces = iH2z1pDao.findAll ();
        iBnd_carry_vendor_basicDao.deleteAll ();
        //数据量太大，分批保存

        if (ces.size () > 2000) {
            List<Bnd_carry_vendor_basic> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_carry_vendor_basic bnd_carry_vendor_basic : ces) {
                ces02.add (bnd_carry_vendor_basic);
                if (a == 2000) {
                    iBnd_carry_vendor_basicDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_carry_vendor_basicDao.saveByList (ces02);
        } else {
            iBnd_carry_vendor_basicDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_carry_vendor_basic");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;

    }


    /**
     * @Author Yu Liqin
     * @Description //TODO a801550 migrition H2Z2P
     * @Date 2020/6/15
     * @Time 上午 09:57
     **/

    @RequestMapping("/mig_vendor_detailed.do")
    public ModelAndView mig_vendor_detailed() throws Exception {
        // mig h2z2p
        ModelAndView mv = new ModelAndView ();
        List<Bnd_carry_vendor_detailed> ces = iH2z2pDao.findAll ();
        iBnd_carry_vendor_detailedDao.deleteAll ();
        //数据量太大，分批保存

        if (ces.size () > 2000) {
            List<Bnd_carry_vendor_detailed> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_carry_vendor_detailed bnd_carry_vendor_detailed : ces) {
                ces02.add (bnd_carry_vendor_detailed);
                if (a == 2000) {
                    iBnd_carry_vendor_detailedDao.saveByListAll (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_carry_vendor_detailedDao.saveByListAll (ces02);
        } else {
            iBnd_carry_vendor_detailedDao.saveByListAll (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_carry_vendor_detailed");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;

    }


    /**
     * @Author Yu Liqin
     * @Description //TODO a801550 migrition H2JKP
     * @Date 2020/6/15
     * @Time 上午 09:57
     **/

    @RequestMapping("/mig_po_controller.do")
    public ModelAndView mig_po_controller() throws Exception {
        // mig h2z1p
        ModelAndView mv = new ModelAndView ();
        List<Bnd_carry_po_controller> ces = iH2jkpDao.findAll ();
        iBnd_carry_po_controllerDao.deleteAll ();
        //数据量太大，分批保存

        if (ces.size () > 2000) {
            List<Bnd_carry_po_controller> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_carry_po_controller bnd_carry_po_controller : ces) {
                ces02.add (bnd_carry_po_controller);
                if (a == 2000) {
                    iBnd_carry_po_controllerDao.saveByListAll (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_carry_po_controllerDao.saveByListAll (ces02);
        } else {
            iBnd_carry_po_controllerDao.saveByListAll (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_carry_po_controller");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;

    }

    /**
     * @Author Yu Liqin
     * @Description //TODO a801550
     * @Date 2020/7/8
     * @Time 下午 01:18
     **/
    @RequestMapping("/mig_vendor_ems_master.do")
    public ModelAndView mig_vendor_ems_master() throws Exception {
        // mig hmzbp 進口轉廠供應商賬冊號主檔
        ModelAndView mv = new ModelAndView ();
        List<Bnd_carry_vendorEms_master> ces = iHmzbpDao.findAll ();
        iBnd_carry_vendorEms_masterDao.deleteAll ();
        //数据量太大，分批保存

        if (ces.size () > 2000) {
            List<Bnd_carry_vendorEms_master> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_carry_vendorEms_master bnd_carry_vendorEms_master : ces) {
                ces02.add (bnd_carry_vendorEms_master);
                if (a == 2000) {
                    iBnd_carry_vendorEms_masterDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_carry_vendorEms_masterDao.saveByList (ces02);
        } else {
            iBnd_carry_vendorEms_masterDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_carry_vendor_ems_master");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;

    }

    /**
     * @Author Yu Liqin
     * @Description //TODO a801550
     * @Date  2020/7/9
     * @Time  上午 09:54
     **/
    @RequestMapping("/mig_vendor_arrival.do")
    public ModelAndView mig_vendor_arrival() throws Exception {
        // mig hmzap 進口結轉到貨明細檔
        ModelAndView mv = new ModelAndView ();
        List<Bnd_carry_vendor_arrival> ces = iHmzapDao.findAll ();
        iBnd_carry_vendor_arrivalDao.deleteAll ();
        //数据量太大，分批保存

        if (ces.size () > 2000) {
            List<Bnd_carry_vendor_arrival> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_carry_vendor_arrival bnd_carry_vendor_arrival : ces) {
                ces02.add (bnd_carry_vendor_arrival);
                if (a == 2000) {
                    iBnd_carry_vendor_arrivalDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_carry_vendor_arrivalDao.saveByList (ces02);
        } else {
            iBnd_carry_vendor_arrivalDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_carry_vendor_arrival");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;

    }
/**
 * @Author Yu Liqin
 * @Description //TODO a801550
 * @Date  2020/7/9
 * @Time  上午 10:42
 **/


    @RequestMapping("/mig_invt_list.do")
    public ModelAndView mig_invt_list() throws Exception {
        // mig hmzcp 進口轉廠核註清單發票別明細
        ModelAndView mv = new ModelAndView ();
        List<Bnd_carry_invt_list> ces = iHmzcpDao.findAll ();
        iBnd_carry_invt_listDao.deleteAll ();
        //数据量太大，分批保存

        if (ces.size () > 2000) {
            List<Bnd_carry_invt_list> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_carry_invt_list bnd_carry_invt_list : ces) {
                ces02.add (bnd_carry_invt_list);
                if (a == 2000) {
                    iBnd_carry_invt_listDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_carry_invt_listDao.saveByList (ces02);
        } else {
            iBnd_carry_invt_listDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_carry_invt_list");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;

    }

    /**
     * @Author Yu Liqin
     * @Description //TODO a801550
     * @Date  2020/7/23
     * @Time  下午 02:04
     **/

    @RequestMapping("/mig_invoice_file.do")
    public ModelAndView mig_invoice_file() throws Exception {
        // mig hmzcp 進口轉廠核註清單發票別明細
        ModelAndView mv = new ModelAndView ();
        List<Bnd_carry_invoice_file> ces = iXtfmpDao.findAll ();
        iBnd_carry_invoice_fileDao.deleteAll ();
        //数据量太大，分批保存

        if (ces.size () > 2000) {
            List<Bnd_carry_invoice_file> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_carry_invoice_file bnd_carry_invoice_file : ces) {
                ces02.add (bnd_carry_invoice_file);
                if (a == 2000) {
                    iBnd_carry_invoice_fileDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_carry_invoice_fileDao.saveByList (ces02);
        } else {
            iBnd_carry_invoice_fileDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_carry_invoice_file");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;

    }

    /**
     * @Author Yu Liqin
     * @Description //TODO a801550
     * @Date  2020/7/29
     * @Time  下午 03:53
     **/


    @RequestMapping("/mig_cif_price.do")
    public ModelAndView mig_cif_price() throws Exception {
        // mig hmzcp 進口轉廠核註清單發票別明細
        ModelAndView mv = new ModelAndView ();
        List<Bnd_carry_cif_price> ces = iHtocpDao.findAll ();
        iBnd_carry_cif_priceDao.deleteAll ();
        //数据量太大，分批保存

        if (ces.size () > 2000) {
            List<Bnd_carry_cif_price> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_carry_cif_price bnd_carry_cif_price : ces) {
                ces02.add (bnd_carry_cif_price);
                if (a == 2000) {
                    iBnd_carry_cif_priceDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_carry_cif_priceDao.saveByList (ces02);
        } else {
            iBnd_carry_cif_priceDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_carry_cif_price");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;

    }

    /**
     * @Author Yu Liqin
     * @Description //TODO a801550
     * @Date  2020/7/30
     * @Time  下午 02:43
     **/

    @RequestMapping("/mig_return_replacement.do")
    public ModelAndView mig_return_replacement() throws Exception {
        // mig xtaap 進口轉廠核註清單發票別明細
        ModelAndView mv = new ModelAndView ();
        List<Bnd_export_return_replacement> ces = iXtaapDao.findAll ();
        iBnd_export_return_replacementDao.deleteAll ();
        //数据量太大，分批保存

        if (ces.size () > 2000) {
            List<Bnd_export_return_replacement> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_export_return_replacement bnd_export_return_replacement : ces) {
                ces02.add (bnd_export_return_replacement);
                if (a == 2000) {
                    iBnd_export_return_replacementDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_export_return_replacementDao.saveByList (ces02);
        } else {
            iBnd_export_return_replacementDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_export_return_replacement");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;

    }

    /**
     * @Author Yu Liqin
     * @Description //TODO a801550
     * @Date  2020/10/22
     * @Time  下午 01:14
     **/
    @RequestMapping("/mig_import_operation.do")
    public ModelAndView mig_import_operation() throws Exception {
        // mig XWZ1P 进口作业管理
        ModelAndView mv = new ModelAndView ();
        List<Bnd_import_operation> ces = iXwz1pDao.findAll ();
        iBnd_import_operationDao.deleteAll ();
        //数据量太大，分批保存

        if (ces.size () > 2000) {
            List<Bnd_import_operation> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_import_operation bnd_import_operation : ces) {
                ces02.add (bnd_import_operation);
                if (a == 2000) {
                    iBnd_import_operationDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_import_operationDao.saveByList (ces02);
        } else {
            iBnd_import_operationDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_import_operation");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;

    }

    /**
     * @Author Wang FengCai
     * @Description xwz5p (bnd_import_fee)数据迁移
     * @Date  2020/11/4
     **/
    @RequestMapping("/mig_import_fee.do")
    public ModelAndView mig_import_fee() throws Exception {
        // mig XWZ5P 进口费用修改
        ModelAndView mv = new ModelAndView ();
        List<Bnd_import_fee> fee = iXwz5pDao.findAll ();
        iBnd_import_feeDao.deleteAll ();
        //数据量太大，分批保存
        if (fee.size () > 2000) {
            List<Bnd_import_fee> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_import_fee bnd_import_fee : fee) {
                ces02.add (bnd_import_fee);
                if (a == 2000) {
                    iBnd_import_feeDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0)
                iBnd_import_feeDao.saveByList (ces02);
        } else {
            iBnd_import_feeDao.saveByList (fee);
        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_import_fee");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;

    }


    /**
     * @Author Yu Liqin
     * @Description //TODO a801550
     * @Date  2020/11/4
     * @Time  下午 02:56
     **/


    @RequestMapping("/mig_master_trade_code.do")
    public ModelAndView mig_master_trade_code() throws Exception {
        // mig TXQKP 进口作业管理
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_trade_code> ces = iTxqkpDao.findAll ();
        iBnd_master_trade_codeDao.deleteAll ();
        //数据量太大，分批保存

        if (ces.size () > 2000) {
            List<Bnd_master_trade_code> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_trade_code bnd_master_trade_code : ces) {
                ces02.add (bnd_master_trade_code);
                if (a == 2000) {
                    iBnd_master_trade_codeDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_trade_codeDao.saveByList (ces02);
        } else {
            iBnd_master_trade_codeDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_trade_code");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;

    }

    /**
     * @Author Yu Liqin
     * @Description //TODO a801550
     * @Date  2020/11/4
     * @Time  下午 03:43
     **/

    @RequestMapping("/mig_master_company_code.do")
    public ModelAndView mig_master_company_code() throws Exception {
        // mig TXQOP 进口作业管理
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_company_code> ces = iTxqopDao.findAll ();
        iBnd_master_company_codeDao.deleteAll ();
        //数据量太大，分批保存

        if (ces.size () > 2000) {
            List<Bnd_master_company_code> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_company_code bnd_master_company_code : ces) {
                ces02.add (bnd_master_company_code);
                if (a == 2000) {
                    iBnd_master_company_codeDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_company_codeDao.saveByList (ces02);
        } else {
            iBnd_master_company_codeDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_company_code");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;

    }


    @RequestMapping("/mig_import_declaration.do")
    public ModelAndView mig_import_declaration() throws Exception {
        // mig xtz3p <Bnd_import_declaration>
        ModelAndView mv = new ModelAndView ();
        List<Bnd_import_declaration> ces = iXtz3pDao.findAll();
        iBnd_import_declarationDao.deleteAll ();
        //数据量太大，分批保存

        if (ces.size () > 500) {
            List<Bnd_import_declaration> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_import_declaration bnd_import_declaration : ces) {
                ces02.add (bnd_import_declaration);
                if (a == 500) {
                    iBnd_import_declarationDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_import_declarationDao.saveByList (ces02);
        } else {
            iBnd_import_declarationDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_import_declaration");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;

    }

    /**
     * @Author Yu Liqin
     * @Description //迁移XTFIP
     * @Date  2021/1/7
     * @Time  上午 10:23
     **/
    @RequestMapping("/mig_export_airway_list.do")
    public ModelAndView mig_export_airway_list() throws Exception {
        // mig xtfip <Bnd_export_airway_list>
        ModelAndView mv = new ModelAndView ();
        List<Bnd_export_airway_list> ces = iXtfipDao.findAll();
        iBnd_export_airway_listDao.deleteAll ();
        //数据量太大，分批保存

        if (ces.size () > 500) {
            List<Bnd_export_airway_list> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_export_airway_list bnd_export_airway_list : ces) {
                ces02.add (bnd_export_airway_list);
                if (a == 500) {
                    iBnd_export_airway_listDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_export_airway_listDao.saveByList (ces02);
        } else {
            iBnd_export_airway_listDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_export_airway_list");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;

    }


}

