package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_if_fmts_process_d {
    private int id;
    private String pmcoce;//CO_CODE
    private String pmyymm;//STAKE_MONTH
    private String pmwipi;//WIP_ID
    private Double pmwips;//WIP_SEQ
    private String pmsapm;//SAP_MO
    private String pmmonr;//MTS_LOT
    private Double pmopsq;//OPERATION SEQUENCE NO.
    private String pmwknr;//WORK CENTER NO.
    private String pmmitn;//MATERIAL ITEM NO.
    private String pmmlot;//MATERIAL LOT NO.
    private Double pmbomv;//BOM_VER
    private Double pmmqty;//MATERIAL QTY
    private Double pmdftq;//MATERIAL DEFECT QTY
    private Double pmlosq;//MATERIAL LOSS QTY
    private String pmrcdt;//RECORD TYPE
    private String pmstat;//0-SEND 1-COMPLETED
    private String pmupdt;//UPDATE TIME
    private String pmvdlo;//VENDOR LOT NO.



    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;


}
