package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_stock_bond_flag {
    private int id;
    private String bond_flag;
    private String stock_bond_flag;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;


}
