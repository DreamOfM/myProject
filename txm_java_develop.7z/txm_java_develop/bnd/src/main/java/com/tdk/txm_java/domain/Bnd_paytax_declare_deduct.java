package com.tdk.txm_java.domain;


import lombok.Data;

import java.sql.Time;
import java.util.Date;

@Data
public class Bnd_paytax_declare_deduct {
    private int id;
    private String item_no;
    private String internal_number;
    private String ems_no;
    private String declaration_no;
    private Double declare_qty;
    private Double declare_net;
    private Double declare_amt;
    private Double used_qty;
    private Double used_net;
    private Double used_amt;
    private String currency;
    private String declare_date;
    private String country_code;
    private Time login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;

}
