package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Time;

@Data
public class Bnd_paytax_special_item {

    private String ccc_code;
    private String item_code;
    private String type;
}
