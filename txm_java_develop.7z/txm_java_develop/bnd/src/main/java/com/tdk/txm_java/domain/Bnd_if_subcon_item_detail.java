package com.tdk.txm_java.domain;

import lombok.Data;

import java.util.Date;


@Data
public class Bnd_if_subcon_item_detail {
    private  int id;
    private String apply_no;//申請表編號
    private String vendor_code;//供應商
    private String operation_type;//委外類別
    private String psa_code;//PSA
    private String item_no;//品名代碼
    private Double operation_sequence_no;//工序
    private Double standard_cost;//委外單價
    private String currency;//CURRENCY
    private String item_description_dbcs;//中文名稱
    private String um_physical_inventory;//監管單位
    private Double cf_physical_inventory;//盤點單位換算係數
    private Double img_no;//歸併項號
    private String ccc_code;//商編
    private String date_from;//有效日期
    private String date_to;//失效日期
    private Double data_state;//0-SEND 1-COMPLETED
    private String update_date;//UPDATE TEIME



    private Date login_time;
    private String login_oid;
    private Date update_time;
    private String update_oid;
    private String update_program;

}
