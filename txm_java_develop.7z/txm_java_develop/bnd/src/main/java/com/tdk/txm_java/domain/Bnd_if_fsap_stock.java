package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Time;

@Data
public class Bnd_if_fsap_stock {
    private int id;
    private String bayymm;//STAKE MONTH
    private String baflag;//FLAG
    private String bamrpc;//MRP
    private String baitnr;//ITEM NO.
    private String basttp;//STORAGE TYPE
    private String baltno;//BATCH
    private String bababf;//BALANCE BOND FLAG
    private Double baohdq;//ON HAND QTY
    private String baioum;//U/M (INCOMING & OUTGOING)
    private String basklc;//STOCK LOCATION
    private Double bapric;//PRICE
    private Double baprcn;//PRICE NUMBER
    private String bastca;//STOCK CATEGORY
    private String baspsi;//SPECIAL STOCK INDICATOR
    private String baspsn;//SPECIAL STOCK NUMBER
    private Double bastat;//0-SEND 1-COMPLETED
    private Double baupdt;//UPDATE TEIME

    private String bonded_logo;
    private String um_incoming_outgoing;
    private String stock_code;
    private String stock_bond_flag;
    private String new_storage_bin;

    private Time login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;

}
