package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_if_fsap_mbom {
    private int id;
    private String bsitnr;//ITEM NO.
    private String bsbomn;//BOM NUMBER
    private String bsaltb;//ALTERNATIVE BOM
    private String bscktn;//ITEM NUMBER
    private String bsbinn;//BOM ITEM NODE NUMBER
    private String bscitm;//COMPONENT ITEM NO.
    private String bsaigr;//AIT. ITEM GROUP
    private String bsairo;//AIT. RANKING ORDER
    private String bsaist;//AIT. ITEM STRATEGY
    private Double bsaiup;//AIT. ITEM USAGE PROB. %
    private Double bsbsqt;//BASE QTY
    private Double bscprq;//COMPONENT QTY
    private Double bslosq;//LOSS QTY
    private Double bsstdl;//EFFECTIVE DATE/MFG LOT
    private Double bsltdl;//EXPIRY DATE/MFG LOT
    private Double bsstat;//0-SEND 1-COMPLETED

    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

}
