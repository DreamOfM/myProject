package com.tdk.txm_java.controller;


import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tdk.txm_java.domain.*;
import com.tdk.txm_java.service.*;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Controller
@RequestMapping("/bnd_master_declare_scrap")
public class Bnd_master_declare_scrapController {
    @Autowired
    private IBnd_master_declare_scrapService iBnd_master_declare_scrapService;
    @Autowired
    private IBnd_master_declare_scrapzService iBnd_master_declare_scrapzService;
    @Autowired
    private IBnd_master_declare_elementService iBnd_master_declare_elementService;
    @Autowired
    private IBnd_master_itemService iBnd_master_itemService;
    @Autowired
    private IBnd_master_ehandbook_dService iBnd_master_ehandbook_dService;
    @Autowired
    private IBnd_master_hs_codeService iBnd_master_hs_codeService;

    @RequestMapping("/findByitem_no")
    public ModelAndView findByitem_no(String item_no) throws Exception {
        List<Bnd_master_declare_scrap> bnd_master_declare_scrap = iBnd_master_declare_scrapService.findByitem_no(item_no);
        Bnd_master_declare_scrapz bnd_master_declare_scrapz = iBnd_master_declare_scrapzService.findByitem_no(item_no);
        Bnd_master_ehandbook_d bnd_master_ehandbook_d=iBnd_master_ehandbook_dService.findByitem(item_no);
        ModelAndView mv = new ModelAndView();
        System.out.println("yayayyaa");
        System.out.println(bnd_master_declare_scrap);
//        if (item_no!="" && (bnd_master_declare_material == null || bnd_master_declare_material.size() == 0)) {
//            mv.setViewName("bnd-master-material-add");
//        } else {
            mv.setViewName("bnd-master-scrap-list");
            mv.addObject("bnd_master_declare_scrap", bnd_master_declare_scrap);
            mv.addObject("bnd_master_declare_scrapz", bnd_master_declare_scrapz);
            mv.addObject("bnd_master_ehandbook_d", bnd_master_ehandbook_d);
//        }
        mv.addObject("item_no", item_no);
        return mv;
    }

    /**
     * 删除
     *
     * @param
     * @return
     * @throws Exception
     */
    @RequestMapping("/delete.do")

    public String delete(HttpServletRequest request, HttpServletResponse response) {
        String items = request.getParameter("delitems");
        String item_no = request.getParameter("item_no");
        String[] strs = items.split(",");
        try {
            iBnd_master_declare_scrapzService.delete(item_no);
        } catch (Exception e) {
            e.printStackTrace();
        }
        for (int i = 0; i < strs.length; i++) {
            try {
                int a = Integer.parseInt(strs[i]);
                iBnd_master_declare_scrapService.delete(a);
            } catch (Exception e) {
            }
        }

        return "redirect:findByitem_no.do";
    }



    /**
     * 新增
     *
     * @param
     * @return
     * @throws Exception
     */
    @RequestMapping("/save.do")
    public String save(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession, RedirectAttributes attr) throws Exception {

        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Map<String, String> hashMap1 = new HashMap<>();
//        String[] vals1 = (String[]) map.get("item_no");

        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        Bnd_master_declare_scrap bnd_master_declare_scrap = new Bnd_master_declare_scrap();
        Bnd_master_declare_scrapz bnd_master_declare_scrapz = new Bnd_master_declare_scrapz();

        String valz = "";
        while (1 == 1) {
            for (String name1 : set) {
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                if (name1.equals("item_no") || name1.equals("img_no") || name1.equals("bonded_logo") || name1.equals("ccc_code") || name1.equals("brand_type") || name1.equals("export_discount") || name1.equals("um_physical_inventory") || name1.equals("item_description_dbcs")|| name1.equals("item_description_dbcs1") || name1.equals("item_description_dbcs2")|| name1.equals("net_weigh") || name1.equals("lawf_unitcd") || name1.equals("lawf_unitcd_cf") || name1.equals("secd_lawf_unitcd") || name1.equals("secd_lawf_unitcd_cf")  || name1.equals("unit_price")) {
                    hashMap.put(name1, vals[0]);
                    if (b == 0) {
                        hashMap1.put(name1, vals[0]);
                        if (name1.equals("brand_type")) {
                            valz = vals[0];
                        }
                        if (name1.equals("export_discount")) {
                            valz = valz + '|' + vals[0];
                        }
                    }
                } else {
                    hashMap.put(name1, vals[b]);
                    if (name1.equals("content")) {
                        valz = valz + '|' + vals[b];
                    }
                }
            }
            try {
                BeanUtils.populate(bnd_master_declare_scrap, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //添加一个判断，如果为空值或者没有输入则不往数据库里插数据
            if (bnd_master_declare_scrap.getSerial_number().equals(null) || bnd_master_declare_scrap.getSerial_number().equals("")) {
                b++;
                if (b == c) break;
                continue;
            }
            String username = (String) httpSession.getAttribute("username");
            bnd_master_declare_scrap.setUpdate_oid(username);
            bnd_master_declare_scrap.setUpdate_program("/bnd_master_scrap/save.do");
            bnd_master_declare_scrap.setLogin_oid(username);
            iBnd_master_declare_scrapService.save(bnd_master_declare_scrap);
            b++;
            if (b == c) break;
        }

        hashMap1.put("content", valz);
        try {
            BeanUtils.populate(bnd_master_declare_scrapz, hashMap1);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        String username = (String) httpSession.getAttribute("username");
        bnd_master_declare_scrapz.setUpdate_oid(username);
        bnd_master_declare_scrapz.setUpdate_program("/bnd_master_scrap/save.do");
        bnd_master_declare_scrapz.setLogin_oid(username);
        iBnd_master_declare_scrapzService.save(bnd_master_declare_scrapz);

        String item_no= request.getParameter("item_no");
        return "redirect:findByitem_no.do";
    }


    //修改
    @RequestMapping("/update.do")
    public String update(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession)
            throws Exception {
        //取出前端传回的所有数据
        System.out.println("abababa");
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Map<String, String> hashMap1 = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        String username = (String) httpSession.getAttribute("username");
//        String item_no = request.getParameter("item_no");

        int b = 0;
        int c = 0;
        String valz = "";
        Bnd_master_declare_scrap bnd_master_declare_scrap = new Bnd_master_declare_scrap();
        Bnd_master_declare_scrapz bnd_master_declare_scrapz = new Bnd_master_declare_scrapz();

        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //将每一个key值对应的一组值放到数组里去
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                hashMap.put(name1, vals[b]);

                if (b == 0) {
                    hashMap1.put(name1, vals[0]);
                    if (name1.equals("brand_type")) {
                        valz = vals[0];
                    }
                    if (name1.equals("export_discount")) {
                        valz = valz + '|' + vals[0];
                    }
//                    if (name1.equals("content")) {
//                        valz = valz + '|' + vals[0];
//                    }
                } else if (name1.equals("content")) {
                    valz = valz + '|' + vals[b];
                }
            }

            System.out.println("fgfg"+valz);
            //根据key值找到集合中对应的id
            int id1 = Integer.parseInt(hashMap.get("id"));
            //找到这个id对应数据库里的数据，并取出
            bnd_master_declare_scrap = iBnd_master_declare_scrapService.findById(id1);
            System.out.println("ssss"+id1);
            System.out.println(bnd_master_declare_scrap);

            try {
                BeanUtils.populate(bnd_master_declare_scrap, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //调用业务层的update()方法
            bnd_master_declare_scrap.setUpdate_oid(username);
            bnd_master_declare_scrap.setUpdate_program("/bnd_master_scrap/update");
            iBnd_master_declare_scrapService.update(bnd_master_declare_scrap);
            b++;
            if (b == c) break;
        }

        hashMap1.put("content", valz);
        System.out.println("6868686" + valz);

        String item_no = hashMap.get("item_no");
        bnd_master_declare_scrapz = iBnd_master_declare_scrapzService.findByitem_no(item_no);
        System.out.println("989898" + item_no);
        System.out.println(bnd_master_declare_scrapz);
        try {
            BeanUtils.populate(bnd_master_declare_scrapz, hashMap1);
        } catch (
                IllegalAccessException e) {
            e.printStackTrace();
        } catch (
                InvocationTargetException e) {
            e.printStackTrace();
        }

        bnd_master_declare_scrapz.setUpdate_oid(username);
        bnd_master_declare_scrapz.setUpdate_program("/bnd_master_scrap/update.do");
        iBnd_master_declare_scrapzService.update(bnd_master_declare_scrapz);

        return "redirect:findByitem_no.do";
    }


    @RequestMapping("/findByitem_nocd.do")

    public ModelAndView findByitem_nocd(HttpServletResponse response, String item_no, String ccc_code) throws
            Exception, JsonGenerationException, JsonMappingException {
//        System.out.println("32323232");
        ResultInfo info = new ResultInfo();
        List<Bnd_master_declare_element> bnd_master_declare_element = iBnd_master_declare_elementService.findByccc_codewithout1(ccc_code);
        Bnd_master_hs_code bnd_master_hs_code = iBnd_master_hs_codeService.findByccc_code(ccc_code);
        Bnd_master_item bnd_master_item = iBnd_master_itemService.findByitem_no(item_no);
        Bnd_master_ehandbook_d bnd_master_ehandbook_d = iBnd_master_ehandbook_dService.findByItem_no(item_no);
        ModelAndView mv = new ModelAndView();
        mv.setViewName("bnd-master-scrap-add");
        mv.addObject("bnd_master_declare_element", bnd_master_declare_element);
        mv.addObject("bnd_master_item", bnd_master_item);
        mv.addObject("bnd_master_ehandbook_d", bnd_master_ehandbook_d);
        mv.addObject("item_no", item_no);
        mv.addObject("ccc_code", ccc_code);
        mv.addObject("bnd_master_hs_code", bnd_master_hs_code);
//        System.out.println(bnd_master_declare_element);
//        System.out.println(bnd_master_hs_code);
//        System.out.println(item_no);
//        System.out.println(ccc_code);
        return mv;
    }

    @RequestMapping("/checkcccd.do")

    public void checkcccd(HttpServletResponse response, String item_no,String ccc_code) throws
            Exception, JsonGenerationException, JsonMappingException {
//        System.out.println("32323232");
        ResultInfo info = new ResultInfo();
        List<Bnd_master_declare_element> bnd_master_declare_element = iBnd_master_declare_elementService.findByccc_codewithout1(ccc_code);
        Bnd_master_item bnd_master_item = iBnd_master_itemService.findByitem_no(item_no);
        List<Bnd_master_declare_scrap> bnd_master_declare_scrap = iBnd_master_declare_scrapService.findByitem_no(item_no);
        if (bnd_master_item == null || bnd_master_item.equals("")) {
            info.setFlag(false);
            info.setErrorMsg("品名主档不存在");
        } else if (bnd_master_declare_scrap.size() != 0) {
                info.setFlag(false);
                info.setErrorMsg("品名已存在");
        } else if (bnd_master_declare_element != null && bnd_master_declare_element.size() != 0) {
            info.setData(bnd_master_declare_element);
            info.setFlag(true);
//            System.out.println("AA11");
        } else {
            info.setFlag(false);
            info.setErrorMsg("商编要素没维护");
        }
        //响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(), info);

    }


}





