package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_stock_location_floor {
    private int id;
    private String stock_location;//存置地點
    private String stock_floor;//樓層
    private String login_time;//登陆时间login_time
    private String login_oid;//登陆人员login_oid
    private String update_time;//更新时间update_time
    private String update_oid;//更新人员update_oid
    private String update_program;//更新程序update_program

}
