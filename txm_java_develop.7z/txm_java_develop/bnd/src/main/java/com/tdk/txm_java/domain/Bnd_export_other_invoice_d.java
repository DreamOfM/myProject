package com.tdk.txm_java.domain;


import lombok.Data;

import java.sql.Time;
@Data
public class Bnd_export_other_invoice_d {
    private int id;
    private String invoice_no;//發票號碼
    private Integer express_id;//序號
    private String item_no;//ITEM
    private String item_description_dbcs;//中英文品名
    private String item_spec;//規格
    private Double unit_price;//單價
    private String currency;//幣別
    private Time login_time;//登陆时间login_time
    private String login_oid;//登陆人员login_oid
    private Time update_time;//更新时间update_time
    private String update_oid;//更新人员update_oid
    private String update_program;//更新程序update_program




}
