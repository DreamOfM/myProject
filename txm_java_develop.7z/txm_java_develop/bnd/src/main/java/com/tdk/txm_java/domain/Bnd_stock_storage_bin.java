package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_stock_storage_bin {
    private int id;
    private String stock_location;
    private String new_storage_bin;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

}
