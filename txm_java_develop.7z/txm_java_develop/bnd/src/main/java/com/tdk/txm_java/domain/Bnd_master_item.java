package com.tdk.txm_java.domain;

public class Bnd_master_item {
    private int id;
    private String item_no;
    private String material_type;
    private String procurement_flag;
    private String procurement_sample_flag;
    private String item_description_dbcs;
    private String item_descrip_en;
    private String item_spec;
    private String item_class_code;
    private String hs_code;
    private Double ie_tax_rate;
    private String um_incoming_outgoing;
    private String um_physical_inventory;
    private Double cf_physical_inventory;
    private String um_weight;
    private Double warranty_period;
    private Double net_weigh;
    private String bonded_logo;
    private String mrpcode;
    private Double img_no;
    private String engineering_drawing_no;
    private String safety_standard_code4;
    private Double pallet_qty;
    private String item_group_code;
    private Double standard_cost;
    private Double standard_cost_number;
    private String sorting_key1;
    private String sorting_key2;
    private String sorting_key3;
    private String sorting_key4;
    private String sorting_key5;
    private String sorting_key6;
    private String sorting_key7;
    private String sorting_key8;
    private String sorting_key9;
    private String sorting_key10;
    private String item_type;
    private String itemized_application_code;
    private String stock_code;
    private String rohs_flag;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getItem_no() {
        return item_no;
    }

    public void setItem_no(String item_no) {
        this.item_no = item_no;
    }

    public String getMaterial_type() {
        return material_type;
    }

    public void setMaterial_type(String material_type) {
        this.material_type = material_type;
    }

    public String getProcurement_flag() {
        return procurement_flag;
    }

    public void setProcurement_flag(String procurement_flag) {
        this.procurement_flag = procurement_flag;
    }

    public String getProcurement_sample_flag() {
        return procurement_sample_flag;
    }

    public void setProcurement_sample_flag(String procurement_sample_flag) {
        this.procurement_sample_flag = procurement_sample_flag;
    }

    public String getItem_description_dbcs() {
        return item_description_dbcs;
    }

    public void setItem_description_dbcs(String item_description_dbcs) {
        this.item_description_dbcs = item_description_dbcs;
    }

    public String getItem_descrip_en() {
        return item_descrip_en;
    }

    public void setItem_descrip_en(String item_descrip_en) {
        this.item_descrip_en = item_descrip_en;
    }

    public String getItem_spec() {
        return item_spec;
    }

    public void setItem_spec(String item_spec) {
        this.item_spec = item_spec;
    }

    public String getItem_class_code() {
        return item_class_code;
    }

    public void setItem_class_code(String item_class_code) {
        this.item_class_code = item_class_code;
    }

    public String getHs_code() {
        return hs_code;
    }

    public void setHs_code(String hs_code) {
        this.hs_code = hs_code;
    }

    public Double getIe_tax_rate() {
        return ie_tax_rate;
    }

    public void setIe_tax_rate(Double ie_tax_rate) {
        this.ie_tax_rate = ie_tax_rate;
    }

    public String getUm_incoming_outgoing() {
        return um_incoming_outgoing;
    }

    public void setUm_incoming_outgoing(String um_incoming_outgoing) {
        this.um_incoming_outgoing = um_incoming_outgoing;
    }

    public String getUm_physical_inventory() {
        return um_physical_inventory;
    }

    public void setUm_physical_inventory(String um_physical_inventory) {
        this.um_physical_inventory = um_physical_inventory;
    }

    public Double getCf_physical_inventory() {
        return cf_physical_inventory;
    }

    public void setCf_physical_inventory(Double cf_physical_inventory) {
        this.cf_physical_inventory = cf_physical_inventory;
    }

    public String getUm_weight() {
        return um_weight;
    }

    public void setUm_weight(String um_weight) {
        this.um_weight = um_weight;
    }

    public Double getWarranty_period() {
        return warranty_period;
    }

    public void setWarranty_period(Double warranty_period) {
        this.warranty_period = warranty_period;
    }

    public Double getNet_weigh() {
        return net_weigh;
    }

    public void setNet_weigh(Double net_weigh) {
        this.net_weigh = net_weigh;
    }

    public String getBonded_logo() {
        return bonded_logo;
    }

    public void setBonded_logo(String bonded_logo) {
        this.bonded_logo = bonded_logo;
    }

    public String getMrpcode() {
        return mrpcode;
    }

    public void setMrpcode(String mrpcode) {
        this.mrpcode = mrpcode;
    }

    public Double getImg_no() {
        return img_no;
    }

    public void setImg_no(Double img_no) {
        this.img_no = img_no;
    }

    public String getEngineering_drawing_no() {
        return engineering_drawing_no;
    }

    public void setEngineering_drawing_no(String engineering_drawing_no) {
        this.engineering_drawing_no = engineering_drawing_no;
    }

    public String getSafety_standard_code4() {
        return safety_standard_code4;
    }

    public void setSafety_standard_code4(String safety_standard_code4) {
        this.safety_standard_code4 = safety_standard_code4;
    }

    public Double getPallet_qty() {
        return pallet_qty;
    }

    public void setPallet_qty(Double pallet_qty) {
        this.pallet_qty = pallet_qty;
    }

    public String getItem_group_code() {
        return item_group_code;
    }

    public void setItem_group_code(String item_group_code) {
        this.item_group_code = item_group_code;
    }

    public Double getStandard_cost() {
        return standard_cost;
    }

    public void setStandard_cost(Double standard_cost) {
        this.standard_cost = standard_cost;
    }

    public Double getStandard_cost_number() {
        return standard_cost_number;
    }

    public void setStandard_cost_number(Double standard_cost_number) {
        this.standard_cost_number = standard_cost_number;
    }

    public String getSorting_key1() {
        return sorting_key1;
    }

    public void setSorting_key1(String sorting_key1) {
        this.sorting_key1 = sorting_key1;
    }

    public String getSorting_key2() {
        return sorting_key2;
    }

    public void setSorting_key2(String sorting_key2) {
        this.sorting_key2 = sorting_key2;
    }

    public String getSorting_key3() {
        return sorting_key3;
    }

    public void setSorting_key3(String sorting_key3) {
        this.sorting_key3 = sorting_key3;
    }

    public String getSorting_key4() {
        return sorting_key4;
    }

    public void setSorting_key4(String sorting_key4) {
        this.sorting_key4 = sorting_key4;
    }

    public String getSorting_key5() {
        return sorting_key5;
    }

    public void setSorting_key5(String sorting_key5) {
        this.sorting_key5 = sorting_key5;
    }

    public String getSorting_key6() {
        return sorting_key6;
    }

    public void setSorting_key6(String sorting_key6) {
        this.sorting_key6 = sorting_key6;
    }

    public String getSorting_key7() {
        return sorting_key7;
    }

    public void setSorting_key7(String sorting_key7) {
        this.sorting_key7 = sorting_key7;
    }

    public String getSorting_key8() {
        return sorting_key8;
    }

    public void setSorting_key8(String sorting_key8) {
        this.sorting_key8 = sorting_key8;
    }

    public String getSorting_key9() {
        return sorting_key9;
    }

    public void setSorting_key9(String sorting_key9) {
        this.sorting_key9 = sorting_key9;
    }

    public String getSorting_key10() {
        return sorting_key10;
    }

    public void setSorting_key10(String sorting_key10) {
        this.sorting_key10 = sorting_key10;
    }

    public String getItemized_application_code() {
        return itemized_application_code;
    }

    public void setItemized_application_code(String itemized_application_code) {
        this.itemized_application_code = itemized_application_code;
    }

    public String getStock_code() {
        return stock_code;
    }

    public void setStock_code(String stock_code) {
        this.stock_code = stock_code;
    }

    public String getRohs_flag() {
        return rohs_flag;
    }

    public void setRohs_flag(String rohs_flag) {
        this.rohs_flag = rohs_flag;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    public String getItem_type() {
        return item_type;
    }

    public void setItem_type(String item_type) {
        this.item_type = item_type;
    }

    @Override
    public String toString() {
        return "Bnd_master_item{" +
                "id=" + id +
                ", item_no='" + item_no + '\'' +
                ", material_type='" + material_type + '\'' +
                ", procurement_flag='" + procurement_flag + '\'' +
                ", procurement_sample_flag='" + procurement_sample_flag + '\'' +
                ", item_description_dbcs='" + item_description_dbcs + '\'' +
                ", item_descrip_en='" + item_descrip_en + '\'' +
                ", item_spec='" + item_spec + '\'' +
                ", item_class_code='" + item_class_code + '\'' +
                ", hs_code='" + hs_code + '\'' +
                ", ie_tax_rate=" + ie_tax_rate +
                ", um_incoming_outgoing='" + um_incoming_outgoing + '\'' +
                ", um_physical_inventory='" + um_physical_inventory + '\'' +
                ", cf_physical_inventory=" + cf_physical_inventory +
                ", um_weight='" + um_weight + '\'' +
                ", warranty_period=" + warranty_period +
                ", net_weigh=" + net_weigh +
                ", bonded_logo='" + bonded_logo + '\'' +
                ", mrpcode='" + mrpcode + '\'' +
                ", img_no=" + img_no +
                ", engineering_drawing_no='" + engineering_drawing_no + '\'' +
                ", safety_standard_code4='" + safety_standard_code4 + '\'' +
                ", pallet_qty=" + pallet_qty +
                ", item_group_code='" + item_group_code + '\'' +
                ", standard_cost=" + standard_cost +
                ", standard_cost_number=" + standard_cost_number +
                ", sorting_key1='" + sorting_key1 + '\'' +
                ", sorting_key2='" + sorting_key2 + '\'' +
                ", sorting_key3='" + sorting_key3 + '\'' +
                ", sorting_key4='" + sorting_key4 + '\'' +
                ", sorting_key5='" + sorting_key5 + '\'' +
                ", sorting_key6='" + sorting_key6 + '\'' +
                ", sorting_key7='" + sorting_key7 + '\'' +
                ", sorting_key8='" + sorting_key8 + '\'' +
                ", sorting_key9='" + sorting_key9 + '\'' +
                ", sorting_key10='" + sorting_key10 + '\'' +
                ", item_type='" + item_type + '\'' +
                ", itemized_application_code='" + itemized_application_code + '\'' +
                ", stock_code='" + stock_code + '\'' +
                ", rohs_flag='" + rohs_flag + '\'' +
                ", login_time='" + login_time + '\'' +
                ", login_oid='" + login_oid + '\'' +
                ", update_time='" + update_time + '\'' +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                '}';
    }
}
