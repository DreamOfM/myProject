package com.tdk.txm_java.domain;

public class Bnd_master_production_material {
    private int id;
    private String mo_no;
    private Double operation_sequence_no;
    private String equipment_name;
    private String item_no;
    private Double revision_no;
    private String mrpcode;
    private String item_descrip_en;
    private String item_spec;
    private Double actual_qty;
    private Double material_count;
    private String material_item_no;
    private String material_item_description;
    private String material_specification;
    private String material_item_no_tmisp;
    private String material_type;
    private String manufacture_lot_no;
    private String vendor_no;
    private String lot_expiration_date;
    private Double actual_materail_qty;
    private Double material_defect_qty;
    private Double loss_qty;
    private String actual_um;
    private String um_incoming_outgoing;
    private Double product_loss_quantity;
    private Double loss_quantity;
    private Double componentparent_itemc;
    private Double component_qtyparent_qty;
    private String material_item_type;
    private String update_type_manual_auto;
    private String text_contents1;
    private String text_contents2;
    private String text_contents3;
    private String text_contents4;
    private String text_contents5;
    private String text_contents6;
    private String sap_mo;
    private Double material_bom_ver;
    private String vendor_lot_no;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMo_no() {
        return mo_no;
    }

    public void setMo_no(String mo_no) {
        this.mo_no = mo_no;
    }

    public Double getOperation_sequence_no() {
        return operation_sequence_no;
    }

    public void setOperation_sequence_no(Double operation_sequence_no) {
        this.operation_sequence_no = operation_sequence_no;
    }

    public String getEquipment_name() {
        return equipment_name;
    }

    public void setEquipment_name(String equipment_name) {
        this.equipment_name = equipment_name;
    }

    public String getItem_no() {
        return item_no;
    }

    public void setItem_no(String item_no) {
        this.item_no = item_no;
    }

    public Double getRevision_no() {
        return revision_no;
    }

    public void setRevision_no(Double revision_no) {
        this.revision_no = revision_no;
    }

    public String getMrpcode() {
        return mrpcode;
    }

    public void setMrpcode(String mrpcode) {
        this.mrpcode = mrpcode;
    }

    public String getItem_descrip_en() {
        return item_descrip_en;
    }

    public void setItem_descrip_en(String item_descrip_en) {
        this.item_descrip_en = item_descrip_en;
    }

    public String getItem_spec() {
        return item_spec;
    }

    public void setItem_spec(String item_spec) {
        this.item_spec = item_spec;
    }

    public Double getActual_qty() {
        return actual_qty;
    }

    public void setActual_qty(Double actual_qty) {
        this.actual_qty = actual_qty;
    }

    public Double getMaterial_count() {
        return material_count;
    }

    public void setMaterial_count(Double material_count) {
        this.material_count = material_count;
    }

    public String getMaterial_item_no() {
        return material_item_no;
    }

    public void setMaterial_item_no(String material_item_no) {
        this.material_item_no = material_item_no;
    }

    public String getMaterial_item_description() {
        return material_item_description;
    }

    public void setMaterial_item_description(String material_item_description) {
        this.material_item_description = material_item_description;
    }

    public String getMaterial_specification() {
        return material_specification;
    }

    public void setMaterial_specification(String material_specification) {
        this.material_specification = material_specification;
    }

    public String getMaterial_item_no_tmisp() {
        return material_item_no_tmisp;
    }

    public void setMaterial_item_no_tmisp(String material_item_no_tmisp) {
        this.material_item_no_tmisp = material_item_no_tmisp;
    }

    public String getMaterial_type() {
        return material_type;
    }

    public void setMaterial_type(String material_type) {
        this.material_type = material_type;
    }

    public String getManufacture_lot_no() {
        return manufacture_lot_no;
    }

    public void setManufacture_lot_no(String manufacture_lot_no) {
        this.manufacture_lot_no = manufacture_lot_no;
    }

    public String getVendor_no() {
        return vendor_no;
    }

    public void setVendor_no(String vendor_no) {
        this.vendor_no = vendor_no;
    }

    public String getLot_expiration_date() {
        return lot_expiration_date;
    }

    public void setLot_expiration_date(String lot_expiration_date) {
        this.lot_expiration_date = lot_expiration_date;
    }

    public Double getActual_materail_qty() {
        return actual_materail_qty;
    }

    public void setActual_materail_qty(Double actual_materail_qty) {
        this.actual_materail_qty = actual_materail_qty;
    }

    public Double getMaterial_defect_qty() {
        return material_defect_qty;
    }

    public void setMaterial_defect_qty(Double material_defect_qty) {
        this.material_defect_qty = material_defect_qty;
    }

    public Double getLoss_qty() {
        return loss_qty;
    }

    public void setLoss_qty(Double loss_qty) {
        this.loss_qty = loss_qty;
    }

    public String getActual_um() {
        return actual_um;
    }

    public void setActual_um(String actual_um) {
        this.actual_um = actual_um;
    }

    public String getUm_incoming_outgoing() {
        return um_incoming_outgoing;
    }

    public void setUm_incoming_outgoing(String um_incoming_outgoing) {
        this.um_incoming_outgoing = um_incoming_outgoing;
    }

    public Double getProduct_loss_quantity() {
        return product_loss_quantity;
    }

    public void setProduct_loss_quantity(Double product_loss_quantity) {
        this.product_loss_quantity = product_loss_quantity;
    }

    public Double getLoss_quantity() {
        return loss_quantity;
    }

    public void setLoss_quantity(Double loss_quantity) {
        this.loss_quantity = loss_quantity;
    }

    public Double getComponentparent_itemc() {
        return componentparent_itemc;
    }

    public void setComponentparent_itemc(Double componentparent_itemc) {
        this.componentparent_itemc = componentparent_itemc;
    }

    public Double getComponent_qtyparent_qty() {
        return component_qtyparent_qty;
    }

    public void setComponent_qtyparent_qty(Double component_qtyparent_qty) {
        this.component_qtyparent_qty = component_qtyparent_qty;
    }

    public String getMaterial_item_type() {
        return material_item_type;
    }

    public void setMaterial_item_type(String material_item_type) {
        this.material_item_type = material_item_type;
    }

    public String getUpdate_type_manual_auto() {
        return update_type_manual_auto;
    }

    public void setUpdate_type_manual_auto(String update_type_manual_auto) {
        this.update_type_manual_auto = update_type_manual_auto;
    }

    public String getText_contents1() {
        return text_contents1;
    }

    public void setText_contents1(String text_contents1) {
        this.text_contents1 = text_contents1;
    }

    public String getText_contents2() {
        return text_contents2;
    }

    public void setText_contents2(String text_contents2) {
        this.text_contents2 = text_contents2;
    }

    public String getText_contents3() {
        return text_contents3;
    }

    public void setText_contents3(String text_contents3) {
        this.text_contents3 = text_contents3;
    }

    public String getText_contents4() {
        return text_contents4;
    }

    public void setText_contents4(String text_contents4) {
        this.text_contents4 = text_contents4;
    }

    public String getText_contents5() {
        return text_contents5;
    }

    public void setText_contents5(String text_contents5) {
        this.text_contents5 = text_contents5;
    }

    public String getText_contents6() {
        return text_contents6;
    }

    public void setText_contents6(String text_contents6) {
        this.text_contents6 = text_contents6;
    }

    public String getSap_mo() {
        return sap_mo;
    }

    public void setSap_mo(String sap_mo) {
        this.sap_mo = sap_mo;
    }

    public Double getMaterial_bom_ver() {
        return material_bom_ver;
    }

    public void setMaterial_bom_ver(Double material_bom_ver) {
        this.material_bom_ver = material_bom_ver;
    }

    public String getVendor_lot_no() {
        return vendor_lot_no;
    }

    public void setVendor_lot_no(String vendor_lot_no) {
        this.vendor_lot_no = vendor_lot_no;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    @Override
    public String toString() {
        return "Bnd_master_production_material{" +
                "id=" + id +
                ", mo_no='" + mo_no + '\'' +
                ", operation_sequence_no=" + operation_sequence_no +
                ", equipment_name='" + equipment_name + '\'' +
                ", item_no='" + item_no + '\'' +
                ", revision_no=" + revision_no +
                ", mrpcode='" + mrpcode + '\'' +
                ", item_descrip_en='" + item_descrip_en + '\'' +
                ", item_spec='" + item_spec + '\'' +
                ", actual_qty=" + actual_qty +
                ", material_count=" + material_count +
                ", material_item_no='" + material_item_no + '\'' +
                ", material_item_description='" + material_item_description + '\'' +
                ", material_specification='" + material_specification + '\'' +
                ", material_item_no_tmisp='" + material_item_no_tmisp + '\'' +
                ", material_type='" + material_type + '\'' +
                ", manufacture_lot_no='" + manufacture_lot_no + '\'' +
                ", vendor_no='" + vendor_no + '\'' +
                ", lot_expiration_date='" + lot_expiration_date + '\'' +
                ", actual_materail_qty=" + actual_materail_qty +
                ", material_defect_qty=" + material_defect_qty +
                ", loss_qty=" + loss_qty +
                ", actual_um='" + actual_um + '\'' +
                ", um_incoming_outgoing='" + um_incoming_outgoing + '\'' +
                ", product_loss_quantity=" + product_loss_quantity +
                ", loss_quantity=" + loss_quantity +
                ", componentparent_itemc=" + componentparent_itemc +
                ", component_qtyparent_qty=" + component_qtyparent_qty +
                ", material_item_type='" + material_item_type + '\'' +
                ", update_type_manual_auto='" + update_type_manual_auto + '\'' +
                ", text_contents1='" + text_contents1 + '\'' +
                ", text_contents2='" + text_contents2 + '\'' +
                ", text_contents3='" + text_contents3 + '\'' +
                ", text_contents4='" + text_contents4 + '\'' +
                ", text_contents5='" + text_contents5 + '\'' +
                ", text_contents6='" + text_contents6 + '\'' +
                ", sap_mo='" + sap_mo + '\'' +
                ", material_bom_ver=" + material_bom_ver +
                ", vendor_lot_no='" + vendor_lot_no + '\'' +
                ", login_time='" + login_time + '\'' +
                ", login_oid='" + login_oid + '\'' +
                ", update_time='" + update_time + '\'' +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                '}';
    }
}
