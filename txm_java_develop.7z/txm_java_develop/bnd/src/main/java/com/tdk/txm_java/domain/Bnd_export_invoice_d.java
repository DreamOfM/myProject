package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Time;

@Data
public class Bnd_export_invoice_d {
    private int id;
    private int packing_serial;//裝箱序號
    private String invoice_no;//發票號碼
    private String customer_no;//顧客代碼
    private String item_no;//品名代碼
    private String item_description_dbcs;//品名（中文）
    private String customer_item_code;//顧客品名代碼
    private String unit;//計量單位（銷售）
    private String customer_item_spec;//顧客品名（中文）
    private String customer_po;//顧客購買訂單號碼
    private String po_no ;//購買訂單號碼
    private Double packing_qty;//包裝數
    private Double carton_no_from;//箱號ＦＲＯＭ
    private Double carton_no_to;//箱號ＴＯ
    private Double net_weigh;//淨重
    private Double caton_weight;//箱重
    private Double sampling_principle;//賣價
    private String mrpcode;//ＭＲＰ基準代碼
    private String so_no ;//SO订单
    private Double packing_amt;//金额
    private String original_invoice;//退货原发票
    private Double catton_qty_by_dn;//DN的箱数
    private Double pallet_qty;//DN的板数
    private String dn_no ;//DN号码
    private Double dn_qty ;//DN别数量
    private String goods ;//货品=item_description_dbcs+customer_item_code
    private String invoice_type;//
    private Time login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;
    private Bnd_export_invoice_h bnd_export_invoice_h;
    private Bnd_master_customer bnd_master_customer;
    private Bnd_master_item bnd_master_item;

}
