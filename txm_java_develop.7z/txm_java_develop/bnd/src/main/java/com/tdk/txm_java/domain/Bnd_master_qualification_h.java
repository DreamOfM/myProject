package com.tdk.txm_java.domain;

import lombok.Data;

import java.util.Date;

@Data
public class Bnd_master_qualification_h {
    private int id;
    private String seq_no;
    private String et_arcrp_no;
    private Double chg_tms_cnt;
    private String etps_preent_no;
    private String master_cuscd;
    private String bizop_etps_sccd;
    private String bizop_etpsno;
    private String bizop_etps_nm;
    private String prcs_etps_sccd;
    private String prcs_etpsno;
    private String prcs_etps_nm;
    private String dec_dm;
    private String dcl_etpsno;
    private String dcl_etps_nm;
    private String dcl_etps_typecd;
    private String conc_addr;
    private String telephone_no;

    private Date finish_valid_time;
    private String finish_valid_time2;

    private Double prcs_prdc_ablt_amt;
    private String apcret_no;
    private String risk_assure_markcd;
    private String rlt_form_no;
    private String dcl_source_markcd;
    private String dcl_typecd;

    private Date dcl_time;
    private String dcl_time2;
    private String emapv_stucd;
    private String exe_markcd;

    private  Date putrec_appr_time;
    private String putrec_appr_time2;

    private Date chg_appr_time;
    private String chg_appr_time2;
    private String rmk;
    private String input_code;
    private String input_credit_code;
    private String input_name;

    private Date input_date;
    private String input_date2;

    private String ems_type;
    private Date login_time;
    private String login_oid;
    private Date update_time;
    private String update_oid;
    private String update_program;

}
