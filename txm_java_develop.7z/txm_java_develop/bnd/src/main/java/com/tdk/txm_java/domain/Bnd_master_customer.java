package com.tdk.txm_java.domain;


public class Bnd_master_customer {
    private int id;
    private String customer_no;
    private String account_group;
    private String customer_name1_dbcs;
    private String customer_name1;
    private String customer_name_abbr_dbcs;
    private String customer_name_abbr;
    private String address1_dbcs;
    private String address1;
    private String invoice_type;
    private String tax_code2;
    private String currency;
    private String country_code;
    private String city_name_dbcs;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCustomer_no() {
        return customer_no;
    }

    public void setCustomer_no(String customer_no) {
        this.customer_no = customer_no;
    }

    public String getAccount_group() {
        return account_group;
    }

    public void setAccount_group(String account_group) {
        this.account_group = account_group;
    }

    public String getCustomer_name1_dbcs() {
        return customer_name1_dbcs;
    }

    public void setCustomer_name1_dbcs(String customer_name1_dbcs) {
        this.customer_name1_dbcs = customer_name1_dbcs;
    }

    public String getCustomer_name1() {
        return customer_name1;
    }

    public void setCustomer_name1(String customer_name1) {
        this.customer_name1 = customer_name1;
    }

    public String getCustomer_name_abbr_dbcs() {
        return customer_name_abbr_dbcs;
    }

    public void setCustomer_name_abbr_dbcs(String customer_name_abbr_dbcs) {
        this.customer_name_abbr_dbcs = customer_name_abbr_dbcs;
    }

    public String getCustomer_name_abbr() {
        return customer_name_abbr;
    }

    public void setCustomer_name_abbr(String customer_name_abbr) {
        this.customer_name_abbr = customer_name_abbr;
    }

    public String getAddress1_dbcs() {
        return address1_dbcs;
    }

    public void setAddress1_dbcs(String address1_dbcs) {
        this.address1_dbcs = address1_dbcs;
    }

    public String getaddress1() {
        return address1;
    }

    public void setaddress1(String address1) {
        this.address1 = address1;
    }

    public String getInvoice_type() {
        return invoice_type;
    }

    public void setInvoice_type(String invoice_type) {
        this.invoice_type = invoice_type;
    }

    public String getTax_code2() {
        return tax_code2;
    }

    public void setTax_code2(String tax_code2) {
        this.tax_code2 = tax_code2;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getCountry_code() {
        return country_code;
    }

    public void setCountry_code(String country_code) {
        this.country_code = country_code;
    }

    public String getCity_name_dbcs() {
        return city_name_dbcs;
    }

    public void setCity_name_dbcs(String city_name_dbcs) {
        this.city_name_dbcs = city_name_dbcs;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    @Override
    public String toString() {
        return "Bnd_master_customer{" +
                "id=" + id +
                ", customer_no=" + customer_no +
                ", account_group=" + account_group +
                ", customer_name1_dbcs=" + customer_name1_dbcs +
                ", customer_name1=" + customer_name1 +
                ", customer_name_abbr_dbcs=" + customer_name_abbr_dbcs +
                ", customer_name_abbr=" + customer_name_abbr +
                ", address1_dbcs=" + address1_dbcs +
                ", address1=" + address1 +
                ", invoice_type=" + invoice_type +
                ", tax_code2=" + tax_code2 +
                ", currency=" + currency +
                ", country_code=" + country_code +
                ", city_name_dbcs=" + city_name_dbcs +
                ", login_time=" + login_time +
                ", login_oid=" + login_oid +
                ", update_time=" + update_time +
                ", update_oid=" + update_oid +
                ", update_program=" + update_program +
                '}';
    }
}
