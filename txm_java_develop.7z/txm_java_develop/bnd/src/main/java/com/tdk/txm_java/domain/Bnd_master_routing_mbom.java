package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Date;

@Data
public class Bnd_master_routing_mbom {
    private int id;
    private String routing_no;//制造途程代码
    private String bom_number;//ISBOMN
    private String alternative_bom;//ISALTB
    private Double circuit_no;//電路板號碼
    private String bom_item_node_number;//ISBINN
    private String item_no;//品名代码
    private Double operation_sequence_no;//作業順序號碼
    private String equipment_name;//工程设备名
    private String component_item_no;//材料品名代碼

    private String rbdltf;//DELETE FLAG
    private Double rbstat;//0-SEND 1-COMPLETED
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

}
