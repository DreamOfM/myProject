package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_if_fmts_process_h {
    private int id;
    private String phcoce;//CO_CODE
    private String phyymm;//STAKE_MONTH
    private String phwipi;//WIP_ID
    private Double phwips;//WIP_SEQ
    private String phsapm;//SAP_MO
    private String phmonr;//MTS_LOT
    private String phitnr;//ITEM NO.
    private Double phopsq;//OPERATION SEQUENCE NO.
    private String phwknr;//WORK CENTER NO.
    private Double phintm;//IN_TIME
    private Double phoutt;//OUT_TIME
    private Double phinqt;//IN_QTY
    private Double phoutq;//OUT_QTY
    private Double phngqt;//NG_QTY
    private String phrcdt;//RECORD TYPE
    private String phstat;//0-SEND 1-COMPLETED
    private String phpack;//PACKING
    private String phupdt;



    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;


}
