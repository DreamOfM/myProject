package com.tdk.txm_java.domain;

import lombok.Data;

import java.util.Date;


@Data
public class Bnd_subcon_item_no {
    private  int id;
    private String operation_no;//委外流水号

    private String mrp_code;//ＭＲＰ基準代碼
    private String psa_code;//Y1WPSA
    private String vendor_code;//供應商代碼
    private String vendor_name_abbr_dbcs;//供應商名稱
    private String apply_date;//申請日期
    private String date_from;//開始日期
    private String date_to;//結束日期
    private String operation_type;//委外程度
    private String item_no;//品名ITEM
    private String ccc_code;//商編
    private Double img_no;//項號
    private String item_class_code;//品名分類代碼
    private String item_description_dbcs;//中文品名
    private Double operation_sequence_no1;//起始工序
    private Double operation_sequence_no2;//結束工序
    private Double operation_quantity ;//委外數量
    private String um_incoming_outgoing;//在庫單位
    private Double physical_quantity ;//監管數量
    private String um_physical_inventory;//監管單位

    private String itemized_application_code;//品名應用代碼
    private Double standard_cost;//標準成本
    private Double operation_amount;//委外金額


    private String operation_no1;//材料流水号
    private Integer current_no;
    private String no_control;
    private String no_control1;

    private Date login_time;
    private String login_oid;
    private Date update_time;
    private String update_oid;
    private String update_program;

}
