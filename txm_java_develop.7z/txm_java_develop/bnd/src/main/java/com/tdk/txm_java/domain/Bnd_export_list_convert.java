package com.tdk.txm_java.domain;

public class Bnd_export_list_convert {
    private int id;
    private String invoice_no;
    private String item_no;
    private Double ucns_verno;
    private Double unit_price;
    private Double enterprise_declared_total_price;
    private Double legal_qty;
    private Double sec_legal_qty;
    private Double weight;
    private Double declare_qty;
    private Double gross_weight;
    private Double net_weigh;
    private Double packing_qty;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getInvoice_no() {
        return invoice_no;
    }

    public void setInvoice_no(String invoice_no) {
        this.invoice_no = invoice_no;
    }

    public String getItem_no() {
        return item_no;
    }

    public void setItem_no(String item_no) {
        this.item_no = item_no;
    }

    public Double getUcns_verno() {
        return ucns_verno;
    }

    public void setUcns_verno(Double ucns_verno) {
        this.ucns_verno = ucns_verno;
    }

    public Double getUnit_price() {
        return unit_price;
    }

    public void setUnit_price(Double unit_price) {
        this.unit_price = unit_price;
    }

    public Double getEnterprise_declared_total_price() {
        return enterprise_declared_total_price;
    }

    public void setEnterprise_declared_total_price(Double enterprise_declared_total_price) {
        this.enterprise_declared_total_price = enterprise_declared_total_price;
    }

    public Double getLegal_qty() {
        return legal_qty;
    }

    public void setLegal_qty(Double legal_qty) {
        this.legal_qty = legal_qty;
    }

    public Double getSec_legal_qty() {
        return sec_legal_qty;
    }

    public void setSec_legal_qty(Double sec_legal_qty) {
        this.sec_legal_qty = sec_legal_qty;
    }

    public Double getWeight() {
        return weight;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    public Double getDeclare_qty() {
        return declare_qty;
    }

    public void setDeclare_qty(Double declare_qty) {
        this.declare_qty = declare_qty;
    }

    public Double getGross_weight() {
        return gross_weight;
    }

    public void setGross_weight(Double gross_weight) {
        this.gross_weight = gross_weight;
    }

    public Double getNet_weigh() {
        return net_weigh;
    }

    public void setNet_weigh(Double net_weigh) {
        this.net_weigh = net_weigh;
    }

    public Double getPacking_qty() {
        return packing_qty;
    }

    public void setPacking_qty(Double packing_qty) {
        this.packing_qty = packing_qty;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    @Override
    public String toString() {
        return "Bnd_export_list_convert{" +
                "id=" + id +
                ", invoice_no='" + invoice_no + '\'' +
                ", item_no='" + item_no + '\'' +
                ", ucns_verno=" + ucns_verno +
                ", unit_price=" + unit_price +
                ", enterprise_declared_total_price=" + enterprise_declared_total_price +
                ", legal_qty=" + legal_qty +
                ", sec_legal_qty=" + sec_legal_qty +
                ", weight=" + weight +
                ", declare_qty=" + declare_qty +
                ", gross_weight=" + gross_weight +
                ", net_weigh=" + net_weigh +
                ", packing_qty=" + packing_qty +
                ", login_time='" + login_time + '\'' +
                ", login_oid='" + login_oid + '\'' +
                ", update_time='" + update_time + '\'' +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                '}';
    }
}
