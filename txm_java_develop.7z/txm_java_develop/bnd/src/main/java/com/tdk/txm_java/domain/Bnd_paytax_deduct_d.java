package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Time;

@Data
public class Bnd_paytax_deduct_d {
    private int id;
    private String ems_no;
    private String internal_number;
    private String item_no;
    private String paytax_declaration_no;
    private Double img_no;
    private Double paytax_qty;
    private String um_physical_inventory;
    private Double paytax_amt;
    private String currency;
    private Double paytax_wet;
    private String country_code;
    private String remark_1;
    private String remark_2;

    private Time login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;

}
