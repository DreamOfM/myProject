package com.tdk.txm_java.domain;

import lombok.Data;

import java.io.Serializable;

@Data
public class Bnd_invoice implements Serializable {
    private String WWSENR;
    private String WWKCTR;
    private String AKDIVI;
    private String AKDVCD;
    private String AJIVNR;
    private Integer AJSHPD;
    private String AJSHPC;
    private double AJPKQT;
    private double AJPKAD;
    private String AJPKAF;
    private Integer AJTCTN;
    private String AJTNWT;
    private Double AJTAWT;
    private String AJCURR;
    private String AJVOUM;
    private String CUCUNB;
    private String CUCUND;
    private String CUPNAM;
    private String CUIVHN;
    private String KFCTNM;
    private String KFCTND;
    private String PCFRGC;
    private String QOCPNM;
    private String AKCUNR;
    private String STCTRY;
    private String STCITY;
    private String STTELN;
    private String STSHTO;
    private String STSAD1;
    private String STSAD2;
    private String STSAD3;
    private String STSND1;
    private String STSND2;
    private Integer SNCUSD;
    private String SNFSDT;
    private String SNSTDT;
    private String SNRCDT;
    private String AKPKCD;
    private String AKSAUM;
    private String QKTDDB;
    private String AJSPIN;
    private String PCSERN;
    private String SBMRK1;
    private String SBMRK2;
    private String SBMRK3;
    private String SBMRK4;
    private String SBMRK5;
    private String SBMRK6;
    private String SBMRK7;
    private String SBMRK8;
    private String SBFLW1;
    private String SBFLW2;
    private String SBFLW3;
    private String DCDCNO;
    private String DCTRID;
    private String DCSEAL;
    private String DCBCTF;
    private String DCCFID;
    private String DCNAME;
    private Integer DEENID;
    private String KWOPID;
    private String KWOPND;
    private String CUBRNH;
    private String DETXNR;
    private String IMITDD;
    private double total_pkqt;

}
