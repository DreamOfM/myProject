package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Time;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_develop</h3>
 * @ClassName<h4></h4>
 * @清单删除写入表
 * @date : 2020-05-23 15:07
 * @version:1.0
 **/
@Data
public class Bnd_master_invt_del_d {
    private int id;
    private String data_state;//數據狀態
    private String ems_no;//加工贸易账册编号
    private String internal_number;//企業內部編號
    private Double gds_seqno                       ;//序號
    private Integer filing_serial_no;//备案序号(对应底账序号）
    private String item_no;//品名代码
    private String good_code;//商品编码
    private String item_description_dbcs;//品名（中文）
    private String item_spec;//品名规格
    private String um_physical_inventory;//计量单位（盘点）
    private String lawf_unitcd;//法定计量单位
    private String secd_lawf_unitcd;//第二法定计量单位
    private String country_code;//国家代码
    private Double unit_price;//監管單價
    private Double enterprise_declared_total_price;//企业申报总价
    private Double usd_statistics_total_amount;//美元统计总金额
    private String currency;//币别
    private Double legal_qty;//法定数量
    private Double sec_legal_qty;//第二法定数量
    private Double weight_scale_factor;//重量比例因子
    private Double declare_qty;//報關單數量
    private Double gross_weight;//毛重
    private Double net_weigh;//净重
    private String use_code;//用途代码
    private String exempting_method;//征免方式
    private Double ucns_verno;//单耗版本号
    private Double customs_declaration_commodity_no ;//报关单商品序号
    private String classification_mark ;//归类标志
    private Double circulation_declaration_no ;//流转申报表序号
    private String final_destination_country ;//最终目的国
    private String modf_markcd;//修改标志
    private String rmk                                     ;//備註
    private Double weight;//重量        Z(8)9.9(9)
    private Double img_no;//归并项号
    private Double finish_good_consolidation_no ;//料件成品归并项号
    private String invoice_no;//發票號碼
    private String um_incoming_outgoing;//计量单位（入出库）
    private Double cf_physical_inventory;//盘点单位换算系数
    private String um_purchase;//购买单位
    private Double cf_purchase;//购买单位换算系数
    private Double packing_qty;//包裝數

    private Time login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;

}
