package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Time;
import java.util.Date;

//运费上载中间档
@Data
public class Bnd_export_freight {
    private int id;
    private String salesman_territory_code;//地區別
    private String shipping_condition_code;//運輸方式
    private String shipping_employee;//運輸業者
//    private int declaration_no;//報關單號    Z(8)9
    private String invoice_no;//發票號碼
    private String shipped_date;//出貨日期
//    private String division_code;//所屬部門
    private String departure_place;//出發地
    private String destination;//目的地
    private Double box_from;//件數
    private Double net_weigh;//重量
//    private String packing_volume;//體積
    private Double selling_price;//單價
    private String price_method;//計價方式
    private Double freight_code;//運費B
    private Double other_cost;//其他費用
    private Double freight;//總運費
    private String statement_customer_no;//負責付款之顧客
    private Double packing_qty;//包裝數
    private Double amt_cn;//裝箱金額（本國)
//    private String item_class_code;//品名分類代碼
    private String remark1;//備  注
    private String name_operator;//簽收人
    private Date sign_in_time;//簽收時間
    private String remark2;//備  注
    private String error_flag;//错误标志
    private Time login_time;//登陆时间login_time
    private String login_oid;//登陆人员login_oid
    private Time update_time;//更新时间update_time
    private String update_oid;//更新人员update_oid
    private String update_program;//更新程序update_program


}
