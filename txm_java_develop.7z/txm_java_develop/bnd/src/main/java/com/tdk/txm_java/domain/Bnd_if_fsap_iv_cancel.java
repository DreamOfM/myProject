package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_if_fsap_iv_cancel {
    private int id;
    private String scivnr;//
    private String sccndt;//
    private String scstat;//

    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

}
