package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Time;

//报关单回执
@Data
public class Bnd_if_fcaip_declare_list {
    private int id;
    private String internal_number;//内部清单编号
    private String bill_no;//核注清单号
    private String ems_no;//手册号
    private String list_no;//清单统一编号
    private String list_declare_date;//清单申报日
    private String declaration_no;//报关单号
    private String ie_date;//进出口日期
    private String declare_date;//报关单申报日期
    private String transaction_code;
    private String import_export_mark_code;
    private String declare_port;
    private String terms_trade;
    private String username;//用户名
    private String import_export_gate;//申报海关
    private String supervision_mode_code;//监管方式
    private Double fee_amount;
    private String fee_mark;//
    private Double fee_rate;//
    private String fee_curr;//
    private String insur_mark;//
    private Double insur_amount;
    private Double insur_rate;//
    private String insur_curr;//
    private Double other_amount;
    private String other_mark;//
    private Double other_rate;//
    private String other_curr;//
    private String error_message;//错误信息
    private String type;//特殊手动标识为1
    private String state;//
    private Time login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;



}
