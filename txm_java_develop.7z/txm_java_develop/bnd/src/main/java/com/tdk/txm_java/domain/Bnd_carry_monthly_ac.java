package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Time;
import java.util.Date;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java</h3>
 * @ClassName<h4></h4>
 * @ToDo<p>月度关账</p>
 * @date : 2020-08-15 14:20
 * @version:1.0
 **/
@Data
public class Bnd_carry_monthly_ac {
    private int id;
    private String yyyymm;//基准年月
    private String vendor_no;//供應商代碼
    private String invoice_no;//發票號碼
    private String item_no;//TDK ITEM
    private String img_no;//備案序號
    private String country_code;//原產國
    private String vendor_ems;//供應商手冊
    private String arrival_date;//日期
    private Double po_boarding_qty;//購買數量
    private String currency;//幣別
    private String um_physical_inventory;//申報單位
    private Double declared_qty;//申報數量
    private Double declared_amount;//申報金額
    private Double declared_weight;//申報重量
    private Double already_declared_qty;//已報數量
    private Double already_declared_amount;//已報金額
    private Double already_declared_weight;//已報重量
    private Double complete_declared_qty;//已轉數量
    private Double complete_declared_amount;//已轉金額
    private Double complete_declared_weight;//已轉重量
    private String expiration_flag;//
    private String fistday;//当月第一天
    private String lastday;//当月最后一天
    private Time login_time;//登陆时间login_time
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;

}
