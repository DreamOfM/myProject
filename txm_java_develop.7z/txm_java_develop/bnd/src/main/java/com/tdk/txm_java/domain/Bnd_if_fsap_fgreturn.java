package com.tdk.txm_java.domain;

import lombok.Data;

import java.util.Date;

@Data
public class Bnd_if_fsap_fgreturn {
    private int id;
    private String srsono;
    private String srrkpz;
    private String srrkpi;
    private String srcxpz;
    private String srcxpi;
    private String srtrdt;
    private String sritnr;
    private String srltno;
    private Double srtrqt;
    private String srstat;
    private String srupdt;


}
