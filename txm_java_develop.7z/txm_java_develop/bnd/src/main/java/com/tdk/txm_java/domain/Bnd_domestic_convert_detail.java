package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Time;

@Data
public class Bnd_domestic_convert_detail {
    private int id;
    private String yyyymm;
    private String type;
    private Double fg_img_no;
    private String endprd_gds_mtno;
    private String fg_description_dbcs;
    private String fg_um_bond;
    private Double ucns_verno;
    private Double raw_img_no;
    private String mtpck_gds_mtno;
    private String raw_description_dbcs;
    private String raw_um_bond;
    private Double dec_cm;
    private Double dec_dm;
    private Double fg_qty;
    private Double raw_qty;
    private Time login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;

}
