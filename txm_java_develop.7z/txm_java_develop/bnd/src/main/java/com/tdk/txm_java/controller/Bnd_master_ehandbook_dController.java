package com.tdk.txm_java.controller;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.tdk.txm_java.domain.*;
import com.tdk.txm_java.service.*;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.lang.reflect.InvocationTargetException;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;


@Controller
@RequestMapping("/bnd_master_ehandbook_d")
public class Bnd_master_ehandbook_dController {
    @Autowired
    private IBnd_master_ehandbook_dService iBnd_master_ehandbook_dService;
    @Autowired
    private IBnd_master_ehandbook_hService iBnd_master_ehandbook_hService;
    @Autowired
    private IBnd_master_itemService iBnd_master_itemService;
    @Autowired
    private IBnd_master_hs_codeService iBnd_master_hs_codeService;
    @Autowired
    private IBnd_master_purchase_priceService iBnd_master_purchase_priceService;
    @Autowired
    private IBnd_master_vendorService iBnd_master_vendorService;
    @Autowired
    private IBnd_master_exchange_rateService iBnd_master_exchange_rateService;
    @Autowired
    private IBnd_master_unit_codeService iBnd_master_unit_codeService;
    @Autowired
    private IBnd_master_declare_materialzService iBnd_master_declare_materialzService;
    @Autowired
    private IBnd_apply_ehandbook_dService iBnd_apply_ehandbook_dService;

    //    查询item检查
    @RequestMapping("/check.do")
    public void check(HttpServletRequest request, HttpServletResponse response, HttpSession Session) throws Exception {
        //取出前端传回的所有数据
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        //根据品名代码去主档中查找
        String item_no = request.getParameter("item_no");
        Bnd_master_item item = iBnd_master_itemService.findByitem_no(item_no);
        Bnd_master_ehandbook_d bnd_master_ehandbook_d = iBnd_master_ehandbook_dService.findByitem(item_no);
        System.out.println("999" + item_no);
        System.out.println(item);
        System.out.println(bnd_master_ehandbook_d);
        //判断
        if (item == null) {
            info.setErrorMsg("品名代碼在品名主檔不存在");
            errorList.add("item_no");
            info.setFlag(false);
        }
        if (item != null && bnd_master_ehandbook_d == null) {
            info.setErrorMsg("品名未备案");
            errorList.add("item_no");
            info.setFlag(false);
        }

        if (item != null && bnd_master_ehandbook_d != null) {
            info.setFlag(true);
        }
        // 响应数据
//        info.setData(item_no);
        info.setErrorList(errorList);
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(), info);
    }

    //    新增item检查
    @RequestMapping("/check1.do")
    public void check1(HttpServletRequest request, HttpServletResponse response, HttpSession Session) throws Exception {
        //取出前端传回的所有数据
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        //根据品名代码去主档中查找
        String item_no = request.getParameter("item_no");
        Bnd_master_item item = iBnd_master_itemService.findByitem_no(item_no);
        if (item == null) {
            info.setErrorMsg("品名代碼在品名主檔不存在");
            errorList.add("item_no");
            info.setFlag(false);
        }else {
            Bnd_master_ehandbook_d bnd_master_ehandbook_d = iBnd_master_ehandbook_dService.findByitem(item_no);
            Bnd_master_hs_code bnd_master_hs_code = iBnd_master_hs_codeService.findByccc_code(item.getHs_code());
            System.out.println("999" + item_no);
            System.out.println(item);
            System.out.println(bnd_master_ehandbook_d);
            //判断
            do {
                if (bnd_master_ehandbook_d != null) {
                    info.setErrorMsg("品名已备案");
                    errorList.add("item_no");
                    info.setFlag(false);
                    break;
                }

                if (item.getBonded_logo().equals("N")) {
                    info.setErrorMsg("非保税品番");
                    errorList.add("item_no");
                    info.setFlag(false);
                    break;
                }

                if (bnd_master_hs_code == null) {
                    info.setErrorMsg("对应商编没维护，不可备案");
                    errorList.add("item_no");
                    info.setFlag(false);
                    break;
                } else {
                    if ("4".equals(bnd_master_hs_code.getData_state())) {
                        info.setErrorMsg("对应商编失效，不可备案");
                        errorList.add("item_no");
                        info.setFlag(false);
                        break;
                    }
                }

//                if (item != null && item.getBonded_logo().equals("Y") && bnd_master_ehandbook_d == null) {
//                    if (bnd_master_hs_code != null) {
//                        if (!"4".equals(bnd_master_hs_code.getData_state())) {
//                            info.setFlag(true);
//                        }
//                    }
//                }
              break;
            }while (true);
        }
        // 响应数据
//        info.setData(item_no);
        info.setErrorList(errorList);
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(), info);
    }

    @RequestMapping("/check02.do")
    public void check02(HttpServletRequest request, HttpServletResponse response, HttpSession Session) throws Exception {
        ResultInfo info = new ResultInfo();

        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        //取出前端传回的所有数据

        String dcl_uprc_amt = request.getParameter("dcl_uprc_amt");
//        String data_state = request.getParameter("data_state");
        String item_type = request.getParameter("item_type");
        String net_weigh = request.getParameter("net_weigh");
        String lawf_unitcd = request.getParameter("lawf_unitcd");
        String lawf_unitcd_cf = request.getParameter("lawf_unitcd_cf");
        String secd_lawf_unitcd = request.getParameter("secd_lawf_unitcd");
        String secd_lawf_unitcd_cf = request.getParameter("secd_lawf_unitcd_cf");
        String item_no = request.getParameter("item_no");

        //判断
        if (item_type.equals("6")) {
            if (dcl_uprc_amt == null || dcl_uprc_amt.equals("")||"0.00000".equals(dcl_uprc_amt)) {
                info.setErrorMsg("不可为0");
                errorList.add("dcl_uprc_amt");
                info.setFlag(false);
            }
        }
        if (net_weigh == null || "0.000000000".equals(net_weigh)) {
            info.setErrorMsg("不可为0");
            errorList.add("net_weigh");
            info.setFlag(false);
        }

//        if (lawf_unitcd == null || "".equals(lawf_unitcd)) {
//            info.setErrorMsg("资料不完整");
//            errorList.add("lawf_unitcd");
//            info.setFlag(false);
//        }
//        if (lawf_unitcd_cf == null || "".equals(lawf_unitcd_cf)) {
//            info.setErrorMsg("资料不完整");
//            errorList.add("lawf_unitcd_cf");
//            info.setFlag(false);
//        }
        if(!lawf_unitcd.equals("")&&!lawf_unitcd.equals(null)){
            List<Bnd_master_unit_code> unit_code=iBnd_master_unit_codeService.findBycustoms_unit_code(lawf_unitcd);
            if(unit_code.size()==0){
                info.setErrorMsg("法定单位在单位主档不存在");
                errorList.add("lawf_unitcd");
                info.setFlag(false);
            }
            else if((lawf_unitcd_cf.equals("") || lawf_unitcd_cf.equals("0.000000000"))){
                info.setErrorMsg("法定单位与系数不匹配");
                errorList.add("lawf_unitcd_cf");
                info.setFlag(false);
            }
        }
        else if (!lawf_unitcd_cf.equals("") && !lawf_unitcd_cf.equals("0.000000000")) {
            info.setErrorMsg("法定单位与系数不匹配");
            errorList.add("lawf_unitcd_cf");
            info.setFlag(false);
        }

        if(!secd_lawf_unitcd.equals("")&&!secd_lawf_unitcd.equals(null)){
            List<Bnd_master_unit_code> unit_code=iBnd_master_unit_codeService.findBycustoms_unit_code(secd_lawf_unitcd);
            if(unit_code.size()==0){
                info.setErrorMsg("法定单位在单位主档不存在");
                errorList.add("secd_lawf_unitcd");
                info.setFlag(false);
            }
            else if((secd_lawf_unitcd_cf.equals("") || secd_lawf_unitcd_cf.equals("0.000000000"))){
                info.setErrorMsg("法定单位与系数不匹配");
                errorList.add("secd_lawf_unitcd_cf");
                info.setFlag(false);
            }
        }
        else if (!secd_lawf_unitcd_cf.equals("") && !secd_lawf_unitcd_cf.equals("0.000000000")) {
            info.setErrorMsg("法定单位与系数不匹配");
            errorList.add("secd_lawf_unitcd_cf");
            info.setFlag(false);
        }

        Bnd_master_declare_materialz declare_materialz=iBnd_master_declare_materialzService.findByitem_no(item_no);
        if(declare_materialz==null){
            info.setErrorMsg("商编申报要素没维护");
//            errorList.add("item_no");
            info.setFlag(false);
        }

        info.setErrorList(errorList);
        // 响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(), info);
    }


    @RequestMapping("/findByitem_noe.do")
    public ModelAndView findByitem_noe(HttpServletResponse response, HttpServletRequest request, HttpSession session) throws Exception {
        System.out.println("2323");
        String item_no = request.getParameter("item_no");
        Bnd_master_item bnd_master_item = iBnd_master_itemService.findByitem_no(item_no);

        //调用业层的方法查询
        Bnd_master_ehandbook_d bnd_master_ehandbook_d = iBnd_master_ehandbook_dService.findByitem(item_no);
        //净重
        double ntwt = 0.0;
        double ntwt1 = 0.0;
        double lawf_unitcd_cf = 0.0;
        double secd_lawf_unitcd_cf = 0.0;
        DecimalFormat dfn = new DecimalFormat("0.000000000");
        System.out.println("SASA" + bnd_master_item);
        if (!bnd_master_item.getWarranty_period().equals(0.0)) {
            ntwt = bnd_master_item.getNet_weigh() / bnd_master_item.getWarranty_period();
        } else {
            ntwt = bnd_master_item.getNet_weigh();
        }
        ntwt1 = ntwt / bnd_master_item.getCf_physical_inventory();

        //单位
        //获取法定单位
        List<Bnd_master_unit_code> bnd_master_unit_code = iBnd_master_unit_codeService.findBycustoms_unit_code(bnd_master_ehandbook_d.getLawf_unitcd());
        List<Bnd_master_unit_code> bnd_master_unit_code1 = iBnd_master_unit_codeService.findBycustoms_unit_code(bnd_master_ehandbook_d.getSecd_lawf_unitcd());
        Bnd_master_unit_code bnd_master_unit_code2 = iBnd_master_unit_codeService.findByunit_code(bnd_master_ehandbook_d.getUm_incoming_outgoing());
        Bnd_master_unit_code bnd_master_unit_code3 = iBnd_master_unit_codeService.findByunit_code(bnd_master_ehandbook_d.getUm_physical_inventory());
        Bnd_master_unit_code bnd_master_unit_code4 = iBnd_master_unit_codeService.findByunit_code(bnd_master_ehandbook_d.getUm_purchase());

        //创建视图对象
        ModelAndView modelAndView = new ModelAndView();
        //使用addObject()设置需要返回的值
        modelAndView.addObject("bnd_master_ehandbook_d", bnd_master_ehandbook_d);
        if (bnd_master_unit_code.size() != 0) {
            modelAndView.addObject("lawf_unitcd1", bnd_master_unit_code.get(0).getUnit_code());
        }
        if (bnd_master_unit_code1.size() != 0) {
            modelAndView.addObject("secd_lawf_unitcd1", bnd_master_unit_code1.get(0).getUnit_code());
        }
        if (bnd_master_unit_code2 != null) {
            modelAndView.addObject("um_incoming_outgoing1", bnd_master_unit_code2.getCustoms_unit_code());
        }
        if (bnd_master_unit_code3 != null) {
            modelAndView.addObject("um_physical_inventory1", bnd_master_unit_code3.getCustoms_unit_code());
        }
        if (bnd_master_unit_code4 != null) {
            modelAndView.addObject("um_purchase1", bnd_master_unit_code4.getCustoms_unit_code());
        }


        modelAndView.addObject("ntwt", dfn.format(ntwt));
        modelAndView.addObject("ntwt1", dfn.format(ntwt1));
        modelAndView.addObject("lawf_unitcd_cf", dfn.format(bnd_master_ehandbook_d.getLawf_unitcd_cf()));
        modelAndView.addObject("secd_lawf_unitcd_cf", dfn.format(bnd_master_ehandbook_d.getSecd_lawf_unitcd_cf()));
//        modelAndView.addObject("item_no", item_no);
        System.out.println("rtrt" + item_no);
        System.out.println(bnd_master_ehandbook_d);
        System.out.println("0911"+secd_lawf_unitcd_cf);
        System.out.println("0911"+bnd_master_ehandbook_d.getSecd_lawf_unitcd());
        //通过setViewName()方法跳转到指定的页面
        modelAndView.setViewName("bnd-master-ehandbook-d-list");
        //返回视图解析对象
        return modelAndView;
    }

    @RequestMapping("/findByitem_noe1.do")
    public ModelAndView findByitem_noe1(HttpServletResponse response, HttpServletRequest request, HttpSession session) throws Exception {
        System.out.println("2323");
        String item_no = request.getParameter("item_no");
        Bnd_master_item bnd_master_item = iBnd_master_itemService.findByitem_no(item_no);
        Bnd_master_hs_code bnd_master_hs_code = iBnd_master_hs_codeService.findByccc_code(bnd_master_item.getHs_code());
        Bnd_master_declare_materialz bnd_master_declare_materialz = iBnd_master_declare_materialzService.findByitem_no(item_no);
        double price = 0.0;
        List<Bnd_master_ehandbook_d> bnd_master_ehandbook_d = iBnd_master_ehandbook_dService.findByitem_seqno(item_no);
        DecimalFormat df = new DecimalFormat("0.00000");
        DecimalFormat dfn = new DecimalFormat("0.000000000");
        //获取法定单位

        if (bnd_master_hs_code != null) {
            List<Bnd_master_unit_code> bnd_master_unit_code = iBnd_master_unit_codeService.findBycustoms_unit_code(bnd_master_hs_code.getLawf_unitcd());
            List<Bnd_master_unit_code> bnd_master_unit_code1 = iBnd_master_unit_codeService.findBycustoms_unit_code(bnd_master_hs_code.getSecd_lawf_unitcd());
            if (bnd_master_unit_code.size() != 0) {
                bnd_master_hs_code.setLawf_unitcd1(bnd_master_unit_code.get(0).getUnit_code());
            }
            if (bnd_master_unit_code1.size() != 0) {
                bnd_master_hs_code.setSecd_lawf_unitcd1(bnd_master_unit_code1.get(0).getUnit_code());
            }
        }

        Bnd_master_unit_code bnd_master_unit_code2 = iBnd_master_unit_codeService.findByunit_code(bnd_master_item.getUm_incoming_outgoing());
        Bnd_master_unit_code bnd_master_unit_code3 = iBnd_master_unit_codeService.findByunit_code(bnd_master_item.getUm_physical_inventory());
        //获取序号
        double seqno = 0;
        System.out.println("erer" + bnd_master_ehandbook_d);
        if (bnd_master_ehandbook_d.size() == 0) {
            Bnd_master_ehandbook_d ehandbook_d = iBnd_master_ehandbook_dService.findByitem_type(bnd_master_item.getItemized_application_code());
            if (ehandbook_d == null) {
                seqno = 1;
            } else {
                seqno = ehandbook_d.getGds_seqno() + 1;
            }
        } else {
            seqno = bnd_master_ehandbook_d.get(0).getGds_seqno();
        }
        System.out.println("pwpw" + seqno);

        //获取净重
        double ntwt = 0;
        double ntwt1 = 0;
//        double lawf_unitcd_cf=0;
//        double secd_lawf_unitcd_cf=0;
        if (!bnd_master_item.getWarranty_period().equals(0.0)) {
            ntwt = bnd_master_item.getNet_weigh() / bnd_master_item.getWarranty_period();
        } else {
            ntwt = bnd_master_item.getNet_weigh();
        }
        ntwt1 = ntwt / bnd_master_item.getCf_physical_inventory();

        //材料计算购买单价
        System.out.println("qqqa" + bnd_master_item.getItemized_application_code());
        Bnd_master_purchase_price bnd_master_purchase_price = new Bnd_master_purchase_price();
        Bnd_master_unit_code bnd_master_unit_code4 = new Bnd_master_unit_code();
        if (bnd_master_item.getItemized_application_code().equals("6")) {
            System.out.println("rgrgr");
            bnd_master_purchase_price = iBnd_master_purchase_priceService.findByitem_no(item_no);
            Bnd_master_vendor bnd_master_vendor = new Bnd_master_vendor();
            String curr = "";
            if (bnd_master_purchase_price != null) {
                bnd_master_vendor = iBnd_master_vendorService.findByVendorNo(bnd_master_purchase_price.getVendor_no());
            }
            if (bnd_master_vendor != null) {
                curr = bnd_master_vendor.getCurrency();
            }
            System.out.println("qwqw" + curr);
            Bnd_master_exchange_rate bnd_master_exchange_rate = iBnd_master_exchange_rateService.findByCurr(curr);
            if(bnd_master_purchase_price!=null) {
                bnd_master_unit_code4 = iBnd_master_unit_codeService.findByunit_code(bnd_master_purchase_price.getUm_purchase());

            double a = bnd_master_purchase_price.getPrice();
            double b = bnd_master_purchase_price.getCf_purchase();
            double c = bnd_master_item.getCf_physical_inventory();

            if (curr.equals("") || curr.equals("RMB") || curr.equals("CNY")) {
                bnd_master_exchange_rate.setRate(1.0);
            }
            if(b!=0.0 && c!=0.0) {
                if (curr.equals("USD")) {
                    price = a / b / c;
                } else {
                    price = (a / b / c) * (bnd_master_exchange_rate.getRate());
                }
            }
        }
        }

        ModelAndView modelAndView = new ModelAndView();

        modelAndView.addObject("bnd_master_item", bnd_master_item);
        modelAndView.addObject("bnd_master_hs_code", bnd_master_hs_code);
        modelAndView.addObject("price", df.format(price));
        modelAndView.addObject("seqno", seqno);
        modelAndView.addObject("ntwt", dfn.format(ntwt));
        modelAndView.addObject("ntwt1", dfn.format(ntwt1));
//        modelAndView.addObject("lawf_unitcd_cf", dfn.format(lawf_unitcd_cf));
//        modelAndView.addObject("secd_lawf_unitcd_cf", dfn.format(secd_lawf_unitcd_cf));
        if (bnd_master_unit_code2 != null) {
            modelAndView.addObject("unit_code2", bnd_master_unit_code2.getCustoms_unit_code());
        }
        if (bnd_master_unit_code3 != null) {
            modelAndView.addObject("unit_code3", bnd_master_unit_code3.getCustoms_unit_code());
        }
        modelAndView.addObject("bnd_master_purchase_price", bnd_master_purchase_price);
        if (bnd_master_unit_code4 != null) {
            modelAndView.addObject("unit_code4", bnd_master_unit_code4.getCustoms_unit_code());
        }
        if (bnd_master_declare_materialz != null) {
            modelAndView.addObject("item_spec", bnd_master_declare_materialz.getContent());
        }
        System.out.println("rtrt" + item_no);
        System.out.println(bnd_master_item);
        System.out.println(bnd_master_hs_code);
        System.out.println("fff" + df.format(price));
        System.out.println("ASA" + seqno);
        modelAndView.setViewName("bnd-master-ehandbook-d-add");

        return modelAndView;
    }


    @RequestMapping("/delete.do")
    public void delete(HttpServletRequest request,
                       HttpServletResponse response, HttpSession session) throws Exception {
        String username = (String) session.getAttribute("username");
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        //取出mrp和part_code
        String item_no = request.getParameter("item_no");
        String data_state = request.getParameter("data_state");
        Bnd_master_ehandbook_d bnd_master_ehandbook_d = iBnd_master_ehandbook_dService.findByitem(item_no);
        bnd_master_ehandbook_d.setUpdate_oid(username);
        bnd_master_ehandbook_d.setUpdate_program("/bnd_master_ehandbook_d/delete");
        //已备案不准删除
        if (data_state.equals("1")) {
            info.setFlag(true);
            iBnd_master_ehandbook_dService.updateState(bnd_master_ehandbook_d);
        } else {
            info.setErrorMsg("已备案不准删除");
            info.setFlag(false);
        }
        //响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(), info);
    }


    @RequestMapping("/update")
    public void update(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {

        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        String username = (String) session.getAttribute("username");
        String item_no = request.getParameter("item_no");
        String data_state = request.getParameter("data_state");

        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
//        int b = 0;
//        int c = 0;

        //遍历每一笔数据
        for (String name1 : set) {
            //将每一个key值对应的一组值放到数组里去
            String[] vals = (String[]) map.get(name1);
//            c = vals.length;
            //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
            hashMap.put(name1, vals[0]);
        }

        if ("2".equals(data_state)) {
            //id找到数据库里的原数据，并取出
            Bnd_master_ehandbook_d bnd_master_ehandbook_d = iBnd_master_ehandbook_dService.findByitem(item_no);
            Bnd_master_ehandbook_d ehandbook_d = new Bnd_master_ehandbook_d();
            try {
                BeanUtils.populate(ehandbook_d, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }

            System.out.println("RRR" + username);
            System.out.println("sdsd" + item_no);
            System.out.println(bnd_master_ehandbook_d);
            bnd_master_ehandbook_d.setUpdate_oid(username);
            bnd_master_ehandbook_d.setUpdate_program("/bnd_master_ehandbook_d/update");

            //调用业务层的update()方法
            iBnd_master_ehandbook_dService.updateState(bnd_master_ehandbook_d);

            List<Bnd_master_ehandbook_h> bnd_master_ehandbook_h = iBnd_master_ehandbook_hService.findAll();
            Bnd_master_declare_materialz bnd_master_declare_materialz = iBnd_master_declare_materialzService.findByitem_no(item_no);
            if (bnd_master_declare_materialz != null) {
                ehandbook_d.setItem_spec(bnd_master_declare_materialz.getContent());
            }
            System.out.println("AX" + bnd_master_declare_materialz);
            ehandbook_d.setSeq_no(bnd_master_ehandbook_h.get(0).getSeq_no());
            ehandbook_d.setEms_no(bnd_master_ehandbook_h.get(0).getEms_no());
            ehandbook_d.setData_state("1");
            ehandbook_d.setItem_no(item_no);
            Bnd_apply_ehandbook_d apply_ehandbook_d=iBnd_apply_ehandbook_dService.findByitem_no(item_no);
            if(apply_ehandbook_d==null) {
                ehandbook_d.setModf_markcd("3");
            }else{
                ehandbook_d.setModf_markcd("1");
            }
            ehandbook_d.setLogin_oid(username);
            ehandbook_d.setUpdate_oid(username);
            ehandbook_d.setUpdate_program("/bnd_master_ehandbook_d/update");
            iBnd_master_ehandbook_dService.save(ehandbook_d);
        } else {
            int id1 = Integer.parseInt(request.getParameter("id"));
            Bnd_master_ehandbook_d a = iBnd_master_ehandbook_dService.findById(id1);
            try {
                //double传不成功
                BeanUtils.populate(a, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
//            a.setDr_weight(s);
            a.setUpdate_oid(username);
            String update_program = "/bnd_master_ehandbook_d/update";
            a.setUpdate_program(update_program);
            iBnd_master_ehandbook_dService.update(a);
        }
        //响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(), info);

    }

    @RequestMapping(value = "/save.do")
    public void save(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {
        String username = (String) session.getAttribute("username");
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        //创建一个hashMap对象
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        String item_no="";
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //将每一个key值对应的一组值放到数组里去
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                //将每一个key值对应的值放到hashMap集合里，增强循环走完一次，则将一笔数据放到集合中。
                hashMap.put(name1, vals[b]);
                if(name1.equals("item_no")){
                    item_no=vals[b];
                }
            }

            //创建对象
            Bnd_master_ehandbook_d bnd_master_ehandbook_d = new Bnd_master_ehandbook_d();
            try {
                BeanUtils.populate(bnd_master_ehandbook_d, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //更新程序
            List<Bnd_master_ehandbook_h> bnd_master_ehandbook_h = iBnd_master_ehandbook_hService.findAll();
            bnd_master_ehandbook_d.setSeq_no(bnd_master_ehandbook_h.get(0).getSeq_no());
            bnd_master_ehandbook_d.setEms_no(bnd_master_ehandbook_h.get(0).getEms_no());
//            bnd_master_ehandbook_d.setModf_markcd("3");
            Bnd_apply_ehandbook_d apply_ehandbook_d=iBnd_apply_ehandbook_dService.findByitem_no(item_no);
            if(apply_ehandbook_d==null) {
                bnd_master_ehandbook_d.setModf_markcd("3");
            }else{
                bnd_master_ehandbook_d.setModf_markcd("1");
            }
            bnd_master_ehandbook_d.setLogin_oid(username);
            bnd_master_ehandbook_d.setUpdate_oid(username);
            bnd_master_ehandbook_d.setUpdate_program("/bnd_master_ehandbook_d/save");

            //调用业务层的save()方法
            System.out.println("1");
            iBnd_master_ehandbook_dService.save(bnd_master_ehandbook_d);

            b++;
            if (b == c) {
                break;
            }

//        return "redirect:findByPartAndMrp.do";
//        return "par-master-list.jsp";
        }
        //响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(), info);
    }

}
