package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_domestic_nonbond_material {
    private int id;
    private String yyyymm;//年月
    private String invoice_no;//發票號碼
    private Integer packing_serial;//裝箱序號
    private String invoice_type;//發票型態
    private Double ucns_verno;//单耗版本号
    private Double transaction_qty;//TRANSACTION QTY
    private String bond_type;//保税类别
    private String lot_no;//批號
    private String item_no_wh;//品名代码
    private String item_description_dbcs;//品名（中文）
    private String material_bonded_logo;//材料保稅區分
    private String fg_gi_date;//成品MO入庫日期
    private Double fg_gi_qty;//成品MO入库數量
    private String mo_no;//製造訂單號碼
    private Double operation_sequence_no;//作業順序號碼
    private String equipment_name;//工作站代碼
    private String item_no_psa;//品名代碼
    private String mrpcode;//ＭＲＰ基準代碼
    private String item_descrip_en;//品名
    private String item_spec;//品名規格
    private Double fg_actual_qty;//本站實際投入數
    private Double material_count;//材料流水號
    private String material_item_no;//材料品名代碼
    private String material_item_description;//材料品名
    private String material_specification;//材料品名規格
    private String material_lot_no;//材料批號
    private Double actual_materail_qty;//實際材料數
    private Double material_defect_qty;//材料不良數
    private Double loss_qty;//損耗數
    private String actual_um;//實際單位
    private String um_incoming_outgoing;//計量單位（入出庫）
    private Double product_loss_quantity;//凈耗
    private Double loss_quantity;//損耗
    private Double componentparent_itemc;//材料用量
    private Double component_qtyparent_qty;//製品用量
    private String sap_mo;//MFSAPM
    private Double material_bom_ver;//MFBOMV
    private String material_item_no_1;//1阶材料品名
    private Double materail_qty_1;//1阶材料用量
    private String return_document;//退货联络书
    private String mo_type;//mo类型
    private Double recycle_qty;//再生数量
    private Double cf_physical_inventory;//成品盘点换算系数
    private String shipped_date;//出货日期
    private String raw_description_dbcs;//材料中文品名
    private Double raw_img_no;//材料项号
    private String raw_io_unit;//材料在库单位
    private String raw_custom_unit;//材料监管单位
    private Double raw_custom_cf;//材料的监管换算系数
    private String raw_bond_logo;//材料的保税标识
    private String convert_mo;//折算的MO
    private Double convert_version;//折算的版本
    private Double dec_cm;//净耗
    private Double dec_dm;//损耗率
    private Double fg_img_no;//成品项号
    private String fg_io_unit;//成品在库单位
    private String fg_custom_unit;//成品监管单位
    private Double fg_custom_qty;//成品的监管出货数量
    private String root_lot;//第一阶Lot
    private String root_item_no;//第一阶Lot
    private Double root_qty;//第一阶Lot qty
    private String lot_2;//第2阶Lot
    private String item_no_2;//第2阶Lot
    private Double qty_2;//第2阶Lot qty
    private String lot_3;//第3阶Lot
    private String item_no_3;//第3阶Lot
    private Double qty_3;//第3阶Lot qty
    private String lot_4;//第4阶Lot
    private String item_no_4;//第4阶Lot
    private Double qty_4;//第4阶Lot qty
    private String father_lot;//上阶LOT
    private Double father_qty;//上阶数量
    private Integer conver_times;//折算次数


    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

}
