package com.tdk.txm_java.domain;

import java.util.Date;

public class Bnd_master_ehandbook_d {
    private int id;
    private String seq_no ;
    private String ems_no;
    private String item_type;
    private String data_state;
    private Double img_no;
    private Double gds_seqno ;
    private String ccc_code;
    private String item_no;
    private String item_description_dbcs;
    private String item_spec;
    private String um_incoming_outgoing;
    private String um_physical_inventory;
    private Double cf_physical_inventory;
    private String um_purchase;
    private Double cf_purchase;
    private String lawf_unitcd;
    private Double lawf_unitcd_cf;
    private String secd_lawf_unitcd;
    private Double secd_lawf_unitcd_cf;
    private String item_class_code;
    private Double net_weigh;
    private Double dcl_uprc_amt;
    private String currency;
    private Double dcl_qty;
    private String lvyrlf_modecd;
    private String qty_cntr_markcd;
    private String adjmtr_markcd;
    private String modf_markcd;
    private String etps_exe_markcd;
    private String cusm_exe_markcd;
    private Double appr_max_surp_qty;
    private Double vclr_prid_init_qty;
    private String ucns_tqsn_flag;
    private String csttn_flag;
    private String regulatory_credentials1;
    private String regulatory_credentials2;
    private String regulatory_credentials3;
    private String regulatory_credentials4;
    private String regulatory_credentials5;
    private String regulatory_credentials6;
    private String regulatory_credentials7;
    private String regulatory_credentials8;
    private String regulatory_credentials9;
    private String regulatory_credentials10;
    private String rmk ;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSeq_no() {
        return seq_no;
    }

    public void setSeq_no(String seq_no) {
        this.seq_no = seq_no;
    }

    public String getEms_no() {
        return ems_no;
    }

    public void setEms_no(String ems_no) {
        this.ems_no = ems_no;
    }

    public String getItem_type() {
        return item_type;
    }

    public void setItem_type(String item_type) {
        this.item_type = item_type;
    }

    public String getData_state() {
        return data_state;
    }

    public void setData_state(String data_state) {
        this.data_state = data_state;
    }

    public Double getImg_no() {
        return img_no;
    }

    public void setImg_no(Double img_no) {
        this.img_no = img_no;
    }

    public Double getGds_seqno() {
        return gds_seqno;
    }

    public void setGds_seqno(Double gds_seqno) {
        this.gds_seqno = gds_seqno;
    }

    public String getCcc_code() {
        return ccc_code;
    }

    public void setCcc_code(String ccc_code) {
        this.ccc_code = ccc_code;
    }

    public String getItem_no() {
        return item_no;
    }

    public void setItem_no(String item_no) {
        this.item_no = item_no;
    }

    public String getItem_description_dbcs() {
        return item_description_dbcs;
    }

    public void setItem_description_dbcs(String item_description_dbcs) {
        this.item_description_dbcs = item_description_dbcs;
    }

    public String getItem_spec() {
        return item_spec;
    }

    public void setItem_spec(String item_spec) {
        this.item_spec = item_spec;
    }

    public String getUm_incoming_outgoing() {
        return um_incoming_outgoing;
    }

    public void setUm_incoming_outgoing(String um_incoming_outgoing) {
        this.um_incoming_outgoing = um_incoming_outgoing;
    }

    public String getUm_physical_inventory() {
        return um_physical_inventory;
    }

    public void setUm_physical_inventory(String um_physical_inventory) {
        this.um_physical_inventory = um_physical_inventory;
    }

    public Double getCf_physical_inventory() {
        return cf_physical_inventory;
    }

    public void setCf_physical_inventory(Double cf_physical_inventory) {
        this.cf_physical_inventory = cf_physical_inventory;
    }

    public String getUm_purchase() {
        return um_purchase;
    }

    public void setUm_purchase(String um_purchase) {
        this.um_purchase = um_purchase;
    }

    public Double getCf_purchase() {
        return cf_purchase;
    }

    public void setCf_purchase(Double cf_purchase) {
        this.cf_purchase = cf_purchase;
    }

    public String getLawf_unitcd() {
        return lawf_unitcd;
    }

    public void setLawf_unitcd(String lawf_unitcd) {
        this.lawf_unitcd = lawf_unitcd;
    }

    public Double getLawf_unitcd_cf() {
        return lawf_unitcd_cf;
    }

    public void setLawf_unitcd_cf(Double lawf_unitcd_cf) {
        this.lawf_unitcd_cf = lawf_unitcd_cf;
    }

    public String getSecd_lawf_unitcd() {
        return secd_lawf_unitcd;
    }

    public void setSecd_lawf_unitcd(String secd_lawf_unitcd) {
        this.secd_lawf_unitcd = secd_lawf_unitcd;
    }

    public Double getSecd_lawf_unitcd_cf() {
        return secd_lawf_unitcd_cf;
    }

    public void setSecd_lawf_unitcd_cf(Double secd_lawf_unitcd_cf) {
        this.secd_lawf_unitcd_cf = secd_lawf_unitcd_cf;
    }

    public String getItem_class_code() {
        return item_class_code;
    }

    public void setItem_class_code(String item_class_code) {
        this.item_class_code = item_class_code;
    }

    public Double getNet_weigh() {
        return net_weigh;
    }

    public void setNet_weigh(Double net_weigh) {
        this.net_weigh = net_weigh;
    }

    public Double getDcl_uprc_amt() {
        return dcl_uprc_amt;
    }

    public void setDcl_uprc_amt(Double dcl_uprc_amt) {
        this.dcl_uprc_amt = dcl_uprc_amt;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public Double getDcl_qty() {
        return dcl_qty;
    }

    public void setDcl_qty(Double dcl_qty) {
        this.dcl_qty = dcl_qty;
    }

    public String getLvyrlf_modecd() {
        return lvyrlf_modecd;
    }

    public void setLvyrlf_modecd(String lvyrlf_modecd) {
        this.lvyrlf_modecd = lvyrlf_modecd;
    }

    public String getQty_cntr_markcd() {
        return qty_cntr_markcd;
    }

    public void setQty_cntr_markcd(String qty_cntr_markcd) {
        this.qty_cntr_markcd = qty_cntr_markcd;
    }

    public String getAdjmtr_markcd() {
        return adjmtr_markcd;
    }

    public void setAdjmtr_markcd(String adjmtr_markcd) {
        this.adjmtr_markcd = adjmtr_markcd;
    }

    public String getModf_markcd() {
        return modf_markcd;
    }

    public void setModf_markcd(String modf_markcd) {
        this.modf_markcd = modf_markcd;
    }

    public String getEtps_exe_markcd() {
        return etps_exe_markcd;
    }

    public void setEtps_exe_markcd(String etps_exe_markcd) {
        this.etps_exe_markcd = etps_exe_markcd;
    }

    public String getCusm_exe_markcd() {
        return cusm_exe_markcd;
    }

    public void setCusm_exe_markcd(String cusm_exe_markcd) {
        this.cusm_exe_markcd = cusm_exe_markcd;
    }

    public Double getAppr_max_surp_qty() {
        return appr_max_surp_qty;
    }

    public void setAppr_max_surp_qty(Double appr_max_surp_qty) {
        this.appr_max_surp_qty = appr_max_surp_qty;
    }

    public Double getVclr_prid_init_qty() {
        return vclr_prid_init_qty;
    }

    public void setVclr_prid_init_qty(Double vclr_prid_init_qty) {
        this.vclr_prid_init_qty = vclr_prid_init_qty;
    }

    public String getUcns_tqsn_flag() {
        return ucns_tqsn_flag;
    }

    public void setUcns_tqsn_flag(String ucns_tqsn_flag) {
        this.ucns_tqsn_flag = ucns_tqsn_flag;
    }

    public String getCsttn_flag() {
        return csttn_flag;
    }

    public void setCsttn_flag(String csttn_flag) {
        this.csttn_flag = csttn_flag;
    }

    public String getRegulatory_credentials1() {
        return regulatory_credentials1;
    }

    public void setRegulatory_credentials1(String regulatory_credentials1) {
        this.regulatory_credentials1 = regulatory_credentials1;
    }

    public String getRegulatory_credentials2() {
        return regulatory_credentials2;
    }

    public void setRegulatory_credentials2(String regulatory_credentials2) {
        this.regulatory_credentials2 = regulatory_credentials2;
    }

    public String getRegulatory_credentials3() {
        return regulatory_credentials3;
    }

    public void setRegulatory_credentials3(String regulatory_credentials3) {
        this.regulatory_credentials3 = regulatory_credentials3;
    }

    public String getRegulatory_credentials4() {
        return regulatory_credentials4;
    }

    public void setRegulatory_credentials4(String regulatory_credentials4) {
        this.regulatory_credentials4 = regulatory_credentials4;
    }

    public String getRegulatory_credentials5() {
        return regulatory_credentials5;
    }

    public void setRegulatory_credentials5(String regulatory_credentials5) {
        this.regulatory_credentials5 = regulatory_credentials5;
    }

    public String getRegulatory_credentials6() {
        return regulatory_credentials6;
    }

    public void setRegulatory_credentials6(String regulatory_credentials6) {
        this.regulatory_credentials6 = regulatory_credentials6;
    }

    public String getRegulatory_credentials7() {
        return regulatory_credentials7;
    }

    public void setRegulatory_credentials7(String regulatory_credentials7) {
        this.regulatory_credentials7 = regulatory_credentials7;
    }

    public String getRegulatory_credentials8() {
        return regulatory_credentials8;
    }

    public void setRegulatory_credentials8(String regulatory_credentials8) {
        this.regulatory_credentials8 = regulatory_credentials8;
    }

    public String getRegulatory_credentials9() {
        return regulatory_credentials9;
    }

    public void setRegulatory_credentials9(String regulatory_credentials9) {
        this.regulatory_credentials9 = regulatory_credentials9;
    }

    public String getRegulatory_credentials10() {
        return regulatory_credentials10;
    }

    public void setRegulatory_credentials10(String regulatory_credentials10) {
        this.regulatory_credentials10 = regulatory_credentials10;
    }

    public String getRmk() {
        return rmk;
    }

    public void setRmk(String rmk) {
        this.rmk = rmk;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    @Override
    public String toString() {
        return "Bnd_master_ehandbook_d{" +
                "id=" + id +
                ", seq_no='" + seq_no + '\'' +
                ", ems_no='" + ems_no + '\'' +
                ", item_type='" + item_type + '\'' +
                ", data_state='" + data_state + '\'' +
                ", img_no=" + img_no +
                ", gds_seqno=" + gds_seqno +
                ", ccc_code='" + ccc_code + '\'' +
                ", item_no='" + item_no + '\'' +
                ", item_description_dbcs='" + item_description_dbcs + '\'' +
                ", item_spec='" + item_spec + '\'' +
                ", um_incoming_outgoing='" + um_incoming_outgoing + '\'' +
                ", um_physical_inventory='" + um_physical_inventory + '\'' +
                ", cf_physical_inventory=" + cf_physical_inventory +
                ", um_purchase='" + um_purchase + '\'' +
                ", cf_purchase=" + cf_purchase +
                ", lawf_unitcd='" + lawf_unitcd + '\'' +
                ", lawf_unitcd_cf=" + lawf_unitcd_cf +
                ", secd_lawf_unitcd='" + secd_lawf_unitcd + '\'' +
                ", secd_lawf_unitcd_cf=" + secd_lawf_unitcd_cf +
                ", item_class_code='" + item_class_code + '\'' +
                ", net_weigh=" + net_weigh +
                ", dcl_uprc_amt=" + dcl_uprc_amt +
                ", currency='" + currency + '\'' +
                ", dcl_qty=" + dcl_qty +
                ", lvyrlf_modecd='" + lvyrlf_modecd + '\'' +
                ", qty_cntr_markcd='" + qty_cntr_markcd + '\'' +
                ", adjmtr_markcd='" + adjmtr_markcd + '\'' +
                ", modf_markcd='" + modf_markcd + '\'' +
                ", etps_exe_markcd='" + etps_exe_markcd + '\'' +
                ", cusm_exe_markcd='" + cusm_exe_markcd + '\'' +
                ", appr_max_surp_qty=" + appr_max_surp_qty +
                ", vclr_prid_init_qty=" + vclr_prid_init_qty +
                ", ucns_tqsn_flag='" + ucns_tqsn_flag + '\'' +
                ", csttn_flag='" + csttn_flag + '\'' +
                ", regulatory_credentials1='" + regulatory_credentials1 + '\'' +
                ", regulatory_credentials2='" + regulatory_credentials2 + '\'' +
                ", regulatory_credentials3='" + regulatory_credentials3 + '\'' +
                ", regulatory_credentials4='" + regulatory_credentials4 + '\'' +
                ", regulatory_credentials5='" + regulatory_credentials5 + '\'' +
                ", regulatory_credentials6='" + regulatory_credentials6 + '\'' +
                ", regulatory_credentials7='" + regulatory_credentials7 + '\'' +
                ", regulatory_credentials8='" + regulatory_credentials8 + '\'' +
                ", regulatory_credentials9='" + regulatory_credentials9 + '\'' +
                ", regulatory_credentials10='" + regulatory_credentials10 + '\'' +
                ", rmk='" + rmk + '\'' +
                ", login_time=" + login_time +
                ", login_oid='" + login_oid + '\'' +
                ", update_time='" + update_time + '\'' +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                '}';
    }
}
