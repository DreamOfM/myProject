package com.tdk.txm_java.domain;


import lombok.Data;

import java.util.Date;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_develop</h3>
 * @ClassName<h4>结转发单控制</h4>
 * @ToDo<p></p>
 * @date : 2020-05-23 15:07
 * @version:1.0
 **/
@Data
public class Bnd_carry_invt_list {
    private int id;
    private String internal_number;//企業內部清單編號
    private String apply_date;//申報日期
    private String invoice_no;//發票號碼
    private String item_no;//TDK ITEM
    private String img_no;//備案序號
    private String country_code;//原產國
    private String vendor_no;//供應商
    private String vendor_ems;//供應商手冊
    private String currency;//幣別
    private String um_physical_inventory;//申報單位
    private Double already_declared_qty;//已報數量
    private Double already_declared_amount;//已報金額
    private Double already_declared_weight;//已報重量
    private String expiration_flag;//已轉標誌
    private String vendor_img_no;//供应商项号
    private Double sum_dec_qty;//申报数量合计
    private Double sum_dec_amount;//申报金额合计
    private Double sum_dec_weight;//申报重量合计
    private String flag;//画面判断时使用
    private Bnd_master_ehandbook_d bndMasterEhandbookD;
    private Bnd_master_item bndMasterItem;
    private Date login_time;
    private String login_oid;
    private Date update_time;
    private String update_oid;
    private String update_program;
    private Date dateFrom;
    private Date dateTo;

    /*by xiaoni 2021/2/26*/
    private String vendor_name_abbr_dbcs;
    private String item_description_dbcs;
    private String bill_no;
    private String declaration_notice;
}
