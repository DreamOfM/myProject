package com.tdk.txm_java.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tdk.txm_java.dao.IBnd_master_invt_dDao;
import com.tdk.txm_java.domain.*;
import com.tdk.txm_java.service.*;
import com.tdk.txm_java.utils.JsonUtil;
import com.tdk.txm_java.utils.DateUtils;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

/**
 * @Author Wang FengCai
 * @Description 手动报关单回执
 * @Date 2020/8/17
 * @Time 下午 01:27
 **/
@Controller
@SessionAttributes
@RequestMapping("/bnd_if_fcaip_declare_list")
@ResponseBody
public class Bnd_if_fcaip_declare_listController {
    @Autowired
    IBnd_master_declare_companyService iBndMasterDeclareCompanyService;
    @Autowired
    IBnd_carry_cif_priceService iBndCarryCifPriceService;
    @Autowired
    IBnd_master_ehandbook_dService iBndMasterEhandbookDService;
    @Autowired
    IBnd_import_asnService iBndImportAsnService;
    @Autowired
    IBnd_master_trade_transactionService iBndMasterTradeTransactionService;
    @Autowired
    IBnd_export_return_replacementService iBndCarryReturnReplacementService;
    @Autowired
    IBnd_master_ehandbook_hService iBndMasterEhandbookHService;
    @Autowired
    IBnd_master_invt_hService iBndMasterInvtHService;
    @Autowired
    IBnd_master_declare_listService iBndMasterDeclareListService;
    @Autowired
    IBnd_master_invt_dService iBndMasterInvtDService;
    @Autowired
    IBnd_master_invt_del_hService iBndMasterInvtDelHService;
    @Autowired
    IBnd_apply_invt_hService iBndApplyInvtHService;
    @Autowired
    IBnd_carry_invt_listService iBndCarryInvtListService;
    @Autowired
    IBnd_carry_vendor_arrivalService iBndCarryVendorArrivalService;
    @Autowired
    IBnd_master_invt_del_dService iBndMasterInvtDelDService;
    @Autowired
    IBnd_apply_invt_dService iBndApplyInvtDService;
    @Autowired
    IBnd_paytax_declare_detailService iBndPaytaxDeclareDetailService;
    @Autowired
    IBnd_carry_invoice_fileService iBndCarryInvoiceFileService;
    @Autowired
    IBnd_master_currency_codeService iBndMasterCurrencyCodeService;
    @Autowired
    IBnd_master_exchange_rateService iBndMasterExchangeRateService;
    @Autowired
    IBnd_master_invt_dDao iBnd_master_invt_dDao;
    @Autowired
    IBnd_if_fcaip_declare_listService iBnd_if_fcaipdeclare_list_Service;

    /**
     * @Author Wang FengCai
     * @Description 根据供应商代码查询
     * @Date 2020/6/5
     * @Time 下午 01:31
     **/
    @RequestMapping("/findAll")
    @ResponseBody
    public ModelAndView findAll(HttpServletRequest request,RedirectAttributes attr) throws Exception {
        ModelAndView modelAndView = new ModelAndView ();
        String type = request.getParameter("type");
        if(type!=null&&!"".equals(type)){
            if("1".equals(type)){
                attr.addAttribute("type",type);
            }
        }
        //带出 bnd_master_ehandbook_h 的数据
        List<Bnd_master_ehandbook_h> bndMasterEhandbookHList = iBndMasterEhandbookHService.findAll ();
        modelAndView.addObject ("bndMasterEhandbookH", bndMasterEhandbookHList);
        modelAndView.setViewName ("bnd-if-fcaip-declare-list");
        return modelAndView;
    }

    /**
     * @Author Wang FengCai
     * @Description 根据账册号和内部清单号和报关单号进行查询
     * @Date 2020/8/8
     * @Time 下午 01:29
     **/
    @RequestMapping("/findByEmsNoAndInternalNumberAndDclNo")
    @ResponseBody
    public ModelAndView findByEmsNoAndInternalNumberAndDclNo(HttpServletRequest request, HttpSession session, @RequestParam(value = "pn", defaultValue = "1") Integer pn, @RequestParam(value = "PageSize", defaultValue = "10") Integer ps) throws Exception {
        ModelAndView modelAndView = new ModelAndView ();

        String emsNo = request.getParameter ("ems_no");
        String internalNumber = request.getParameter ("internal_number");
        String dclNo = request.getParameter ("declaration_no");
        String type = request.getParameter("type");
        //引入PageHelper分页插件
        PageHelper.startPage (pn, ps);
        //1.根据ems_no,internal_number,declaration_no去bnd_master_invt_h(H2LHP)中查找带出表头
        Bnd_master_invt_h bndMasterInvtH = iBndMasterInvtHService.findByInternalNumberAndEmsNo (internalNumber, emsNo);
        String invtNm = null;
        String dclNm = null;
        String itemNo = null;

        if (bndMasterInvtH != null && !"".equals (bndMasterInvtH)) {
            //a.如果LHENTN（declaration_no 報關單預錄入編號X(18)）不为空	MOVELLHENTN	 W1ENTN
            //如果LHENTN （declaration_no 報關單預錄入編號X(18)）为空	 MOVELW1ENID（画面的查询栏位的报关单号）	W1ENTN
            String decNo = bndMasterInvtH.getDeclaration_no ();
            if (decNo == null || "".equals (decNo)) {
                bndMasterInvtH.setDeclaration_no (dclNo);
            }

            //b.根据核注单位编码（dcl_etpsno）去bnd_master_declare_company 申报单位明细档查询
            String dclEtpsno = bndMasterInvtH.getDcl_etpsno ();
            List<Bnd_master_declare_company> bndMasterDeclareCompanyList = iBndMasterDeclareCompanyService.findByDclEtpsNo (dclEtpsno);
            if (bndMasterDeclareCompanyList.size () > 0) {
                for (Bnd_master_declare_company bndMasterDeclareCompany : bndMasterDeclareCompanyList) {
                    invtNm = bndMasterDeclareCompany.getDcl_etps_nm ();
                }
                bndMasterInvtH.setInvt_nm (invtNm);
            }

            //c.根据报关单位编码（corresponding_customs_unit_code）去bnd_master_declare_company 申报单位明细档查询
            String corresponding_customs_unit_code = bndMasterInvtH.getCorresponding_customs_unit_code ();
            List<Bnd_master_declare_company> bndMasterDeclareCompanyList1 = iBndMasterDeclareCompanyService.findByDclEtpsNo (corresponding_customs_unit_code);
            if (bndMasterDeclareCompanyList1 != null && bndMasterDeclareCompanyList1.size () > 0) {
                for (Bnd_master_declare_company bndMasterDeclareCompany : bndMasterDeclareCompanyList1) {
                    dclNm = bndMasterDeclareCompany.getDcl_etps_nm ();
                }
                bndMasterInvtH.setDcl_nm (dclNm);
            }
            //d.将系统日期赋值给申报日期
            bndMasterInvtH.setDcl_date (DateUtils.getDateByString ());
        }


        //2.根据报关单号+账册号去报关单列表 H2DEP( bnd_master_declare_list)查询
        Bnd_master_declare_list bndMasterDeclareList = iBndMasterDeclareListService.findByDclNoAndEmsNo (dclNo, emsNo);
        //a.判断
        if (bndMasterDeclareList == null || "".equals (bndMasterDeclareList)) {

            //1.新增
            //跳转到新增画面
            //带出表体的数据H2LDP
            List<Bnd_master_invt_d> bndMasterInvtDList = iBndMasterInvtDService.findByInternalNumberAndEmsNo (internalNumber, emsNo);
            if (bndMasterInvtDList.size () > 0) {

            }
            bndMasterInvtH.setType(type);
            modelAndView.addObject ("bndMasterInvtH", bndMasterInvtH);
            modelAndView.addObject ("bndMasterInvtDs", bndMasterInvtDList);

            modelAndView.setViewName ("bnd-if-fcaip-declare-list-add");
        } else {
            //2.更新
            //a.带出如下信息显示在表头
            bndMasterInvtH.setBndMasterDeclareList (bndMasterDeclareList);
            //根据报关单去HTOCP(bnd_carry_cif_price )查询 HTOCP表中，同一个报关单的运费,费率那些是一样的
            Bnd_carry_cif_price bndCarryCifPrice = iBndCarryCifPriceService.findByDeclarationNo (dclNo);
            if (bndCarryCifPrice != null && !"".equals (bndCarryCifPrice)) {
                bndMasterInvtH.setBndCarryCifPrice (bndCarryCifPrice);
            }

            //b.根据清单号+账册号去核注清单申报明细档(bnd_master_invt_d)查询带出表体
            List<Bnd_master_invt_d> bndMasterInvtDs = iBndMasterInvtDService.findAvgByInternalNumberAndEmsNo (internalNumber, emsNo);
            if (bndMasterInvtDs != null && bndMasterInvtDs.size () > 0) {
                for (Bnd_master_invt_d bndMasterInvtD : bndMasterInvtDs) {
                    //根据item_no 去bnd_master_ehangbook_d（账册表体）中查询归并项号
                    itemNo = bndMasterInvtD.getItem_no ();
                    Bnd_master_ehandbook_d bndMasterEhandbookD = iBndMasterEhandbookDService.findByItem_no (itemNo);
                    //取出归并项号
                    Double imgNo = bndMasterEhandbookD.getImg_no ();
                    String itemSpec = bndMasterEhandbookD.getItem_spec ();
                    bndMasterInvtD.setImgNo (imgNo);
                    bndMasterInvtD.setItem_spec (itemSpec);
                }
            }
            PageInfo page = new PageInfo (bndMasterInvtDs, ps);
            modelAndView.addObject ("pageInfo", page);
            modelAndView.addObject ("bndMasterInvtDs", bndMasterInvtDs);
            modelAndView.addObject ("bndMasterInvtH", bndMasterInvtH);
            modelAndView.setViewName ("bnd-if-fcaip-declare-list");
        }
        return modelAndView;
    }

    /**
     * @Author Wang FengCai
     * @Description 报关单检查
     * @Date  2020/12/19
     **/
    @RequestMapping("/CheckSaveReturn")
    public void CheckSaveReturn(HttpServletRequest request,HttpServletResponse response) throws Exception{
        ResultInfo info = new ResultInfo ();
        info.setFlag (true);
        Map map = request.getParameterMap ();

        Map<String, String> hashMap = new HashMap<> ();
        Set<String> set = map.keySet ();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            for (String name1 : set) {
                String[] vals = (String[]) map.get (name1);
                c = vals.length;
                hashMap.put (name1, vals[b]);
            }
            //将前端传回的数据封装到S2DEP这个对象中
            Bnd_if_fcaip_declare_list bnd_if_fcaip_declare_list = new Bnd_if_fcaip_declare_list();
            try {
                BeanUtils.populate (bnd_if_fcaip_declare_list, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace ();
            } catch (InvocationTargetException e) {
                e.printStackTrace ();
            }
            //调用service层的方法处理
            info = iBnd_if_fcaipdeclare_list_Service.dclReturnSaveCheck(bnd_if_fcaip_declare_list);

            b++;
            if (b == c) {
                break;
            }
        }
        //响应数据
        JsonUtil.writeValue(info,response);
    }

    //查询时的检查
    @RequestMapping("/CheckQueryReturn")
    public void CheckQueryReturn(HttpServletRequest request,HttpServletResponse response) throws Exception{
        ResultInfo info = new ResultInfo ();
        info.setFlag (true);
        Map map = request.getParameterMap ();

        Map<String, String> hashMap = new HashMap<> ();
        Set<String> set = map.keySet ();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            for (String name1 : set) {
                String[] vals = (String[]) map.get (name1);
                c = vals.length;
                hashMap.put (name1, vals[b]);
            }
            //将前端传回的数据封装到S2DEP这个对象中
            Bnd_if_fcaip_declare_list bnd_if_fcaip_declare_list = new Bnd_if_fcaip_declare_list();
            try {
                BeanUtils.populate (bnd_if_fcaip_declare_list, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace ();
            } catch (InvocationTargetException e) {
                e.printStackTrace ();
            }
            //调用service层的方法处理
            info = iBnd_if_fcaipdeclare_list_Service.dclReturnQueryCheck(bnd_if_fcaip_declare_list);

            b++;
            if (b == c) {
                break;
            }
        }
        //响应数据
         JsonUtil.writeValue(info,response);
    }

    /**
     * @Author Wang FengCai
     * @Description 更新表
     * @Date 2020/9/12
     **/
    @RequestMapping("/update")
    public void update(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception {
        ResultInfo info = new ResultInfo ();
        info.setFlag (true);
        Map map = request.getParameterMap ();
        String username = (String) httpSession.getAttribute ("username");
        Map<String, String> hashMap = new HashMap<> ();
        Set<String> set = map.keySet ();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            for (String name1 : set) {
                String[] vals = (String[]) map.get (name1);
                c = vals.length;
                hashMap.put (name1, vals[b]);
            }

            //1.W1ENID+W#ITNR在HTOCP查找，找到update，没找到插入
            //取出内部清单号
            String dclNo = hashMap.get ("declaration_no");
            //取出item
            String itemNo = hashMap.get ("item_no");

            Bnd_carry_cif_price bndCarryCifPrice = iBndCarryCifPriceService.findByDeclarationNoAndItemNo (dclNo, itemNo);
            if (bndCarryCifPrice != null && !"".equals (bndCarryCifPrice)) {
                //更新
                try {
                    BeanUtils.populate (bndCarryCifPrice, hashMap);
                } catch (IllegalAccessException e) {
                    e.printStackTrace ();
                } catch (InvocationTargetException e) {
                    e.printStackTrace ();
                }
                bndCarryCifPrice.setUpdate_program ("bnd_if_fcaip_declare_list/update");
                iBndCarryCifPriceService.update (bndCarryCifPrice);
            } else {
                //插入
                try {
                    BeanUtils.populate (bndCarryCifPrice, hashMap);
                } catch (IllegalAccessException e) {
                    e.printStackTrace ();
                } catch (InvocationTargetException e) {
                    e.printStackTrace ();
                }
                bndCarryCifPrice.setUpdate_oid (username);
                bndCarryCifPrice.setUpdate_program ("bnd_if_fcaip_declare_list/update");
                iBndCarryCifPriceService.save (bndCarryCifPrice);
            }

            //2.更新XTAAP  W#IVNR在XTAAP中查找   MOVEL'20'	AASTAT
            //取出发票号
            String invoicrNo = hashMap.get ("invoice_no").trim ();
            iBndCarryReturnReplacementService.upadteByInvoiceNo (invoicrNo);

            b++;
            if (b == c) {
                break;
            }
        }
        //响应数据
       JsonUtil.writeValue(info,response);
    }

    //报关单回执
    @RequestMapping("/save")
    public void save(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception {
        ResultInfo info = new ResultInfo ();
        info.setFlag (true);
        Map map = request.getParameterMap ();
        String username = (String) httpSession.getAttribute ("username");
        Map<String, String> hashMap = new HashMap<> ();
        Set<String> set = map.keySet ();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            for (String name1 : set) {
                String[] vals = (String[]) map.get (name1);
                c = vals.length;
                hashMap.put (name1, vals[b]);
            }
            //将前端传回的数据封装到S2DEP这个对象中
            Bnd_if_fcaip_declare_list bnd_if_fcaip_declare_list = new Bnd_if_fcaip_declare_list();
            try {
                BeanUtils.populate (bnd_if_fcaip_declare_list, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace ();
            } catch (InvocationTargetException e) {
                e.printStackTrace ();
            }

            bnd_if_fcaip_declare_list.setUsername(username);
            //调用service层的方法处理
            iBnd_if_fcaipdeclare_list_Service.dclReturnPro(bnd_if_fcaip_declare_list);

            b++;
            if (b == c) {
                break;
            }
        }
        //响应数据
        JsonUtil.writeValue(info,response);
    }


    /**
     * @Author Wang FengCai
     * @Description 根据id删除
     * @Date 2020/6/8
     * @Time 下午 01:48
     **/
    @RequestMapping("/delete")
    public void delete(String declaration_no, String invoice_no, HttpServletRequest request, HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo ();
        info.setFlag (true);
        //功能键：取消登录
        //1	删除HTOCP数据
        //	W1ENID找到HTOCP数据删除
        List<Bnd_master_declare_list> bndMasterDeclareLists = iBndMasterDeclareListService.findByDclNo (declaration_no);
        if (bndMasterDeclareLists.size () > 0) {
            for (Bnd_master_declare_list bndMasterDeclareList : bndMasterDeclareLists) {
                int id = bndMasterDeclareList.getId ();
                iBndMasterDeclareListService.delete (id);
            }
        }
        //2	更新XTAAP，状态改成 10
        //	W#IVNR在XTAAP中查找
        List<Bnd_export_return_replacement> bndCarryReturnReplacements = iBndCarryReturnReplacementService.findByInvoiceNo (invoice_no);
        if (bndMasterDeclareLists.size () > 0) {
            for (Bnd_export_return_replacement bndCarryReturnReplacement : bndCarryReturnReplacements) {
                int id = bndCarryReturnReplacement.getId ();
                //	MOVEL'10'	AASTAT
                String status = "10";
                iBndCarryReturnReplacementService.updateStateById (id, status);
            }
        }
        //响应数据
        JsonUtil.writeValue(info,response);
    }


}
