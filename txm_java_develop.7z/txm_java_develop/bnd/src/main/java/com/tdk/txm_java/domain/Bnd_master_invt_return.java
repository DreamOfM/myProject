package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Time;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_dev0604</h3>
 * @ClassName<h4></h4>
 * @ToDo<p>报关清单生成中间档——表头</p>
 * @date : 2020-07-04 10:18
 * @version:1.0
 **/
@Data
public class Bnd_master_invt_return {
    private int id;
    private String internal_number;//企業內部編號
    private String bill_no;//清单编号
    private String declare_date;//報關日期
    private String state;//状态

    private Time login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;



}
