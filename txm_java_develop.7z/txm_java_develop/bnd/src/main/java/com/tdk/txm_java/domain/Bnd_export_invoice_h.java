package com.tdk.txm_java.domain;



import lombok.Data;
import java.sql.Time;
import java.util.List;

@Data
public class Bnd_export_invoice_h {
    private int id;
    private String release_status;//發行狀態
    private String statement_customer_no;//負責付款之顧客
    private String shipped_date;//出貨日期
    private String shipping_month;//出貨日期-月份
    private String shipping_year;//出貨日期-年份
    private String shipping_day;//出貨日期-日
    private String invoice_no;//發票號碼
    private String shipping_condition_code;//運送方式
    private String ship_to_name1_dbcs;//出貨對象名１（中文）
    private String terms_trade;//貿易條件代碼
    private String currency;//貨幣代碼
    private Double shipping_date_rate;//匯率（出貨日）
    private Double packing_date_rate;//匯率（裝箱日）
    private Double packing_qty;//包裝數
    private Double amt_cn;//裝箱金額（本國）　
    private Double amt_foreign;//裝箱金額（外幣）
    private Double box_qty;//總箱數
    private Double total_netwet;//總淨重
    private Double total_grosswet;//箱數
    private String invoice_type;//AJIVTP
    private String departure_date;//AJDPDT
    private String bill_to;//AJBILL
    private String port_description;//AJPORT
    private String forwarder_code;//AJFRGC
    private Double pallet_qty;//发票总板数
    private String product_country_code;//生产国家代码
    private String packing_code;//包装代码
    private String customer_no;
    private String mrp_code;
    private String so_type;
    private String bond_type;

    private Time login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;
    private List<Bnd_export_invoice_d> bnd_export_invoice_d;
    private String internal_number;
    private String master_airway_bill;
    private String type_nm;
    private String delivery_note_name;
    private String type;
    private String sold_to_name;

    public void setBnd_export_invoice_d(List<Bnd_export_invoice_d> bnd_export_invoice_d) {
        this.bnd_export_invoice_d = bnd_export_invoice_d;
    }

    public List<Bnd_export_invoice_d> getBnd_export_invoice_d() {
        return bnd_export_invoice_d;
    }
}
