package com.tdk.txm_java.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tdk.txm_java.dao.*;
import com.tdk.txm_java.dao2.*;
import com.tdk.txm_java.domain.*;
import com.tdk.txm_java.service.IBnd_export_other_invoice_hService;
import com.tdk.txm_java.service.IBnd_mig_listService;
import com.tdk.txm_java.utils.JsonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

@Component
@Controller
@RequestMapping("/mig_master")
public class Mig_masterController {
    @Autowired
    private IH2cdpDao iH2cdpDao;
    @Autowired
    private IBnd_master_declare_scrapDao iBnd_master_declare_scrapDao;
    @Autowired
    private IH2cepDao iH2cepDao;
    @Autowired
    private IBnd_master_declare_scrapzDao iBnd_master_declare_scrapzDao;

    @Autowired
    private IH2edpDao iH2edpDao;
    @Autowired
    private IBnd_master_qualification_dDao iBnd_master_qualification_dDao;
    @Autowired
    private IBnd_mig_listDao iBnd_mig_listDao;
    @Autowired
    private IBnd_mig_listService iBnd_mig_listService;

    @Autowired
    private IH2etpDao iH2etpDao;
    @Autowired
    private IBnd_master_qualification_hDao iBnd_master_qualification_hDao;

    @Autowired
    private ITmsupDao iTmsupDao;
    @Autowired
    private IBnd_master_vendorDao iBnd_master_vendorDao;

    @Autowired
    private ITmimpDao iTmimpDao;
    @Autowired
    private IBnd_master_itemDao iBnd_master_itemDao;
    @Autowired
    private IH2btpDao iH2btpDao;
    @Autowired
    private IBnd_master_beginning_balanceDao iBnd_master_beginning_balanceDao;
    @Autowired
    private ITmbppDao iTmbppDao;
    @Autowired
    private IBnd_master_purchase_priceDao iBnd_master_purchase_priceDao;
    @Autowired
    private ITmispDao iTmispDao;
    @Autowired
    private IBnd_master_product_structureDao iBnd_master_product_structureDao;
    @Autowired
    private ITtmopmigDao iTtmopmigDao;
    @Autowired
    private IBnd_master_moDao iBnd_master_moDao;
    @Autowired
    private IXtmfpmigDao iXtmfpmigDao;
    @Autowired
    private IBnd_master_production_materialDao iBnd_master_production_materialDao;
    @Autowired
    private ITmrdpDao iTmrdpDao;
    @Autowired
    private IBnd_master_routingDao iBnd_master_routingDao;
    @Autowired
    private IHtm2pmigDao iHtm2pmigDao;
    @Autowired
    private IBnd_master_mo_versionDao iBnd_master_mo_versionDao;
    @Autowired
    private IXtblpmigDao iXtblpmigDao;
    @Autowired
    private IBnd_master_batch_lotDao iBnd_master_batch_lotDao;
    @Autowired
    private IH2ucpmigDao iH2ucpmigDao;
    @Autowired
    private IBnd_master_unit_codeDao iBnd_master_unit_codeDao;
    @Autowired
    private IHmctpDao iHmctpDao;
    @Autowired
    private IBnd_master_hs_codeDao iBnd_master_hs_codeDao;
    @Autowired
    private ITtadpDao iTtadpDao;
    @Autowired
    private IBnd_master_allocated_componentDao iBnd_master_allocated_componentDao;

    @Autowired
    private IH2crpDao iH2crpDao;
    @Autowired
    private IBnd_master_currency_codeDao iBnd_master_currency_codeDao;

    @Autowired
    private ITmcupDao iTmcupDao;
    @Autowired
    private IBnd_master_customerDao iBnd_master_customerDao;

    @Autowired
    private IH2t9pDao iH2t9pDao;
    @Autowired
    private IBnd_master_country_codeDao iBnd_master_country_codeDao;

    @Autowired
    private IH2ddpDao iH2ddpDao;
    @Autowired
    private IBnd_master_declare_companyDao iBnd_master_declare_companyDao;
    @Autowired
    private IHbcupDao iHbcupDao;
    @Autowired
    private IBnd_master_customsDao iBnd_master_customsDao;
    @Autowired
    private IHtctpDao iHtctpDao;
    @Autowired
    private IBnd_master_trade_transactionDao iBnd_master_trade_transactionDao;
    @Autowired
    private IH2ehpDao iH2ehpDao;
    @Autowired
    private IBnd_master_ehandbook_hDao iBnd_master_ehandbook_hDao;
    @Autowired
    private IH2eipDao iH2eipDao;
    @Autowired
    private IBnd_master_ehandbook_dDao iBnd_master_ehandbook_dDao;

    @Autowired
    private IH2bspmigDao iH2BspmigDao;
    @Autowired
    private IBnd_master_bomDao iBnd_master_bomDao;
    @Autowired
    private IHtm6pDao iHtm6pDao;
    @Autowired
    private IBnd_master_maximun_lossDao iBnd_master_maximun_lossDao;
    @Autowired
    private IHmccpDao iHmccpDao;
    @Autowired
    private IBnd_master_declare_elementDao iBnd_master_declare_elementDao;
    @Autowired
    private IHmcdpDao iHmcdpDao;
    @Autowired
    private IBnd_master_declare_materialDao iBnd_master_declare_materialDao;
    @Autowired
    private IHmcepDao iHmcepDao;
    @Autowired
    private IBnd_master_declare_materialzDao iBnd_master_declare_materialzDao;
    @Autowired
    private IHbappDao iHbappDao;
    @Autowired
    private IBnd_master_use_codeDao iBnd_master_use_codeDao;
    @Autowired
    private IHbdmpDao iHbdmpDao;
    @Autowired
    private IBnd_master_remission_typeDao iBnd_master_remission_typeDao;
    @Autowired
    private IHbtspDao iHbtspDao;
    @Autowired
    private IBnd_master_trans_codeDao iBnd_master_trans_codeDao;
    @Autowired
    private IH2depDao iH2depDao;
    @Autowired
    private IBnd_master_declare_listDao iBnd_master_declare_listDao;

    @Autowired
    private IH2lhpDao iH2lhpDao;
    @Autowired
    private IBnd_master_invt_hDao iBnd_master_invt_hDao;
    @Autowired
    private IH2ldpDao iH2ldpDao;
    @Autowired
    private IBnd_master_invt_dDao iBnd_master_invt_dDao;
    @Autowired
    private IHtm5pDao iHtm5pDao;
    @Autowired
    private IBnd_master_nonbond_lotDao iBnd_master_nonbond_lotDao;
    @Autowired
    private IHtahpDao iHtahpDao;
    @Autowired
    private IBnd_export_other_invoice_hDao iBnd_export_other_invoice_hDao;
    @Autowired
    private IHtadpDao iHtadpDao;
    @Autowired
    private IBnd_export_other_invoice_dDao iBnd_export_other_invoice_dDao;
    @Autowired
    private ITxknpDao iTxknpDao;
    @Autowired
    private IBnd_master_exchange_rateDao iBnd_master_exchange_rateDao;
    @Autowired
    private ITxqppDao iTxqppDao;
    @Autowired
    private IBnd_master_unit_measure_codeDao iBnd_master_unit_measure_codeDao;
    @Autowired
    private IHttipDao iHttipDao;
    @Autowired
    private IBnd_export_invoice_freightDao iBnd_export_invoice_freightDao;
    @Autowired
    private IHtttpDao iHtttpDao;
    @Autowired
    private IBnd_export_cabinet_typeDao iBnd_export_cabinet_typeDao;
    @Autowired
    private ITxqepDao iTxqepDao;
    @Autowired
    private IBnd_master_port_codeDao iBnd_master_port_codeDao;
    @Autowired
    private IBnd_master_bom_weedDao iBnd_master_bom_weedDao;
    @Autowired
    private IHtm3pDao iHtm3pDao;

    @RequestMapping("/mig_scrap.do")
    public void mig_scrap(HttpServletResponse response) throws Exception {
        ResultInfo info = new ResultInfo (); //取出前端传回的所有数据
        info.setFlag (true);
        // mig h2cdp
        List<Bnd_master_declare_scrap> ces = iH2cdpDao.findAll ();
        iBnd_master_declare_scrapDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 2000) {
            List<Bnd_master_declare_scrap> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_declare_scrap bnd_master_declare_scrap : ces) {
                ces02.add (bnd_master_declare_scrap);
                if (a == 2000) {
                    iBnd_master_declare_scrapDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_declare_scrapDao.saveByList (ces02);
        } else {
            iBnd_master_declare_scrapDao.saveByList (ces);
        }
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_declare_scrap");
        iBnd_mig_listService.update (bnd_mig_list);

         JsonUtil.writeValue(info,response);
    }

    @RequestMapping("/mig_scrapz.do")
    public ModelAndView mig_scrapz() throws Exception {
        // mig h2cep
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_declare_scrapz> ces = iH2cepDao.findAll ();
        iBnd_master_declare_scrapzDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 2000) {
            List<Bnd_master_declare_scrapz> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_declare_scrapz bnd_master_declare_scrapz : ces) {
                ces02.add (bnd_master_declare_scrapz);
                if (a == 2000) {
                    iBnd_master_declare_scrapzDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_declare_scrapzDao.saveByList (ces02);
        } else {
            iBnd_master_declare_scrapzDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_declare_scrapz");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }

    @RequestMapping("/mig_vendor.do")
    public ModelAndView mig_vendor() throws Exception {
        // mig Tmsup
        ModelAndView mv = new ModelAndView ();
//        System.out.println("6868686");
        List<Bnd_master_vendor> ces = iTmsupDao.findAll ();
        iBnd_master_vendorDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 2000) {
            List<Bnd_master_vendor> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_vendor bnd_master_vendor : ces) {
                ces02.add (bnd_master_vendor);
                if (a == 2000) {
                    iBnd_master_vendorDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_vendorDao.saveByList (ces02);
        } else {
            iBnd_master_vendorDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_vendor");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }

    @RequestMapping("/mig_item.do")
    public ModelAndView mig_item() throws Exception {
        // mig Tmimp
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_item> ces = iTmimpDao.findAll ();
        iBnd_master_itemDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 2000) {
            List<Bnd_master_item> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_item bnd_master_item : ces) {
                ces02.add (bnd_master_item);
                if (a == 2000) {
                    iBnd_master_itemDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_itemDao.saveByList (ces02);
        } else {
            iBnd_master_itemDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_item");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }

    @RequestMapping("/mig_beginning_balance.do")
    public ModelAndView mig_beginning_balance() throws Exception {
        // mig H2btpp
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_beginning_balance> ces = iH2btpDao.findAll ();
        iBnd_master_beginning_balanceDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 2000) {
            List<Bnd_master_beginning_balance> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_beginning_balance bnd_master_beginning_balance : ces) {
                ces02.add (bnd_master_beginning_balance);
                if (a == 2000) {
                    iBnd_master_beginning_balanceDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_beginning_balanceDao.saveByList (ces02);
        } else {
            iBnd_master_beginning_balanceDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_beginning_balance");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }

    @RequestMapping("/mig_purchase_price.do")
    public ModelAndView mig_purchase_price() throws Exception {
        // mig Tmbpp
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_purchase_price> ces = iTmbppDao.findAll ();
        iBnd_master_purchase_priceDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 2000) {
            List<Bnd_master_purchase_price> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_purchase_price bnd_master_purchase_price : ces) {
                ces02.add (bnd_master_purchase_price);
                if (a == 2000) {
                    iBnd_master_purchase_priceDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_purchase_priceDao.saveByList (ces02);
        } else {
            iBnd_master_purchase_priceDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_purchase_price");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }

    @RequestMapping("/mig_product_structure.do")
    public ModelAndView mig_product_structure() throws Exception {
        // mig Tmisp
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_product_structure> ces = iTmispDao.findAll ();
        iBnd_master_product_structureDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 2000) {
            List<Bnd_master_product_structure> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_product_structure bnd_master_product_structure : ces) {
                ces02.add (bnd_master_product_structure);
                if (a == 2000) {
                    iBnd_master_product_structureDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_product_structureDao.saveByList (ces02);
        } else {
            iBnd_master_product_structureDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_product_structure");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }

    @RequestMapping("/mig_mo.do")
    public ModelAndView mig_mo() throws Exception {
        // mig Ttmop
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_mo> ces = iTtmopmigDao.findAll ();
        iBnd_master_moDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 2000) {
            List<Bnd_master_mo> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_mo bnd_master_mo : ces) {
                ces02.add (bnd_master_mo);
                if (a == 2000) {
                    iBnd_master_moDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_moDao.saveByList (ces02);
        } else {
            iBnd_master_moDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_mo");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }

    @RequestMapping("/mig_production_material.do")
    public ModelAndView mig_production_material() throws Exception {
        // mig xtmfp
        ModelAndView mv = new ModelAndView ();
        //数据量太大，分批保存

        Com_limit com_limit = new Com_limit ();
        int number = 500000;
        com_limit.setStart (1);
        com_limit.setEnd (number);
        iBnd_master_production_materialDao.deleteAll ();
        do {
            List<Bnd_master_production_material> temp = iXtmfpmigDao.findAll (com_limit);

            //数据量太大，分批保存
            if (temp.size () > 1000) {
                List<Bnd_master_production_material> temp02 = new ArrayList<> ();
                int a = 1;
                for (Bnd_master_production_material bnd_master_production_material : temp) {
                    temp02.add (bnd_master_production_material);
                    if (a == 1000) {
                        iBnd_master_production_materialDao.saveByList (temp02);
                        temp02.clear ();
                        a = 1;
                    }
                    a++;
                }
                if (temp02.size () > 0) iBnd_master_production_materialDao.saveByList (temp02);
            } else {
                iBnd_master_production_materialDao.saveByList (temp);

            }
            if (temp.size () < number) break;
            com_limit.setStart (com_limit.getStart () + number);
        } while (1 == 1);

        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_production_material");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }

    @RequestMapping("/mig_routing.do")
    public ModelAndView mig_routing() throws Exception {
        // mig Ttmop
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_routing> ces = iTmrdpDao.findAll ();
        iBnd_master_routingDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 2000) {
            List<Bnd_master_routing> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_routing bnd_master_routing : ces) {
                ces02.add (bnd_master_routing);
                if (a == 2000) {
                    iBnd_master_routingDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_routingDao.saveByList (ces02);
        } else {
            iBnd_master_routingDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_routing");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }

    @RequestMapping("/mig_mo_version.do")
    public ModelAndView mig_mo_version() throws Exception {
        // mig Htm2p
        ModelAndView mv = new ModelAndView ();
        Com_limit com_limit = new Com_limit ();
        int number = 500000;
        com_limit.setStart (1);
        com_limit.setEnd (number);
        iBnd_master_mo_versionDao.deleteAll ();
        do {
            List<Bnd_master_mo_version> temp = iHtm2pmigDao.findAll (com_limit);

            //数据量太大，分批保存
            if (temp.size () > 1000) {
                List<Bnd_master_mo_version> temp02 = new ArrayList<> ();
                int a = 1;
                for (Bnd_master_mo_version bnd_master_mo_version : temp) {
                    temp02.add (bnd_master_mo_version);
                    if (a == 1000) {
                        iBnd_master_mo_versionDao.saveByList (temp02);
                        temp02.clear ();
                        a = 1;
                    }
                    a++;
                }
                if (temp02.size () > 0) iBnd_master_mo_versionDao.saveByList (temp02);
            } else {
                iBnd_master_mo_versionDao.saveByList (temp);

            }
            if (temp.size () < number) break;
            com_limit.setStart (com_limit.getStart () + number);
        } while (1 == 1);

        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_mo_version");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }

    @RequestMapping("/mig_batch_lot.do")
    public ModelAndView mig_batch_lot() throws Exception {
        // mig Htm2p
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_batch_lot> ces = iXtblpmigDao.findAll ();
        iBnd_master_batch_lotDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 2000) {
            List<Bnd_master_batch_lot> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_batch_lot bnd_master_batch_lot : ces) {
                bnd_master_batch_lot.setDomestic_use_qty(0.0);
                ces02.add (bnd_master_batch_lot);
                if (a == 2000) {
                    iBnd_master_batch_lotDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_batch_lotDao.saveByList (ces02);
        } else {
            iBnd_master_batch_lotDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_batch_lot");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }

    @RequestMapping("/mig_unit_code.do")
    public ModelAndView mig_unit_code() throws Exception {
        // mig H2ucp
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_unit_code> ces = iH2ucpmigDao.findAll ();
        iBnd_master_unit_codeDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 2000) {
            List<Bnd_master_unit_code> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_unit_code bnd_master_unit_code : ces) {
                ces02.add (bnd_master_unit_code);
                if (a == 2000) {
                    iBnd_master_unit_codeDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_unit_codeDao.saveByList (ces02);
        } else {
            iBnd_master_unit_codeDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_unit_code");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }

    @RequestMapping("/mig_hs_code.do")
    public ModelAndView mig_hs_code() throws Exception {
        // mig H2ucp
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_hs_code> ces = iHmctpDao.findAll ();
        iBnd_master_hs_codeDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 2000) {
            List<Bnd_master_hs_code> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_hs_code bnd_master_hs_code : ces) {
                ces02.add (bnd_master_hs_code);
                if (a == 2000) {
                    iBnd_master_hs_codeDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_hs_codeDao.saveByList (ces02);
        } else {
            iBnd_master_hs_codeDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_hs_code");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }

    @RequestMapping("/mig_allocated_component.do")
    public ModelAndView mig_allocated_component() throws Exception {
        // mig Ttadp
        ModelAndView mv = new ModelAndView ();
        Com_limit com_limit = new Com_limit ();
        int number = 500000;
        com_limit.setStart (1);
        com_limit.setEnd (number);
        iBnd_master_allocated_componentDao.deleteAll ();
        do {
            List<Bnd_master_allocated_component> temp = iTtadpDao.findAll (com_limit);

            //数据量太大，分批保存
            if (temp.size () > 1000) {
                List<Bnd_master_allocated_component> temp02 = new ArrayList<> ();
                int a = 1;
                for (Bnd_master_allocated_component bnd_master_allocated_component : temp) {
                    temp02.add (bnd_master_allocated_component);
                    if (a == 1000) {
                        iBnd_master_allocated_componentDao.saveByList (temp02);
                        temp02.clear ();
                        a = 1;
                    }
                    a++;
                }
                if (temp02.size () > 0) iBnd_master_allocated_componentDao.saveByList (temp02);
            } else {
                iBnd_master_allocated_componentDao.saveByList (temp);

            }
            if (temp.size () < number) break;
            com_limit.setStart (com_limit.getStart () + number);
        } while (1 == 1);

        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_allocated_component");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }

    /**
     * @Author Yu Liqin
     * @Description //TODO a801550
     * @Date  2020/12/19
     * @Time  上午 08:50
     **/
    @RequestMapping("/mig_exchange_rate.do")
    public ModelAndView mig_exchange_rate() throws Exception {
        // mig TXNKP
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_exchange_rate> ces = iTxknpDao.findAll ();
        iBnd_master_exchange_rateDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 2000) {
            List<Bnd_master_exchange_rate> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_exchange_rate bnd_master_exchange_rate : ces) {
                ces02.add (bnd_master_exchange_rate);
                if (a == 2000) {
                    iBnd_master_exchange_rateDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_exchange_rateDao.saveByList (ces02);
        } else {
            iBnd_master_exchange_rateDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_currency_code");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }



    /**
     * @Author Yu Liqin
     * @Description //TODO a801550
     * @Date 2020/7/6
     * @Time 下午 03:36
     **/
    @RequestMapping("/mig_currency_code.do")
    public ModelAndView mig_currency_code() throws Exception {
        // mig H2CRP
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_currency_code> ces = iH2crpDao.findAll ();
        iBnd_master_currency_codeDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 2000) {
            List<Bnd_master_currency_code> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_currency_code bnd_master_currency_code : ces) {
                ces02.add (bnd_master_currency_code);
                if (a == 2000) {
                    iBnd_master_currency_codeDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_currency_codeDao.saveByList (ces02);
        } else {
            iBnd_master_currency_codeDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_currency_code");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }


    /**
     * @Author Yu Liqin
     * @Description //TODO a801550
     * @Date 2020/7/7
     * @Time 上午 08:46
     **/
    @RequestMapping("/mig_master_customer.do")
    public ModelAndView mig_master_customer() throws Exception {
        // mig TMCUP
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_customer> ces = iTmcupDao.findAll ();
        iBnd_master_customerDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 1000) {
            List<Bnd_master_customer> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_customer bnd_master_customer : ces) {
                ces02.add (bnd_master_customer);
                if (a == 1000) {
                    iBnd_master_customerDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_customerDao.saveByList (ces02);
        } else {
            iBnd_master_customerDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_customer");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }


    /**
     * @Author Yu Liqin
     * @Description //TODO a801550
     * @Date 2020/7/7
     * @Time 上午 09:17
     **/

    @RequestMapping("/mig_country_code.do")
    public ModelAndView mig_country_code() throws Exception {
        // mig TMCUP
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_country_code> ces = iH2t9pDao.findAll ();
        iBnd_master_country_codeDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 1000) {
            List<Bnd_master_country_code> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_country_code bnd_master_country_code : ces) {
                ces02.add (bnd_master_country_code);
                if (a == 1000) {
                    iBnd_master_country_codeDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_country_codeDao.saveByList (ces02);
        } else {
            iBnd_master_country_codeDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_country_code");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }


    /**
     * @Author Yu Liqin
     * @Description //TODO a801550
     * @Date 2020/7/7
     * @Time 上午 09:43
     **/

    @RequestMapping("/mig_declare_company.do")
    public ModelAndView mig_declare_company() throws Exception {
        // mig H2DDP
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_declare_company> ces = iH2ddpDao.findAll ();
        iBnd_master_declare_companyDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 2000) {
            List<Bnd_master_declare_company> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_declare_company bnd_master_declare_company : ces) {
                ces02.add (bnd_master_declare_company);
                if (a == 2000) {
                    iBnd_master_declare_companyDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_declare_companyDao.saveByList (ces02);
        } else {
            iBnd_master_declare_companyDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_declare_company");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }

    /**
     * @Author Yu Liqin
     * @Description //TODO a801550
     * @Date 2020/7/7
     * @Time 上午 10:16
     **/
    @RequestMapping("/mig_master_customs.do")
    public ModelAndView mig_master_customs() throws Exception {
        // mig HBCUP
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_customs> ces = iHbcupDao.findAll ();
        iBnd_master_customsDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 2000) {
            List<Bnd_master_customs> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_customs bnd_master_customs : ces) {
                ces02.add (bnd_master_customs);
                if (a == 2000) {
                    iBnd_master_customsDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_customsDao.saveByList (ces02);
        } else {
            iBnd_master_customsDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_customs");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }

    /**
     * @Author Yu Liqin
     * @Description //TODO a801550
     * @Date 2020/7/7
     * @Time 上午 10:27
     **/

    @RequestMapping("/mig_trade_transaction.do")
    public ModelAndView mig_trade_transaction() throws Exception {
        // mig HTCTP
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_trade_transaction> ces = iHtctpDao.findAll ();
        iBnd_master_trade_transactionDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 2000) {
            List<Bnd_master_trade_transaction> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_trade_transaction bnd_master_trade_transaction : ces) {
                ces02.add (bnd_master_trade_transaction);
                if (a == 2000) {
                    iBnd_master_trade_transactionDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_trade_transactionDao.saveByList (ces02);
        } else {
            iBnd_master_trade_transactionDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_trade_transaction");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }

    /**
     * @Author Yu Liqin
     * @Description //TODO a801550 迁移H2EDP
     * @Date 2020/6/18
     * @Time 下午 03:08
     **/

    @RequestMapping("/mig_qualification_d.do")
    public ModelAndView  mig_qualification_d() throws Exception {
        // mig h2edp
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_qualification_d> ces = iH2edpDao.findAll ();
        iBnd_master_qualification_dDao.deleteAll ();
        //数据量太大，分批保存

        if (ces.size () > 2000) {
            List<Bnd_master_qualification_d> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_qualification_d bnd_master_qualification_d : ces) {
                ces02.add (bnd_master_qualification_d);
                if (a == 2000) {
                    iBnd_master_qualification_dDao.saveByListAll (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_qualification_dDao.saveByListAll (ces02);
        } else {
            iBnd_master_qualification_dDao.saveByListAll (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_qualification_d");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;

    }


/**
 * @Author Yu Liqin
 * @Description //TODO a801550 迁移H2ETP
 * @Date  2020/6/20
 * @Time  下午 02:13
 **/
   @RequestMapping("/mig_qualification_h.do")
    public ModelAndView mig_qualification_h() throws Exception {
        // mig h2etp
       ModelAndView mv = new ModelAndView ();
        List<Bnd_master_qualification_h> ces = iH2etpDao.findAll ();
        iBnd_master_qualification_hDao.deleteAll ();
        //数据量太大，分批保存

        if (ces.size () > 2000) {
            List<Bnd_master_qualification_h> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_qualification_h bnd_master_qualification_h : ces) {
                ces02.add (bnd_master_qualification_h);
                if (a == 2000) {
                    iBnd_master_qualification_hDao.saveByListAll (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0)  iBnd_master_qualification_hDao.saveByListAll (ces02);
        } else {
            iBnd_master_qualification_hDao.saveByListAll (ces);


        }
       mv.setViewName ("bnd-mig-list");
       Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
       //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
       bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_qualification_h");
       iBnd_mig_listService.update (bnd_mig_list);
       return mv;

    }

    /**
     * @Author Yu Liqin
     * @Description //TODO a801550
     * @Date  2020/7/7
     * @Time  下午 01:23
     **/

    @RequestMapping("/mig_ehandbook_h.do")
    public ModelAndView mig_ehandbook_h() throws Exception {
        // mig H2EHP
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_ehandbook_h> ces = iH2ehpDao.findAll ();
        iBnd_master_ehandbook_hDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 2000) {
            List<Bnd_master_ehandbook_h> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_ehandbook_h bnd_master_ehandbook_h : ces) {
                ces02.add (bnd_master_ehandbook_h);
                if (a == 2000) {
                    iBnd_master_ehandbook_hDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_ehandbook_hDao.saveByList (ces02);
        } else {
            iBnd_master_ehandbook_hDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_ehandbook_h");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }



    @RequestMapping("/mig_ehandbook_d.do")
    public ModelAndView mig_ehandbook_d() throws Exception {
        // mig H2EIP
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_ehandbook_d> ces = iH2eipDao.findAll ();
        iBnd_master_ehandbook_dDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 500) {
            List<Bnd_master_ehandbook_d> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_ehandbook_d bnd_master_ehandbook_d : ces) {
                ces02.add (bnd_master_ehandbook_d);
                if (a == 500) {
                    iBnd_master_ehandbook_dDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_ehandbook_dDao.saveByList (ces02);
        } else {
            iBnd_master_ehandbook_dDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_ehandbook_d");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }


    @RequestMapping("/mig_master_bom.do")
    public ModelAndView mig_master_bom() throws Exception {
        // mig H2BSP
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_bom> ces = iH2BspmigDao.findAll ();
        iBnd_master_bomDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 2000) {
            List<Bnd_master_bom> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_bom bnd_master_bom : ces) {
                ces02.add (bnd_master_bom);
                if (a == 2000) {
                    iBnd_master_bomDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_bomDao.saveByList (ces02);
        } else {
            iBnd_master_bomDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_bom");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }



    @RequestMapping("/mig_maximun_loss.do")
    public ModelAndView mig_maximun_loss() throws Exception {
        // mig HTM6P
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_maximun_loss> ces = iHtm6pDao.findAll ();
        iBnd_master_maximun_lossDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 2000) {
            List<Bnd_master_maximun_loss> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_maximun_loss bnd_master_maximun_loss : ces) {
                ces02.add (bnd_master_maximun_loss);
                if (a == 2000) {
                    iBnd_master_maximun_lossDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_maximun_lossDao.saveByList (ces02);
        } else {
            iBnd_master_maximun_lossDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_maximun_loss");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }



    @RequestMapping("/mig_declare_element.do")
    public ModelAndView mig_declare_element() throws Exception {
        // mig HMCCP
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_declare_element> ces = iHmccpDao.findAll ();
        iBnd_master_declare_elementDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 2000) {
            List<Bnd_master_declare_element> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_declare_element bnd_master_declare_element : ces) {
                ces02.add (bnd_master_declare_element);
                if (a == 2000) {
                    iBnd_master_declare_elementDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_declare_elementDao.saveByList (ces02);
        } else {
            iBnd_master_declare_elementDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_declare_element");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }


    @RequestMapping("/mig_declare_material.do")
    public ModelAndView mig_declare_material() throws Exception {
        // mig HMCDP
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_declare_material> ces = iHmcdpDao.findAll ();
        iBnd_master_declare_materialDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 2000) {
            List<Bnd_master_declare_material> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_declare_material bnd_master_declare_material : ces) {
                ces02.add (bnd_master_declare_material);
                if (a == 2000) {
                    iBnd_master_declare_materialDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_declare_materialDao.saveByList (ces02);
        } else {
            iBnd_master_declare_materialDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_declare_material");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }


    @RequestMapping("/mig_declare_materialz.do")
    public ModelAndView mig_declare_materialz() throws Exception {
        // mig HMCDP
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_declare_materialz> ces = iHmcepDao.findAll ();
        iBnd_master_declare_materialzDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 1000) {
            List<Bnd_master_declare_materialz> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_declare_materialz bnd_master_declare_materialz : ces) {
                ces02.add (bnd_master_declare_materialz);
                if (a == 1000) {
                    iBnd_master_declare_materialzDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_declare_materialzDao.saveByList (ces02);
        } else {
            iBnd_master_declare_materialzDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_declare_materialz");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }

    /**
     * @Author Yu Liqin
     * @Description //TODO a801550
     * @Date  2020/7/8
     * @Time  上午 08:49
     **/
    @RequestMapping("/mig_use_code.do")
    public ModelAndView mig_use_code() throws Exception {
        // mig HBAPP 用途代碼
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_use_code> ces = iHbappDao.findAll ();
        iBnd_master_use_codeDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 1000) {
            List<Bnd_master_use_code> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_use_code bnd_master_use_code : ces) {
                ces02.add (bnd_master_use_code);
                if (a == 1000) {
                    iBnd_master_use_codeDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_use_codeDao.saveByList (ces02);
        } else {
            iBnd_master_use_codeDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_use_code");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }

    /**
     * @Author Yu Liqin
     * @Description //TODO a801550
     * @Date  2020/7/8
     * @Time  上午 09:57
     **/
    @RequestMapping("/mig_remission_type.do")
    public ModelAndView mig_remission_type() throws Exception {
        // mig HBDMP 減免方式
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_remission_type> ces = iHbdmpDao.findAll ();
        iBnd_master_remission_typeDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 1000) {
            List<Bnd_master_remission_type> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_remission_type bnd_master_remission_type : ces) {
                ces02.add (bnd_master_remission_type);
                if (a == 1000) {
                    iBnd_master_remission_typeDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_remission_typeDao.saveByList (ces02);
        } else {
            iBnd_master_remission_typeDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_remission_type");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }


    /**
     * @Author Yu Liqin
     * @Description //TODO a801550
     * @Date  2020/7/8
     * @Time  上午 09:57
     **/
    @RequestMapping("/mig_trans_code.do")
    public ModelAndView mig_trans_code() throws Exception {
        // mig HBTSP	運輸代碼
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_trans_code> ces = iHbtspDao.findAll ();
        iBnd_master_trans_codeDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 1000) {
            List<Bnd_master_trans_code> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_trans_code bnd_master_trans_code : ces) {
                ces02.add (bnd_master_trans_code);
                if (a == 1000) {
                    iBnd_master_trans_codeDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_trans_codeDao.saveByList (ces02);
        } else {
            iBnd_master_trans_codeDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_trans_code");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }

    /**
     * @Author Yu Liqin
     * @Description //TODO a801550
     * @Date  2020/7/21
     * @Time  上午 09:46
     **/
    @RequestMapping("/mig_declare_list.do")
    public ModelAndView mig_declare_list() throws Exception {
        // mig HBTSP	運輸代碼
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_declare_list> ces = iH2depDao.findAll ();
        iBnd_master_declare_listDao.deleteAll ();
        //数据量太大，分批保存
        if (ces.size () > 1000) {
            List<Bnd_master_declare_list> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_declare_list bnd_master_declare_list : ces) {
                ces02.add (bnd_master_declare_list);
                if (a == 1000) {
                    iBnd_master_declare_listDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_declare_listDao.saveByList (ces02);
        } else {
            iBnd_master_declare_listDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_delcare_list");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;
    }


    @RequestMapping("/mig_invt_h.do")
    public ModelAndView mig_invt_h() throws Exception {
        // mig h2lhp <InvtHeadType>
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_invt_h> ces = iH2lhpDao.findAll ();
        iBnd_master_invt_hDao.deleteAll ();
        //数据量太大，分批保存

        if (ces.size () > 1000) {
            List<Bnd_master_invt_h> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_invt_h bnd_master_invt_h : ces) {
                ces02.add (bnd_master_invt_h);
                if (a == 1000) {
                    iBnd_master_invt_hDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_invt_hDao.saveByList (ces02);
        } else {
            iBnd_master_invt_hDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_invt_h");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;

    }


    @RequestMapping("/mig_invt_d.do")
    public ModelAndView mig_invt_d() throws Exception {
        // mig h2ldp <InvtHeadType>
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_invt_d> ces = iH2ldpDao.findAll ();
        iBnd_master_invt_dDao.deleteAll ();
        //数据量太大，分批保存

        if (ces.size () > 500) {
            List<Bnd_master_invt_d> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_invt_d bnd_master_invt_d : ces) {
                ces02.add (bnd_master_invt_d);
                if (a == 500) {
                    iBnd_master_invt_dDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_invt_dDao.saveByList (ces02);
        } else {
            iBnd_master_invt_dDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_carry_invt_d");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;

    }

    @RequestMapping("/mig_nonbond_lot.do")
    public ModelAndView mig_nonbond_lot() throws Exception {
        // mig htm5p <Bnd_master_nonbond_lot>
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_nonbond_lot> ces = iHtm5pDao.findAll ();
        iBnd_master_nonbond_lotDao.deleteAll ();
        //数据量太大，分批保存

        if (ces.size () > 500) {
            List<Bnd_master_nonbond_lot> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_nonbond_lot bnd_master_nonbond_lot : ces) {
                ces02.add (bnd_master_nonbond_lot);
                if (a == 500) {
                    iBnd_master_nonbond_lotDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_nonbond_lotDao.saveByList (ces02);
        } else {
            iBnd_master_nonbond_lotDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_nonbond_lot");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;

    }

    @RequestMapping("/mig_other_invoice.do")
    public ModelAndView mig_other_invoice() throws Exception {
        // mig htm5p <Bnd_master_nonbond_lot>
        ModelAndView mv = new ModelAndView ();
        List<Bnd_export_other_invoice_h> ces = iHtahpDao.findAll ();
        iBnd_export_other_invoice_hDao.deleteAll ();
        //数据量太大，分批保存

        if (ces.size () > 500) {
            List<Bnd_export_other_invoice_h> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_export_other_invoice_h bnd_export_other_invoice_h : ces) {
                ces02.add (bnd_export_other_invoice_h);
                if (a == 500) {
                    iBnd_export_other_invoice_hDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_export_other_invoice_hDao.saveByList (ces02);
        } else {
            iBnd_export_other_invoice_hDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_export_other_invoice_h");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;

    }


    /**
     * @Author Yu Liqin
     * @Description //迁移HTADP
     * @Date  2021/1/19
     * @Time  下午 03:31
     **/

    @RequestMapping("/mig_other_invoice_d.do")
    public ModelAndView mig_other_invoice_d() throws Exception {
        // mig htadp
        ModelAndView mv = new ModelAndView ();
        List<Bnd_export_other_invoice_d> ces = iHtadpDao.findAll ();
        iBnd_export_other_invoice_dDao.deleteAll ();
        //数据量太大，分批保存

        if (ces.size () > 500) {
            List<Bnd_export_other_invoice_d> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_export_other_invoice_d bnd_export_other_invoice_d : ces) {
                ces02.add (bnd_export_other_invoice_d);
                if (a == 500) {
                    iBnd_export_other_invoice_dDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_export_other_invoice_dDao.saveByList (ces02);
        } else {
            iBnd_export_other_invoice_dDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_export_other_invoice_d");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;

    }

    /**
     * @Author Yu Liqin
     * @Description //TODO a801550
     * @Date  2021/1/7
     * @Time  下午 03:38
     **/

    @RequestMapping("/mig_unit_measure_code.do")
    public ModelAndView mig_unit_measure_code() throws Exception {
        // mig txqpp <Bnd_master_unit_measure_code>
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_unit_measure_code> ces = iTxqppDao.findAll ();
        iBnd_master_unit_measure_codeDao.deleteAll ();
        //数据量太大，分批保存

        if (ces.size () > 500) {
            List<Bnd_master_unit_measure_code> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_unit_measure_code bnd_master_unit_measure_code : ces) {
                ces02.add (bnd_master_unit_measure_code);
                if (a == 500) {
                    iBnd_master_unit_measure_codeDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_unit_measure_codeDao.saveByList (ces02);
        } else {
            iBnd_master_unit_measure_codeDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_unit_measure_code");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;

    }

    @RequestMapping("/mig_invoice_freight.do")
    public ModelAndView mig_invoice_freight() throws Exception {
        ModelAndView mv = new ModelAndView ();
        List<Bnd_export_invoice_freight> ces = iHttipDao.findAll ();
        iBnd_export_invoice_freightDao.deleteAll ();
        //数据量太大，分批保存

        if (ces.size () > 500) {
            List<Bnd_export_invoice_freight> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_export_invoice_freight bnd_export_invoice_freight : ces) {
                ces02.add (bnd_export_invoice_freight);
                if (a == 500) {
                    iBnd_export_invoice_freightDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_export_invoice_freightDao.saveByList (ces02);
        } else {
            iBnd_export_invoice_freightDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_export_invoice_freight");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;

    }

    @RequestMapping("/mig_cabinet_type.do")
    public ModelAndView mig_cabinet_type() throws Exception {
        ModelAndView mv = new ModelAndView ();
        List<Bnd_export_cabinet_type> ces = iHtttpDao.findAll ();
        iBnd_export_cabinet_typeDao.deleteAll ();
        //数据量太大，分批保存

        if (ces.size () > 500) {
            List<Bnd_export_cabinet_type> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_export_cabinet_type bnd_export_cabinet_type : ces) {
                ces02.add (bnd_export_cabinet_type);
                if (a == 500) {
                    iBnd_export_cabinet_typeDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_export_cabinet_typeDao.saveByList (ces02);
        } else {
            iBnd_export_cabinet_typeDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_export_cabinet_type");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;

    }

    @RequestMapping("/mig_port_code.do")
    public ModelAndView mig_port_code() throws Exception {
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_port_code> ces = iTxqepDao.findAll ();
        iBnd_master_port_codeDao.deleteAll ();
        //数据量太大，分批保存

        if (ces.size () > 500) {
            List<Bnd_master_port_code> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_port_code bnd_master_port_code : ces) {
                ces02.add (bnd_master_port_code);
                if (a == 500) {
                    iBnd_master_port_codeDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_port_codeDao.saveByList (ces02);
        } else {
            iBnd_master_port_codeDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_port_code");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;

    }

    @RequestMapping("/mig_bom_weed.do")
    public ModelAndView mig_bom_weed() throws Exception {
        ModelAndView mv = new ModelAndView ();
        List<Bnd_master_bom_weed> ces = iHtm3pDao.findAll ();
        iBnd_master_bom_weedDao.deleteAll ();
        //数据量太大，分批保存

        if (ces.size () > 500) {
            List<Bnd_master_bom_weed> ces02 = new ArrayList<> ();
            int a = 1;
            for (Bnd_master_bom_weed bnd_master_bom_weed : ces) {
                ces02.add (bnd_master_bom_weed);
                if (a == 500) {
                    iBnd_master_bom_weedDao.saveByList (ces02);
                    ces02.clear ();
                    a = 1;
                }
                a++;
            }
            if (ces02.size () > 0) iBnd_master_bom_weedDao.saveByList (ces02);
        } else {
            iBnd_master_bom_weedDao.saveByList (ces);


        }
        mv.setViewName ("bnd-mig-list");
        Bnd_mig_list bnd_mig_list = new Bnd_mig_list ();
        //找到这个id对应数据库里的数据，并取出更新数据迁移的时间
        bnd_mig_list = iBnd_mig_listService.findByTableName ("bnd_master_bom_weed");
        iBnd_mig_listService.update (bnd_mig_list);
        return mv;

    }

}



