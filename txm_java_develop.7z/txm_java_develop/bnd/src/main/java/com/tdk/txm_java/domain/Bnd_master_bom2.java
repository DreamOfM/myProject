package com.tdk.txm_java.domain;

public class Bnd_master_bom2 {
    private int id;
    private String ems_no;
    private String endprd_gds_mtno;
    private String mtpck_gds_mtno;
    private Double mtpck_seqno;
    private Double dec_cm;
    private Double dec_dm;

    public Double getMtpck_seqno() {
        return mtpck_seqno;
    }

    public void setMtpck_seqno(Double mtpck_seqno) {
        this.mtpck_seqno = mtpck_seqno;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEms_no() {
        return ems_no;
    }

    public void setEms_no(String ems_no) {
        this.ems_no = ems_no;
    }

    public String getEndprd_gds_mtno() {
        return endprd_gds_mtno;
    }

    public void setEndprd_gds_mtno(String endprd_gds_mtno) {
        this.endprd_gds_mtno = endprd_gds_mtno;
    }


    public String getMtpck_gds_mtno() {
        return mtpck_gds_mtno;
    }

    public void setMtpck_gds_mtno(String mtpck_gds_mtno) {
        this.mtpck_gds_mtno = mtpck_gds_mtno;
    }

    public Double getDec_cm() {
        return dec_cm;
    }

    public void setDec_cm(Double dec_cm) {
        this.dec_cm = dec_cm;
    }

    public Double getDec_dm() {
        return dec_dm;
    }

    public void setDec_dm(Double dec_dm) {
        this.dec_dm = dec_dm;
    }

    @Override
    public String toString() {
        return "Bnd_master_bom2{" +
                "id=" + id +
                ", ems_no='" + ems_no + '\'' +
                ", endprd_gds_mtno='" + endprd_gds_mtno + '\'' +
                ", mtpck_gds_mtno='" + mtpck_gds_mtno + '\'' +
                ", mtpck_seqno='" + mtpck_seqno + '\'' +
                ", dec_cm=" + dec_cm +
                ", dec_dm=" + dec_dm +
                '}';
    }
}
