package com.tdk.txm_java.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tdk.txm_java.domain.*;

import com.tdk.txm_java.service.*;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.lang.reflect.InvocationTargetException;
import java.util.*;


@Controller
@RequestMapping("/bnd_export_invoice_check")
public class Bnd_export_invoice_checkController {
    @Autowired
    private IBnd_export_invoice_dService iBnd_export_invoice_dService;
    @Autowired
    private IBnd_export_invoice_batchService iBnd_export_invoice_batchService;
    @Autowired
    private IBnd_export_invoice_hService iBnd_export_invoice_hService;
    @Autowired
    private IBnd_master_trade_transactionService iBnd_master_trade_transactionService;
    @Autowired
    private IBnd_master_ehandbook_dService iBnd_master_ehandbook_dService;
    @Autowired
    private IBnd_master_mo_versionService iBnd_master_mo_versionService;

    @RequestMapping("/check.do")
    public void check(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception {
        ResultInfo info = new ResultInfo();
        List<Bnd_export_invoice_check> invoice_checks = new ArrayList<Bnd_export_invoice_check>();
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();

        // check body
        int b = 0;   //第几笔记录
        int c = 0;   //total
        String trade_code = "";
        String trade_code0 = "";
        String currency = "";
        String currency0 = "";
        String gnbr_ver = "";
        List<String> gnv_list = new ArrayList<>();
        String num = "";

        while (true) {
            List<String> gnv1_list = new ArrayList<>();
            hashMap.clear();
            for (String name1 : set) {
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                if (c > b && name1.equals("invoice_no")) {
                    hashMap.put(name1, vals[b]);
                }
            }

            Bnd_export_invoice_check bnd_export_invoice_check = new Bnd_export_invoice_check();

            try {
                BeanUtils.populate(bnd_export_invoice_check, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //添加一个判断，如果为空值或者没有输入则不往数据库里插数据
            if (bnd_export_invoice_check.getInvoice_no().equals(null) || bnd_export_invoice_check.getInvoice_no().equals("") || bnd_export_invoice_check.getInvoice_no() == null) {
                bnd_export_invoice_check.setErr_num(0);
                bnd_export_invoice_check.setErr_description("");
                invoice_checks.add(bnd_export_invoice_check);
                b++;
                if (b == c) break;
                continue;
            }

            String invoice_no = bnd_export_invoice_check.getInvoice_no();
            List<Bnd_export_invoice_d> export_invoice_ds = iBnd_export_invoice_dService.findByInvoice_no(invoice_no);
            for (Bnd_export_invoice_d export_invoice_d : export_invoice_ds) {
                Bnd_export_invoice_batch invoice_batch = iBnd_export_invoice_batchService.findByIv_sn_qty(export_invoice_d.getInvoice_no(), export_invoice_d.getPacking_serial());
                if (!invoice_batch.getTransaction_qty().equals(export_invoice_d.getPacking_qty())) {
                    bnd_export_invoice_check.setErr_description("捡料不足");
                    break;
                }
            }
//            检查成交方式&币别
            Bnd_export_invoice_h invoice_h = iBnd_export_invoice_hService.findByInvoice_no(bnd_export_invoice_check.getInvoice_no());
//            Bnd_master_trade_transaction trade_transaction = iBnd_master_trade_transactionService.findByTermsTrade(invoice_h.getTerms_trade());
            trade_code=invoice_h.getTerms_trade();
//            if (trade_transaction == null) {
//                trade_code = "XXX";
//            } else {
//                trade_code = trade_transaction.getCustoms_import_code();
//            }
            currency = invoice_h.getCurrency();
            if (!trade_code0.equals("") && !trade_code0.equals(trade_code)) {
                bnd_export_invoice_check.setErr_description(trade_code0 + "&" + trade_code + "成交方式不一致");
//            } else if (!currency0.equals("") && !currency0.equals(currency)) {
//                bnd_export_invoice_check.setErr_description(currency0 + "&" + currency + "币别不一致");
            } else {
//                检查是否备案
                List<Bnd_export_invoice_batch> invoice_batches = iBnd_export_invoice_batchService.findByInvoice_no(invoice_no);
                for (Bnd_export_invoice_batch invoice_batch1 : invoice_batches) {
                    Bnd_master_ehandbook_d ehandbook_d = iBnd_master_ehandbook_dService.findByItem_no(invoice_batch1.getItem_no());
                    if (ehandbook_d == null) {
                        bnd_export_invoice_check.setErr_num(999);
                        bnd_export_invoice_check.setErr_description("未捡料");
                        break;
                    }
//                    检查版本
                    else {
                        gnbr_ver = ehandbook_d.getImg_no().toString();
                        Bnd_master_mo_version mo_version = iBnd_master_mo_versionService.findByMo_item(invoice_batch1.getLot_no(), invoice_batch1.getItem_no());
                        if (mo_version == null) {
                            bnd_export_invoice_check.setErr_description(invoice_batch1.getLot_no() + "版次0");
                            break;
                        } else if (mo_version.getUcns_verno().equals(0.0) || mo_version.getUcns_verno().equals(0)) {
                            bnd_export_invoice_check.setErr_description(invoice_batch1.getLot_no() + "版次0");
                            break;
                        } else {
                            gnbr_ver = gnbr_ver + mo_version.getUcns_verno().toString();
                            if (!gnv_list.contains(gnbr_ver)) {
                                gnv_list.add(gnbr_ver);
                            }
                            if (!gnv1_list.contains(gnbr_ver)) {
                                gnv1_list.add(gnbr_ver);
                            }
                        }
                        bnd_export_invoice_check.setErr_num(gnv1_list.size());
                    }
                }
                if (gnv_list.size() > 49) {
                    bnd_export_invoice_check.setErr_description("归并项号+海关BOM版次超过49项次");
                }
            }

            trade_code0 = trade_code;
            currency0 = currency;
            invoice_checks.add(bnd_export_invoice_check);
            b++;
            if (b == c) break;
        }

        errorList.add(String.valueOf(gnv_list.size()));
        info.setData(invoice_checks);
        info.setErrorList(errorList);
        //响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(), info);
    }
}
