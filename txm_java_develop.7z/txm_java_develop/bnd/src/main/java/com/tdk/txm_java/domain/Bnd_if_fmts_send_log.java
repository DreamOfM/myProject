package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_if_fmts_send_log {
    private int id;
    private String ixtask;//部門代碼
    private String ixupdt;//更新時間



    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;


}
