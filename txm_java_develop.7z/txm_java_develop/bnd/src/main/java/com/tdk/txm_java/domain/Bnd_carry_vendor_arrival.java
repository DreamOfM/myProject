package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Time;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_develop</h3>
 * @ClassName<h4>结转发单控制</h4>
 * @ToDo<p></p>
 * @date : 2020-05-23 15:07
 * @version:1.0
 **/
@Data
public class Bnd_carry_vendor_arrival {
    private int id;
    private String vendor_no;
    private String invoice_no;
    private String item_no;
    private String  img_no;
    private String country_code;
    private String vendor_ems;
    private String arrival_date;
    private Double po_boarding_qty;
    private String currency;
    private String um_physical_inventory;
    private Double declared_qty;
    private Double declared_amount;
    private Double declared_weight;
    private Double already_declared_qty;
    private Double already_declared_amount;
    private Double already_declared_weight;
    private String expiration_flag;
    private Double sum_dec_qty;//申报数量合计
    private Double sum_dec_amount;//申报金额合计
    private Double sum_dec_weight;//申报重量合计
    private Double complete_declared_qty;//已转数量
    private Double complete_declared_amount;//已转金额
    private Double complete_declared_weight;//已转重量
    private String fistday;//当月第一天
    private String lastday;//当月最后一天

    private Time login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;

    private String vendor_name_abbr_dbcs;
    private String mrpcode;
    private String item_description_dbcs;
    private String yyyymm;

}
