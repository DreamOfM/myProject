package com.tdk.txm_java.domain;

public class Bnd_master_hs_code {
    private int id;
    private String ccc_code;
    private String data_state;
    private String lawf_unitcd;
    private String secd_lawf_unitcd;
    private String other_regulatory_conditions;
    private Double tax_rate;
    private String regulatory_credentials1;
    private String regulatory_credentials2;
    private String regulatory_credentials3;
    private String regulatory_credentials4;
    private String regulatory_credentials5;
    private String regulatory_credentials6;
    private String regulatory_credentials7;
    private String regulatory_credentials8;
    private String regulatory_credentials9;
    private String regulatory_credentials10;
    private String inspection_quarantine1;
    private String inspection_quarantine2;
    private String inspection_quarantine3;
    private String inspection_quarantine4;
    private String inspection_quarantine5;
    private String inspection_quarantine6;
    private String inspection_quarantine7;
    private String inspection_quarantine8;
    private String inspection_quarantine9;
    private String inspection_quarantine10;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;
    private String lawf_unitcd1;
    private String secd_lawf_unitcd1;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCcc_code() {
        return ccc_code;
    }

    public void setCcc_code(String ccc_code) {
        this.ccc_code = ccc_code;
    }

    public String getData_state() {
        return data_state;
    }

    public void setData_state(String data_state) {
        this.data_state = data_state;
    }

    public String getLawf_unitcd() {
        return lawf_unitcd;
    }

    public void setLawf_unitcd(String lawf_unitcd) {
        this.lawf_unitcd = lawf_unitcd;
    }

    public String getSecd_lawf_unitcd() {
        return secd_lawf_unitcd;
    }

    public void setSecd_lawf_unitcd(String secd_lawf_unitcd) {
        this.secd_lawf_unitcd = secd_lawf_unitcd;
    }

    public String getOther_regulatory_conditions() {
        return other_regulatory_conditions;
    }

    public void setOther_regulatory_conditions(String other_regulatory_conditions) {
        this.other_regulatory_conditions = other_regulatory_conditions;
    }

    public Double getTax_rate() {
        return tax_rate;
    }

    public void setTax_rate(Double tax_rate) {
        this.tax_rate = tax_rate;
    }

    public String getRegulatory_credentials1() {
        return regulatory_credentials1;
    }

    public void setRegulatory_credentials1(String regulatory_credentials1) {
        this.regulatory_credentials1 = regulatory_credentials1;
    }

    public String getRegulatory_credentials2() {
        return regulatory_credentials2;
    }

    public void setRegulatory_credentials2(String regulatory_credentials2) {
        this.regulatory_credentials2 = regulatory_credentials2;
    }

    public String getRegulatory_credentials3() {
        return regulatory_credentials3;
    }

    public void setRegulatory_credentials3(String regulatory_credentials3) {
        this.regulatory_credentials3 = regulatory_credentials3;
    }

    public String getRegulatory_credentials4() {
        return regulatory_credentials4;
    }

    public void setRegulatory_credentials4(String regulatory_credentials4) {
        this.regulatory_credentials4 = regulatory_credentials4;
    }

    public String getRegulatory_credentials5() {
        return regulatory_credentials5;
    }

    public void setRegulatory_credentials5(String regulatory_credentials5) {
        this.regulatory_credentials5 = regulatory_credentials5;
    }

    public String getRegulatory_credentials6() {
        return regulatory_credentials6;
    }

    public void setRegulatory_credentials6(String regulatory_credentials6) {
        this.regulatory_credentials6 = regulatory_credentials6;
    }

    public String getRegulatory_credentials7() {
        return regulatory_credentials7;
    }

    public void setRegulatory_credentials7(String regulatory_credentials7) {
        this.regulatory_credentials7 = regulatory_credentials7;
    }

    public String getRegulatory_credentials8() {
        return regulatory_credentials8;
    }

    public void setRegulatory_credentials8(String regulatory_credentials8) {
        this.regulatory_credentials8 = regulatory_credentials8;
    }

    public String getRegulatory_credentials9() {
        return regulatory_credentials9;
    }

    public void setRegulatory_credentials9(String regulatory_credentials9) {
        this.regulatory_credentials9 = regulatory_credentials9;
    }

    public String getRegulatory_credentials10() {
        return regulatory_credentials10;
    }

    public void setRegulatory_credentials10(String regulatory_credentials10) {
        this.regulatory_credentials10 = regulatory_credentials10;
    }

    public String getInspection_quarantine1() {
        return inspection_quarantine1;
    }

    public void setInspection_quarantine1(String inspection_quarantine1) {
        this.inspection_quarantine1 = inspection_quarantine1;
    }

    public String getInspection_quarantine2() {
        return inspection_quarantine2;
    }

    public void setInspection_quarantine2(String inspection_quarantine2) {
        this.inspection_quarantine2 = inspection_quarantine2;
    }

    public String getInspection_quarantine3() {
        return inspection_quarantine3;
    }

    public void setInspection_quarantine3(String inspection_quarantine3) {
        this.inspection_quarantine3 = inspection_quarantine3;
    }

    public String getInspection_quarantine4() {
        return inspection_quarantine4;
    }

    public void setInspection_quarantine4(String inspection_quarantine4) {
        this.inspection_quarantine4 = inspection_quarantine4;
    }

    public String getInspection_quarantine5() {
        return inspection_quarantine5;
    }

    public void setInspection_quarantine5(String inspection_quarantine5) {
        this.inspection_quarantine5 = inspection_quarantine5;
    }

    public String getInspection_quarantine6() {
        return inspection_quarantine6;
    }

    public void setInspection_quarantine6(String inspection_quarantine6) {
        this.inspection_quarantine6 = inspection_quarantine6;
    }

    public String getInspection_quarantine7() {
        return inspection_quarantine7;
    }

    public void setInspection_quarantine7(String inspection_quarantine7) {
        this.inspection_quarantine7 = inspection_quarantine7;
    }

    public String getInspection_quarantine8() {
        return inspection_quarantine8;
    }

    public void setInspection_quarantine8(String inspection_quarantine8) {
        this.inspection_quarantine8 = inspection_quarantine8;
    }

    public String getInspection_quarantine9() {
        return inspection_quarantine9;
    }

    public void setInspection_quarantine9(String inspection_quarantine9) {
        this.inspection_quarantine9 = inspection_quarantine9;
    }

    public String getInspection_quarantine10() {
        return inspection_quarantine10;
    }

    public void setInspection_quarantine10(String inspection_quarantine10) {
        this.inspection_quarantine10 = inspection_quarantine10;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    public String getLawf_unitcd1() {
        return lawf_unitcd1;
    }

    public void setLawf_unitcd1(String lawf_unitcd1) {
        this.lawf_unitcd1 = lawf_unitcd1;
    }

    public String getSecd_lawf_unitcd1() {
        return secd_lawf_unitcd1;
    }

    public void setSecd_lawf_unitcd1(String secd_lawf_unitcd1) {
        this.secd_lawf_unitcd1 = secd_lawf_unitcd1;
    }

    @Override
    public String toString() {
        return "Bnd_master_hs_code{" +
                "id=" + id +
                ", ccc_code='" + ccc_code + '\'' +
                ", data_state='" + data_state + '\'' +
                ", lawf_unitcd='" + lawf_unitcd + '\'' +
                ", secd_lawf_unitcd='" + secd_lawf_unitcd + '\'' +
                ", other_regulatory_conditions='" + other_regulatory_conditions + '\'' +
                ", tax_rate=" + tax_rate +
                ", regulatory_credentials1='" + regulatory_credentials1 + '\'' +
                ", regulatory_credentials2='" + regulatory_credentials2 + '\'' +
                ", regulatory_credentials3='" + regulatory_credentials3 + '\'' +
                ", regulatory_credentials4='" + regulatory_credentials4 + '\'' +
                ", regulatory_credentials5='" + regulatory_credentials5 + '\'' +
                ", regulatory_credentials6='" + regulatory_credentials6 + '\'' +
                ", regulatory_credentials7='" + regulatory_credentials7 + '\'' +
                ", regulatory_credentials8='" + regulatory_credentials8 + '\'' +
                ", regulatory_credentials9='" + regulatory_credentials9 + '\'' +
                ", regulatory_credentials10='" + regulatory_credentials10 + '\'' +
                ", inspection_quarantine1='" + inspection_quarantine1 + '\'' +
                ", inspection_quarantine2='" + inspection_quarantine2 + '\'' +
                ", inspection_quarantine3='" + inspection_quarantine3 + '\'' +
                ", inspection_quarantine4='" + inspection_quarantine4 + '\'' +
                ", inspection_quarantine5='" + inspection_quarantine5 + '\'' +
                ", inspection_quarantine6='" + inspection_quarantine6 + '\'' +
                ", inspection_quarantine7='" + inspection_quarantine7 + '\'' +
                ", inspection_quarantine8='" + inspection_quarantine8 + '\'' +
                ", inspection_quarantine9='" + inspection_quarantine9 + '\'' +
                ", inspection_quarantine10='" + inspection_quarantine10 + '\'' +
                ", login_time='" + login_time + '\'' +
                ", login_oid='" + login_oid + '\'' +
                ", update_time='" + update_time + '\'' +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                ", lawf_unitcd1='" + lawf_unitcd1 + '\'' +
                ", secd_lawf_unitcd1='" + secd_lawf_unitcd1 + '\'' +
                '}';
    }
}
