package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Date;
import java.sql.Time;

@Data
public class Bnd_if_fsap_purchase_price {
    private int id;
    private String bpvdnr;//供货商代码
    private String bpitnr;//品名代码
    private String bpvinr;//BPVINR
    private String bptrmc;//贸易条件
    private String bppoum;//购买单位
    private String bppocf;//购买单位换算系数
    private String bpcurr;//币别
    private Date bpstdt;//生效日
    private Date bpltdt;//失效日
    private Double bpppr1;//購買價格區間１
    private String bpstat;//状态
    private Time login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;





}
