package com.tdk.txm_java.domain;

import lombok.Data;

import java.util.Date;


@Data
public class Bnd_subcon_material_sum {
    private  int id;
    private String operation_no;//製品流水號
    private String operation_no1;//材料流水號
    private String vendor_code;//協力廠代碼
    private String psa_code;//Y3WPSA
    private String operation_type;//委外類型
    private String mrp_code;//ＭＲＰ基準代碼
    private String material_no;//品名代碼
    private String ccc_code;//商編
    private String material_type;//外撥材料類型
    private Double operation_sequence_no;//仕掛站別
    private Double img_no;//項號
    private String item_class_code;//品名分類代碼
    private String item_description_dbcs;//中文品名
    private Double material_quantity;//委外數量
    private Double material_quantity_after;//修改委外數量
    private String um_incoming_outgoing;//在庫單位
    private Double physical_quantity ;//監管數量
    private Double physical_quantity_after ;//修改監管數量
    private String um_physical_inventory;//監管單位
    private String itemized_application_code;//品名應用代碼
    private Double standard_cost;//單價
    private Double operation_amount;//申請金額

    private String apply_date;//申請日期
    private String date_from;//開始日期
    private String date_to;//結束日期



    private Date login_time;
    private String login_oid;
    private Date update_time;
    private String update_oid;
    private String update_program;

}
