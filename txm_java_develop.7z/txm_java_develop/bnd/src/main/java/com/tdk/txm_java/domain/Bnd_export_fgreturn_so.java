package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Date;

@Data
public class Bnd_export_fgreturn_so {
    private int id;
    private String so_no ;//SO订单
    private String return_so;//退货SO
    private String original_invoice;//退货原发票
    private String original_shpd_date;//original_shpd_date
    private String customer_no;//顾客代码
    private String invoice_type;//發票型態
    private String statement_customer_no;//負責付款之顧客
    private String tax_code2;//税率别代码２
    private Integer return_date;//计划退货日期
    private String item_no;//品名代码
    private Double so_qty;//退货数量
    private Double price0;//价格
    private String currency;//币别
    private String return_reason;//退货原因
    private String delete_flag;//删除标识
    private String bond_flag;//保稅標誌
    private String material_document;//入庫憑證
    private String actual_return_date;//actual_return_date
    private Double actual_return_qty;//actual_return_qty
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;


}
