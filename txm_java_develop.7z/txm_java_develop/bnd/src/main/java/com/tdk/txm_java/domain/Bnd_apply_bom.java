package com.tdk.txm_java.domain;

import lombok.Data;

import java.util.Date;


public class Bnd_apply_bom {
    private int id;
    private Double gds_seqno;
    private Double endprd_seqno;
    private String endprd_gds_mtno;
    private Double mtpck_seqno;
    private String mtpck_gds_mtno;
    private Double ucns_verno;
    private Double dec_cm;
    private Double dec_dm;
    private Double intgb_loss_rate;
    private Double bond_mtpck_prpr;
    private String rmk;
    private String bom_versions;
    private String exe_markcd;
    private String expiration_date;
    private String modf_markcd;
    private String bizop_etpsno;
    private String etps_preent_no;
    private String item_type;
    private String opers_status;
    private String file_no;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Double getGds_seqno() {
        return gds_seqno;
    }

    public void setGds_seqno(Double gds_seqno) {
        this.gds_seqno = gds_seqno;
    }

    public Double getEndprd_seqno() {
        return endprd_seqno;
    }

    public void setEndprd_seqno(Double endprd_seqno) {
        this.endprd_seqno = endprd_seqno;
    }

    public String getEndprd_gds_mtno() {
        return endprd_gds_mtno;
    }

    public void setEndprd_gds_mtno(String endprd_gds_mtno) {
        this.endprd_gds_mtno = endprd_gds_mtno;
    }

    public Double getMtpck_seqno() {
        return mtpck_seqno;
    }

    public void setMtpck_seqno(Double mtpck_seqno) {
        this.mtpck_seqno = mtpck_seqno;
    }

    public String getMtpck_gds_mtno() {
        return mtpck_gds_mtno;
    }

    public void setMtpck_gds_mtno(String mtpck_gds_mtno) {
        this.mtpck_gds_mtno = mtpck_gds_mtno;
    }

    public Double getUcns_verno() {
        return ucns_verno;
    }

    public void setUcns_verno(Double ucns_verno) {
        this.ucns_verno = ucns_verno;
    }

    public Double getDec_cm() {
        return dec_cm;
    }

    public void setDec_cm(Double dec_cm) {
        this.dec_cm = dec_cm;
    }

    public Double getDec_dm() {
        return dec_dm;
    }

    public void setDec_dm(Double dec_dm) {
        this.dec_dm = dec_dm;
    }

    public Double getIntgb_loss_rate() {
        return intgb_loss_rate;
    }

    public void setIntgb_loss_rate(Double intgb_loss_rate) {
        this.intgb_loss_rate = intgb_loss_rate;
    }

    public Double getBond_mtpck_prpr() {
        return bond_mtpck_prpr;
    }

    public void setBond_mtpck_prpr(Double bond_mtpck_prpr) {
        this.bond_mtpck_prpr = bond_mtpck_prpr;
    }

    public String getRmk() {
        return rmk;
    }

    public void setRmk(String rmk) {
        this.rmk = rmk;
    }

    public String getBom_versions() {
        return bom_versions;
    }

    public void setBom_versions(String bom_versions) {
        this.bom_versions = bom_versions;
    }

    public String getExe_markcd() {
        return exe_markcd;
    }

    public void setExe_markcd(String exe_markcd) {
        this.exe_markcd = exe_markcd;
    }

    public String getExpiration_date() {
        return expiration_date;
    }

    public void setExpiration_date(String expiration_date) {
        this.expiration_date = expiration_date;
    }

    public String getModf_markcd() {
        return modf_markcd;
    }

    public void setModf_markcd(String modf_markcd) {
        this.modf_markcd = modf_markcd;
    }

    public String getBizop_etpsno() {
        return bizop_etpsno;
    }

    public void setBizop_etpsno(String bizop_etpsno) {
        this.bizop_etpsno = bizop_etpsno;
    }

    public String getEtps_preent_no() {
        return etps_preent_no;
    }

    public void setEtps_preent_no(String etps_preent_no) {
        this.etps_preent_no = etps_preent_no;
    }

    public String getItem_type() {
        return item_type;
    }

    public void setItem_type(String item_type) {
        this.item_type = item_type;
    }

    public String getOpers_status() {
        return opers_status;
    }

    public void setOpers_status(String opers_status) {
        this.opers_status = opers_status;
    }

    public String getFile_no() {
        return file_no;
    }

    public void setFile_no(String file_no) {
        this.file_no = file_no;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    @Override
    public String toString() {
        return "Bnd_apply_bom{" +
                "id=" + id +
                ", gds_seqno=" + gds_seqno +
                ", endprd_seqno=" + endprd_seqno +
                ", endprd_gds_mtno='" + endprd_gds_mtno + '\'' +
                ", mtpck_seqno=" + mtpck_seqno +
                ", mtpck_gds_mtno='" + mtpck_gds_mtno + '\'' +
                ", ucns_verno=" + ucns_verno +
                ", dec_cm=" + dec_cm +
                ", dec_dm=" + dec_dm +
                ", intgb_loss_rate=" + intgb_loss_rate +
                ", bond_mtpck_prpr=" + bond_mtpck_prpr +
                ", rmk='" + rmk + '\'' +
                ", bom_versions='" + bom_versions + '\'' +
                ", exe_markcd='" + exe_markcd + '\'' +
                ", expiration_date='" + expiration_date + '\'' +
                ", modf_markcd='" + modf_markcd + '\'' +
                ", bizop_etpsno='" + bizop_etpsno + '\'' +
                ", etps_preent_no='" + etps_preent_no + '\'' +
                ", item_type='" + item_type + '\'' +
                ", opers_status='" + opers_status + '\'' +
                ", file_no='" + file_no + '\'' +
                ", login_time='" + login_time + '\'' +
                ", login_oid='" + login_oid + '\'' +
                ", update_time='" + update_time + '\'' +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                '}';
    }
}
