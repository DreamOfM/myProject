package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_if_fsap_psa_mrp {
    private int id;
    private String psa_mrp;//
    private String state;//

    private String login_time;
    private String login_oid;//登陆操作员代码
    private String update_time;
    private String update_oid;
    private String update_program;

}
