package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Time;

@Data

public class Bnd_export_delivery_note_controller {
    private int id;
    private String sold_to;//sold to
    private String ship_to;//ship to
    private String type;//类型
    private String type_nm;//类型描述
    private String sold_to_name;//sold to name
    private String ship_to_name;//ship to name
    private String delivery_note_name;//发货单名称
    private String flag;//使用标志
    private String remark;//备注
    private Time login_time;//登陆时间login_time
    private String login_oid;//登陆人员login_oid
    private Time update_time;//更新时间update_time
    private String update_oid;//更新人员update_oid
    private String update_program;//更新程序update_program


}
