package com.tdk.txm_java.domain;

import lombok.Data;

import java.util.Date;


@Data
public class Bnd_if_subcon_material_sap {
    private  int id;
    private String apply_no;//申請表編號
    private String vendor_code;//供應商代碼
    private String operation_type;//委外類型
    private Double operation_amount;//備案金額
    private Double output_amount;//撥出金額
    private Double available_amount;//可用金額
    private String date_from;//有效日期
    private String date_to;//失效日期
    private Double data_state;//0-SEND 1-COMPLETED
    private String flag;//A-ADD  U-UPDATE
    private Double update_date;//UPDATE TEIME


    private Date login_time;
    private String login_oid;
    private Date update_time;
    private String update_oid;
    private String update_program;

}
