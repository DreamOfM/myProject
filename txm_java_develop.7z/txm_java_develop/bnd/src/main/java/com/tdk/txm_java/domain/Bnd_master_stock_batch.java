package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_master_stock_batch {
    private int id;
    private String mrpcode;//mrp
    private String item_no;//品名代码
    private String storage_type;//storagetype
    private String lot_no;//批號
    private String bond_flag;//保税标识
    private String on_hand_qty;//在库数量
    private String um_incoming_outgoing;//计量单位（入出库）
    private String stock_location;//料架
    private Double price0;//价格
    private Double price_number;//价格数量
    private String category;//库存类型

    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

}
