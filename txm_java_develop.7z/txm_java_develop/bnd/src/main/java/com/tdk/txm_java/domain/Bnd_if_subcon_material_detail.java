package com.tdk.txm_java.domain;

import lombok.Data;

import java.util.Date;


@Data
public class Bnd_if_subcon_material_detail {
    private  int id;
    private String apply_no;//申請表編號
    private String vendor_code;//供應商
    private String operation_type;//委外類型
    private String psa_code;//PSA
    private String material_no;//品名代碼
    private Double operation_sequence_no;//工序
    private Double standard_cost;//委外單價
    private String currency;//CURRENCY
    private String um_incoming_outgoing;//在庫單位
    private String date_from;//有效日期
    private String date_to;//失效日期
    private Double data_state;//0-SEND 1-COMPLETED
    private String flag;//A-ADD  U-UPDATE
    private String mark;//加工運回標誌
    private Double update_date;//UPDATE TEIME


    private Date login_time;
    private String login_oid;
    private Date update_time;
    private String update_oid;
    private String update_program;

}
