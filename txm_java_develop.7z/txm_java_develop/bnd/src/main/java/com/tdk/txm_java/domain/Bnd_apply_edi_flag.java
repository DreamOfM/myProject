package com.tdk.txm_java.domain;

import java.sql.Time;

public class Bnd_apply_edi_flag {
    int id;
    private String qualification_flag;
    private String ehandbook_flag;
    private String declare_flag;
    private Time login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;

    public String getQualification_flag() {
        return qualification_flag;
    }

    public void setQualification_flag(String qualification_flag) {
        this.qualification_flag = qualification_flag;
    }

    public String getEhandbook_flag() {
        return ehandbook_flag;
    }

    public void setEhandbook_flag(String ehandbook_flag) {
        this.ehandbook_flag = ehandbook_flag;
    }

    public String getDeclare_flag() {
        return declare_flag;
    }

    public void setDeclare_flag(String declare_flag) {
        this.declare_flag = declare_flag;
    }

    public Time getLogin_time() {
        return login_time;
    }

    public void setLogin_time(Time login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public Time getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(Time update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Bnd_apply_edi_flag{" +
                "id=" + id +
                ", qualification_flag='" + qualification_flag + '\'' +
                ", ehandbook_flag='" + ehandbook_flag + '\'' +
                ", declare_flag='" + declare_flag + '\'' +
                ", login_time=" + login_time +
                ", login_oid='" + login_oid + '\'' +
                ", update_time=" + update_time +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                '}';
    }
}
