package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Time;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_dev0604</h3>
 * @ClassName<h4></h4>
 * @ToDo<p>核注清单申报</p>
 * @date : 2020-07-14 15:14
 * @version:1.0
 **/
@Data
public class Bnd_apply_invt_h {
    private int id;
    private String internal_number;//企業內部清單編號
    private String ems_no;//備案編號
    private String part_sign_code;//料件成品標記代碼
    private String import_export_mark_code;//進出口標記代碼
    private String supervision_mode_code ;//監管方式代碼
    private String transport_code;//運輸方式代碼
    private String import_export_gate;//進出境關別
    private String master_cuscd                            ;//主管海關
    private String origin_destination_country;//起運/運抵國(地區）
    private String declaration_flag;//是否報關標志
    private String customs_declaration_type_code;//報關類型代碼
    private String apcret_no                               ;//申請表編號
    private String mis_bill_id;//內部單據編號
    private String mis_factory_code;//工廠代碼
    private String bill_to;//提運單號
    private String declare_port;//申報地關區代碼
    private String trade_country;//貿易國
    private String invoice_no;//發票號碼
    private String rmk                                     ;//備注
    private String bizop_etpsno                            ;//company_code
    private String corresponding_customs_unit_code;//對應報關單單位編號
    private String correntry_dcletps_nm                      ;//對應報關單單位名稱
    private String correntry_dcletps_ccd                    ;//對應報關單信用代碼
    private String related_customs_declaration_no ;//關聯報關單編號
    private String associated_list_no ;//關聯清單編號
    private String related_record_no ;//關聯備案編號
    private String customs_declaration_type;//報關單類型
    private String list_type;//清單類型
    private String circulation_type;//流轉類型
    private String dict_type;//歸併類型
    private String oper_status;
    private String file;//FILE
    private Time login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;

}
