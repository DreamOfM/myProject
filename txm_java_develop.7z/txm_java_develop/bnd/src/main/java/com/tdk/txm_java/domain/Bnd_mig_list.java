package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_mig_list {
    private  int id;
    private  String table_type;
    private  String table_name;
    private  String  as_table_name;
    private  String mig_function;
    private  String table_desc;
    private  String latest_mig_time;
    private  int mig_no;
    private  int run_time;
    private  String table_pic;
}
