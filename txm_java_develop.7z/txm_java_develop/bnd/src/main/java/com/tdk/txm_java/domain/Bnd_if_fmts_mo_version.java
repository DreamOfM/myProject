package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_if_fmts_mo_version {
    private int id;
    private String bvcoce;//CO_CODE
    private String bvbach;//BATCH_NO
    private String bvitnr;//PROD_PN
    private Double bvexgv;//BOM_VER.
    private String bvcrtd;//CRE_DATE
    private String bvmold;//MOLD
    private String bvquag;//QUALITY GRADE
    private String bvcunr;//CUSTOMER CODE
    private String bvstat;//0-SEND 1-COMPLETED
    private String bvupdt;//UPDATE TIME





    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;


}
