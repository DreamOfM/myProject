package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_master_allocated_component {
    private int id;
    private String mfg_order_request_no;//制造订单
    private Double operation_sequence_no;
    private String component_item_no;
    private Double component_revision_no;
    private String stock_location;
    private String lot_no;
    private String component_item_type;
    private String reason_code;
    private String bonded_logo;
    private String alternative_item_no;
    private Double alternative_revision_no;
    private String mrpcode;
    private String warehouse_code;
    private String dept;
    private String plant_code;
    private String equipment_name;
    private String account_code;
    private String vendor_no;
    private Double issue_price;
    private String plan_issue_date;
    private String actual_issue_date;
    private Double require_qty;
    private Double plan_issue_qty;
    private Double allocated_qty;
    private Double actual_issue_qty;
    private Double consumption;
    private Double return_component_qty_work;
    private String allocate_status;
    private String issue_finish_flag;
    private Double picking_batch_no;
    private String request_no;
    private String slip_no;
    private Double component_sequence_no;
    private String safety_standard_flag;
    private String transaction_code;
    private String expiry_flag;
    private String in_out_stock_flag;
    private Double yield;
    private String lot_no_code;
    private String component_item_applicode;
    private Double component_qtyparent_qty;
    private Double componentparent_itemc;
    private String consistent_lot_no;
    private Double product_loss_quantity;
    private Double loss_quantity;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;


}
