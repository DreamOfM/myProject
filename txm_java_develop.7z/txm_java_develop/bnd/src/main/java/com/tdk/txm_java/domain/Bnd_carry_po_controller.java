package com.tdk.txm_java.domain;

import lombok.Data;

import java.util.Date;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_develop</h3>
 * @ClassName<h4>结转发单控制</h4>
 * @ToDo<p></p>
 * @date : 2020-05-23 15:07
 * @version:1.0
 **/
@Data
public class Bnd_carry_po_controller {
    private  int id;
    private  String data_state;
    private  String item_no;
    private  String item_spec;
    //监管单位
    private  String um_physical_inventory;
    private  String img_no;
    private  String  vendor_no;
    private  String item_description_dbcs;
    private Date login_time;
    private String login_oid;
    private Date update_time;
    private String update_oid;
    private String update_program;

}
