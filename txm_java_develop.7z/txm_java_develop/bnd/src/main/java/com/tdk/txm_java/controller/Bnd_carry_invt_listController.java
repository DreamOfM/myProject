package com.tdk.txm_java.controller;

import com.tdk.txm_java.domain.*;
import com.tdk.txm_java.service.*;
import com.tdk.txm_java.utils.JsonUtil;
import com.tdk.txm_java.utils.DateUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.*;

/**
 * @Author Wang FengCai
 * @Description 在途清單生成
 * @Date 2020/5/28
 * @Time 下午 05:57
 **/
@Controller
@SessionAttributes
@RequestMapping("/bnd_carry_invt_list")
@ResponseBody
public class Bnd_carry_invt_listController {
    @Autowired
    IBnd_carry_invt_listService iBndCarryInvtListService;
    @Autowired
    IBnd_carry_vendor_detailedService iBndCarryVendorDetailedService;
    @Autowired
    IBnd_carry_vendor_arrivalService iBndCarryVendorArrivalService;
    @Autowired
    IBnd_master_vendorService iBndMasterVendorService;
    @Autowired
    IBnd_carry_vendor_lockService iBndCarryVendorLockService;
    @Autowired
    ICom_serialnumService iComSerialnumService;
    @Autowired
    IBnd_carry_vendorEms_msterService iBndCarryVendorEmsMsterService;


    @RequestMapping("/checkVendorNo")
    @ResponseBody
    public void checkVendorNo(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws IOException {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        String username = String.valueOf(session.getAttribute("username"));
        String vendor_no = request.getParameter("vendor_no");
        String ems_no = request.getParameter("ems_no");
        String dateFrom = request.getParameter("dateFrom");
        String dateTo = request.getParameter("dateTo");
        //去供应商主档判断是否是结转供应商
        Bnd_master_vendor bndMasterVendor = iBndMasterVendorService.findByVendorNo(vendor_no);
        Bnd_carry_vendorEms_master bndCarryVendorEmsMaster = new Bnd_carry_vendorEms_master();
        if (bndMasterVendor != null) {
            //不是结转供应商
            if (!"3502".equals(bndMasterVendor.getCustom_approved_no().trim())) {
                //非结转供应商号码
                info.setFlag(false);
                info.setErrorMsg("非结转供应商号码，请确认");
                errorList.add("vendor_no");
            } else {
                //判断该供应商号码是否被锁住
                try {
                    Bnd_carry_vendor_lock bndCarryVendorLock = iBndCarryVendorLockService.findByVendorNo(vendor_no);
                    if (bndCarryVendorLock != null) {
                        //判断是否是同一个账号锁定
                        if (!username.equals(bndCarryVendorLock.getLogin_oid())) {
                            //提示用户该供应商代码已被锁定
                            info.setFlag(false);
                            errorList.add("vendor_no");
                            info.setErrorMsg("该供应商代码被锁定，请确认");
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } else {
            info.setFlag(false);
            info.setErrorMsg("供应商号码不存在，请确认");
            errorList.add("vendor_no");
        }

        //判断日期是否为空
        if(dateFrom==null||"".equals(dateFrom)||"".equals(dateTo)||dateTo==null){
            info.setFlag(false);
            info.setErrorMsg("日期期间必须输入，请确认");
            errorList.add("dateFrom");
            errorList.add("dateTo");
        }else{
            //判断供应商手册号是否为空？
            if(ems_no==null||"".equals(ems_no)){
                //根据供应商代码在HMZBP(bnd_carry_vendor_ems_master)结转供应商账册维护档 中找到日期符合日期期间的手册账号（ZBSTDT<=W#DATF<=ZBLTDT）
                bndCarryVendorEmsMaster = iBndCarryVendorEmsMsterService.findByVendorNoAndDate(vendor_no,dateFrom,dateTo);
                if(bndCarryVendorEmsMaster!=null&&!"".equals(bndCarryVendorEmsMaster)){
                    info.setData(bndCarryVendorEmsMaster);
                }
            }
        }
        info.setErrorList(errorList);
        info.setData(bndCarryVendorEmsMaster);
        //响应数据
        JsonUtil.writeValue(info,response);
    }


    /**
     * @Author Wang FengCai
     * @Description 根据供应商代码查询
     * @Date 2020/6/5
     * @Time 下午 01:31
     **/
    @RequestMapping("/findByVendorNoAndEmsNoAndDate")
    @ResponseBody
    public ModelAndView findByVendorNoAndEmsNoAndDate(HttpServletRequest request, HttpSession session) throws Exception {
        //获取程序开始的时间
        long start=System.currentTimeMillis();
        //取出前端传回的值
        String vendorNo = request.getParameter("vendor_no");
        String vendorEms = request.getParameter("vendor_ems");
        String dateFrom = request.getParameter("dateFrom");
        String dateTo = request.getParameter("dateTo");
        String username = String.valueOf(session.getAttribute("username"));
        //创建视图对象
        ModelAndView modelAndView = new ModelAndView();
        //调用业务层方法查询
        List<Bnd_carry_vendor_arrival> bndCarryVendorArrivals = iBndCarryVendorArrivalService.findByVendorNoAndEmsNoAndDate(vendorNo, vendorEms, dateFrom, dateTo);
        modelAndView.addObject("bndCarryInvtLists", bndCarryVendorArrivals);
        modelAndView.setViewName("bnd-carry-invt-list");
        //获取结束时间
        long end=System.currentTimeMillis();
        System.out.println("程序运行时间： "+(end-start)+"ms");
        return modelAndView;
    }

    /**
     * @Author Wang FengCai
     * @Description 根据id删除
     * @Date 2020/6/8
     * @Time 下午 01:48
     **/
    @RequestMapping("/delete")
    public String delete(int[] ids, String vendor_no, String ems_no, Date dateFrom, Date dateTo, RedirectAttributes attr) throws Exception {
        if (ids != null && ids.length > 0) {
            //遍历数组
            for (int id : ids) {
                //单条删除
                iBndCarryVendorArrivalService.delete(id);
            }
        }
        //传递条件
        attr.addAttribute("vendor_no", vendor_no);
        attr.addAttribute("ems_no", ems_no);
        attr.addAttribute("dateFrom", dateFrom);
        attr.addAttribute("dateTo", dateTo);
        return "redirect:findByVendorNoAndEmsNoAndDate.do";
    }

    /**
     * @Author Wang FengCai
     * @Description 加总
     * @Date 2020/7/1
     **/
    @RequestMapping("/sum")
    public ModelAndView save(int[] ids, HttpSession session ,RedirectAttributes attr) throws Exception {
        ModelAndView mv = new ModelAndView();
        List<Bnd_carry_vendor_arrival> bndCarryVendorArrivalList1 = null;
        List<Object> idList = new ArrayList<>();
        //取出前端被选中的选项
        if (ids != null && ids.length > 0) {
            //遍历数组
            for (int i = 0; i <= ids.length - 1; i++) {
                idList.add(ids[i]);
            }
            bndCarryVendorArrivalList1= iBndCarryVendorArrivalService.findByIdList(idList);
        }
        attr.addAttribute(String.valueOf(ids),ids);
        mv.addObject("bndCarryVendorArrivalList",  bndCarryVendorArrivalList1);
        mv.setViewName("bnd-carry-invt-sum");
        return mv;


    }

    /**
     * @Author Wang FengCai
     * @Description 在途清单生成
     * @Date 2020/7/2
     * @Time 上午 09:40
     **/
    @RequestMapping("/update")
    public void update1(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception {

        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        //取出前端传回的所有数据
        Map map = request.getParameterMap();
        String username = (String) session.getAttribute("username");

        int b = 0;
        int c = 0;

        Bnd_carry_invt_list bndCarryInvtList = new Bnd_carry_invt_list();
        //获取流水号
//        Com_serialnum com_serialnum = new Com_serialnum();
//        com_serialnum.setType("bnd");
//        //key01   CARRY表示进口结转
//        com_serialnum.setKey01("CARRY");
//        //key02   INVT表示核注清单
//        com_serialnum.setKey02("INVT");
//        Com_serialnum par_serialnum1 = iComSerialnumService.find(com_serialnum);
//        iComSerialnumService.update(com_serialnum);
//        // JTI 代表前面补充JTI 7代表长度为7 d 代表参数为正数型
//        //取出当前时间，年份的后两位
//        String date = DateUtils.getDateByString();
//        String internalNumber = ("JTI" + date.substring(2, 4) + String.format("%05d", par_serialnum1.getSerialnum()));
        String internalNumber = iComSerialnumService.findAndUpdate("bnd","CARRY","INVT",5);
        System.out.println("1:"+internalNumber);
        bndCarryInvtList.setInternal_number(internalNumber);

        String ids = request.getParameter("ids");
        //拆分字符串，因为传过来的是“1,2”这种格式
        String[] id = ids.split(",");
        String vendorNo = null;
            //遍历
            for (int i = 0; i <= id.length - 1; i++) {
                Bnd_carry_vendor_arrival bndCarryVendorArrival = iBndCarryVendorArrivalService.findById(Integer.parseInt(id[i]));
                if(bndCarryVendorArrival!=null&&!"".equals(bndCarryVendorArrival)){
                    vendorNo = bndCarryVendorArrival.getVendor_no();
                    //取出申报数据，金额，重量
                    Double decQty = Double.valueOf(bndCarryVendorArrival.getDeclared_qty());
                    Double decAmo = Double.valueOf(bndCarryVendorArrival.getDeclared_amount());
                    Double decWei = Double.valueOf(bndCarryVendorArrival.getDeclared_weight());

                    Double aleDecQty;
                    Double aleDecAmo;
                    Double aleDecWei;
                    //取出已申報數量，已申報金額，已申報重量
                    aleDecQty = bndCarryVendorArrival.getAlready_declared_qty();
                    aleDecAmo = bndCarryVendorArrival.getAlready_declared_amount();
                    aleDecWei = bndCarryVendorArrival.getAlready_declared_weight();

                    //此次申报的数量，金额，重量。因为数据是从数据库取出来的所以在这里会在做一步处理
                    Double decQtyNow = decQty-aleDecQty;
                    Double decAmoNow = decAmo-aleDecAmo;
                    Double decWeiNow = decWei-aleDecWei;


                    if(decQtyNow>0){
                        bndCarryVendorArrival.setAlready_declared_qty(decQtyNow+aleDecQty);
                    }else{
                        bndCarryVendorArrival.setAlready_declared_qty(decQty);
                    }
                    if(decAmoNow>0){
                        bndCarryVendorArrival.setAlready_declared_amount(aleDecAmo+decAmoNow);
                    }else{
                        bndCarryVendorArrival.setAlready_declared_amount(decAmo);
                    }
                    if(decWeiNow>0){
                        bndCarryVendorArrival.setAlready_declared_weight(aleDecWei+decWeiNow);
                    }else{
                        bndCarryVendorArrival.setAlready_declared_weight(decWei);
                    }

                    bndCarryVendorArrival.setUpdate_oid(username);
                    bndCarryVendorArrival.setUpdate_program("update");
                    //调用业务层的方法
                    iBndCarryVendorArrivalService.update(bndCarryVendorArrival);

                    try {
                         BeanUtils.copyProperties(bndCarryVendorArrival,bndCarryInvtList);
                    } catch (Exception e) {
                            e.printStackTrace();
                    }

                    if(decQtyNow>0){
                        bndCarryInvtList.setAlready_declared_qty(decQtyNow+aleDecQty);
                    }else{
                        bndCarryInvtList.setAlready_declared_qty(decQty);
                    }
                    if(decAmoNow>0){
                        bndCarryInvtList.setAlready_declared_amount(aleDecAmo+decAmoNow);
                    }else{
                        bndCarryInvtList.setAlready_declared_amount(decAmo);
                    }
                    if(decWeiNow>0){
                        bndCarryInvtList.setAlready_declared_weight(aleDecWei+decWeiNow);
                    }else{
                        bndCarryInvtList.setAlready_declared_weight(decWei);
                    }

                    Date now = new Date();
                    String dateNow = DateUtils.date2String(now,"yyyy-MM-dd");
                    bndCarryInvtList.setApply_date(dateNow);
                    bndCarryInvtList.setUpdate_oid(username);
                    bndCarryInvtList.setUpdate_program("/update");
                    //调用业务层的方法
                    iBndCarryInvtListService.save(bndCarryInvtList);
                    b++;
                    if (b == c) {
                        break;
                            }
                        }
                }
            //解锁供应商号码
            iBndCarryVendorLockService.deleteByVendorNo(vendorNo);
            // 响应数据
            info.setData(internalNumber);
        JsonUtil.writeValue(info,response);
    }
    /**
     * @Author Xiaoni Chen
     * @Description //结转核注清单查询
     * @Date  2021/2/26
     * @Time  上午 09:24
     **/
    @RequestMapping("/findByVendorNoAndDateAndNumber")
    public ModelAndView findByVendorNoAndDateAndNumber(HttpServletRequest request, HttpSession session) throws Exception {
        //取出前端传回的值
        String vendorNo = request.getParameter("vendor_no");
        String internalNumber = request.getParameter("internal_number");
        String dateFrom = request.getParameter("apply_dateFrom");
        String dateTo = request.getParameter("apply_dateTo");
        //创建视图对象
        ModelAndView modelAndView = new ModelAndView();
        //调用业务层方法查询
        List<Bnd_carry_invt_list> bnd_carry_invt_list = iBndCarryInvtListService.findByVendorNoAndDateAndNumber(vendorNo, dateFrom, dateTo,internalNumber);
        modelAndView.addObject("vendor_no", vendorNo);
        modelAndView.addObject("internal_number", internalNumber);
        modelAndView.addObject("apply_dateFrom", dateFrom);
        modelAndView.addObject("apply_dateTo", dateTo);
        modelAndView.setViewName("bnd-carry-invt-inquiry");
        modelAndView.addObject("bnd_carry_invt_list", bnd_carry_invt_list);
        return modelAndView;
    }
}
