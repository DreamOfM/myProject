package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_export_invoice_freight {
    private int id;
    private String port_code;//港口代碼
    private String shipping_condition_code;//出貨方式
    private String terms_trade;//貿易條件
    private String freight_base;//運費標準
    private String cabinet_type;//櫃型
    private Double unit_price;//單價
    private String currency;//幣別
    private String login_time;//登陆时间login_time
    private String login_oid;//登陆人员login_oid
    private String update_time;//更新时间update_time
    private String update_oid;//更新人员update_oid
    private String update_program;//更新程序update_program

}
