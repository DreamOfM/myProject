package com.tdk.txm_java.domain;

public class Bnd_master_country_code {
    //国家代码对照档
   	private int id;

    private String country_code_5a;  //国家代码...a
    private String country_code_3a;
    private String country_code_2a;
    private String country_name;   //国家名
    private String country_name_dbcs;   //国家中文名

    private String login_time;
    private String login_oid;//登陆操作员代码
    private String update_time;
    private String update_oid;
    private String update_program;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCountry_code_5a() {
        return country_code_5a;
    }

    public void setCountry_code_5a(String country_code_5a) {
        this.country_code_5a = country_code_5a;
    }

    public String getCountry_code_3a() {
        return country_code_3a;
    }

    public void setCountry_code_3a(String country_code_3a) {
        this.country_code_3a = country_code_3a;
    }

    public String getCountry_code_2a() {
        return country_code_2a;
    }

    public void setCountry_code_2a(String country_code_2a) {
        this.country_code_2a = country_code_2a;
    }

    public String getCountry_name() {
        return country_name;
    }

    public void setCountry_name(String country_name) {
        this.country_name = country_name;
    }

    public String getCountry_name_dbcs() {
        return country_name_dbcs;
    }

    public void setCountry_name_dbcs(String country_name_dbcs) {
        this.country_name_dbcs = country_name_dbcs;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    @Override
    public String toString() {
        return "Bnd_master_country_code{" +
                "id=" + id +
                ", country_code_5a='" + country_code_5a + '\'' +
                ", country_code_3a='" + country_code_3a + '\'' +
                ", country_code_2a='" + country_code_2a + '\'' +
                ", country_name='" + country_name + '\'' +
                ", country_name_dbcs='" + country_name_dbcs + '\'' +
                ", login_time='" + login_time + '\'' +
                ", login_oid='" + login_oid + '\'' +
                ", update_time='" + update_time + '\'' +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                '}';
    }
}
