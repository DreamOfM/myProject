package com.tdk.txm_java.domain;



import lombok.Data;

import java.sql.Time;
import java.util.Date;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_dev0604</h3>
 * @ClassName<h4></h4>
 * @报关清单生成中间档——表头</p>
 * @date : 2020-07-04 10:18
 * @version:1.0
 **/
@Data
public class Bnd_master_invt_d {
    private int id;
    private String data_state;//數據狀態
    private String ems_no;//備案編號
    private String internal_number;//企業內部清單編號
    private Double gds_seqno;//商品序號
    private Integer filing_serial_no;//備案序號(對應底賬序號）
    private String item_no;//商品料號
    private String good_code;//商品編碼
    private String item_description_dbcs;//商品名稱
    private String item_spec;//商品規格型號
    private String um_physical_inventory;//申報計量單位
    private String lawf_unitcd;//法定計量單位
    private String secd_lawf_unitcd;//法定第二計量
    private String country_code;//原產國 (地區)
    private Double unit_price;//企業申報單價
    private Double enterprise_declared_total_price;//企業申報總價
    private Double usd_statistics_total_amount;//美元統計總金額
    private String currency;//幣制
    private Double legal_qty;//法定數量
    private Double sec_legal_qty;//第二法定數量
    private Double weight_scale_factor;//重量比例因子
    private Double declare_qty;//申報數量
    private Double gross_weight;//毛重
    private Double net_weight;//淨重
    private String use_code;//用途代碼
    private String exempting_method;//征免方式
    private Double ucns_verno;//單耗版本號
    private int customs_declaration_commodity_no ;//報關單商品序號
    private String classification_mark ;//歸類標志
    private Double circulation_declaration_no ;//流轉申報表序號
    private String final_destination_country ;//最終目的國
    private String modf_markcd;//修改標志
    private String rmk;//備注
    private Double weight;//重量        Z(8)9.9(9)
    private Double img_no;//對應報關單商品號Z(8)9
    private Double finish_good_consolidation_no ;//料件成品歸併項號
    private String invoice_no;//裝箱/到貨發票
    private String um_incoming_outgoing;//在庫單位
    private Double cf_physical_inventory;//換算系數
    private String um_purchase;//購買單位
    private Double cf_purchase;//換算系數
    private Double packing_qty;//裝箱/在途數量
    private String unit_net_weigh;//购买单重
    private String declare_date;//申报日期

    /**
     * @Author Wang FengCai
     * @Description 增加一个状态 （若bnd_master_hs_code表的regulatory_credentials1-10这10个字段有一个值不为空，则状态为Y，否则N）
     * @Date  2020/9/17
     * @Time  上午 10:21
     **/
    private String regul_cred_status;//监管证件代码状态
    /**
     * @Author Wang FengCai
     * @Description 用于存放 品番别的平均单价 = 总金额/总的数量
     * @Date  2020/8/4
     * @Time  上午 10:51
     **/
    private Double avgPrice;
    /**
     * @Author Wang FengCai
     * @Description 用于存放品番别的数量
     * @Date  2020/8/4
     * @Time  上午 11:00
     **/
    private Double sum_dcl_qty;
    /**
     * @Author Wang FengCai
     * @Description 用于存放品番别的总价
     * @Date  2020/8/4
     * @Time  下午 01:34
     **/
    private Double sum_amount;
    private Double sum_legal_qty; //汇总法定数量
    private Double sum_sec_legal_qty;//汇总第二法定数量
    private Double sum_weight;//汇总重量
    private Double sum_net_weight;//汇总净重
    //用于存放在账册表体取出的归并项号
    private Double imgNo;
    private Bnd_master_item bndMasterItem;

    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

}
