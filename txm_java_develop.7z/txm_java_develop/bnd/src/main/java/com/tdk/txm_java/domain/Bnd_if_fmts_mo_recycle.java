package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_if_fmts_mo_recycle {
    private int id;
    private String ricoce;//CO_CODE
    private String rimonr;//MTS LOT
    private Double riopsq;//RECY_OPR_ID
    private String ridmon;//DEFECT MTS LOT
    private Integer ridops;//DEF_OPR_ID
    private Double ridqty;//RECY_QTY
    private String rircdt;//RECORD TYPE
    private String ristat;//0-SEND 1-COMPLETED
    private String riupdt;//UPDATE TIME





    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;


}
