package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_stock_annual_inventory {
    private int id;
    private String mrp_code;//MRP代碼
    private String stock_type;//盤點型態
    private String storage_type;//存儲類別
    private String stock_location;//料架
    private String stock_location_detail;//存置地點明細
    private String item_no;//品名代碼
    private String bond_flag;//保稅標誌
    private String lot_no;//批次
    private Double seq_no ;//工序
    private String equipment_name;//工作中心
    private Double on_hand_qty;//在庫數量
    private Double price;//價格
    private String um_incoming_outgoing;//在庫單位
    private String card_no;//盤點卡號
    private String summary_card_no;//盤存清冊號碼
    private String print_code;//列印次數代碼
    private String psa;//P6BOWN
    private String login_time;//登陆时间login_time
    private String login_oid;//登陆人员login_oid
    private String update_time;//更新时间update_time
    private String update_oid;//更新人员update_oid
    private String update_program;//更新程序update_program
    private String custom_bin;

}
