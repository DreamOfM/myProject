package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_if_fepo_asn {
    private int id;
    private String snivnr;//到貨發票
    private Double snivln;//發票行號
    private String snstat;//發票狀態
    private String snvdnr;//供應商代碼
    private String snmrpc;// MRP
    private String snitnr;//材料品番
    private String snvinr;//供應商品番
    private Double snpopr;//購買單價
    private Double snpbdq;//在途數量
    private Double snpbam;//在途金額
    private String sncurr;//比別
    private String snpbdt;//在途日期
    private String snpoum;//購買單位
    private Double snpocf;//換算係數
    private Double snntwt;//總淨重
    private Double sngrwt;//總毛重
    private String snvctg;//原產國
    private String sngfnr;//關封號碼
    private Double sngfsn;//關封序號
    private String snpnct;//板代碼
    private Double snpsum;//總板數
    private String snboct;//包裝代碼
    private Double snbsum;//總箱數
    private String sngfdi;//工發地
    private String sntran;//運送方式
    private String sntrmc;//貿易條件
    private Double snupdt;//更新日期
    private String snrcdt;//記錄類型
    private String snpono;// PO NO.
    private String snpoln;// PO LINE
    private String snflag;// 1已處理


    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;
}
