package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_master_trade_code {
    private int id;
    private String trade_code;//TRADE               TERM CODE
    private String trade_desc;//TRADE               TERM DESC.
    private String trade_term_dbsc;//TRADE TERM          DESC.(DBCS)
    private String trade_term_abbr;//TRADE TERM          DESC.(ABBR.)
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;
}
