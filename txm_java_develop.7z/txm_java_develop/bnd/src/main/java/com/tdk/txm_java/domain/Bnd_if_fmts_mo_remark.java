package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_if_fmts_mo_remark {
    private int id;
    private String lrcoce;//CO_CODE
    private String lrmonr;//LOT NO
    private String lrwipn;//WIP_ID
    private String lrwknr;//WORKCENTER.
    private String lrrmk1;//REMARK1.
    private String lrrmk2;//REMARK2.
    private String lrrmk3;//REMARK3.
    private String lrrmk4;//REMARK4.
    private String lrrmk5;//REMARK5.
    private String lrrmk6;//REMARK6.
    private String lrflag;//A-ADD  D-DELETE
    private String lrstat;//0-SEND 1-COMPLETED
    private String lropid;//UPDATE OPERATOR ID
    private String lrupdt;//UPDATE TIME





    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;


}
