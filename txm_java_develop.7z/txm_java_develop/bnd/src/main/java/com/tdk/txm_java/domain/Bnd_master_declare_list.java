package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Time;
import java.util.Date;

@Data
public class Bnd_master_declare_list {
    private int id;
    private String ems_no;//帳冊編號    X(12)
    private Double dcr_times;//報核次數    Z(8)9
    private String internal_number;//企業內部歸併前清單編號
    private String declaration_no;//報關單號    Z(8)9
    private String declaration_notice;//報關單預錄入
    private String tax_no;//稅單號
    private String bill_no;//稅單號
    private String customs_name;//報關地海關代號9(4)
    private String ie_flag;//進出口標志  X(1)
    private Double items_num;//商品項數    Z(8)9
    private String declare_date;//申報日期    Z(8)
    private String ie_date;//進出日期    Z(8)
    private String deduction_clearance_mode ;//核扣通關方式X(2)
    private String list_no;//清單統一編號X(18)
    private String examine_flag;//審核標志    X(1)
    private String reason_code;//備注        X(10)
    private String modf_markcd;//修改標誌    X(1)
    private String copy_flag;//修改標誌    X(1)
    private Time login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;

}
