package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_master_company_code {
    private int id;
    private String company_code;//公司代码
    private String company_type;//公司型态
    private String company_name;//公司名（中文）
    private String address1_dbcs;//住址１（中文）
    private String address2_dbcs;//住址２（中文）
    private String address3_dbcs;//住址３（中文）
    private String company_name_2;//公司名 2
    private String company_offical_code;//公司名称代码
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;
}
