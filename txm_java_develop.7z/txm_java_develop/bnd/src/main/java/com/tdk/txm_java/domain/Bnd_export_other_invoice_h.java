package com.tdk.txm_java.domain;

public class Bnd_export_other_invoice_h {
    private int id;
    private String name_operator;
    private String invoice_no;
    private String mrp_code;
    private String shipped_date;
    private Double box_from;
    private String packing_code1;
    private Double net_weight;
    private Double gross_weight;
    private Double declare_qty;
    private String um_incoming_outgoing;
    private String origin_country;
    private String packing_volume;
    private String trading_country;
    private String whether_tdk;
    private String type;
    private String shipping_condition_code;
    private String terms_trade;
    private Double amt_foreign;
    private String currency;
    private String contract_no;
    private String destination;
    private String ship_to1;
    private String ship_to2;
    private String ship_to3;
    private String ship_to4;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName_operator() {
        return name_operator;
    }

    public void setName_operator(String name_operator) {
        this.name_operator = name_operator;
    }

    public String getInvoice_no() {
        return invoice_no;
    }

    public void setInvoice_no(String invoice_no) {
        this.invoice_no = invoice_no;
    }

    public String getMrp_code() {
        return mrp_code;
    }

    public void setMrp_code(String mrp_code) {
        this.mrp_code = mrp_code;
    }

    public String getShipped_date() {
        return shipped_date;
    }

    public void setShipped_date(String shipped_date) {
        this.shipped_date = shipped_date;
    }

    public Double getBox_from() {
        return box_from;
    }

    public void setBox_from(Double box_from) {
        this.box_from = box_from;
    }

    public String getPacking_code1() {
        return packing_code1;
    }

    public void setPacking_code1(String packing_code1) {
        this.packing_code1 = packing_code1;
    }

    public Double getNet_weight() {
        return net_weight;
    }

    public void setNet_weight(Double net_weight) {
        this.net_weight = net_weight;
    }

    public Double getGross_weight() {
        return gross_weight;
    }

    public void setGross_weight(Double gross_weight) {
        this.gross_weight = gross_weight;
    }

    public Double getDeclare_qty() {
        return declare_qty;
    }

    public void setDeclare_qty(Double declare_qty) {
        this.declare_qty = declare_qty;
    }

    public String getUm_incoming_outgoing() {
        return um_incoming_outgoing;
    }

    public void setUm_incoming_outgoing(String um_incoming_outgoing) {
        this.um_incoming_outgoing = um_incoming_outgoing;
    }

    public String getOrigin_country() {
        return origin_country;
    }

    public void setOrigin_country(String origin_country) {
        this.origin_country = origin_country;
    }

    public String getPacking_volume() {
        return packing_volume;
    }

    public void setPacking_volume(String packing_volume) {
        this.packing_volume = packing_volume;
    }

    public String getTrading_country() {
        return trading_country;
    }

    public void setTrading_country(String trading_country) {
        this.trading_country = trading_country;
    }

    public String getWhether_tdk() {
        return whether_tdk;
    }

    public void setWhether_tdk(String whether_tdk) {
        this.whether_tdk = whether_tdk;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getShipping_condition_code() {
        return shipping_condition_code;
    }

    public void setShipping_condition_code(String shipping_condition_code) {
        this.shipping_condition_code = shipping_condition_code;
    }

    public String getTerms_trade() {
        return terms_trade;
    }

    public void setTerms_trade(String terms_trade) {
        this.terms_trade = terms_trade;
    }

    public Double getAmt_foreign() {
        return amt_foreign;
    }

    public void setAmt_foreign(Double amt_foreign) {
        this.amt_foreign = amt_foreign;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getContract_no() {
        return contract_no;
    }

    public void setContract_no(String contract_no) {
        this.contract_no = contract_no;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getShip_to1() {
        return ship_to1;
    }

    public void setShip_to1(String ship_to1) {
        this.ship_to1 = ship_to1;
    }

    public String getShip_to2() {
        return ship_to2;
    }

    public void setShip_to2(String ship_to2) {
        this.ship_to2 = ship_to2;
    }

    public String getShip_to3() {
        return ship_to3;
    }

    public void setShip_to3(String ship_to3) {
        this.ship_to3 = ship_to3;
    }

    public String getShip_to4() {
        return ship_to4;
    }

    public void setShip_to4(String ship_to4) {
        this.ship_to4 = ship_to4;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    @Override
    public String toString() {
        return "Bnd_export_other_invoice_h{" +
                "id=" + id +
                ", name_operator='" + name_operator + '\'' +
                ", invoice_no='" + invoice_no + '\'' +
                ", mrp_code='" + mrp_code + '\'' +
                ", shipped_date=" + shipped_date +
                ", box_from=" + box_from +
                ", packing_code1='" + packing_code1 + '\'' +
                ", net_weight=" + net_weight +
                ", gross_weight=" + gross_weight +
                ", declare_qty=" + declare_qty +
                ", um_incoming_outgoing='" + um_incoming_outgoing + '\'' +
                ", origin_country='" + origin_country + '\'' +
                ", packing_volume='" + packing_volume + '\'' +
                ", trading_country='" + trading_country + '\'' +
                ", whether_tdk='" + whether_tdk + '\'' +
                ", type='" + type + '\'' +
                ", shipping_condition_code='" + shipping_condition_code + '\'' +
                ", terms_trade='" + terms_trade + '\'' +
                ", amt_foreign=" + amt_foreign +
                ", currency='" + currency + '\'' +
                ", contract_no='" + contract_no + '\'' +
                ", destination='" + destination + '\'' +
                ", ship_to1='" + ship_to1 + '\'' +
                ", ship_to2='" + ship_to2 + '\'' +
                ", ship_to3='" + ship_to3 + '\'' +
                ", ship_to4='" + ship_to4 + '\'' +
                ", login_time='" + login_time + '\'' +
                ", login_oid='" + login_oid + '\'' +
                ", update_time='" + update_time + '\'' +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                '}';
    }
}
