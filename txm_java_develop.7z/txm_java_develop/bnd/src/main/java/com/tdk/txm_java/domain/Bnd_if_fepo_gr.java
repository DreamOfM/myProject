package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_if_fepo_gr {
    private int id;
    private String grivnr;//到貨發票
    private String grrgdc;//到貨日期
    private String grtype;// A:到貨C:取消到貨
    private Double grstat;//0-SEND 1-COMPLETED
    private Double grupdt;//UPDATE DATE
    private Double gruptm;//UPDATE TIME
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;
}
