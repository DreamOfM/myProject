package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_if_fmts_process_m {
    private int id;
    private String macoce;//部門代碼
    private String mamonr;//SAP MO
    private String maitnr;//品名代碼
    private Double maopid;//綁定工序
    private String mamlot;//指定材料批號
    private String macitm;//材料品名代碼
    private String maalgr;//替代材料組別
    private String maairo;//替代材料順序
    private String mauspi;//替代材料比率
    private Double macpri;//材料單耗
    private String maflag;//狀態
    private Double mabol1;//净耗
    private Double mabol2;//损耗
    private String mastat;//狀態
    private String maupdt;//狀態


    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;


}
