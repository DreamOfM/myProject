package com.tdk.txm_java.controller;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tdk.txm_java.domain.*;
import com.tdk.txm_java.service.*;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.*;


@Controller
@RequestMapping("/bnd_stock_location_floor")
public class Bnd_stock_location_floorController {
    @Autowired
    private IBnd_stock_location_floorService iBnd_stock_location_floorService;
    @Autowired
    private IBnd_stock_annual_inventoryService iBnd_stock_annual_inventoryService;

    @RequestMapping("/findBylocation.do")
    public ModelAndView findByenter(HttpServletResponse response, HttpServletRequest request, HttpSession session) throws Exception {
        ModelAndView modelAndView = new ModelAndView();
        String message = null;
        String stock_location = request.getParameter("stock_location") + "%";
        List<Bnd_stock_location_floor> bnd_stock_location_floor = iBnd_stock_location_floorService.findBylocation(stock_location);
        modelAndView.addObject("bnd_stock_location_floor", bnd_stock_location_floor);
        modelAndView.setViewName("bnd-stock-location-floor-list");

        //返回视图解析对象
        return modelAndView;
    }

    @RequestMapping("/delete.do")
    public String delete(int[] ids, HttpServletRequest request, RedirectAttributes attr) throws Exception {
        System.out.println("20210129" + ids);
        if (ids != null && ids.length > 0) {
            //遍历数组
            for (int id : ids) {
                //单条删除
                iBnd_stock_location_floorService.delete(id);
            }
        }
        return "redirect:findBylocation.do";

    }


    @RequestMapping("/update.do")
    public String update(String[] ids, HttpServletRequest request, HttpServletResponse response, HttpSession httpSession, RedirectAttributes attr) throws Exception {
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        String username = (String) httpSession.getAttribute("username");

        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //将每一个key值对应的一组值放到数组里去
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                hashMap.put(name1, vals[b]);

            }
            Bnd_stock_location_floor location_floor = new Bnd_stock_location_floor();
            //根据key值找到集合中对应的id
            int id1 = Integer.parseInt(hashMap.get("id"));

            //找到这个id对应数据库里的数据，并取出
            location_floor = iBnd_stock_location_floorService.findById(id1);

            try {
                BeanUtils.populate(location_floor, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            //调用业务层的update()方法
            location_floor.setUpdate_oid(username);
            location_floor.setUpdate_program("/stock_location_floor/update");
            iBnd_stock_location_floorService.update(location_floor);
            b++;
            if (b == c) break;
        }
        return "redirect:findBylocation.do";
    }

    @RequestMapping("/save.do")
    public String save(String[] ids, HttpServletRequest request, HttpServletResponse response, HttpSession httpSession, RedirectAttributes attr) throws Exception {
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        // 使用keySet()方法获取所有的key值
        Set<String> set = map.keySet();
        String username = (String) httpSession.getAttribute("username");

        int b = 0;
        int c = 0;
        while (1 == 1) {
            //遍历每一笔数据
            for (String name1 : set) {
                //将每一个key值对应的一组值放到数组里去
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                hashMap.put(name1, vals[b]);

            }
            Bnd_stock_location_floor location_floor = new Bnd_stock_location_floor();

            try {
                BeanUtils.populate(location_floor, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }
            if (location_floor.getStock_location().equals(null) || location_floor.getStock_location().equals("")) {
                b++;
                if (b == c) break;
                continue;
            }
            //调用业务层的update()方法
            location_floor.setLogin_oid(username);
            location_floor.setUpdate_program("/stock_location_floor/save");
            iBnd_stock_location_floorService.save(location_floor);
            b++;
            if (b == c) break;
        }
        return "redirect:findBylocation.do";
    }


    @RequestMapping("/check.do")
    public void check(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception, IOException, JsonGenerationException, JsonMappingException {
        ResultInfo info = new ResultInfo(); //取出前端传回的所有数据
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();

        // check body
        int b = 0;   //第几笔记录
        int c = 0;   //total

        List<String> location_list = new ArrayList<>();
        while (true) {
            for (String name1 : set) {
                //将每一个key值对应的一组值放到数组里去
                String[] vals = (String[]) map.get(name1);
                c = vals.length;
                hashMap.put(name1, vals[b]);
            }
            Bnd_stock_location_floor location_floor = new Bnd_stock_location_floor();

            try {
                BeanUtils.populate(location_floor, hashMap);
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            } catch (InvocationTargetException e) {
                e.printStackTrace();
            }

            //添加一个判断，如果为空值或者没有输入则不往数据库里插数据
            if (location_floor.getStock_location().equals(null) || location_floor.getStock_location().equals("")) {
                b++;
                if (b == c) break;
                continue;
            }

            //检查序号是否重复
            if (location_list.contains(location_floor.getStock_location())) {
                info.setErrorMsg("存置位置重复");
                String errLine = String.valueOf(b);
                errorList.add("stock_location" + errLine);
                info.setFlag(false);
            } else {
                location_list.add(location_floor.getStock_location());
                Bnd_stock_location_floor bnd_stock_location_floor=iBnd_stock_location_floorService.findBystock_loc(location_floor.getStock_location());
                if(bnd_stock_location_floor!=null){
                    info.setErrorMsg("该存置位置已维护");
                    String errLine = String.valueOf(b);
                    errorList.add("stock_location" + errLine);
                    info.setFlag(false);
                }
            }
            b++;
            if (b == c) break;
        }

        info.setErrorList(errorList);
        //响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(), info);
    }


    @RequestMapping("/check1.do")
    public void check1(String[] ids,HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) throws Exception, IOException, JsonGenerationException, JsonMappingException {
        ResultInfo info = new ResultInfo();
        info.setFlag(true);
        List<String> errorList = new ArrayList<String>();
        Map map = request.getParameterMap();
        Map<String, String> hashMap = new HashMap<>();
        Set<String> set = map.keySet();
        int b = 0;
        int c = 0;
        while (1 == 1) {
            for (String name1 : set) {
                if (!name1.equals("ids")) {
                    String[] vals = (String[]) map.get(name1);
                    c = vals.length;
                    hashMap.put(name1, vals[b]);
                }
            }
            //记录当前记录行
            String id = hashMap.get("id");
            String errLine = String.valueOf(b);
            boolean isContains = Arrays.asList(ids).contains(id);
            if (isContains) {
                //取出存置地点
                String stock_location = hashMap.get("stock_location");
                List<Bnd_stock_annual_inventory> annual_inventory=iBnd_stock_annual_inventoryService.findBystock_loc(stock_location);
                //判断
                if (annual_inventory.size()>0) {
                    info.setFlag(false);
                    info.setErrorMsg("存置地点不可删除，已维护盘点数据");
                    errorList.add("stock_location" + errLine);
                }
            }
            b++;
            if (b == c) {
                break;
            }
        }
        info.setErrorList(errorList);
        //响应数据
        ObjectMapper mapper = new ObjectMapper();
        response.setContentType("application/json;charset=utf-8");
        mapper.writeValue(response.getOutputStream(), info);
    }

}
