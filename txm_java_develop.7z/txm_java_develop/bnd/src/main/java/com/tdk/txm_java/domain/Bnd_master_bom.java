package com.tdk.txm_java.domain;

public class Bnd_master_bom {
    private int id;
    private String seq_no;
    private String ems_no;
    private String data_state;
    private Double gds_seqno;
    private Double endprd_seqno;
    private String endprd_gds_mtno;
    private String endprd_gdecd;
    private String endprd_gds_nm;
    private Double mtpck_seqno;
    private String mtpck_gds_mtno;
    private String mtpck_gdecd;
    private String mtpck_gds_nm;
    private Double ucns_verno;
    private Double ucns_qty;
    private Double dec_cm;
    private Double dec_dm;
    private Double intgb_loss_rate;
    private String ucns_dcl_stucd;
    private String modf_markcd;
    private Double bond_mtpck_prpr;
    private String rmk;
    private String effective_date;
    private String expiration_date;
    private String product_unit;
    private String material_unit;
    private String equipment_name;
    private Double operation_sequence_no;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;
    private Double img_no;
    private String um_physical_inventory;
    private String item_spec;
    private String item_description_dbcs;
    private String routing_no;
    private Double ucns_verno1;

    public Double getUcns_verno1() {
        return ucns_verno1;
    }

    public void setUcns_verno1(Double ucns_verno1) {
        this.ucns_verno1 = ucns_verno1;
    }

    public String getRouting_no() {
        return routing_no;
    }

    public void setRouting_no(String routing_no) {
        this.routing_no = routing_no;
    }

    public Double getImg_no() {
        return img_no;
    }

    public void setImg_no(Double img_no) {
        this.img_no = img_no;
    }

    public String getUm_physical_inventory() {
        return um_physical_inventory;
    }

    public void setUm_physical_inventory(String um_physical_inventory) {
        this.um_physical_inventory = um_physical_inventory;
    }

    public String getItem_spec() {
        return item_spec;
    }

    public void setItem_spec(String item_spec) {
        this.item_spec = item_spec;
    }

    public String getItem_description_dbcs() {
        return item_description_dbcs;
    }

    public void setItem_description_dbcs(String item_description_dbcs) {
        this.item_description_dbcs = item_description_dbcs;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSeq_no() {
        return seq_no;
    }

    public void setSeq_no(String seq_no) {
        this.seq_no = seq_no;
    }

    public String getEms_no() {
        return ems_no;
    }

    public void setEms_no(String ems_no) {
        this.ems_no = ems_no;
    }

    public String getData_state() {
        return data_state;
    }

    public void setData_state(String data_state) {
        this.data_state = data_state;
    }

    public Double getGds_seqno() {
        return gds_seqno;
    }

    public void setGds_seqno(Double gds_seqno) {
        this.gds_seqno = gds_seqno;
    }

    public Double getEndprd_seqno() {
        return endprd_seqno;
    }

    public void setEndprd_seqno(Double endprd_seqno) {
        this.endprd_seqno = endprd_seqno;
    }

    public String getEndprd_gds_mtno() {
        return endprd_gds_mtno;
    }

    public void setEndprd_gds_mtno(String endprd_gds_mtno) {
        this.endprd_gds_mtno = endprd_gds_mtno;
    }

    public String getEndprd_gdecd() {
        return endprd_gdecd;
    }

    public void setEndprd_gdecd(String endprd_gdecd) {
        this.endprd_gdecd = endprd_gdecd;
    }

    public String getEndprd_gds_nm() {
        return endprd_gds_nm;
    }

    public void setEndprd_gds_nm(String endprd_gds_nm) {
        this.endprd_gds_nm = endprd_gds_nm;
    }

    public Double getMtpck_seqno() {
        return mtpck_seqno;
    }

    public void setMtpck_seqno(Double mtpck_seqno) {
        this.mtpck_seqno = mtpck_seqno;
    }

    public String getMtpck_gds_mtno() {
        return mtpck_gds_mtno;
    }

    public void setMtpck_gds_mtno(String mtpck_gds_mtno) {
        this.mtpck_gds_mtno = mtpck_gds_mtno;
    }

    public String getMtpck_gdecd() {
        return mtpck_gdecd;
    }

    public void setMtpck_gdecd(String mtpck_gdecd) {
        this.mtpck_gdecd = mtpck_gdecd;
    }

    public String getMtpck_gds_nm() {
        return mtpck_gds_nm;
    }

    public void setMtpck_gds_nm(String mtpck_gds_nm) {
        this.mtpck_gds_nm = mtpck_gds_nm;
    }

    public Double getUcns_verno() {
        return ucns_verno;
    }

    public void setUcns_verno(Double ucns_verno) {
        this.ucns_verno = ucns_verno;
    }

    public Double getUcns_qty() {
        return ucns_qty;
    }

    public void setUcns_qty(Double ucns_qty) {
        this.ucns_qty = ucns_qty;
    }

    public Double getDec_cm() {
        return dec_cm;
    }

    public void setDec_cm(Double dec_cm) {
        this.dec_cm = dec_cm;
    }

    public Double getDec_dm() {
        return dec_dm;
    }

    public void setDec_dm(Double dec_dm) {
        this.dec_dm = dec_dm;
    }

    public Double getIntgb_loss_rate() {
        return intgb_loss_rate;
    }

    public void setIntgb_loss_rate(Double intgb_loss_rate) {
        this.intgb_loss_rate = intgb_loss_rate;
    }

    public String getUcns_dcl_stucd() {
        return ucns_dcl_stucd;
    }

    public void setUcns_dcl_stucd(String ucns_dcl_stucd) {
        this.ucns_dcl_stucd = ucns_dcl_stucd;
    }

    public String getModf_markcd() {
        return modf_markcd;
    }

    public void setModf_markcd(String modf_markcd) {
        this.modf_markcd = modf_markcd;
    }

    public Double getBond_mtpck_prpr() {
        return bond_mtpck_prpr;
    }

    public void setBond_mtpck_prpr(Double bond_mtpck_prpr) {
        this.bond_mtpck_prpr = bond_mtpck_prpr;
    }

    public String getRmk() {
        return rmk;
    }

    public void setRmk(String rmk) {
        this.rmk = rmk;
    }

    public String getEffective_date() {
        return effective_date;
    }

    public void setEffective_date(String effective_date) {
        this.effective_date = effective_date;
    }

    public String getExpiration_date() {
        return expiration_date;
    }

    public void setExpiration_date(String expiration_date) {
        this.expiration_date = expiration_date;
    }

    public String getProduct_unit() {
        return product_unit;
    }

    public void setProduct_unit(String product_unit) {
        this.product_unit = product_unit;
    }

    public String getMaterial_unit() {
        return material_unit;
    }

    public void setMaterial_unit(String material_unit) {
        this.material_unit = material_unit;
    }

    public String getEquipment_name() {
        return equipment_name;
    }

    public void setEquipment_name(String equipment_name) {
        this.equipment_name = equipment_name;
    }

    public Double getOperation_sequence_no() {
        return operation_sequence_no;
    }

    public void setOperation_sequence_no(Double operation_sequence_no) {
        this.operation_sequence_no = operation_sequence_no;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    @Override
    public String toString() {
        return "Bnd_master_bom{" +
                "id=" + id +
                ", seq_no='" + seq_no + '\'' +
                ", ems_no='" + ems_no + '\'' +
                ", data_state='" + data_state + '\'' +
                ", gds_seqno=" + gds_seqno +
                ", endprd_seqno=" + endprd_seqno +
                ", endprd_gds_mtno='" + endprd_gds_mtno + '\'' +
                ", endprd_gdecd='" + endprd_gdecd + '\'' +
                ", endprd_gds_nm='" + endprd_gds_nm + '\'' +
                ", mtpck_seqno=" + mtpck_seqno +
                ", mtpck_gds_mtno='" + mtpck_gds_mtno + '\'' +
                ", mtpck_gdecd='" + mtpck_gdecd + '\'' +
                ", mtpck_gds_nm='" + mtpck_gds_nm + '\'' +
                ", ucns_verno=" + ucns_verno +
                ", ucns_qty=" + ucns_qty +
                ", dec_cm=" + dec_cm +
                ", dec_dm=" + dec_dm +
                ", intgb_loss_rate=" + intgb_loss_rate +
                ", ucns_dcl_stucd='" + ucns_dcl_stucd + '\'' +
                ", modf_markcd='" + modf_markcd + '\'' +
                ", bond_mtpck_prpr=" + bond_mtpck_prpr +
                ", rmk='" + rmk + '\'' +
                ", effective_date='" + effective_date + '\'' +
                ", expiration_date='" + expiration_date + '\'' +
                ", product_unit='" + product_unit + '\'' +
                ", material_unit='" + material_unit + '\'' +
                ", equipment_name='" + equipment_name + '\'' +
                ", operation_sequence_no=" + operation_sequence_no +
                ", login_time='" + login_time + '\'' +
                ", login_oid='" + login_oid + '\'' +
                ", update_time='" + update_time + '\'' +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                ", img_no=" + img_no +
                ", um_physical_inventory='" + um_physical_inventory + '\'' +
                ", item_spec='" + item_spec + '\'' +
                ", item_description_dbcs='" + item_description_dbcs + '\'' +
                ", routing_no='" + routing_no + '\'' +
                ", ucns_verno1=" + ucns_verno1 +
                '}';
    }
}
