package com.tdk.txm_java.domain;

import lombok.Data;

import java.util.Date;


public class Bnd_apply_ehandbook_d {
    private int id;
    private Double gds_seqno ;
    private String item_no;
    private String item_description_dbcs;
    private String item_spec;
    private String um_physical_inventory;
    private String lawf_unitcd;
    private String secd_lawf_unitcd;
    private String currency;
    private String ccc_code;
    private String lvyrlf_modecd;
    private String etps_exe_markcd;
    private String modf_markcd;
    private String company_code;
    private String etps_preent_no;
    private String item_type;
    private String opers_status;
    private String file_no;
    private Date login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Double getGds_seqno() {
        return gds_seqno;
    }

    public void setGds_seqno(Double gds_seqno) {
        this.gds_seqno = gds_seqno;
    }

    public String getItem_no() {
        return item_no;
    }

    public void setItem_no(String item_no) {
        this.item_no = item_no;
    }

    public String getItem_description_dbcs() {
        return item_description_dbcs;
    }

    public void setItem_description_dbcs(String item_description_dbcs) {
        this.item_description_dbcs = item_description_dbcs;
    }

    public String getItem_spec() {
        return item_spec;
    }

    public void setItem_spec(String item_spec) {
        this.item_spec = item_spec;
    }

    public String getUm_physical_inventory() {
        return um_physical_inventory;
    }

    public void setUm_physical_inventory(String um_physical_inventory) {
        this.um_physical_inventory = um_physical_inventory;
    }

    public String getLawf_unitcd() {
        return lawf_unitcd;
    }

    public void setLawf_unitcd(String lawf_unitcd) {
        this.lawf_unitcd = lawf_unitcd;
    }

    public String getSecd_lawf_unitcd() {
        return secd_lawf_unitcd;
    }

    public void setSecd_lawf_unitcd(String secd_lawf_unitcd) {
        this.secd_lawf_unitcd = secd_lawf_unitcd;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getCcc_code() {
        return ccc_code;
    }

    public void setCcc_code(String ccc_code) {
        this.ccc_code = ccc_code;
    }

    public String getLvyrlf_modecd() {
        return lvyrlf_modecd;
    }

    public void setLvyrlf_modecd(String lvyrlf_modecd) {
        this.lvyrlf_modecd = lvyrlf_modecd;
    }

    public String getEtps_exe_markcd() {
        return etps_exe_markcd;
    }

    public void setEtps_exe_markcd(String etps_exe_markcd) {
        this.etps_exe_markcd = etps_exe_markcd;
    }

    public String getModf_markcd() {
        return modf_markcd;
    }

    public void setModf_markcd(String modf_markcd) {
        this.modf_markcd = modf_markcd;
    }

    public String getCompany_code() {
        return company_code;
    }

    public void setCompany_code(String company_code) {
        this.company_code = company_code;
    }

    public String getEtps_preent_no() {
        return etps_preent_no;
    }

    public void setEtps_preent_no(String etps_preent_no) {
        this.etps_preent_no = etps_preent_no;
    }

    public String getItem_type() {
        return item_type;
    }

    public void setItem_type(String item_type) {
        this.item_type = item_type;
    }

    public String getOpers_status() {
        return opers_status;
    }

    public void setOpers_status(String opers_status) {
        this.opers_status = opers_status;
    }

    public String getFile_no() {
        return file_no;
    }

    public void setFile_no(String file_no) {
        this.file_no = file_no;
    }

    public Date getLogin_time() {
        return login_time;
    }

    public void setLogin_time(Date login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    @Override
    public String toString() {
        return "Bnd_apply_ehandbook_d{" +
                "id=" + id +
                ", gds_seqno=" + gds_seqno +
                ", item_no='" + item_no + '\'' +
                ", item_description_dbcs='" + item_description_dbcs + '\'' +
                ", item_spec='" + item_spec + '\'' +
                ", um_physical_inventory='" + um_physical_inventory + '\'' +
                ", lawf_unitcd='" + lawf_unitcd + '\'' +
                ", secd_lawf_unitcd='" + secd_lawf_unitcd + '\'' +
                ", currency='" + currency + '\'' +
                ", ccc_code='" + ccc_code + '\'' +
                ", lvyrlf_modecd='" + lvyrlf_modecd + '\'' +
                ", etps_exe_markcd='" + etps_exe_markcd + '\'' +
                ", modf_markcd='" + modf_markcd + '\'' +
                ", company_code='" + company_code + '\'' +
                ", etps_preent_no='" + etps_preent_no + '\'' +
                ", item_type='" + item_type + '\'' +
                ", opers_status='" + opers_status + '\'' +
                ", file_no='" + file_no + '\'' +
                ", login_time=" + login_time +
                ", login_oid='" + login_oid + '\'' +
                ", update_time='" + update_time + '\'' +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                '}';
    }
}
