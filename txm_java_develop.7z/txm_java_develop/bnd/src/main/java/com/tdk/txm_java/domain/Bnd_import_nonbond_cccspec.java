package com.tdk.txm_java.domain;

import lombok.Data;

import java.util.Date;

@Data
public class Bnd_import_nonbond_cccspec {
    private int id;
    private String item_no;//ITEM
    private String img_no;//歸并項號
    private String ccc_code;//商編
    private String item_spec;//規格型號
    private String e_item_spec;//英文規格型號
    private String note;//備注
    private String login_time;//登陆时间login_time
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

    private Bnd_master_item bnd_master_item;
    private Bnd_import_custom_regulatory bnd_import_custom_regulatory;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getItem_no() {
        return item_no;
    }

    public void setItem_no(String item_no) {
        this.item_no = item_no;
    }

    public String getImg_no() {
        return img_no;
    }

    public void setImg_no(String img_no) {
        this.img_no = img_no;
    }

    public String getCcc_code() {
        return ccc_code;
    }

    public void setCcc_code(String ccc_code) {
        this.ccc_code = ccc_code;
    }

    public String getItem_spec() {
        return item_spec;
    }

    public void setItem_spec(String item_spec) {
        this.item_spec = item_spec;
    }

    public String getE_item_spec() {
        return e_item_spec;
    }

    public void setE_item_spec(String e_item_spec) {
        this.e_item_spec = e_item_spec;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    public Bnd_master_item getBnd_master_item() {
        return bnd_master_item;
    }

    public void setBnd_master_item(Bnd_master_item bnd_master_item) {
        this.bnd_master_item = bnd_master_item;
    }

    public Bnd_import_custom_regulatory getBnd_import_custom_regulatory() {
        return bnd_import_custom_regulatory;
    }

    public void setBnd_import_custom_regulatory(Bnd_import_custom_regulatory bnd_import_custom_regulatory) {
        this.bnd_import_custom_regulatory = bnd_import_custom_regulatory;
    }
}
