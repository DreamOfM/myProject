package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_master_sample_consume {
    private int id;
    private String mrp_code;//MRP基准代码
    private String type;//
    private Double yyyymm;//
    private String material_document;//MD号
    private String document_item;//MD序号
    private String doc_head_text;//MD表头
    private String reference_document_number;//关联文档
    private Double posting_date;//异动日期
    private Double document_date;//文档日期
    private Double document_time;//文档时间
    private String item_no;//品名代码
    private Double transaction_qty;//TRANSACTION QTY
    private String unit;//单位
    private String lot_no;//批號
    private String cost_center;//成本 中心
    private String psa_code;//PSA
    private String movement_type;//异动类型
    private String user_id;//用户ID
    private String state;//状态

    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

}
