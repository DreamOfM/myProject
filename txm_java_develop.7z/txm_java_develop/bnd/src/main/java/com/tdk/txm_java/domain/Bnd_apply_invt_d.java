package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Time;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_dev0604</h3>
 * @ClassName<h4></h4>
 * @ToDo<p>核注清单申报</p>
 * @date : 2020-07-14 15:14
 * @version:1.0
 **/
@Data
public class Bnd_apply_invt_d {
    private String internal_number;//企業內部清單編號
    private Integer filing_serial_no;//備案序號(對應底賬序號）
    private String item_no;//商品料號
    private Double declare_qty;//申報數量
    private Double legal_qty;//法定數量
    private Double sec_legal_qty;//第二法定數量
    private Double unit_price;//企業申報單價
    private String currency;//幣制
    private String country_code;//原產國 (地區)
    private String final_destination_country ;//最終目的國
    private String exempting_method;//征免方式
    private Double ucns_verno;//單耗版本號
    private Double customs_declaration_commodity_no ;//報關單商品序號
    private Double gross_weight;//毛重
    private Double net_weigh;//淨重
    private String rmk                                     ;//備注
    private Double enterprise_declared_total_price;//企業申報總價
    private Double circulation_declaration_no ;//流轉申報表序號
    private String mis_bill_id;//內部單據編號
    private String batch_no;//批次號
    private String exg_version_mis;//工單單耗版本號
    private Double gds_seqno                       ;//商品序號
    private String doc_po_no;//內部業務單據編號
    private String invoice_no;//發票號碼
    private String item_description_dbcs;//商品名稱
    private String item_spec;//商品規格型號
    private String um_physical_inventory;//申報計量單位
    private String ccc_code;//商品編碼
    private String import_export_mark_code;//進出口標記代碼
    private String oper_status;//OPERSTATUS
    private String file;//FILE
    private Time login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;

}
