package com.tdk.txm_java.domain;

import lombok.Data;

import java.util.Date;
//运费上载中间档
@Data
public class Bnd_export_freight_upload {
    private int id;
    private String salesman_territory_code;
    private String shipping_condition_code;
    private String invoice_no;
    private String shipped_date;
    private Double freight;
    private String net_weigh;
    private Date upload_date;
    private String error_flag;
    private String error_reason;
    private String shipping_employee;
    private Date login_time;
    private String login_oid;
    private Date update_time;
    private String update_oid;
    private String update_program;


}
