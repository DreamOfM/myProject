package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Time;

@Data
public class Bnd_if_fassist4_pgi {
    private int id;
    private String sdivnr;//
    private String sdivdt;//
    private String sdstat;//
    private String sdupdt;//

    private Time login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;

}
