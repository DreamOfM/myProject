package com.tdk.txm_java.domain;

public class Bnd_export_invoice_check {
    private String invoice_no;
    private int err_num;
    private String err_description;

    public String getInvoice_no() {
        return invoice_no;
    }

    public void setInvoice_no(String invoice_no) {
        this.invoice_no = invoice_no;
    }

    public int getErr_num() {
        return err_num;
    }

    public void setErr_num(int err_num) {
        this.err_num = err_num;
    }

    public String getErr_description() {
        return err_description;
    }

    public void setErr_description(String err_description) {
        this.err_description = err_description;
    }

    @Override
    public String toString() {
        return "Bnd_export_invoice_check{" +
                "invoice_no='" + invoice_no + '\'' +
                ", err_num=" + err_num +
                ", err_description='" + err_description + '\'' +
                '}';
    }
}
