package com.tdk.txm_java.domain;

import lombok.Data;

import java.util.Date;

/**
 * @Author Yu Liqin
 * @Description //TODO a801550
 * @Date  2020/7/23
 * @Time  下午 01:46
 **/

@Data
public class Bnd_carry_invoice_file {
    private int id;
    private String customer_no;
    private String invoice_no;
    private Double carton_qty;
    private String customer_item_spec;
    private Double packing_qty;
    private Double amt_cn;
    private Double selling_price;
    private String currency;
    private String unit;
    private String trade_mode;
    private String fax_no;
    private String cable_address;
    private String telephone_no;
    private String cop_list_no;
    private String ship_to_name;
    private String address2_dbcs;
    private String ship_no;
    private String departure_code;
    private String ship_to_code;
    private String shipped_date;
    private String invoice_date;
    private Double net_weight;
    private Double gross_weight;
    private Double img_no;
    private Double ucns_verno;
    private String invoice_type;
    private Date login_time;
    private String login_oid;
    private Date update_time;
    private String update_oid;
    private String update_program;


}
