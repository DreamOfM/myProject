package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Time;
import java.util.Date;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_develop</h3>
 * @ClassName<h4></h4>
 * @清单删除写入表
 * @date : 2020-05-23 15:07
 * @version:1.0
 **/
@Data
public class Bnd_master_invt_del_h {
    private int id;
    private String data_state;//數據狀態
    private String ems_no;//加工贸易账册编号
    private String internal_number;//企業內部編號
    private String bizop_etpsno                            ;//經營單位編碼
    private String receive_enterprise_no;//收货企业编号
    private String dcl_etpsno;//海關十位元編碼
    private String bill_no;//清单编号
    private Date declare_date;//報關日期
    private Date declaration_date ;//报关单申报日期
    private String corresponding_customs_declaration_no;//对应报关单编号
    private String associated_list_no ;//关联清单编号
    private String related_record_no ;//关联备案编号
    private String related_customs_declaration_no ;//关联报关单编号
    private String rel_declaration_domestic_rd_no;//关联报关单境内收发货编号
    private String rel_declaration_customs_rd_no;//关联报关单海关收发货编号
    private String rel_declaration_customs_applicant_code ;//关联报关单海关申报单位编码
    private String import_export_gate;//进出境关别
    private String declare_port;//申報口岸
    private String import_export_mark_code;//进出口标记代码
    private String part_sign_code;//料件成品标记代码
    private String supervision_mode_code ;//监管方式代码
    private String transport_code;//运输方式代码
    private String declaration_flag;//是否报关标志
    private String customs_declaration_type_code;//报关类型代码
    private String check_mark_code;//核扣标记代码
    private String list_import_export_state_code;//清单进出卡口状态代码
    private Date withholding_time;//预核扣时间
    private Date finish_valid_time                       ;//結束有效期
    private String apcret_no                               ;//批准證編號
    private String circulation_type;//流转类型
    private String input_code                              ;//錄入單位編碼
    private String declarant_ic_no;//申报人IC卡号
    private Date input_date                              ;//錄入日期
    private String list_state;//清单状态
    private String corresponding_customs_unit_code;//对应报关单申报单位代码
    private String customs_declaration_type;//报关单类型
    private Double chg_tms_cnt                             ;//變更次數
    private String origin_destination_country;//国家代码
    private String list_type;//清单类型
    private String declaration_state;//报关状态
    private String check_pass_flag_code;//核放单生成标志代码
    private String dcl_etps_typecd                         ;//申報單位類型
    private String declaration_sync_alt_flag;//报关单同步修改标志
    private String taxis_amount;//计征金额
    private String trade_country;//贸易国
    private String rmk                                     ;//備註
    private String declaration_no;//報關單號
    private Time login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;

}
