package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Date;

@Data
public class Bnd_master_purchase_price {
    private int id;
    private String vendor_no;
    private String item_no;
    private Double revision_no;
    private String terms_trade;
    private Date effective_date;
    private String effective_date1;

    private Date expiration_date;
    private String expiration_date1;
    private String um_purchase;
    private Double cf_purchase;
    private Double price;
    private String maker_code;
    private String vendor_item_no;
    private String currency;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;


   }
