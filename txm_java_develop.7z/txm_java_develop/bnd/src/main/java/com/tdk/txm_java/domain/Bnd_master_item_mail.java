package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Date;

@Data
public class Bnd_master_item_mail {
    private int id;
    private String item_no;//品名代码
    private String state;//状态
    private String item_spec;//品名规格
    private String item_spec_new;//品名规格
    private String bonded_logo;//保税标志
    private String bonded_logo_new;//保税标志
    private String item_class_code;//品名分类代码
    private String item_class_code_new;//品名分类代码
    private String um_incoming_outgoing;//计量单位（入出库）
    private String um_incoming_outgoing_new;//计量单位（入出库）
    private String um_physical_inventory;//计量单位（盘点）
    private String um_physical_inventory_new;//计量单位（盘点）
    private Double cf_physical_inventory;//盘点单位换算系数
    private Double cf_physical_inventory_new;//盘点单位换算系数
    private String sorting_key4;//分类代码４
    private String sorting_key4_new;//分类代码４
    private Double net_weigh;//净重
    private Double net_weigh_new;//净重
    private String net_weigh_s;//净重
    private String net_weigh_new_s;//净重

    private Date login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

}
