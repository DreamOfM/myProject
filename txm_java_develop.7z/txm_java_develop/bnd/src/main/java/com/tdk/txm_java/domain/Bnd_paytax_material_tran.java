package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Time;
import java.util.Date;

@Data
public class Bnd_paytax_material_tran {
    private int id;
    private String declaration_no;
    private String internal_number;
    private String list_no;
    private Date apply_date;
    private Date paytax_date;
    private String ems_no;
    private String item_class_code;
    private String item_no;
    private String ccc_code;
    private Double tax_rate;
    private Double img_no;
    private Double used_qty;
    private Double used_amt;
    private Double used_wet;
    private String um_physical_inventory;
    private String currency;
    private String paytax_declaration_no1;
    private Double paytax_qty1;
    private String paytax_declaration_no2;
    private Double paytax_qty2;
    private String paytax_declaration_no3;
    private Double paytax_qty3;
    private String paytax_declaration_no4;
    private Double paytax_qty4;
    private String paytax_declaration_no5;
    private Double paytax_qty5;
    private String country_code;
    private String remark_1;
    private String remark_2;
    private Time login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;

}
