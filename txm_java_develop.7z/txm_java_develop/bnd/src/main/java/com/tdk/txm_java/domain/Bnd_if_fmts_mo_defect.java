package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_if_fmts_mo_defect {
    private int id;
    private String mdcoce;//CO_CODE
    private String mdyymm;//STAKE_MONTH
    private String mdsapm;//SAP_MO
    private String mdmonr;//MTS_LOT
    private String mdwipi;//WIP_ID
    private String mditnr;//ITEM NO.
    private Double mdopsq;//OPERATION SEQUENCE NO.
    private String mdwknr;//WORK CENTER NO.
    private String mddfcd;//DEFECT CODE
    private Double mddftq;//DEFECT QTY
    private String mdrcdt;//RECORD TYPE
    private String mdstat;//0-SEND 1-COMPLETED
    private String mdupdt;//UPDATE TIME





    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;


}
