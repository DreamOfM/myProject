package com.tdk.txm_java.domain;

import lombok.Data;

/**
 * @Author Yu Liqin
 * @Description //TODO a801550
 * @Date  2020/7/8
 * @Time  上午 09:42
 **/

@Data
public class Bnd_master_use_code {
    private int id;
    private String use_code;
    private String use_code_name;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

}
