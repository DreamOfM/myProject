package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_if_fmts_mo_h {
    private int id;
    private String mhcoce;//部門代碼
    private String mhplnt;//關帳年月
    private String mhmonr;//製造訂單號碼
    private String mhtype;//SAP MO類型
    private String mhpdvr;//MO生產版本
    private String mhitnr;//品番
    private String mhitds;//ITEM DESCRIPTIONS
    private Double mhplnq;//投入數
    private String mhpstd;//計劃開始日
    private String mhpcpd;//計劃完成日
    private String mhstlc;//STORAGE LOCATION
    private Double mhbbom;//BOM基數
    private String mhrtnr;//製造途程代碼
    private String mhpdsv;//生產管理者
    private String mhcpit;//參考品番
    private String mhioum;//單位
    private String mhmdqa;//模穴/等級
    private String mhcunr;//顧客代碼
    private String mhrgdd;//開始日
    private String mhlotc;//批次管理區分
    private String mhbond;//保稅標示
    private String mhpfct;//利潤中心
    private String mhlbfg;//顧客承認標示
    private String mhflag;//標示
    private Double mhstat;//狀態
    private String mhupsr;//更新操作員代碼
    private String mhupdt;//更新時間

    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;


}
