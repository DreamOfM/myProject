package com.tdk.txm_java.domain;

public class Bnd_master_customs {
    //关区代码
    private int id;

    private Double customs_code;  //关区代码
    private String customs_name;   //关区名称

    private String login_time;
    private String login_oid;//登陆操作员代码
    private String update_time;
    private String update_oid;
    private String update_program;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Double getCustoms_code() {
        return customs_code;
    }

    public void setCustoms_code(Double customs_code) {
        this.customs_code = customs_code;
    }

    public String getCustoms_name() {
        return customs_name;
    }

    public void setCustoms_name(String customs_name) {
        this.customs_name = customs_name;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    @Override
    public String toString() {
        return "Bnd_master_customs{" +
                "id=" + id +
                ", customs_code=" + customs_code +
                ", customs_name='" + customs_name + '\'' +
                ", login_time='" + login_time + '\'' +
                ", login_oid='" + login_oid + '\'' +
                ", update_time='" + update_time + '\'' +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                '}';
    }
}
