package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Time;
import java.util.Date;

@Data
public class Bnd_import_operation {
    private int id;
    private String invoice_no;
    private String mrp_code_1;
    private String mrp_code_2;
    private String mrp_code_3;
    private String mrp_code_4;
    private String mrp_code_5;
    private String mrp_code_6;
    private String mrp_code_7;
    private String mrp_code_8;
    private String mrp_code_9;
    private String mrp_code_10;
    private String mrpcode;
    private String type_1;
    private String type_2;
    private String type_3;
    private String type_4;
    private String type_5;
    private String type;
    private Integer pieces;
    private Date industrial_development_date;
    private String industrial_development_date2;
    private Date receiving_date ;
    private String receiving_date2 ;
    private String industrial_development_type;
    private String industrial_development_place;
    private String ori_no;
    private Double net_weight;
    private Double gross_weight;
    private Date rcnt_vclr_time;
    private String rcnt_vclr_time2;
    private Date depart_port_date;
    private String depart_port_date2;
    private String depart_flight_no;
    private Date transit_port_arrival_date;
    private String transit_port_arrival_date2;
    private Date transit_port_industrial_development_date ;
    private String transit_port_industrial_development_date2 ;
    private String transit_port_flight_no;
    private String bl_no;
    private Double bl_gross;
    private Double bl_volume;
    private Date last_arrival_date;
    private String last_arrival_date2;
    private Date arrival_date;
    private String arrival_date2;
    private Double declaration_amount;
    private String de_currency;
    private Double iv_amount;
    private String iv_currency;
    private String customs_broker;
    private Date declaration_date;
    private String declaration_date1;
    private String declaration_date2;
    private Date regress_date;
    private String regress_date2;
    private Date actual_declaration_date;//实际报关日期
    private String actual_declaration_date2;//实际报关日期

    private Double clearance_lt;
    private Double whole_course_lt;
    private String carrier;
    private String terms_trade;//贸易条件
    private String pay_state;//付款状态
    private String forwarder_code;
    private String fn_no;//分单号

    private String container_no;
    private String reason_delay;
    private String express_no;
    private Date pass_date;
    private String pass_date2;
    private String note;
    private String declaration_no;
    private String reduction_tax_no ;
    private String note_1;
    private String note_2;
    private String note_3;
    private String note_4;
    private String special_supervision_area;
    private String packing_code;
    private String plant_code;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;
    private String trade_term_dbsc;//贸易描述
    private String trade_term_abbr;//贸易简称
    private String freight_code;//货运公司代码
    private String vendor_no;//供应商代码
    private String company_name;//货运公司名称

}
