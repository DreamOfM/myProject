package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Date;
import java.sql.Time;

@Data

public class Bnd_export_delivery_note_file {
    private int id;
    private String invoice_no;//發票號碼
    private String  shipped_date;//出货日期
    private String flag1;//是否可做送貨單
    private String flag2;//送貨單已做標識
    private String type_nm;//送貨單方式
    private String type;//送貨單方式
    private String delivery_note_name;//送貨單名称
     private String sold_to_name;
     private String port_description;
    private Time login_time;//登陆时间login_time
    private String login_oid;//登陆人员login_oid
    private Time update_time;//更新时间update_time
    private String update_oid;//更新人员update_oid
    private String update_program;//更新程序update_program



}
