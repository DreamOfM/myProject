package com.tdk.txm_java.domain;

import lombok.Data;

@Data

public class Bnd_export_delivery_note_temp {
    private int id;
    private String shipped_date;//出貨日期
    private Double packing_amout_qty;//包裝數
    private Double amt_cn;//裝箱金額（本國）
    private Double amt_foreign;//裝箱金額（外幣）
    private String currency;//貨幣代碼
    private Double box_from;//總箱數
    private Double total_netwet;//總淨重
    private Double total_grosswet;//總箱重
    private String shipping_condition_code;//運送方式
    private String invoice_no;//發票號碼
    private String customer_no;//顧客代碼
    private String item_no;//品名代碼
    private String customer_item_code;//顧客品名代碼
    private String customer_po;//顧客購買訂單號碼
    private String po_no ;//購買訂單號碼
    private Double packing_qty;//包裝數
    private Double net_weigh;//淨重
    private Double caton_weight;//箱重
    private Double sampling_principle;//賣價
    private Double catton_qty_by_dn;// DN的箱数
    private Double carton_no_from;//箱號ＦＲＯＭ
    private Double carton_no_to;//箱號ＴＯ
    private Double dn_qty ;//dn别數量
    private String um_incoming_outgoing;//计量单位（入出库）
    private String item_spec;//品名规格
    private String rohs_flag;//保税标识
    private String customer_name_abbr;//顧客簡稱


}
