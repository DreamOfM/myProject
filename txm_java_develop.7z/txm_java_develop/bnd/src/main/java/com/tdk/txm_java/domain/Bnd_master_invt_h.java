package com.tdk.txm_java.domain;



import lombok.Data;

import java.sql.Time;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_dev0604</h3>
 * @ClassName<h4></h4>
 * @ToDo<p>报关清单生成中间档——表头</p>
 * @date : 2020-07-04 10:18
 * @version:1.0
 **/
@Data
public class Bnd_master_invt_h {
    private int id;
    private String data_state;//數據狀態
    private String ems_no;//備案編號
    private String internal_number;//企業內部清單編號
    private String bizop_etpsno;//經營企業編號
    private String bizop_etps_nm;//經營企業名
    private String receive_enterprise_no;//收貨企業編號
    private String dcl_etpsno;//申報企業編號
    private String bill_no;//清單編號
    private String declare_date;//清單申報時間
    private String declaration_date;//報關單申報日期
    private String corresponding_customs_declaration_no;//對應報關單編號
    private String associated_list_no;//關聯清單編號
    private String related_record_no;//關聯備案編號
    private String related_customs_declaration_no;//關聯報關單編號
    private String rel_declaration_domestic_rd_no;//關聯報關單境內收發貨編號
    private String rel_declaration_customs_rd_no;//關聯報關單海關收發貨編號
    private String rel_declaration_customs_applicant_code;//關聯報關單海關申報單位編碼
    private String import_export_gate;//進出境關別
    private String declare_port;//申報地關區代碼
    private String import_export_mark_code;//進出口標記代碼
    private String part_sign_code;//料件成品標記代碼
    private String supervision_mode_code;//監管方式代碼
    private String transport_code;//運輸方式代碼
    private String declaration_flag;//是否報關標志
    private String customs_declaration_type_code;//報關類型代碼
    private String check_mark_code;//核扣標記代碼
    private String list_import_export_state_code;//清單進出卡口狀態代碼
    private String withholding_time;//預核扣時間
    private String finish_valid_time;//正式核扣時間
    private String apcret_no;//申請表編號
    private String circulation_type;//流轉類型
    private String input_code;//錄入企業編號
    private String declarant_ic_no;//申報人IC卡號
    private String input_date;//錄入日期
    private String list_state;//清單狀態
    private String corresponding_customs_unit_code;//對應報關單申報單位代碼
    private String customs_declaration_type;//報關單類型
    private Double chg_tms_cnt;//修改變更次數
    private String origin_destination_country;//起運/運抵國(地區）
    private String list_type;//清單類型
    private String declaration_state;//報關狀態
    private String check_pass_flag_code;//核放單生成標志代碼
    private String dcl_etps_typecd;//申報類型
    private String declaration_sync_alt_flag;//報關單同步修改標志
    private String taxis_amount;//計征金額
    private String trade_country;//貿易國
    private String rmk;//備注
    private String declaration_no;//報關單預錄入編號X(18)
    //用于存放H2DDP的dcl_etps_nm字段
    private String Invt_nm;//核注单位名称
    private String  dcl_nm;//申报日
    private String dcl_etpsno_nm;//核注单位名称
    private String corresponding_customs_unit_nm;//报关单位名称
    private String  dcl_date;//申报日

    private Bnd_master_declare_list bndMasterDeclareList;//报关单列表
    private Bnd_carry_cif_price bndCarryCifPrice;

    private String login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;
    private String type;//手动回执特殊处理 type=1



}
