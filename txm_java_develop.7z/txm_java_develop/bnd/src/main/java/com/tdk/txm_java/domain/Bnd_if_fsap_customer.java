package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_if_fsap_customer {
    private int id;
    private String customer_no;
    private String account_group;
    private String customer_name1_dbcs;
    private String customer_name1;
    private String customer_name_abbr_dbcs;
    private String customer_name_abbr;
    private String address1_dbcs;
    private String address1;
    private String invoice_type;
    private String tax_code2;
    private String currency;
    private String country_code;
    private String city_name_dbcs;
    private String state;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;


}
