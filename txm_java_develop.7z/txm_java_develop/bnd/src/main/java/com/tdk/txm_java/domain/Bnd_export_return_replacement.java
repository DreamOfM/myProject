package com.tdk.txm_java.domain;

import lombok.Data;

import java.util.Date;

@Data
public class Bnd_export_return_replacement {
    private int id;
    private String so_no ;//AASONO
    private String return_so;//退貨聯絡書
    private String indication_type;//指示類別
    private String invoice_no;//原出貨發票
    private String replacement_invoice;//補貨出貨發票
    private String return_invoice;//退貨發票
    private String item_no;//品名代碼
    private String statement_customer_no;//負責付款顧客
    private String ship_to_code;//出貨對象
    private String item_spec;//品名規格
    private String customer_item_code;//顧客品名代碼
    private String state;//狀態
    private Double packing_qty;//原裝箱數
    private Double indication_qty;//指示數量
    private String input_date                              ;//指示日期
    private Double lost_qty;//落帳數
    private String plan_shipping_date;//計畫補貨日或退貨日
    private String actual_shipping_date;//實際補貨日或退貨日
    private String custom_flag;//報關標示
    private String alternate_field;//備用1
    private Double ucns_verno;//AAEXGV
    private String customer_no;//AACUNR
    private Date login_time;//登陆时间login_time
    private String login_oid;
    private Date update_time;
    private String update_oid;
    private String update_program;


}
