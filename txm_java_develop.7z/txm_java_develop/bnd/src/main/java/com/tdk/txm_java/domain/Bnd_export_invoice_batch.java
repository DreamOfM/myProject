package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Time;
import java.util.List;

@Data
public class Bnd_export_invoice_batch {
    private int id;
    private String invoice_no;
    private Integer packing_serial;
    private String item_no;
    private String lot_no;
    private String release_status;
    private Double transaction_qty;
    private Double transaction_amt;
    private String transaction_date;
    private String bond_type;
    private String yyyymm;
    private String um_incoming_outgoing;
    private String um_physical_inventory;
    private Double cf_physical_inventory;
    private Double ucns_verno;
    private List<Bnd_master_bom> bnd_master_boms;


    private Time login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;


}
