package com.tdk.txm_java.domain;

import lombok.Data;
import java.util.Date;


public class Bnd_apply_qualification_h {
    private int id;
    private String file_no;
    private String data_state;
    private String seq_no;
    private String et_arcrp_no;
    private Double chg_tms_cnt;
    private String etps_preent_no;
    private String master_cuscd;
    private String bizop_etps_sccd;
    private String bizop_etpsno;
    private String bizop_etps_nm;
    private String prcs_etps_sccd;
    private String prcs_etpsno;
    private String prcs_etps_nm;
    private String dec_dm;
    private String dcl_etpsno;
    private String dcl_etps_nm;
    private String dcl_etps_typecd;
    private String conc_addr;
    private String telephone_no;
    private Date finish_valid_time;
    private Double prcs_prdc_ablt_amt;
    private String apcret_no;
    private String risk_assure_markcd;
    private String rlt_form_no;
    private String dcl_source_markcd;
    private String dcl_typecd;
    private Date dcl_time;
    private String emapv_stucd;
    private String exe_markcd;
    private Date putrec_appr_time;
    private Date chg_appr_time;
    private String rmk;
    private String input_code;
    private String input_credit_code;
    private String input_name;
    private Date input_date;
    private String ems_type;
    private Date login_time;
    private String login_oid;
    private Date update_time;
    private String update_oid;
    private String update_program;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFile_no() {
        return file_no;
    }

    public void setFile_no(String file_no) {
        this.file_no = file_no;
    }

    public String getData_state() {
        return data_state;
    }

    public void setData_state(String data_state) {
        this.data_state = data_state;
    }

    public String getSeq_no() {
        return seq_no;
    }

    public void setSeq_no(String seq_no) {
        this.seq_no = seq_no;
    }

    public String getEt_arcrp_no() {
        return et_arcrp_no;
    }

    public void setEt_arcrp_no(String et_arcrp_no) {
        this.et_arcrp_no = et_arcrp_no;
    }

    public Double getChg_tms_cnt() {
        return chg_tms_cnt;
    }

    public void setChg_tms_cnt(Double chg_tms_cnt) {
        this.chg_tms_cnt = chg_tms_cnt;
    }

    public String getEtps_preent_no() {
        return etps_preent_no;
    }

    public void setEtps_preent_no(String etps_preent_no) {
        this.etps_preent_no = etps_preent_no;
    }

    public String getMaster_cuscd() {
        return master_cuscd;
    }

    public void setMaster_cuscd(String master_cuscd) {
        this.master_cuscd = master_cuscd;
    }

    public String getBizop_etps_sccd() {
        return bizop_etps_sccd;
    }

    public void setBizop_etps_sccd(String bizop_etps_sccd) {
        this.bizop_etps_sccd = bizop_etps_sccd;
    }

    public String getBizop_etpsno() {
        return bizop_etpsno;
    }

    public void setBizop_etpsno(String bizop_etpsno) {
        this.bizop_etpsno = bizop_etpsno;
    }

    public String getBizop_etps_nm() {
        return bizop_etps_nm;
    }

    public void setBizop_etps_nm(String bizop_etps_nm) {
        this.bizop_etps_nm = bizop_etps_nm;
    }

    public String getPrcs_etps_sccd() {
        return prcs_etps_sccd;
    }

    public void setPrcs_etps_sccd(String prcs_etps_sccd) {
        this.prcs_etps_sccd = prcs_etps_sccd;
    }

    public String getPrcs_etpsno() {
        return prcs_etpsno;
    }

    public void setPrcs_etpsno(String prcs_etpsno) {
        this.prcs_etpsno = prcs_etpsno;
    }

    public String getPrcs_etps_nm() {
        return prcs_etps_nm;
    }

    public void setPrcs_etps_nm(String prcs_etps_nm) {
        this.prcs_etps_nm = prcs_etps_nm;
    }

    public String getDec_dm() {
        return dec_dm;
    }

    public void setDec_dm(String dec_dm) {
        this.dec_dm = dec_dm;
    }

    public String getDcl_etpsno() {
        return dcl_etpsno;
    }

    public void setDcl_etpsno(String dcl_etpsno) {
        this.dcl_etpsno = dcl_etpsno;
    }

    public String getDcl_etps_nm() {
        return dcl_etps_nm;
    }

    public void setDcl_etps_nm(String dcl_etps_nm) {
        this.dcl_etps_nm = dcl_etps_nm;
    }

    public String getDcl_etps_typecd() {
        return dcl_etps_typecd;
    }

    public void setDcl_etps_typecd(String dcl_etps_typecd) {
        this.dcl_etps_typecd = dcl_etps_typecd;
    }

    public String getConc_addr() {
        return conc_addr;
    }

    public void setConc_addr(String conc_addr) {
        this.conc_addr = conc_addr;
    }

    public String getTelephone_no() {
        return telephone_no;
    }

    public void setTelephone_no(String telephone_no) {
        this.telephone_no = telephone_no;
    }

    public Date getFinish_valid_time() {
        return finish_valid_time;
    }

    public void setFinish_valid_time(Date finish_valid_time) {
        this.finish_valid_time = finish_valid_time;
    }

    public Double getPrcs_prdc_ablt_amt() {
        return prcs_prdc_ablt_amt;
    }

    public void setPrcs_prdc_ablt_amt(Double prcs_prdc_ablt_amt) {
        this.prcs_prdc_ablt_amt = prcs_prdc_ablt_amt;
    }

    public String getApcret_no() {
        return apcret_no;
    }

    public void setApcret_no(String apcret_no) {
        this.apcret_no = apcret_no;
    }

    public String getRisk_assure_markcd() {
        return risk_assure_markcd;
    }

    public void setRisk_assure_markcd(String risk_assure_markcd) {
        this.risk_assure_markcd = risk_assure_markcd;
    }

    public String getRlt_form_no() {
        return rlt_form_no;
    }

    public void setRlt_form_no(String rlt_form_no) {
        this.rlt_form_no = rlt_form_no;
    }

    public String getDcl_source_markcd() {
        return dcl_source_markcd;
    }

    public void setDcl_source_markcd(String dcl_source_markcd) {
        this.dcl_source_markcd = dcl_source_markcd;
    }

    public String getDcl_typecd() {
        return dcl_typecd;
    }

    public void setDcl_typecd(String dcl_typecd) {
        this.dcl_typecd = dcl_typecd;
    }

    public Date getDcl_time() {
        return dcl_time;
    }

    public void setDcl_time(Date dcl_time) {
        this.dcl_time = dcl_time;
    }

    public String getEmapv_stucd() {
        return emapv_stucd;
    }

    public void setEmapv_stucd(String emapv_stucd) {
        this.emapv_stucd = emapv_stucd;
    }

    public String getExe_markcd() {
        return exe_markcd;
    }

    public void setExe_markcd(String exe_markcd) {
        this.exe_markcd = exe_markcd;
    }

    public Date getPutrec_appr_time() {
        return putrec_appr_time;
    }

    public void setPutrec_appr_time(Date putrec_appr_time) {
        this.putrec_appr_time = putrec_appr_time;
    }

    public Date getChg_appr_time() {
        return chg_appr_time;
    }

    public void setChg_appr_time(Date chg_appr_time) {
        this.chg_appr_time = chg_appr_time;
    }

    public String getRmk() {
        return rmk;
    }

    public void setRmk(String rmk) {
        this.rmk = rmk;
    }

    public String getInput_code() {
        return input_code;
    }

    public void setInput_code(String input_code) {
        this.input_code = input_code;
    }

    public String getInput_credit_code() {
        return input_credit_code;
    }

    public void setInput_credit_code(String input_credit_code) {
        this.input_credit_code = input_credit_code;
    }

    public String getInput_name() {
        return input_name;
    }

    public void setInput_name(String input_name) {
        this.input_name = input_name;
    }

    public Date getInput_date() {
        return input_date;
    }

    public void setInput_date(Date input_date) {
        this.input_date = input_date;
    }

    public String getEms_type() {
        return ems_type;
    }

    public void setEms_type(String ems_type) {
        this.ems_type = ems_type;
    }

    public Date getLogin_time() {
        return login_time;
    }

    public void setLogin_time(Date login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public Date getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(Date update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    @Override
    public String toString() {
        return "Bnd_apply_qualification_h{" +
                "id=" + id +
                ", file_no='" + file_no + '\'' +
                ", data_state='" + data_state + '\'' +
                ", seq_no='" + seq_no + '\'' +
                ", et_arcrp_no='" + et_arcrp_no + '\'' +
                ", chg_tms_cnt=" + chg_tms_cnt +
                ", etps_preent_no='" + etps_preent_no + '\'' +
                ", master_cuscd='" + master_cuscd + '\'' +
                ", bizop_etps_sccd='" + bizop_etps_sccd + '\'' +
                ", bizop_etpsno='" + bizop_etpsno + '\'' +
                ", bizop_etps_nm='" + bizop_etps_nm + '\'' +
                ", prcs_etps_sccd='" + prcs_etps_sccd + '\'' +
                ", prcs_etpsno='" + prcs_etpsno + '\'' +
                ", prcs_etps_nm='" + prcs_etps_nm + '\'' +
                ", dec_dm='" + dec_dm + '\'' +
                ", dcl_etpsno='" + dcl_etpsno + '\'' +
                ", dcl_etps_nm='" + dcl_etps_nm + '\'' +
                ", dcl_etps_typecd='" + dcl_etps_typecd + '\'' +
                ", conc_addr='" + conc_addr + '\'' +
                ", telephone_no='" + telephone_no + '\'' +
                ", finish_valid_time=" + finish_valid_time +
                ", prcs_prdc_ablt_amt=" + prcs_prdc_ablt_amt +
                ", apcret_no='" + apcret_no + '\'' +
                ", risk_assure_markcd='" + risk_assure_markcd + '\'' +
                ", rlt_form_no='" + rlt_form_no + '\'' +
                ", dcl_source_markcd='" + dcl_source_markcd + '\'' +
                ", dcl_typecd='" + dcl_typecd + '\'' +
                ", dcl_time=" + dcl_time +
                ", emapv_stucd='" + emapv_stucd + '\'' +
                ", exe_markcd='" + exe_markcd + '\'' +
                ", putrec_appr_time=" + putrec_appr_time +
                ", chg_appr_time=" + chg_appr_time +
                ", rmk='" + rmk + '\'' +
                ", input_code='" + input_code + '\'' +
                ", input_credit_code='" + input_credit_code + '\'' +
                ", input_name='" + input_name + '\'' +
                ", input_date=" + input_date +
                ", ems_type='" + ems_type + '\'' +
                ", login_time=" + login_time +
                ", login_oid='" + login_oid + '\'' +
                ", update_time=" + update_time +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                '}';
    }
}
