package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_if_fmts_mo {
    private int id;
    private String mococe;//部門代碼
    private String moyymm;//關帳年月
    private String momonr;//SAP製造訂單號碼
    private String moltno;//MTS LOT號
    private String mobach;//LOT 入庫批次
    private String mowipn;//WIP_ID
    private String moitnr;//品番
    private String motype;//SAP MO類型 ZP01正常 ZP39再生  ZP02 重工 ZP34转品番
    private String molotp;//LOT類型 N正常 S分割 M合并 C转品番
    private String mortnr;//製造途程代碼
    private String morvnr;//製造途程版本
    private Double moplnq;//投入數
    private Double morgdd;//開始日
    private String mowips;//順序號
    private Double mocops;//當前工序
    private String mocwkn;//當前工作站
    private String moline;//生產線
    private String mojobn;//工作代碼
    private String mocunr;//顧客代碼
    private String mojob2;//捺印號
    private String moflag;//標示
    private String mostat;//狀態
    private String moupsr;
    private String moupdt;

    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;


}
