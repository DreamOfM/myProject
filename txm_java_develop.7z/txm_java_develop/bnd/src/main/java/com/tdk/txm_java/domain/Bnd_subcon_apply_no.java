package com.tdk.txm_java.domain;

import lombok.Data;

import java.util.Date;


@Data
public class Bnd_subcon_apply_no {
    private  int id;
    private String operation_no;//委外流水号
    private String operation_no1;//委外流水号
    private String apply_no;//申請表編號
    private String no_type;//流水號類型
    private String mrp_code;//ＭＲＰ基準代碼
    private String psa_code;//PSA
    private String vendor_code;//供應商代碼
    private String no_control;//號碼類型
    private Integer current_no;//序列號
    private String vendor_name_abbr_dbcs;//供應商名稱
    private String apply_date;//申請日期
    private String date_from;//開始日期
    private String date_to;//結束日期
    private String operation_type;//委外程度
    private String flag;//備案標誌

    private Date login_time;
    private String login_oid;
    private Date update_time;
    private String update_oid;
    private String update_program;

}
