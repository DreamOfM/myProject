package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_stock_psa_upload {
    private int id;
    private String storage_type;//STORAGE TYPE
    private String item_no;//MATERIAL
    private String batch_no;//BATCH
    private Double quantity;//QUANTITY
    private String unit_code;//UNIT
    private String bonded_logo;//BOND
    private String custom_bin;//CUSTOM BIN
    private String login_time;//登陆时间login_time
    private String login_oid;//登陆人员login_oid
    private String update_time;//更新时间update_time
    private String update_oid;//更新人员update_oid
    private String update_program;//更新程序update_program
    private int count;

}
