package com.tdk.txm_java.controller;

import com.tdk.txm_java.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/bnd_export_invoice_h")
public class Bnd_export_invoice_hController {
    @Autowired
    private IBnd_export_invoice_hService iBnd_export_invoice_hService;





    @RequestMapping("/domesticNonbond.do")
    public void domesticNonbond() throws Exception {

        System.out.println("domestic_nonbond finish");
    }

}





