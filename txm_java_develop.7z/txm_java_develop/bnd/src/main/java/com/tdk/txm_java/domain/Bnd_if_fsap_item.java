package com.tdk.txm_java.domain;

import lombok.Data;

import java.sql.Time;

@Data
public class Bnd_if_fsap_item {
    private int id;
    private String m1itnr;
    private String m1mttp;
    private String m1prfg;
    private String m1prsf;
    private String m1itdd;
    private String m1itds;
    private String m1spec;
    private String m1icls;
    private String m1hscd;
    private Double m1rate;
    private String m1ioum;
    private String m1pium;
    private Double m1picf;
    private String m1wtum;
    private Double m1wrnt;
    private Double m1ntwt;
    private String m1bond;
    private String m1mrpc;
    private String m1gnbr;
    private String m1egnr;
    private String m1std4;
    private Double m1pltq;
    private String m1itgp;
    private Double m1stdc;
    private Double m1sdcn;
    private String m1srt1;
    private String m1srt2;
    private String m1srt3;
    private String m1srt4;
    private String m1srt5;
    private String m1srt6;
    private String m1srt7;
    private String m1srt8;
    private String m1srt9;
    private String m1srt0;
    private String m1itza;
    private String m1stkc;
    private String m1rohs;
    private String m1titd;
    private Double m1stat;
    private Double m1updt;
    private Time login_time;
    private String login_oid;
    private Time update_time;
    private String update_oid;
    private String update_program;

}
