package com.tdk.txm_java.domain;

import lombok.Data;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java_dev0604</h3>
 * @ClassName<h4></h4>
 * @ToDo<p>运输代码档案</p>
 * @date : 2020-07-07 13:43
 * @version:1.0
 **/
@Data
public class Bnd_master_trans_code {
    private int id;
    private String trans_mode;
    private String trans_mode_name;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

}
