package com.tdk.txm_java.domain;

import lombok.Data;

import java.util.Date;

@Data
public class Bnd_master_mo_recycle {
    private int id;
    private String co_code;
    private String mo_no;
    private Double operation_sequence_no;
    private String recy_date;
    private String defect_mts_lot;
    private Double def_opr_id;
    private Double recy_qty;
    private Double domestic_use_qty;

    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;


}
