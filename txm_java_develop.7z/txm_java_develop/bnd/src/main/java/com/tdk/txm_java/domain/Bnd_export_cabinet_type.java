package com.tdk.txm_java.domain;

import lombok.Data;

import java.util.Date;

@Data
public class Bnd_export_cabinet_type {
    private int id;
    private String declare_port;//口岸
    private String declare_date;//清單申報日期
    private String internal_number;//歸併前清單編號
    private String city_name_dbcs;//目的港
    private Integer type_LCL;//LCL
    private Integer type_20;//20
    private Integer type_40;//40
    private Integer type_45;//45
    private String login_time;//登陆时间login_time
    private String login_oid;//登陆人员login_oid
    private String update_time;//更新时间update_time
    private String update_oid;//更新人员update_oid
    private String update_program;//更新程序update_program

}
