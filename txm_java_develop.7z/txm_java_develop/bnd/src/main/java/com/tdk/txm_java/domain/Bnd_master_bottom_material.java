package com.tdk.txm_java.domain;

public class Bnd_master_bottom_material {
    private int id;
    private String mrpcode;
    private String mo_no;
    private Double operation_sequence_no;
    private String equipment_name;
    private String item_no;
    private String material_item_no;
    private Double cf_physical_inventory;
    private Double componentparent_itemc;
    private Double loss_quantity;
    private Double product_loss_quantity;
    private Double material_cf;
    private Double dec_cm;
    private Double dec_dm;
    private Double gds_seqno;
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;
    private Double img_no;
    private String um_physical_inventory;
    private String item_description_dbcs;
    private String item_spec;
    private String ccc_code;


    public String getCcc_code() {
        return ccc_code;
    }

    public void setCcc_code(String ccc_code) {
        this.ccc_code = ccc_code;
    }

    public Double getImg_no() {
        return img_no;
    }

    public void setImg_no(Double img_no) {
        this.img_no = img_no;
    }

    public String getUm_physical_inventory() {
        return um_physical_inventory;
    }

    public void setUm_physical_inventory(String um_physical_inventory) {
        this.um_physical_inventory = um_physical_inventory;
    }

    public String getItem_description_dbcs() {
        return item_description_dbcs;
    }

    public void setItem_description_dbcs(String item_description_dbcs) {
        this.item_description_dbcs = item_description_dbcs;
    }

    public String getItem_spec() {
        return item_spec;
    }

    public void setItem_spec(String item_spec) {
        this.item_spec = item_spec;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMrpcode() {
        return mrpcode;
    }

    public void setMrpcode(String mrpcode) {
        this.mrpcode = mrpcode;
    }

    public String getMo_no() {
        return mo_no;
    }

    public void setMo_no(String mo_no) {
        this.mo_no = mo_no;
    }

    public Double getOperation_sequence_no() {
        return operation_sequence_no;
    }

    public void setOperation_sequence_no(Double operation_sequence_no) {
        this.operation_sequence_no = operation_sequence_no;
    }

    public String getEquipment_name() {
        return equipment_name;
    }

    public void setEquipment_name(String equipment_name) {
        this.equipment_name = equipment_name;
    }

    public String getItem_no() {
        return item_no;
    }

    public void setItem_no(String item_no) {
        this.item_no = item_no;
    }

    public String getMaterial_item_no() {
        return material_item_no;
    }

    public void setMaterial_item_no(String material_item_no) {
        this.material_item_no = material_item_no;
    }

    public Double getCf_physical_inventory() {
        return cf_physical_inventory;
    }

    public void setCf_physical_inventory(Double cf_physical_inventory) {
        this.cf_physical_inventory = cf_physical_inventory;
    }

    public Double getComponentparent_itemc() {
        return componentparent_itemc;
    }

    public void setComponentparent_itemc(Double componentparent_itemc) {
        this.componentparent_itemc = componentparent_itemc;
    }

    public Double getLoss_quantity() {
        return loss_quantity;
    }

    public void setLoss_quantity(Double loss_quantity) {
        this.loss_quantity = loss_quantity;
    }

    public Double getProduct_loss_quantity() {
        return product_loss_quantity;
    }

    public void setProduct_loss_quantity(Double product_loss_quantity) {
        this.product_loss_quantity = product_loss_quantity;
    }

    public Double getMaterial_cf() {
        return material_cf;
    }

    public void setMaterial_cf(Double material_cf) {
        this.material_cf = material_cf;
    }

    public Double getDec_cm() {
        return dec_cm;
    }

    public void setDec_cm(Double dec_cm) {
        this.dec_cm = dec_cm;
    }

    public Double getDec_dm() {
        return dec_dm;
    }

    public void setDec_dm(Double dec_dm) {
        this.dec_dm = dec_dm;
    }

    public Double getGds_seqno() {
        return gds_seqno;
    }

    public void setGds_seqno(Double gds_seqno) {
        this.gds_seqno = gds_seqno;
    }

    public String getLogin_time() {
        return login_time;
    }

    public void setLogin_time(String login_time) {
        this.login_time = login_time;
    }

    public String getLogin_oid() {
        return login_oid;
    }

    public void setLogin_oid(String login_oid) {
        this.login_oid = login_oid;
    }

    public String getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time = update_time;
    }

    public String getUpdate_oid() {
        return update_oid;
    }

    public void setUpdate_oid(String update_oid) {
        this.update_oid = update_oid;
    }

    public String getUpdate_program() {
        return update_program;
    }

    public void setUpdate_program(String update_program) {
        this.update_program = update_program;
    }

    @Override
    public String toString() {
        return "Bnd_master_bottom_material{" +
                "id=" + id +
                ", mrpcode='" + mrpcode + '\'' +
                ", mo_no='" + mo_no + '\'' +
                ", operation_sequence_no=" + operation_sequence_no +
                ", equipment_name='" + equipment_name + '\'' +
                ", item_no='" + item_no + '\'' +
                ", material_item_no='" + material_item_no + '\'' +
                ", cf_physical_inventory=" + cf_physical_inventory +
                ", componentparent_itemc=" + componentparent_itemc +
                ", loss_quantity=" + loss_quantity +
                ", product_loss_quantity=" + product_loss_quantity +
                ", material_cf=" + material_cf +
                ", dec_cm=" + dec_cm +
                ", dec_dm=" + dec_dm +
                ", gds_seqno=" + gds_seqno +
                ", login_time='" + login_time + '\'' +
                ", login_oid='" + login_oid + '\'' +
                ", update_time='" + update_time + '\'' +
                ", update_oid='" + update_oid + '\'' +
                ", update_program='" + update_program + '\'' +
                ", img_no=" + img_no +
                ", um_physical_inventory='" + um_physical_inventory + '\'' +
                ", item_description_dbcs='" + item_description_dbcs + '\'' +
                ", item_spec='" + item_spec + '\'' +
                ", ccc_code='" + ccc_code + '\'' +
                '}';
    }
}
