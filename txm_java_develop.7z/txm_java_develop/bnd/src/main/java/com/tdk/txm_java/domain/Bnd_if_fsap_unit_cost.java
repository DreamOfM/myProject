package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_if_fsap_unit_cost {
    private int id;
    private String item_no;//品名代码
    private Double operation_sequence_no;//作業順序號碼
    private Double unit_cost;//COST
    private Double csot_number;//COST NUMBER
    private Double state;//0-SEND 1-COMPLETED

    private String login_time;
    private String login_oid;//登陆操作员代码
    private String update_time;
    private String update_oid;
    private String update_program;

}
