package com.tdk.txm_java.domain;

public class Bnd_export_general_trade_temp {
    private int id;
    private String declaration_no;
    private double declaration_amt;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDeclaration_no() {
        return declaration_no;
    }

    public void setDeclaration_no(String declaration_no) {
        this.declaration_no = declaration_no;
    }

    public double getDeclaration_amt() {
        return declaration_amt;
    }

    public void setDeclaration_amt(double declaration_amt) {
        this.declaration_amt = declaration_amt;
    }

    @Override
    public String toString() {
        return "Bnd_export_general_trade_temp{" +
                "id=" + id +
                ", declaration_no='" + declaration_no + '\'' +
                ", declaration_amt=" + declaration_amt +
                '}';
    }
}
