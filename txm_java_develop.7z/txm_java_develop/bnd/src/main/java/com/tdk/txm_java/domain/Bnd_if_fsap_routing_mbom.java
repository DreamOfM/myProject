package com.tdk.txm_java.domain;

import lombok.Data;

@Data
public class Bnd_if_fsap_routing_mbom {
    private int id;
    private String rbgrpn;//GROUP NO.
    private String rbgrpc;//GROUP COUNTER
    private String rbitnr;//ITEM NO.
    private String rbopsq;//OPERATION SEQUENCE NO
    private String rbwknr;//WORK CENTER NO.
    private String rbbomn;//BOM NUMBER
    private String rbaltb;//ALTERNATIVE BOM
    private String rbcktn;//ITEM NUMBER
    private String rbbinn;//BOM ITEM NODE NUMBER
    private String rbcitm;//COMPONENT ITEM NO.
    private String rbdltf;//DELETE FLAG
    private Double rbstat;//0-SEND 1-COMPLETED
    private String login_time;
    private String login_oid;
    private String update_time;
    private String update_oid;
    private String update_program;

}
