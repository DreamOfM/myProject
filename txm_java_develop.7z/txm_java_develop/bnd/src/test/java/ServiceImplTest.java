import com.tdk.txm_java.service.IBnd_if_fcaip_declare_listService;
import com.tdk.txm_java.service.IBnd_master_invt_returnService;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.text.DecimalFormat;

/**
 * @author : Wang FengCai
 * @ProjectName<h3>txm_java</h3>
 * @ClassName<h4></h4>
 * @ToDo<p>测试类</p>
 * @date : 2020-09-04 08:49
 * @version:1.0
 **/
public class ServiceImplTest {
    @Autowired
    IBnd_master_invt_returnService iBndMasterInvtReturnService;
    @Autowired
    IBnd_if_fcaip_declare_listService iBndIfListReturnService;

    /**
     * @Author Wang FengCai
     * @Description 测试报关单自动回执功能
     * @Date 2020/9/4
     * @Time 上午 08:54
     **/
    @Test
    public void testDclReturn() throws Exception {
        //调用业务层方法
//        iBndIfListReturnService.dclReturn();

    }

    @Test
    public void testInvtReturn() {
        //调用业务层方法
        try {
            iBndMasterInvtReturnService.invtReturn();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    public void testformat() {
        DecimalFormat dfn = new DecimalFormat("0.0");
        System.out.println(dfn.format(11356.970800000));
        String invoice_no="819615835";
        System.out.println(invoice_no.substring(0,3));
    }
}
